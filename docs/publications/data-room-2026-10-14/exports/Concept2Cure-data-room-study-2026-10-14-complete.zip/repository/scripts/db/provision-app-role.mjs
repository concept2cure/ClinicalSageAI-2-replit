/**
 * provision-app-role.mjs — the runtime database role: mint it, grant it, audit it.
 *
 * ── Why this exists (the RLS unlock) ──────────────────────────────────────────
 * PostgreSQL Row-Level Security only filters rows for a role that is neither a
 * superuser nor holds BYPASSRLS, and — for the table owner — only when the table
 * carries FORCE ROW LEVEL SECURITY. The application has historically connected
 * with the same owner/admin credentials the migrations use (DATABASE_URL), which
 * is a superuser on most managed providers. Under those credentials RLS is inert
 * no matter what `app.rls_enforce` says, and the boot-time catalog posture check
 * (server/db/rlsEnforcement.ts → assertRlsCatalogPosture) fails closed in
 * production: "runtime role postgres is a PostgreSQL superuser".
 *
 * This provisions a dedicated, least-privilege LOGIN role — `app_service` by
 * default — that the runtime connects as (via APP_DATABASE_URL; see
 * server/db/getDatabaseUrl.ts). It is explicitly NOSUPERUSER / NOBYPASSRLS, so
 * the tenant_isolation_policy actually filters, and it is not the table owner,
 * so it cannot sidestep RLS even without FORCE. Migrations keep running as the
 * owner (DATABASE_URL); only the request-serving pool downgrades.
 *
 * ── The grant recipe is ONE function, called from every path ─────────────────
 * `grantRuntimeRolePrivileges` is the single definition of what the runtime
 * role may do. It is reached three ways:
 *
 *   provisionAppServiceRole   APP_SERVICE_DB_PASSWORD set → mint/align the role,
 *                             then the recipe (install-fresh 7/8, deploy-migrate 4/5).
 *   refreshRuntimeRoleGrants  a runtime role that already EXISTS and is
 *                             identifiable (see resolveRuntimeRole) → the recipe
 *                             only. No password is needed to grant.
 *   ensureRuntimeRole         the entry point the installers call: picks one of
 *                             the two above, or reports the single-role posture.
 *
 * ── Why refresh without a password (2026-09-21, IQ-DEV-001) ──────────────────
 * Until this change grants were refreshed ONLY when APP_SERVICE_DB_PASSWORD was
 * set. Every other split-role estate — an owner that migrates and a distinct
 * runtime role that the operator never asked this script to mint — got no
 * grants at all: after install-fresh + deploy-migrate as the owner, the runtime
 * role (`c2c` locally, measured 2026-09-20) lacked SELECT/INSERT on 183 public
 * tables the owner had created, section creation in Authoring answered 500, and
 * every Part 11 step behind it could not execute. The password gate was meant
 * to keep single-role deployments untouched; it also kept every unminted
 * split-role deployment broken. The gate now is "is a runtime role identifiable
 * and distinct from the owner" — a role that this connection did not create
 * can still be granted to, and must be.
 *
 * ── Never widen the audit store ──────────────────────────────────────────────
 * The recipe grants `audit` SELECT, INSERT only. `auditRuntimeRoleGrants` is
 * the check the deploy verifies with: it fails on any relation the role cannot
 * reach AND on any privilege beyond the append-only ceiling that the role holds
 * on an audit relation it does not own — a PUBLIC grant or a hand GRANT of
 * UPDATE on audit.tamper_proof_log fails the deploy; the recipe never grants
 * it and never will.
 *
 * ── …nor the append-only stores in `public` (2026-10-01, P0-8, DP-04) ────────
 * The ceiling used to stop at the `audit` schema. audit_logs, audit_events,
 * electronic_signatures and the other append-only records live in `public`,
 * where the blanket grant gave the runtime role UPDATE and DELETE, so their
 * immutability rested on a trigger alone: with the trigger out of the way (a
 * restore without triggers, replica mode, DISABLE TRIGGER) the role deleted an
 * audit row, and the audit reported that estate clean (evidence
 * docs/evidence/D6/2026-10-01-tranche-4/P0-8-grants/). The recipe now
 * withholds UPDATE, DELETE and TRUNCATE on every APPEND_ONLY_TABLES store after
 * the blanket grant (withholdAppendOnlyPrivileges), and the audit holds each
 * store to SELECT, INSERT. The one governed UPDATE, signature revocation, gets
 * exactly the columns its trigger admits. audit_logs' only deletion path stays
 * the archive door, audit_logs_archive_delete(), which runs as audit_archiver.
 * A store's `ceiling` narrows that further (2026-10-01, P0-8 follow-up): the
 * archive ledger, audit_log_archives, is SELECT only, because the door writes
 * it as audit_archiver, which holds INSERT itself.
 *
 * ── Idempotency ───────────────────────────────────────────────────────────────
 * Safe to re-run. The role is created or aligned; grants and default privileges
 * are re-applied. `GRANT ... ON ALL TABLES` only reaches tables that exist at
 * grant time, so this runs at the END of a from-scratch install and again after
 * every incremental deploy migration; ALTER DEFAULT PRIVILEGES covers tables the
 * owner creates in the future.
 *
 * MUST run on a connection with rights to GRANT (and, for minting, CREATE ROLE):
 * the owner/admin URL the installers already use.
 */

import { createHash, createHmac, pbkdf2Sync, randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';

/** A single, unqualified PostgreSQL identifier: no quoting metacharacters. */
const ROLE_NAME_RE = /^[a-z_][a-z0-9_]*$/;

/**
 * Minimum runtime password length. Short enough not to fight a generated
 * secret, long enough to reject an obviously-placeholder value.
 */
const MIN_PASSWORD_LENGTH = 12;

/**
 * The password as PostgreSQL stores it: a SCRAM-SHA-256 verifier, computed
 * HERE so the plaintext never reaches the server.
 *
 * `ALTER ROLE … PASSWORD '<plaintext>'` is DDL, and production's RDS parameter
 * group sets log_statement = 'ddl' and exports the server log to CloudWatch.
 * So every mint wrote APP_DATABASE_URL's password, in the clear, into a log
 * group anyone with logs:GetLogEvents can read (review finding SEC-1,
 * 2026-09-24). A pre-hashed verifier is stored as given, and a log line holding
 * it discloses nothing a client can log in with. This is what psql's
 * \password does, per RFC 5802 / RFC 7677:
 *
 *   SaltedPassword = PBKDF2-HMAC-SHA-256(SASLprep(password), salt, 4096)
 *   StoredKey      = SHA-256(HMAC(SaltedPassword, "Client Key"))
 *   ServerKey      = HMAC(SaltedPassword, "Server Key")
 *
 * SASLprep is the identity on printable ASCII, which is the only input
 * accepted here — so this verifier is exactly the one the server would compute,
 * and a password outside that set is refused rather than hashed differently
 * from how the server will hash it at login.
 */
export function scramSha256Verifier(password, { salt = randomBytes(16), iterations = 4096 } = {}) {
  if (!/^[\x20-\x7e]+$/.test(password)) {
    throw new Error(
      'APP_SERVICE_DB_PASSWORD must be printable ASCII. The SCRAM verifier is computed before the ' +
        'password reaches the server, and outside ASCII that computation (SASLprep) is not ' +
        'guaranteed to match the one the server performs at login.',
    );
  }
  const salted = pbkdf2Sync(password, salt, iterations, 32, 'sha256');
  const hmac = (key, msg) => createHmac('sha256', key).update(msg).digest();
  const storedKey = createHash('sha256').update(hmac(salted, 'Client Key')).digest();
  const serverKey = hmac(salted, 'Server Key');
  return `SCRAM-SHA-256$${iterations}:${salt.toString('base64')}$${storedKey.toString('base64')}:${serverKey.toString('base64')}`;
}

/**
 * Table privileges granted to the runtime role, per schema.
 *
 * The role is granted on EVERY application schema that exists (discovered at
 * grant time), because the runtime touches many more than a handful: public,
 * intelligence, core, cortex, lumen, vault, precedent, compliance, clinical_ops,
 * manufacturing, labeling, ectd, … A hardcoded allowlist silently locks the role
 * out of any schema it omits, which surfaces as a `permission denied for schema
 * X` 500 the moment a feature backed by X is hit (and a "green" install would
 * not catch it). So the default is full DML on every non-system schema, with a
 * few deliberate per-schema OVERRIDES:
 *
 *   - `audit` is APPEND-ONLY (SELECT, INSERT — no UPDATE/DELETE) to preserve the
 *     21 CFR Part 11 tamper-evidence guarantee: the runtime only ever INSERTs
 *     into audit.tamper_proof_log (server/lib/tamper-proof-audit.ts); no code
 *     path updates or deletes an audit row, so withholding those privileges
 *     costs the app nothing and denies a compromised app process the ability to
 *     rewrite the audit trail.
 *   - `extensions` is READ-ONLY (SELECT): it holds extension-installed objects
 *     (types/functions the runtime references via USAGE); the app never writes
 *     extension tables.
 *
 * This does not weaken the RLS unlock: the role is still NOSUPERUSER /
 * NOBYPASSRLS and is not the table owner, so Row-Level Security filters every
 * row it touches in every schema regardless of these DML grants.
 */
export const SCHEMA_PRIVILEGE_OVERRIDES = Object.freeze({
  audit: ['SELECT', 'INSERT'],
  extensions: ['SELECT'],
});

/** Full DML — the default for every application schema without an override. */
export const DEFAULT_TABLE_PRIVILEGES = Object.freeze(['SELECT', 'INSERT', 'UPDATE', 'DELETE']);

/**
 * The append-only audit stores: relations the runtime role may read and append
 * to and must NEVER update, delete from, truncate or own. Ownership confers
 * every privilege, so a runtime role that owns a store can rewrite it no matter
 * what was granted; the audit reports that as a failure, not an observation.
 *
 * Membership: each store's immutability trigger is one the production boot
 * requires (server/services/audit/audit-immutability-triggers.ts
 * EXPECTED_AUDIT_IMMUTABILITY_TRIGGERS), plus audit_log_archives, the archive
 * door's own ledger. server/db/__tests__/provision-app-role.test.ts pins the
 * two lists to each other, naming each trigger-guarded table that is not here
 * and why. No runtime path UPDATEs, DELETEs, TRUNCATEs, upserts or row-locks
 * any of them (census 2026-10-01); audit_logs is deleted only through
 * audit_logs_archive_delete(), which runs as audit_archiver.
 *
 * `updatableColumns` is the one governed UPDATE: a signature's revocation sets
 * superseded_by and the verification column group (signature-persistence.ts
 * persistGovernedSignatureRevocation), exactly what trg_electronic_signatures_immutable
 * admits. The runtime role gets UPDATE on those columns and on no other.
 *
 * `ceiling` is a store's own ceiling where it is narrower than SELECT, INSERT
 * (2026-10-01, P0-8 follow-up). audit_log_archives is SELECT only: the archive
 * door, audit_logs_archive_delete(), appends its ledger row as audit_archiver,
 * which holds INSERT itself, and the anchor verifier only reads it. With the
 * runtime role's INSERT, one forged ledger row could make the verifier excuse
 * a truncated head (finding DP-68; the verifier was hardened in the same fix
 * round, and this removes the forger). The recipe withholds INSERT there too,
 * and the audit reports it as excess.
 *
 * P1-24's domain-history stores (workflow_history, document_audit_logs,
 * regulatory_audit_logs, c2c_ana_actions, authoring_signatures) joined on
 * 2026-10-01 (DP-66), once migrations/20261001_domain_history_append_only.sql
 * had landed; tests/db/domain-history-append-only.dbtest.ts reads a refusal as
 * 42501 as well as the trigger's.
 */
export const APPEND_ONLY_TABLES = Object.freeze(
  [
    { schema: 'audit', name: 'tamper_proof_log' },
    { schema: 'public', name: 'audit_logs' },
    { schema: 'public', name: 'audit_log_archives', ceiling: Object.freeze(['SELECT']) },
    { schema: 'public', name: 'audit_events' },
    {
      schema: 'public',
      name: 'electronic_signatures',
      updatableColumns: Object.freeze(['superseded_by', 'is_valid', 'verification_status', 'verification_date', 'updated_at']),
    },
    { schema: 'public', name: 'ana_turn_records' },
    { schema: 'public', name: 'ana_record_blobs' },
    { schema: 'public', name: 'ana_source_read_receipts' },
    { schema: 'public', name: 'authoring_audit_trail' },
    { schema: 'public', name: 'doc_revisions' },
    { schema: 'public', name: 'concept2cure_signatures' },
    { schema: 'public', name: 'concept2cure_submission_snapshots' },
    // DP-66 (plan P1-52), 2026-10-01. Audit, history and ledger stores that had
    // no trigger and full DML for the runtime role. A census of every writer
    // found each written by INSERT only (no UPDATE, DELETE, TRUNCATE, upsert or
    // FOR UPDATE on any path); foreign-key actions run as the table's owner, so
    // a ceiling here changes none of them
    // (docs/evidence/D6/2026-10-01-tranche-4/DP-66-store-ceiling/).
    { schema: 'public', name: 'proof_audit_logs' },
    { schema: 'public', name: 'coauthor_validation_history' },
    { schema: 'public', name: 'embedding_audit_log' },
    { schema: 'public', name: 'ai_provider_audit_log' },
    // Its creator left the runtime role DELETE for erasure and retention
    // (20260813_ai_gateway_audit_log.sql); no runtime path uses it, and an
    // erasure belongs behind a door, as the turn records' is (06152498).
    { schema: 'ai', name: 'gateway_audit_log' },
    { schema: 'public', name: 'credit_ledger' },
    { schema: 'public', name: 'document_audit_trail' },
    { schema: 'public', name: 'ectd_submission_status_history' },
    { schema: 'public', name: 'specification_audit_log' },
    { schema: 'public', name: 'stab_audit' },
    { schema: 'public', name: 'ivdr_validation_parameter_history' },
    { schema: 'public', name: 'ivdr_evidence_result_history' },
    { schema: 'public', name: 'ivdr_cdx_status_history' },
    { schema: 'regulatory_harmonization', name: 'export_job_audit_log' },
    // P1-24's domain-history stores, append-only by trigger since 00f94ee9 (DP-66).
    { schema: 'public', name: 'workflow_history' },
    { schema: 'public', name: 'document_audit_logs' },
    { schema: 'public', name: 'regulatory_audit_logs' },
    { schema: 'public', name: 'c2c_ana_actions' },
    { schema: 'public', name: 'authoring_signatures' },
    // DP-84, 2026-10-05: the Module 3 signed section snapshots and provenance
    // trail, append-only by trigger (migrations/20261005c_cmc_module3_history_
    // append_only.sql); every writer INSERTs only (census in that file).
    { schema: 'public', name: 'cmc_module3_section_versions' },
    { schema: 'public', name: 'cmc_provenance_events' },
  ].map((t) => Object.freeze(t)),
);

/** The ceiling on an append-only store: read and append. A store's own `ceiling` may narrow it. */
export const APPEND_ONLY_PRIVILEGES = Object.freeze(['SELECT', 'INSERT']);

/** What the recipe withholds on every append-only store, from PUBLIC and the runtime role. */
export const WITHHELD_APPEND_ONLY_PRIVILEGES = Object.freeze(['UPDATE', 'DELETE', 'TRUNCATE']);

/** One store's ceiling: its own `ceiling`, or SELECT, INSERT. */
const storeCeiling = (store) => store.ceiling ?? APPEND_ONLY_PRIVILEGES;

/** What the recipe withholds on one store: UPDATE, DELETE, TRUNCATE, and anything of SELECT, INSERT above its ceiling. */
const withheldOn = (store) => [
  ...WITHHELD_APPEND_ONLY_PRIVILEGES,
  ...APPEND_ONLY_PRIVILEGES.filter((p) => !storeCeiling(store).includes(p)),
];

/** The table privileges the audit reads per relation. */
const PROBED_TABLE_PRIVILEGES = Object.freeze(['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'TRUNCATE']);

const qualified = (t) => `${t.schema}.${t.name}`;

/** System schemas the recipe and the audit never touch. */
const SYSTEM_SCHEMA_FILTER = `nspname NOT IN ('pg_catalog', 'information_schema') AND nspname !~ '^pg_'`;

function assertRoleName(name, origin) {
  if (!ROLE_NAME_RE.test(name)) {
    throw new Error(
      `${origin} "${name}" is not a valid PostgreSQL identifier (must match ^[a-z_][a-z0-9_]*$).`,
    );
  }
  return name;
}

/**
 * Resolve and validate the runtime role name (APP_SERVICE_DB_ROLE, default
 * `app_service`). Validated against a strict identifier grammar because it is
 * interpolated into DDL after being quoted by Postgres — the regex is a second
 * line of defense, not the only one.
 */
export function resolveAppServiceRole(env = process.env) {
  const name = (env.APP_SERVICE_DB_ROLE || 'app_service').trim();
  return assertRoleName(name, 'APP_SERVICE_DB_ROLE');
}

/**
 * The login role named in a connection string, or null when the string names
 * none. Accepts the `psql '…'` wrapper operators paste from consoles (as
 * connection.mjs does) and falls back to a plain scheme://user[:pw]@ scan for
 * URLs the WHATWG parser rejects (unencoded characters in the password).
 */
export function roleFromUrl(url) {
  if (!url) return null;
  const cleaned = String(url).replace(/^psql\s+'?/i, '').replace(/'?\s*$/, '');
  try {
    const u = new URL(cleaned);
    return u.username ? decodeURIComponent(u.username) : null;
  } catch {
    const m = /^[a-z][a-z0-9+.-]*:\/\/([^:@/?#]+)(?::[^@]*)?@/i.exec(cleaned);
    return m ? decodeURIComponent(m[1]) : null;
  }
}

/**
 * Identify the runtime (request-serving) role from the environment, or null
 * when the estate is single-role (the runtime IS the owner).
 *
 * Precedence — first identifiable wins:
 *   1. RUNTIME_DB_ROLE           explicit; what scripts/db/provision.mjs hands
 *                                its children so they never see the app URL.
 *   2. APP_SERVICE_DB_PASSWORD   the mint path; the role is APP_SERVICE_DB_ROLE.
 *   3. APP_DATABASE_URL          the role the server will connect as.
 *   4. DATABASE_URL              when DATABASE_OWNER_URL made a different role
 *                                the owner, DATABASE_URL is the runtime's.
 *
 * A candidate equal to `ownerRole` (the role this connection runs as, i.e. the
 * one that owns what it creates) is the single-role posture and yields null:
 * an owner needs no grants on its own tables.
 *
 * @param {Record<string, string|undefined>} env
 * @param {{ownerRole?: string|null}} [opts]
 * @returns {{role: string, source: string} | null}
 */
export function resolveRuntimeRole(env = process.env, { ownerRole = null } = {}) {
  let candidate = null;
  if (env.RUNTIME_DB_ROLE && env.RUNTIME_DB_ROLE.trim()) {
    candidate = { role: assertRoleName(env.RUNTIME_DB_ROLE.trim(), 'RUNTIME_DB_ROLE'), source: 'RUNTIME_DB_ROLE' };
    if (env.APP_SERVICE_DB_PASSWORD) {
      const minted = resolveAppServiceRole(env);
      if (minted !== candidate.role) {
        throw new Error(
          `RUNTIME_DB_ROLE=${candidate.role} conflicts with the role APP_SERVICE_DB_PASSWORD would mint ` +
            `(${minted}, from APP_SERVICE_DB_ROLE). The runtime would connect as one role while the other ` +
            'is granted. Set them to the same name.',
        );
      }
    }
  } else if (env.APP_SERVICE_DB_PASSWORD) {
    candidate = { role: resolveAppServiceRole(env), source: 'APP_SERVICE_DB_PASSWORD' };
  } else if (env.APP_DATABASE_URL && env.APP_DATABASE_URL.trim()) {
    const role = roleFromUrl(env.APP_DATABASE_URL);
    if (!role) throw new Error('APP_DATABASE_URL names no login role — cannot identify the runtime role.');
    candidate = { role: assertRoleName(role, 'APP_DATABASE_URL role'), source: 'APP_DATABASE_URL' };
  } else if (env.DATABASE_URL && env.DATABASE_URL.trim()) {
    const role = roleFromUrl(env.DATABASE_URL);
    if (role) candidate = { role: assertRoleName(role, 'DATABASE_URL role'), source: 'DATABASE_URL' };
  }
  if (!candidate) return null;
  if (ownerRole && candidate.role === ownerRole) return null;
  return candidate;
}

/** The immutable attribute set for the runtime role — the security contract. */
const ROLE_ATTRIBUTES = 'LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS NOREPLICATION';

/**
 * The same contract, minus the three attributes PostgreSQL lets only a
 * superuser NAME in ALTER ROLE — even to set them to NO.
 *
 * On Amazon RDS the master is LOGIN CREATEROLE CREATEDB but not a superuser,
 * and `ALTER ROLE … NOSUPERUSER` from it fails with "Only roles with the
 * SUPERUSER attribute may change the SUPERUSER attribute" (likewise BYPASSRLS
 * and REPLICATION). 080_gcc has always created the role by then, so the mint
 * step took this branch and failed on RDS every time. A non-superuser cannot
 * GRANT those attributes either, so omitting them loses nothing it could have
 * asserted — the result is then READ BACK and refused if it is not safe
 * (assertRuntimeRoleAttributes), which is the part that actually protects.
 * CREATE ROLE is unaffected: naming NOSUPERUSER there is permitted.
 */
const ROLE_ATTRIBUTES_NON_SUPERUSER = 'LOGIN NOCREATEDB NOCREATEROLE';

/**
 * Read the role back and fail closed unless it is exactly what the runtime is
 * allowed to be. Checked after every mint, because the attributes the mint
 * could not name (as a non-superuser) are ones a pre-existing role may carry.
 */
async function assertRuntimeRoleAttributes(db, role) {
  const { rows } = await db.query(
    `SELECT rolcanlogin, rolsuper, rolbypassrls, rolreplication, rolcreatedb, rolcreaterole
       FROM pg_roles WHERE rolname = $1`,
    [role],
  );
  const a = rows[0];
  if (!a) throw new Error(`runtime role ${role} does not exist after minting it.`);
  const wrong = [
    !a.rolcanlogin && 'cannot LOGIN',
    a.rolsuper && 'is SUPERUSER',
    a.rolbypassrls && 'is BYPASSRLS',
    a.rolreplication && 'has REPLICATION',
    a.rolcreatedb && 'has CREATEDB',
    a.rolcreaterole && 'has CREATEROLE',
  ].filter(Boolean);
  if (wrong.length) {
    throw new Error(
      `runtime role ${role} ${wrong.join(', ')} — it must be LOGIN NOSUPERUSER NOBYPASSRLS ` +
        'NOREPLICATION NOCREATEDB NOCREATEROLE, and the connecting role cannot make it so ' +
        '(only a superuser can clear SUPERUSER, BYPASSRLS or REPLICATION). A BYPASSRLS or ' +
        'superuser runtime role reads every tenant\'s rows; refusing rather than minting it.',
    );
  }
}

/**
 * The SECURITY DEFINER functions the runtime role may execute, by signature
 * (`schema.name(identity arguments)`), from ./security-definer-allowlist.json.
 *
 * A definer function runs as its owner, past every tenant policy, so each one
 * the runtime role can execute is a way around RLS. Only a reviewed one — its
 * entry says why it cannot cross a tenant, or what its caller must guarantee —
 * stays executable. Kept beside this script because the production image
 * ships scripts/db (D3, docs/evidence/D3/2026-09-30-definer-revoke/).
 */
export function loadDefinerAllowlist() {
  const doc = JSON.parse(readFileSync(new URL('./security-definer-allowlist.json', import.meta.url), 'utf8'));
  return new Set(
    Object.entries(doc.functions)
      .filter(([, v]) => v.status === 'reviewed' || v.status === 'reviewed-risk')
      .map(([sig]) => sig),
  );
}

/**
 * REVOKE EXECUTE, from PUBLIC and the runtime role, on every SECURITY DEFINER
 * function not on the reviewed allowlist. The last step of the grant recipe,
 * which runs after the migration set on every deploy: the recipe itself
 * GRANTs EXECUTE on every function in every schema, and a function is
 * PUBLIC-executable when created, so a revoke anywhere earlier would not hold.
 * An unreviewed definer function therefore fails closed ("permission denied
 * for function") for the runtime role rather than reading past RLS for it.
 * Functions the owner calls — policy helpers, trigger functions, other definer
 * functions — are unaffected: those run with their owner's privileges.
 *
 * Runs inside the caller's transaction. `roleIdent` must come from quote_ident.
 *
 * @returns {Promise<string[]>} the signatures revoked.
 */
export async function revokeUnreviewedDefinerExecute(
  db,
  roleIdent,
  { allowlist = loadDefinerAllowlist(), log = () => {} } = {},
) {
  const { rows } = await db.query(
    `SELECT p.oid::regprocedure::text AS ref,
            n.nspname || '.' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')' AS sig
       FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE p.prosecdef AND p.prokind = 'f' AND ${SYSTEM_SCHEMA_FILTER}
      ORDER BY 2`,
  );
  const revoked = [];
  for (const { ref, sig } of rows) {
    if (allowlist.has(sig)) continue;
    await db.query(`REVOKE EXECUTE ON FUNCTION ${ref} FROM PUBLIC, ${roleIdent}`);
    revoked.push(sig);
  }
  log(`  ✓ EXECUTE revoked on ${revoked.length} unreviewed SECURITY DEFINER function(s)`);
  return revoked;
}

/**
 * REVOKE UPDATE, DELETE and TRUNCATE on every append-only store present, and
 * INSERT where the store's `ceiling` is SELECT, from PUBLIC and the runtime
 * role, then GRANT back UPDATE on a store's `updatableColumns` (the revocation
 * carve-out) where it has them. Runs after
 * the blanket per-schema grants — `GRANT … ON ALL TABLES IN SCHEMA public` and
 * the default privileges hand every new table full DML — so each run of the
 * recipe, and so each deploy, withholds them again. A store this edition does
 * not have is skipped; a carve-out column it does not have is not named.
 *
 * The owner's own privileges are untouched (REVOKE … FROM PUBLIC never reaches
 * the owner). Runs inside the caller's transaction. `roleIdent` must come from
 * quote_ident.
 *
 * @returns {Promise<string[]>} the stores withheld on, as `schema.name`.
 */
export async function withholdAppendOnlyPrivileges(
  db,
  roleIdent,
  { stores = APPEND_ONLY_TABLES, log = () => {} } = {},
) {
  const { rows } = await db.query(
    `SELECT t.schema, t.name, c.oid::regclass::text AS ref,
            ARRAY(SELECT quote_ident(a.attname)::text FROM pg_attribute a
                   WHERE a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
                     AND a.attname = ANY (string_to_array(t.cols, ','))
                   ORDER BY a.attnum) AS cols
       FROM unnest($1::text[], $2::text[], $3::text[]) WITH ORDINALITY AS t(schema, name, cols, ord)
       JOIN pg_namespace n ON n.nspname = t.schema
       JOIN pg_class c ON c.relnamespace = n.oid AND c.relname = t.name AND c.relkind IN ('r', 'p')
      ORDER BY t.ord`,
    [stores.map((s) => s.schema), stores.map((s) => s.name), stores.map((s) => (s.updatableColumns ?? []).join(','))],
  );
  const byName = new Map(stores.map((st) => [qualified(st), st]));
  const withheld = [];
  for (const { schema, name, ref, cols } of rows) {
    const store = byName.get(`${schema}.${name}`) ?? { schema, name };
    await db.query(`REVOKE ${withheldOn(store).join(', ')} ON TABLE ${ref} FROM PUBLIC, ${roleIdent}`);
    if (cols.length) await db.query(`GRANT UPDATE (${cols.join(', ')}) ON TABLE ${ref} TO ${roleIdent}`);
    withheld.push(`${schema}.${name}`);
  }
  log(
    `  ✓ ${WITHHELD_APPEND_ONLY_PRIVILEGES.join(', ')} withheld on ${withheld.length}/${stores.length} append-only ` +
      `store(s) present${withheld.length ? `: ${withheld.join(', ')}` : ''}; INSERT too where a store's ceiling is SELECT`,
  );
  return withheld;
}

/**
 * THE grant recipe. Grants the runtime role, on every application schema
 * present: USAGE; the per-schema table privileges; USAGE, SELECT on sequences;
 * EXECUTE on functions; and the same as DEFAULT PRIVILEGES for objects the
 * connecting role (the owner) creates later. Grants only, with two exceptions
 * at the end: UPDATE, DELETE and TRUNCATE are withheld on every append-only
 * store (withholdAppendOnlyPrivileges), and EXECUTE on an unreviewed SECURITY
 * DEFINER function is revoked (revokeUnreviewedDefinerExecute). The owner's own
 * privileges on relations it happens to own are untouched.
 *
 * Runs inside the caller's transaction. `roleIdent` must come from quote_ident.
 *
 * @returns {Promise<string[]>} the schemas granted, as `schema(PRIVS)`.
 */
async function grantRuntimeRolePrivileges(db, roleIdent, { log = () => {} } = {}) {
  const dbIdent = (await db.query('SELECT quote_ident(current_database()) AS db_ident')).rows[0].db_ident;
  await db.query(`GRANT CONNECT ON DATABASE ${dbIdent} TO ${roleIdent}`);

  // Discover every application schema present and grant on ALL of them, so no
  // schema the runtime uses can be silently left ungranted. System schemas
  // (pg_catalog, pg_toast, pg_temp_*, information_schema) are excluded.
  const schemaRows = (
    await db.query(`SELECT nspname FROM pg_namespace WHERE ${SYSTEM_SCHEMA_FILTER} ORDER BY nspname`)
  ).rows;

  const grantedSchemas = [];
  for (const { nspname: schema } of schemaRows) {
    const privs = SCHEMA_PRIVILEGE_OVERRIDES[schema] || DEFAULT_TABLE_PRIVILEGES;

    const schemaIdentRes = await db.query('SELECT quote_ident($1) AS s', [schema]);
    const schemaIdent = schemaIdentRes.rows[0].s;
    const privList = privs.join(', ');

    await db.query(`GRANT USAGE ON SCHEMA ${schemaIdent} TO ${roleIdent}`);
    await db.query(`GRANT ${privList} ON ALL TABLES IN SCHEMA ${schemaIdent} TO ${roleIdent}`);
    await db.query(`GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA ${schemaIdent} TO ${roleIdent}`);
    // Functions too, not just tables: functions default to PUBLIC EXECUTE, so
    // this looked redundant — until 069_gcc_multitenant_rls_expansion.sql
    // REVOKEd PUBLIC on core.can_access_program/can_write_program and granted
    // them back to nobody. Every RLS policy that calls those helpers then
    // fails for the runtime role with "permission denied for function", which
    // means every INSERT/UPDATE on the policied tables fails. The runtime
    // role must be able to execute application functions; the functions
    // themselves enforce their own logic.
    await db.query(`GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA ${schemaIdent} TO ${roleIdent}`);
    // Forward coverage: tables/sequences the OWNER (the role running this)
    // creates later inherit the same grants, so a new migration never locks
    // the runtime out of a table it needs.
    await db.query(
      `ALTER DEFAULT PRIVILEGES IN SCHEMA ${schemaIdent} GRANT ${privList} ON TABLES TO ${roleIdent}`,
    );
    await db.query(
      `ALTER DEFAULT PRIVILEGES IN SCHEMA ${schemaIdent} GRANT USAGE, SELECT ON SEQUENCES TO ${roleIdent}`,
    );
    await db.query(
      `ALTER DEFAULT PRIVILEGES IN SCHEMA ${schemaIdent} GRANT EXECUTE ON FUNCTIONS TO ${roleIdent}`,
    );
    grantedSchemas.push(`${schema}(${privList})`);
  }

  // After the blanket grants, so nothing above re-grants them: an append-only
  // store is read and appended to, never rewritten (withholdAppendOnlyPrivileges).
  await withholdAppendOnlyPrivileges(db, roleIdent, { log });
  // Last, so nothing above re-grants it: an unreviewed definer function is not
  // the runtime role's to execute (see revokeUnreviewedDefinerExecute).
  await revokeUnreviewedDefinerExecute(db, roleIdent, { log });

  log(`  ✓ grants applied on: ${grantedSchemas.join('; ') || '(no known schemas present)'}`);
  log(`  ✓ default privileges set — future owner-created tables auto-grant to ${roleIdent}`);
  return grantedSchemas;
}

/**
 * Create-or-align the non-superuser runtime role and (re)apply its grants.
 * No-op (returns { skipped: true }) unless APP_SERVICE_DB_PASSWORD is set — the
 * mint path needs a password; an estate whose runtime role already exists uses
 * refreshRuntimeRoleGrants (or ensureRuntimeRole, which chooses).
 *
 * @param {{query: Function}} db  A pg Pool or Client on an owner/admin connection.
 * @param {{env?: object, log?: (msg: string) => void}} [opts]
 * @returns {Promise<{skipped: boolean, role: string, schemas?: string[]}>}
 */
export async function provisionAppServiceRole(db, { env = process.env, log = () => {} } = {}) {
  const role = resolveAppServiceRole(env);
  const password = env.APP_SERVICE_DB_PASSWORD;

  if (!password) {
    log(
      `  • APP_SERVICE_DB_PASSWORD not set — not minting ${role}. ` +
        'Set it to mint or rotate the role; an existing runtime role is granted without it ' +
        '(ensureRuntimeRole).',
    );
    return { skipped: true, role };
  }
  if (String(password).length < MIN_PASSWORD_LENGTH) {
    throw new Error(
      `APP_SERVICE_DB_PASSWORD must be at least ${MIN_PASSWORD_LENGTH} characters.`,
    );
  }

  // Never string-concat a password (or identifier) into DDL: let Postgres quote
  // both. quote_ident yields a safely-quoted identifier; quote_literal yields a
  // safely-quoted string literal including its surrounding quotes. What is
  // quoted is the SCRAM verifier, never the plaintext (scramSha256Verifier).
  const quoted = await db.query(
    'SELECT quote_ident($1) AS role_ident, quote_literal($2::text) AS pwd_lit, quote_ident(current_database()) AS db_ident',
    [role, scramSha256Verifier(String(password))],
  );
  const roleIdent = quoted.rows[0].role_ident;
  const pwdLit = quoted.rows[0].pwd_lit;

  await db.query('BEGIN');
  try {
    const exists =
      (await db.query('SELECT 1 FROM pg_roles WHERE rolname = $1', [role])).rowCount > 0;
    if (exists) {
      // ALTER, not DROP+CREATE: the role owns grants and may hold live
      // connections; rotating the password and re-asserting attributes in place
      // is both idempotent and non-disruptive.
      const connectingIsSuperuser = (
        await db.query('SELECT rolsuper FROM pg_roles WHERE rolname = current_user')
      ).rows[0]?.rolsuper === true;
      const attrs = connectingIsSuperuser ? ROLE_ATTRIBUTES : ROLE_ATTRIBUTES_NON_SUPERUSER;
      await db.query(`ALTER ROLE ${roleIdent} WITH ${attrs} PASSWORD ${pwdLit}`);
      await assertRuntimeRoleAttributes(db, role);
      log(`  ✓ role ${role} aligned (LOGIN · NOSUPERUSER · NOBYPASSRLS · password set)`);
    } else {
      await db.query(`CREATE ROLE ${roleIdent} WITH ${ROLE_ATTRIBUTES} PASSWORD ${pwdLit}`);
      await assertRuntimeRoleAttributes(db, role);
      log(`  ✓ role ${role} created (LOGIN · NOSUPERUSER · NOBYPASSRLS)`);
    }

    const schemas = await grantRuntimeRolePrivileges(db, roleIdent, { log });

    await db.query('COMMIT');
    return { skipped: false, role, schemas };
  } catch (err) {
    await db.query('ROLLBACK').catch(() => {});
    throw err;
  }
}

/**
 * Re-apply the grant recipe to a runtime role that already exists. This is the
 * path for every estate whose runtime role this script did not mint: the role
 * is identified (resolveRuntimeRole), it must exist — a role that does not is
 * a fail-closed error, because the request-serving pool could not connect as
 * it either — and the recipe runs as-is. No password, no ALTER ROLE.
 *
 * @param {{query: Function}} db  owner/admin connection
 * @param {{role: string, log?: (msg: string) => void}} opts
 * @returns {Promise<{skipped: false, role: string, schemas: string[], attrs: object}>}
 */
export async function refreshRuntimeRoleGrants(db, { role, log = () => {} }) {
  assertRoleName(role, 'runtime role');
  const attrsRes = await db.query(
    'SELECT rolname, rolsuper, rolbypassrls, rolcanlogin FROM pg_roles WHERE rolname = $1',
    [role],
  );
  if (attrsRes.rowCount === 0) {
    throw new Error(
      `runtime role ${role} does not exist on this server — nothing to grant to, and the ` +
        'request-serving pool would fail to connect as it. Mint it by setting ' +
        'APP_SERVICE_DB_PASSWORD (scripts/db/provision-app-role.mjs), or correct ' +
        'RUNTIME_DB_ROLE / APP_DATABASE_URL / DATABASE_URL.',
    );
  }
  const attrs = attrsRes.rows[0];
  if (attrs.rolsuper || attrs.rolbypassrls) {
    log(
      `  ⚠ runtime role ${role} is ${attrs.rolsuper ? 'a superuser' : 'BYPASSRLS'} — grants are moot ` +
        'and every tenant_isolation_policy is inert on it; the readiness contract refuses it.',
    );
  }
  const roleIdent = (await db.query('SELECT quote_ident($1) AS role_ident', [role])).rows[0].role_ident;

  await db.query('BEGIN');
  try {
    log(`  • refreshing grants for existing runtime role ${role} (not minted here; no password needed)`);
    const schemas = await grantRuntimeRolePrivileges(db, roleIdent, { log });
    await db.query('COMMIT');
    return { skipped: false, role, schemas, attrs };
  } catch (err) {
    await db.query('ROLLBACK').catch(() => {});
    throw err;
  }
}

/**
 * The installers' entry point. Decides, on this owner connection, which path
 * the runtime role takes:
 *
 *   APP_SERVICE_DB_PASSWORD set        → provisionAppServiceRole  (mode 'minted')
 *   a distinct runtime role identified → refreshRuntimeRoleGrants (mode 'refreshed')
 *   neither                            → nothing                  (mode 'single-role')
 *
 * @param {{query: Function}} db  owner/admin connection
 * @param {{env?: object, log?: (msg: string) => void}} [opts]
 * @returns {Promise<{skipped: boolean, mode: 'minted'|'refreshed'|'single-role', role: string|null, owner: string, source?: string, schemas?: string[]}>}
 */
export async function ensureRuntimeRole(db, { env = process.env, log = () => {} } = {}) {
  const owner = (await db.query('SELECT current_user AS role')).rows[0].role;
  const identified = resolveRuntimeRole(env, { ownerRole: owner });

  if (env.APP_SERVICE_DB_PASSWORD) {
    const minted = await provisionAppServiceRole(db, { env, log });
    return { ...minted, mode: 'minted', owner, source: 'APP_SERVICE_DB_PASSWORD' };
  }
  if (!identified) {
    log(
      `  • single-role posture: no runtime role distinct from the owner (${owner}) is identifiable ` +
        '(RUNTIME_DB_ROLE / APP_SERVICE_DB_PASSWORD / APP_DATABASE_URL / DATABASE_URL). Nothing to grant.',
    );
    return { skipped: true, mode: 'single-role', role: null, owner };
  }
  log(`  • runtime role ${identified.role} identified from ${identified.source} (owner is ${owner})`);
  const refreshed = await refreshRuntimeRoleGrants(db, { role: identified.role, log });
  return { ...refreshed, mode: 'refreshed', owner, source: identified.source };
}

/**
 * Per relation, which columns of the append-only stores `role` may UPDATE
 * (column-level privilege), as `Map<"schema.name", {col, can_update}[]>`.
 * attnum form: never throws on a column, and needs no quoting.
 */
async function readAppendOnlyColumnUpdates(db, role) {
  const { rows } = await db.query(
    `SELECT n.nspname || '.' || c.relname AS relation, a.attname::text AS col,
            has_column_privilege($1, c.oid, a.attnum, 'UPDATE') AS can_update
       FROM pg_class c
       JOIN pg_namespace n ON n.oid = c.relnamespace
       JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
      WHERE n.nspname || '.' || c.relname = ANY ($2::text[])
      ORDER BY 1, a.attnum`,
    [role, APPEND_ONLY_TABLES.map(qualified)],
  );
  const byRelation = new Map();
  for (const r of rows) {
    if (!byRelation.has(r.relation)) byRelation.set(r.relation, []);
    byRelation.get(r.relation).push({ col: r.col, can_update: Boolean(r.can_update) });
  }
  return byRelation;
}

/**
 * An append-only store's column-level findings for a role that does not own
 * it: carve-out columns it cannot UPDATE (`missing`, the revocation would
 * fail), and any other column it can (`beyond`). Table-level UPDATE is already
 * reported as `UPDATE`, so columns are not listed again under it.
 */
function appendOnlyColumnFindings(store, columns, tableLevelUpdate) {
  const allowed = new Set(store.updatableColumns ?? []);
  const lacking = columns.filter((c) => allowed.has(c.col) && !c.can_update).map((c) => c.col);
  const extra = tableLevelUpdate ? [] : columns.filter((c) => c.can_update && !allowed.has(c.col)).map((c) => c.col);
  return {
    missing: lacking.length ? [`UPDATE(${lacking.join(', ')})`] : [],
    beyond: extra.length ? [`UPDATE(${extra.join(', ')})`] : [],
  };
}

/**
 * One relation against the recipe: what the role lacks (`missing`), and — on a
 * relation under a ceiling (an override schema, or an append-only store
 * wherever it lives) that the role does not own — what it holds beyond it.
 */
function auditRelation(r, store, columns) {
  const ceiling = store ? storeCeiling(store) : SCHEMA_PRIVILEGE_OVERRIDES[r.schema];
  const required = ceiling || DEFAULT_TABLE_PRIVILEGES;
  const held = PROBED_TABLE_PRIVILEGES.filter((p) => r[`can_${p.toLowerCase()}`]);
  const missing = [...(r.schema_usage ? [] : ['USAGE']), ...required.filter((p) => !held.includes(p))];
  const beyond = ceiling && !r.owned ? held.filter((p) => !ceiling.includes(p)) : [];
  if (store && !r.owned) {
    const cols = appendOnlyColumnFindings(store, columns ?? [], held.includes('UPDATE'));
    missing.push(...cols.missing);
    beyond.push(...cols.beyond);
  }
  return { ceiling, missing, beyond };
}

/**
 * Audit what `role` can actually do against the recipe, relation by relation.
 *
 * For every table, partitioned table, view, materialized view and foreign
 * table in every application schema:
 *   - `denied`  — the role lacks USAGE on the schema or a privilege the recipe
 *                 requires there (full DML, the schema's override, or — on an
 *                 append-only store — its ceiling, SELECT, INSERT unless the
 *                 store's `ceiling` says SELECT, and UPDATE on its carve-out
 *                 columns, as `UPDATE(col, …)`);
 *   - `excess`  — on a relation under a ceiling that the role does NOT own, it
 *                 holds a privilege beyond it: UPDATE/DELETE/TRUNCATE on an
 *                 audit-schema table or on an APPEND_ONLY_TABLES store wherever
 *                 it lives (audit_logs is in `public`), INSERT on a store whose
 *                 ceiling is SELECT (the archive ledger), or UPDATE on a store
 *                 column outside its carve-out (`UPDATE(col)`). The recipe
 *                 withholds those; a PUBLIC grant or a hand GRANT gave them.
 *   - `ownedAppendOnly` — the role owns an APPEND_ONLY_TABLES relation, which
 *                 confers every privilege regardless of grants.
 * Relations in an override schema that the role owns (a single-role history:
 * `c2c` owns most of `audit` locally) are counted in `ownedInOverrideSchemas`
 * and not reported as excess — ownership is not a grant this recipe made or
 * can take away.
 *
 * Runs on any connection: pg_class and the privilege functions are readable by
 * every role, so the app connection can audit itself and the owner can audit
 * the app role.
 *
 * @param {{query: Function}} db
 * @param {string} role
 */
export async function auditRuntimeRoleGrants(db, role) {
  assertRoleName(role, 'runtime role');
  const attrsRes = await db.query(
    'SELECT rolname, rolsuper, rolbypassrls, rolcanlogin FROM pg_roles WHERE rolname = $1',
    [role],
  );
  const empty = { role, exists: false, attrs: null, relations: 0, denied: [], excess: [], ownedAppendOnly: [], ownedInOverrideSchemas: 0, schemasWithoutUsage: [] };
  if (attrsRes.rowCount === 0) return empty;

  // OID forms of the privilege functions: they never throw on a schema the
  // role lacks USAGE on (the text form can), and need no quoting.
  const rows = (
    await db.query(
      `SELECT n.nspname AS schema, c.relname AS name, c.relkind,
              pg_get_userbyid(c.relowner) = $1 AS owned,
              has_schema_privilege($1, n.oid, 'USAGE') AS schema_usage,
              has_table_privilege($1, c.oid, 'SELECT') AS can_select,
              has_table_privilege($1, c.oid, 'INSERT') AS can_insert,
              has_table_privilege($1, c.oid, 'UPDATE') AS can_update,
              has_table_privilege($1, c.oid, 'DELETE') AS can_delete,
              has_table_privilege($1, c.oid, 'TRUNCATE') AS can_truncate
         FROM pg_class c
         JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind IN ('r', 'p', 'v', 'm', 'f')
          AND n.nspname NOT IN ('pg_catalog', 'information_schema') AND n.nspname !~ '^pg_'
        ORDER BY 1, 2`,
      [role],
    )
  ).rows;
  const columns = await readAppendOnlyColumnUpdates(db, role);

  const denied = [];
  const excess = [];
  const ownedAppendOnly = [];
  const schemasWithoutUsage = new Set();
  let ownedInOverrideSchemas = 0;
  const stores = new Map(APPEND_ONLY_TABLES.map((t) => [qualified(t), t]));

  for (const r of rows) {
    const relation = `${r.schema}.${r.name}`;
    const store = stores.get(relation);
    const { ceiling, missing, beyond } = auditRelation(r, store, columns.get(relation));
    if (!r.schema_usage) schemasWithoutUsage.add(r.schema);
    if (missing.length) denied.push({ relation, missing });
    if (!ceiling) continue;
    if (!r.owned) {
      if (beyond.length) excess.push({ relation, held: beyond });
    } else if (store) {
      ownedAppendOnly.push(relation);
    } else {
      ownedInOverrideSchemas += 1;
    }
  }

  return {
    role,
    exists: true,
    attrs: attrsRes.rows[0],
    relations: rows.length,
    denied,
    excess,
    ownedAppendOnly,
    ownedInOverrideSchemas,
    schemasWithoutUsage: [...schemasWithoutUsage],
  };
}
