/**
 * The out-of-band migration set — the ordered list of .sql files that no other
 * durable path applies, plus the loop that applies them.
 *
 * WHY THIS MODULE EXISTS. Two entrypoints need the exact same set:
 *   • scripts/db/apply-c2c-migrations.mjs — the manual/preview applier.
 *   • scripts/db/deploy-migrate.mjs       — the production deploy-time applier
 *                                           run as a one-off ECS task before
 *                                           the API/worker services roll.
 * Holding the list in one place is what stops the deploy path and the manual
 * path from silently diverging — which is the failure mode that produced the
 * gap these files close in the first place (merged ≠ applied).
 *
 * These files live in the root `migrations/` tree (the established convention
 * for phase migrations) or in `db/migrations/` without the `_gcc_` infix, so
 * NOTHING else applies them: drizzle's runtime migrate() replays only the
 * journaled baseline, the CI psql loop matches only `db/migrations/*_gcc_*.sql`,
 * and install-fresh's overlay covers only the root tree. Every file here is
 * CREATE/ALTER ... IF NOT EXISTS, so the set is safe to apply repeatedly.
 */

import fs from 'node:fs';
import path from 'node:path';
import { ensureJournal, recordApplied } from './migration-journal.mjs';

// Dependency-safe order: governance ALTERs ana_capability_registry (pre-existing),
// PV + commitments create their own tables, council provisioning seeds the four
// drafting-council agents into the lumen schema.
//
// Entries are repo-relative so a root-lineage file can declare a prerequisite that
// lives in the canonical db/migrations lineage. 044b is that prerequisite: it owns
// the ONLY definition of lumen.data_atoms, and the council file that follows it
// reads from that table. Applying it here means this out-of-band path provisions
// the same shape the manifest lineage does, instead of racing it under
// CREATE TABLE IF NOT EXISTS. See ledger C-12.
// ── Data-room / evidence lineage (added 2026-07-26) ────────────────────────
// ORDER MATTERS. The spine creates cre_evidence_sources; the program-scope
// migration ALTERs it. The spine entry is repo-relative into db/migrations for
// the same reason 044b is: a root-lineage file declares a prerequisite that
// lives in the canonical lineage.
//
// Why the spine is listed here at all: it has been merged since 20260724 and IS
// present in db/migrations/migrations_manifest.json, but NOTHING consumes that
// manifest — it is ordering metadata, and readiness-audit.mjs only reports. The
// other applier, preview_db_test, applies only migrations a PR *adds*, to an
// ephemeral Neon branch deleted when the PR closes. So the spine was applied
// once to a throwaway branch and never to a real database, and every cre_*
// write (CSR adapter, CRL ingestion, chat-upload source identity) has been
// hitting a table that does not exist. This list is the only durable path, so
// it is where the gap gets closed.
//
// The wider problem stands: merged and applied have diverged silently across
// 358 migrations because the manifest is not authoritative for anything. Making
// something consume it is a separate change to how schema ships.
/**
 * The two tenant-isolation steps, named once.
 *
 * Both are POSITIONAL invariants, not just membership ones: the integer sweep
 * must be the LAST entry so it sees every table the set creates (ledger C-33),
 * and the uuid non-public step must sit immediately before it so the pair is
 * the final two. A file appended after either one is never swept, which is a
 * tenant-keyed table shipping with no policy — silent, and only visible once
 * somebody reads across tenants.
 *
 * They are exported because four separate places used to hardcode these
 * strings — three contract tests and the list itself — so the invariant had
 * four copies and no single definition. scripts/ci/check-migration-set-order.mjs
 * and the contract tests now import them from here, next to the list they
 * constrain.
 */
export const TENANT_ISOLATION_SWEEP = 'db/migrations/20260801_tenant_isolation_sweep.sql';
export const UUID_TENANT_ISOLATION_NONPUBLIC =
  'db/migrations/20260801_uuid_tenant_isolation_nonpublic.sql';
export const C48_STAGE1_IDENTITY_ORG_BRIDGE =
  'db/migrations/20260919_c48_stage1_identity_org_bridge.sql';

/**
 * Parent-scoped RLS for child tables. Runs in the isolation tail, after the uuid
 * step and before the integer sweep (2026-09-29, D3): its chained list
 * delegates to parent policies the uuid step creates, and every table the set
 * creates must exist before it runs. It creates no table, so the sweep stays
 * last. Evidence docs/evidence/D3/2026-09-29-child-scope-first-deploy/.
 */
export const CHILD_TABLE_PARENT_SCOPE = 'db/migrations/20260813_child_table_parent_scoped_rls.sql';

export const C2C_MIGRATION_FILES = [
  // ── Golden-journey prerequisites ────────────────────────────────────────────
  // Seven migrations that tests/golden-journeys provision and depend on, and
  // that no durable applier ran — the exact drift ci:journey-migration-
  // reachability exists to catch. They lead the set because later entries
  // depend on what they create: the c2c_documents family (phase9) is ALTERed by
  // 20260728_c2c_document_sections_timestamps and _c2c_section_version_author_kind
  // and read by the 20260804+ rule-pack outlines; regulatory_programs
  // (program_workbench) is scoped by 20260726_cre_source_program_scope and
  // anchored by 20260814_projects_regulatory_program_anchor.
  //
  // Order within the block is dependency order, which here matches date order:
  // phase9_backfill reads regulatory_programs and writes the c2c_documents
  // family, so it follows both; audit_hmac_seal seals the chain columns
  // mutation_primitives adds to audit_logs, so it follows that.
  //
  // Prerequisites all come from drizzle-kit push, which runs before this set:
  // cerv2_510k_sections, cer_reports, pma_submissions and audit_logs are all
  // declared in shared/schema.ts. Every ALTER here is ADD COLUMN IF NOT EXISTS
  // or guarded on information_schema, and the backfill guards each source table
  // the same way, so the block is safe on a database that already has them and
  // on one that does not.
  'migrations/20260506_kit_section_draft_provenance.sql',
  'migrations/20260524_program_workbench_schema.sql',
  'migrations/20260527_mutation_primitives.sql',
  'migrations/20260528_phase9_document_schema.sql',
  'migrations/20260529_phase9_backfill.sql',
  'migrations/20260604_shadow_review.sql',
  'migrations/20260609_audit_hmac_seal.sql',
  // audit_logs chain order key (WA 2026-09-21, VSR-001 F-1 / row D5): adds
  // chain_seq + the BEFORE INSERT trigger that assigns it for writers that
  // announce a chain position, so the sha256 chain has an order key of its own
  // and is one chain per tenant. Depends on sha256_chain/occurred_at from
  // mutation_primitives, so it follows the seal file; additive and idempotent.
  'migrations/20260921_audit_logs_chain_seq.sql',
  // ── End golden-journey prerequisites ────────────────────────────────────────

  // ── The canonical submission core ───────────────────────────────────────────
  // Creates submissions / submission_regions / ectd_sequences / submission_leaves
  // — the region-agnostic core `server/routes/submissions.ts` serves and
  // `submission-service.ts` reads through Drizzle.
  //
  // It reached NO durable applier. Nothing in this repository referenced the
  // file except an audit document: it is not in this list, carries no `_gcc_`
  // infix, and `shared/schema/submissions.ts` is re-exported from
  // shared/schema.ts but these tables are not in the drizzle journal either, so
  // only install-fresh's root-tree overlay created them — fresh databases only.
  // Any database provisioned before 2026-06-04 and kept current with
  // deploy-migrate has never had them.
  //
  // That is the MDX UAT's item A2: GET /api/submissions returned 500 while
  // GET /api/510k/estar/submissions returned 200. Not two services disagreeing
  // — two STORES, one of which was never created, so `listSubmissions`' first
  // statement raised 42P01. The device eSTAR path has its own tables (see
  // 20260730_estar_submission.sql below, which IS in this list) and was
  // unaffected.
  //
  // Placed after the audit/program block and before everything else that runs:
  // its only prerequisites are organizations and users (drizzle-push base
  // tables), and later entries reference submissions rather than the reverse.
  // The file is CREATE TABLE IF NOT EXISTS throughout, so it is a no-op on the
  // fresh installs that already have it.
  'migrations/20260604_submission_core_canonical.sql',

  'migrations/20260603_ai_capability_governance.sql',
  'migrations/20260603_pv_operational.sql',
  'migrations/20260603_commitments.sql',
  'db/migrations/044b_gcc_lumen_schema_prerequisite.sql',
  'migrations/20260724_lumen_council_provisioning.sql',
  'migrations/20260724_ana_deep_investigations.sql',
  // Clinical-Regulatory Evidence spine — creates cre_evidence_sources and the
  // rest of the cre_* graph. Fully idempotent: 6 CREATE TABLE IF NOT EXISTS,
  // 22 CREATE INDEX IF NOT EXISTS, no data statements, no unguarded DDL.
  'db/migrations/20260724_clinical_regulatory_evidence_spine.sql',
  // file_uploads tenancy contract — codifies the columns the upload route
  // writes, adds organization_id idempotently, backfills it from the
  // uploads/org-{id}/ storage-path prefix.
  'migrations/20260726_file_uploads_tenancy.sql',
  // Program scope for canonical sources. MUST follow the spine: it ALTERs
  // cre_evidence_sources. Self-guarding on to_regclass, so it no-ops with a
  // NOTICE if the spine is somehow absent rather than failing the run.
  'migrations/20260726_cre_source_program_scope.sql',
  // ── Authoring program scope (added 2026-07-27, from #1131) ────────────────
  // Program scope for authoring documents: a guarded ALTER that adds
  // client_program_id to authoring_documents. It self-guards on to_regclass.
  // Callers provision the authoring subsystem (below) BEFORE this loop runs, so
  // on a fresh DB the table is now present and this ALTER applies for real
  // rather than no-opping.
  'migrations/20260727_authoring_document_program_scope.sql',
  // Source-usage index + column semantics on authoring_citations. Also guarded
  // on to_regclass; likewise lands for real now that the subsystem is
  // provisioned ahead of this loop.
  'migrations/20260726_authoring_citation_source_usage.sql',
  // Industry-context tailoring: organization_industry_profiles +
  // project_industry_profiles. Fully idempotent (CREATE TABLE/INDEX IF NOT
  // EXISTS, no data statements).
  'db/migrations/20260727_industry_context_profiles.sql',
  // MDx task metadata: additive nullable columns on unified_tasks
  // (lifecycle_phase, market, filing_type, study_id, deliverable_id,
  // client_visibility) + lifecycle_phase index. Fully idempotent
  // (ADD COLUMN IF NOT EXISTS / CREATE INDEX IF NOT EXISTS, no data statements).
  'db/migrations/20260727_unified_tasks_mdx_metadata.sql',
  // ── Risk-Based Monitoring lineage (added 2026-07-27) ──────────────────────
  // These five migration files exist in migrations/ and create the ENTIRE rbm_*
  // schema, but none was on any durable apply path: not here, not in the Drizzle
  // journaled baseline (shared/schema.ts defines no rbm_* table), not in
  // migrations/meta. Yet the RBM/RBQM module writes to these tables on every
  // action — rbm-actuator, metric-ingestion, site-risk-engine, the mdx-rbm* routes
  // and the AnA tools all issue INSERT/UPDATE/SELECT against rbm_*. So the whole
  // module has only ever addressed tables that existed on the ephemeral Neon
  // preview branch a PR created and then deleted; on any real database those
  // writes hit a table that is not there. This list is the only durable path, so
  // it is where the gap gets closed.
  //
  // ORDER MATTERS. rbm_surfaces creates the eight base tables; the rest either
  // create a table referencing them or backfill a column on one:
  //   kri_values        -> rbm_kri_values (FK rbm_kris)
  //   patient_profiles  -> rbm_patient_profiles (the cohort scorer's store)
  //   metric_ingestion  -> rbm_data_runs + rbm_metric_observations (the load path)
  //   not_evaluated     -> backfills status on rbm_kris / rbm_qtls
  //
  // All five are idempotent (every CREATE TABLE / CREATE INDEX / ADD COLUMN is
  // IF NOT EXISTS; the backfill is to_regclass-guarded and re-runnable), none
  // opens its own transaction, and none contains DROP or TRUNCATE — safe under
  // the repeated-run contract.
  'migrations/20260629_rbm_surfaces.sql',
  'migrations/20260630_rbm_kri_values.sql',
  'migrations/20260701_rbm_patient_profiles.sql',
  'migrations/20260726_rbm_metric_ingestion.sql',
  'migrations/20260726_rbm_not_evaluated_backfill.sql',
  // ── Collaboration state (added 2026-07-27) ────────────────────────────────
  // Durable Y.js CRDT state for the /collab socket. Fully self-contained: one
  // CREATE TABLE IF NOT EXISTS that references nothing, plus an ON DELETE
  // CASCADE FK to authoring_documents added only inside a to_regclass guard.
  // Listed after the authoring entries so that on a fresh database — where
  // applyAuthoringSubsystem() has already run — the guard finds the table and
  // the cascade actually lands, instead of leaving CRDT state that outlives the
  // document it belongs to.
  //
  // Without this entry the collaboration server has nowhere to persist: its
  // store reports the table missing, onLoadDocument refuses the connection, and
  // the subsystem is off anyway until ENABLE_COLLAB_CRDT is set. Listing it
  // here is what makes turning that flag on a configuration change rather than
  // a schema migration.
  'db/migrations/20260727_collab_document_state.sql',
  // ── artifacts (added 2026-07-28) ──────────────────────────────────────────
  // Chat-generated artifacts. Two shipped paths addressed this table and nothing
  // created it: a fire-and-forget INSERT in server/routes/chat-actions.ts (whose
  // .catch turned "relation does not exist" into a console.warn while the
  // request still returned ok:true) and the workspace summary's "Recent
  // artifacts" read. Self-contained: one CREATE TABLE IF NOT EXISTS referencing
  // nothing, one index, and its own tenant_isolation_policy — 0021 has long
  // since run and never revisits a newly-added table.
  'db/migrations/20260728_artifacts_table.sql',
  // ── c2c section timestamps (added 2026-07-28) ─────────────────────────────
  // c2c_document_sections was created with no updated_at/created_at, yet FOUR
  // shipped queries reference ds.updated_at: /workstreams (projects.ts:334),
  // /drafts (:371,:377), the project vault (project-vault.ts:365) and the UPDATE
  // branch of the canonical Part 11 section save (documents.ts:441). Postgres
  // rejects an unknown column at plan time, so those are unconditional 42703
  // failures — /workstreams and /drafts have 500'd on every project page load,
  // and the section save would 500 on the first re-save of any section.
  //
  // Must be on this list, not just in migrations/: the root tree reaches new
  // databases only, and every database with this defect is an existing one.
  // CREATE TABLE IF NOT EXISTS cannot add a column to a table that already
  // exists, so the guarded ALTER is the only way the column lands.
  'migrations/20260728_c2c_document_sections_timestamps.sql',
  // ── CMC Module 3 operating system (added 2026-07-28) ──────────────────────
  // The ONLY file that creates cmc_module3_sections, cmc_source_objects,
  // cmc_section_lineage, cmc_provenance_events and seven siblings — and it was
  // on NO durable apply path. It carries no `_gcc_` infix so the CI psql loop
  // skips it; it lives in db/migrations so install-fresh's root-tree overlay
  // never sees it; and it was not in this list. It IS in
  // db/migrations/migrations_manifest.json, which nothing consumes.
  //
  // Consequences, both observed: the blank-DB provisioning job failed with
  // `relation "cmc_module3_sections" does not exist`, and migrations/0016 and
  // 0017 — which ALTER these tables from the root tree — have been ALTERing
  // tables that install-fresh never created. Every CMC Module 3 write in the
  // product has only ever addressed tables that exist on databases provisioned
  // by some other means.
  //
  // Fully idempotent: 11 CREATE TABLE IF NOT EXISTS, no unguarded DDL, no data
  // statements, and `organizations` is its only external FK target — which
  // deploy-migrate already asserts as a base sentinel before this loop runs.
  //
  // MUST precede the re-key below, which indexes the tables this creates.
  'db/migrations/20260401_cmc_convergence_os.sql',

  // ── project_workflows (added 2026-08-23) ─────────────────────────────────
  // The CMC workflow store. `server/api/cmc/routes.ts` and
  // `server/api/cmc/workflowRoutes.ts` query `project_workflows`; this file is
  // its ONLY creator, and it was on no applier — so the table existed on no
  // real database and both routes 500'd. (2026-10-05: workflowRoutes.ts was
  // retired with no caller; routes.ts still writes the table, so this stays.)
  //
  // It was invisible to ci:migration-reachability because that guard treated
  // any `pgTable(...)` under shared/ as the drizzle push surface, and
  // shared/cmc-schema.ts declares this table. drizzle.config.ts scopes push to
  // shared/schema.ts alone, which does not re-export cmc-schema, so drizzle
  // never created it either. The guard is corrected in the same change and now
  // reports exactly this one finding.
  //
  // Meets the wiring bar (scripts/db/verify-migration-set.mjs): applied against
  // a real PostgreSQL 16 with the full install present, creates
  // project_workflows, and is CREATE TABLE IF NOT EXISTS throughout — its
  // second pass reported "relation already exists, skipping" rather than
  // failing, so the deploy's every-time re-run is safe. Placed after
  // 20260401_cmc_convergence_os.sql, which provisions the CMC tables it sits
  // beside.
  'db/migrations/20260402_cmc_runtime_ddl_to_migration.sql',
  // ── Schedule of events tenant-scoped uniqueness (added 2026-07-28) ────────
  // SECURITY. project_schedule_of_events had a unique constraint on (project_id)
  // alone — org-blind. generateProjectSchedule() upserted with
  // `ON CONFLICT (project_id) DO UPDATE SET`, matching any tenant's row, and
  // the DO UPDATE SET did not reset organization_id. A cross-org attacker could
  // regenerate another org's schedule with new dates and regulatory milestones.
  // This migration is the fix: (organization_id, project_id) arbiter + composite
  // FK to projects(id, organization_id) for structural consistency.
  //
  // Must be on this durable path: the migration was written into db/migrations
  // but WAS NOT on this list, so it never shipped to production databases.
  // Landing without this entry would make the code's `ON CONFLICT
  // (organization_id, project_id)` reference a constraint that does not exist:
  // "there is no unique or exclusion constraint matching the ON CONFLICT
  // specification" (42P10). Every upsert would fail.
  'db/migrations/20260728_schedule_of_events_org_scoped_uniqueness.sql',
  // ── CMC Module 3 tenant-scoped uniqueness (added 2026-07-28) ──────────────
  // SECURITY. cmc_module3_sections and cmc_source_objects were unique on keys
  // that omit organization_id (migrations/0016:22, migrations/0017:102,107).
  // Uniqueness is what ON CONFLICT arbitrates against, so an org-blind key
  // decides WHOSE ROW an upsert lands on — and the Module 3 compile route
  // upserted on (project_id, section_key), matching any tenant's row for that
  // project id while the DO UPDATE SET left organization_id alone.
  //
  // This one MUST be on the durable path, not just in migrations/. The root
  // tree is applied only by install-fresh (new databases). Every already-
  // provisioned database — which is every database that has the defect — gets
  // schema only from this list. Landing the code fix without this entry would
  // ship an ON CONFLICT clause naming an index that does not exist there:
  // "there is no unique or exclusion constraint matching the ON CONFLICT
  // specification" (42P10) on every compile. Merged-but-never-applied is the
  // failure mode this module exists to prevent; here it would also be an
  // outage.
  'migrations/20260728_cmc_module3_org_scoped_uniqueness.sql',

  // Part 11 attribution. c2c_snapshot_section_version() hardcoded author_kind
  // to 'human' for every superseded version, so AnA-generated text entered the
  // immutable ledger claiming a person wrote it. The section row's own
  // draft_source is mutable and overwritten by the next edit, which makes the
  // version ledger the only durable record of AI involvement — and it was
  // uniformly wrong. CREATE OR REPLACE FUNCTION only; no table is altered and
  // no existing row is rewritten.
  'migrations/20260728_c2c_section_version_author_kind.sql',

  // authoring_comments never had the eight columns its own API references —
  // parent_comment_id, user_name/user_email, position_data, the resolution
  // trio, updated_at. GET /docs/:id/comments and its reply sub-query were
  // therefore unconditional 42703 failures. All additive and nullable, so no
  // backfill; guarded on the table so it no-ops where the authoring bundle is
  // absent.
  'migrations/20260728_authoring_comments_threading.sql',

  // Governed binding: authoring_documents.c2c_document_id. c2c_documents is the
  // system of record for a regulatory filing; the authoring stack is the editing
  // layer over it, and this column is the join. MUST follow the authoring bundle
  // and the c2c document schema — it is guarded on both, so it no-ops rather
  // than aborting the set where either is absent. Nothing is backfilled:
  // historical authoring documents carry no derivable doc_type/agency, and
  // inventing a regulatory class for a past record would be worse than leaving
  // it unbound.
  'migrations/20260728_authoring_document_governed_binding.sql',
  // Provenance for authoring documents (WM, 2026-09-21): a nullable JSONB
  // column that says whether AnA drafted the document (source 'ana' with the
  // conversation/turn and the model the gateway reported), a seed produced it,
  // or it was imported; NULL keeps meaning "a person authored it". Guarded on
  // to_regclass like the program-scope ALTER above, so it lands for real once
  // the authoring bundle is provisioned and no-ops with a NOTICE otherwise.
  // Additive, idempotent, no backfill.
  'migrations/20260921_authoring_document_provenance.sql',
  // Reconcile lumen_data_atoms embeddings onto 1536 dimensions (audit P0c). The
  // superseded db/migrations/20260125_add_atom_embeddings.sql declared the column
  // and the search_atoms_* functions at vector(3072) and was never in this set, so
  // on real databases the column/functions are absent and the 1536 write + hybrid
  // search silently failed. Self-guarding: creates-or-reconciles, and only needs
  // lumen_data_atoms (present via the drizzle baseline the preflight verifies).
  'db/migrations/20260730_fix_atom_embedding_dimension.sql',

  // ── The 21 CFR Part 11 e-signature path (ledger C-17/C-19/C-20) ────────────
  //
  // These reconcile the drizzle push surface with the incremental-deploy lineage
  // for the entire signing path. They were authored into db/migrations and the
  // manifest, but the manifest APPLIES NOTHING — only this set (and drizzle-kit
  // push at one-time fresh install) is durable — so on an existing customer DB
  // that deploys incrementally they never landed. Adding them here is what makes
  // the release-signature gate actually work on such an environment. ORDER
  // MATTERS: the orchestrator store must exist before the e-sig port widens its
  // status CHECK; the users/auth columns are independent. All additive and
  // guarded (CREATE/ALTER ... IF NOT EXISTS), so idempotent where push already
  // provisioned them.
  'db/migrations/20260725_submission_orchestrator_store_port.sql',
  /* Immediately after the port, which is the only file on this applier that
     creates submission_orchestrator_runs with the narrow four-value region
     CHECK — so the DROP-then-ADD below always has that constraint to replace on
     a bare database, and never runs before its table exists. The live state on a
     pushed database is no CHECK at all; see the file's 2026-09-18 header. */
  'migrations/20260629_orchestrator_region_check_alignment.sql',
  'db/migrations/20260725_esig_gate_columns_port.sql',
  'db/migrations/20260725_users_signing_lockout_columns.sql',

  // ── Golden-journey-proven, deploy-dead migrations (ledger C-1/C-8/C-10/C-16) ─
  //
  // Each file below creates tables that the product's own golden-journey tests
  // exercise end-to-end, yet NONE was on a durable apply path: none carries the
  // `_gcc_` infix (CI psql loop skips them), all live in db/migrations (the
  // install-fresh root overlay never sees them), none is in the drizzle journaled
  // baseline, and — decisively — NOT ONE of their primary tables is defined in
  // shared/schema.ts, so drizzle-kit push does not create them on a fresh install
  // either. They existed on NO real database, fresh or incremental. The only
  // record that "declared" them was db/migrations/migrations_manifest.json, which
  // applies nothing. This is the same code-derived-only gap the C-11 authoring
  // loop tables had; the fix is the same — put them on this list, the one durable
  // path a real deploy runs.
  //
  // ORDER MATTERS:
  //   ind_section_tracking creates project_sections (+ the section-tracking
  //     tables); the content_columns ALTER below widens it, so it must land first.
  //   assumption/decision/contradiction is the operating-system core — self-
  //     contained, only FKs itself + organizations/projects.
  //   governance_boundary FKs concept2cure_artifacts (a base table push
  //     provisions and deploy-migrate asserts is present before this loop).
  //   resolution_orchestration creates the resolution_* / supersession tables and
  //     their enum types (each guarded by DO $$ … EXCEPTION WHEN duplicate_object,
  //     so re-runnable).
  //   bundle_execution_receipts (ADR-0009) carries bundle_id as a plain UUID —
  //     no FK — but is conceptually downstream of the bundles above; listed after.
  //   project_sections_content_columns ALTERs project_sections and self-guards on
  //     ALTER TABLE IF EXISTS, so it no-ops if ind_section_tracking is absent.
  //
  // All six are idempotent (CREATE TABLE/INDEX IF NOT EXISTS, ALTER … IF EXISTS /
  // ADD COLUMN IF NOT EXISTS, DO-block-guarded types), open no transaction of
  // their own, and contain no DROP/TRUNCATE — safe under the repeated-run
  // contract. A new CI lineage-reachability guard asserts every golden-journey-
  // declared migration is present on a durable applier, so this class of gap
  // fails the build instead of shipping silently.
  // Reconciliation MUST precede the ind-section-tracking entry below: that
  // file's CREATE TABLE IF NOT EXISTS no-ops against the baseline
  // project_milestones shape and its CREATE INDEX ON (target_date) then
  // halts the whole run (blank-DB provisioning audit 2026-07-30). This lands
  // the additive union of both rival shapes first — which is also what the
  // one live consumer (project-sections.ts) actually needs, since its INSERT
  // straddles the two.
  'db/migrations/20260730_project_milestones_reconciliation.sql',
  'db/migrations/20260220_ind_section_tracking.sql',
  'db/migrations/20260323_assumption_decision_contradiction.sql',
  'db/migrations/20260725_governance_boundary_tables.sql',
  'db/migrations/20260725_resolution_orchestration_tables.sql',
  'db/migrations/20260725_bundle_execution_receipts.sql',
  'db/migrations/20260725_project_sections_content_columns.sql',

  // eCTD project-level compilation unblock (ledger C-16). shared/schema.ts was
  // corrected to make ectd_compilations.module_id and .compiled_by nullable — a
  // PROJECT-level compilation spans every module and has no interactive user, so
  // the NOT NULLs made POST /api/ectd-compile/:projectId/compile impossible. But
  // a schema.ts edit only reaches FRESH installs (via drizzle-kit push); every
  // EXISTING customer database still carries the original NOT NULLs and rejects
  // the insert. This ALTER is the existing-database half of that fix and was
  // itself deploy-dead (db/migrations, no `_gcc_`, not in the journal). Both
  // statements are ALTER … IF EXISTS … DROP NOT NULL — a no-op once dropped, so
  // idempotent and safe where push already provisioned the nullable shape.
  'db/migrations/20260725_ectd_compilations_project_level.sql',
  // eCTD sequence-continuity gate unblock (ledger C-31). ectd_compilations
  // carried NEITHER application_number NOR sequence_number in any definition, yet
  // ectd-validator-hardening.ts's detectSequenceGaps (step 5 of the hardened
  // gateway-readiness gate) SELECTs both from it — so the query threw
  // `column does not exist`, the catch reported a false "database unreachable",
  // and every submission was blocked. Adds the two columns (nullable) + an
  // application_number index. Existing-database half of the fix; fresh installs
  // get the columns from shared/schema.ts via push. Additive ALTER … ADD COLUMN
  // IF NOT EXISTS, idempotent, safe to re-run.
  'db/migrations/20260730_ectd_compilations_sequence_columns.sql',
  // The per-sequence leaf manifest (added to the set 2026-09-22, WO-09 Click 6).
  // package-from-core reads the PRIOR sequence's ectd_compilations.leaf_manifest to
  // derive every replace/append/delete and its modified-file pointer, and the
  // compile route writes it. The column reached FRESH installs through drizzle
  // push, but this file — the existing-database half — was on no applier, and
  // deploy-migrate runs no push. On a database provisioned before 2026-07-30 the
  // compile's manifest INSERT failed, was caught as a warning, and every later
  // sequence was diffed against no prior state at all. Proven on a copy of such a
  // database: drop the column, run this applier, the column stays absent; with
  // this entry, it returns. ADD COLUMN IF NOT EXISTS: idempotent, RULE 1 safe.
  'db/migrations/20260730_ectd_compilations_leaf_manifest.sql',
  // An imported agency-validator (LORENZ eValidator) report, kept with the
  // compilation whose package it covered (2026-09-23, W5/D7, WO-9 Click 6).
  // ADD COLUMN IF NOT EXISTS on a table already under the tenant sweep:
  // idempotent, additive, RULE 1 safe.
  'db/migrations/20260923_ectd_compilations_external_validation.sql',
  // ── Part 11 DB-level immutability (added 2026-07-30, auth/e-sig audit) ────
  // electronic_signatures: DELETE always refused; UPDATE refused except the
  // write-once supersession transition (superseded_by NULL → id).
  // device_audit_trail: strictly append-only (no UPDATE, no DELETE).
  // MUST follow the e-sig gate port above — the trigger reads superseded_by,
  // which that port adds. Idempotent (CREATE OR REPLACE FUNCTION + conditional
  // CREATE TRIGGER, to_regclass guarded). Proven by
  // tests/schema-contract/esig-audit-immutability.contract.test.ts; policy in
  // docs/compliance/part11-immutability-record-class-policy.md.
  'db/migrations/20260730_esign_audit_db_level_immutability.sql',
  // Orchestrator run-ledger hardening (same audit's P1 follow-ups): run rows
  // gain write-once workflow_version + dependency_graph_digest provenance
  // columns (the service now SELECTs and INSERTs them — schema-shape errors
  // are deliberately fatal there, so this entry must ship with that code);
  // the step-events FK drops ON DELETE CASCADE for RESTRICT (deleting a run
  // can no longer erase its history); and a trigger makes step events
  // append-only at the database. MUST follow the orchestrator store port.
  // Idempotent (ADD COLUMN IF NOT EXISTS; FK swap only rewrites a CASCADE;
  // conditional trigger). Proven by
  // tests/schema-contract/orchestrator-ledger-hardening.contract.test.ts.
  'db/migrations/20260730_orchestrator_run_ledger_hardening.sql',
  // Release-gate OQ-3 backstop: UNIQUE partial index on the active release
  // signature per (org, payload-digest), scoped to signature_type =
  // 'submission-release' so document multi-signing is unaffected. MUST follow
  // the e-sig gate port (adds bound_payload_digest/superseded_by) and the
  // immutability migration (its dedup pre-step uses the permitted superseded_by
  // transition). Idempotent (guarded dedup + CREATE UNIQUE INDEX IF NOT EXISTS).
  'db/migrations/20260730_release_signature_uniqueness.sql',
  // ── Blank-DB provisioning audit (added 2026-07-30) ────────────────────────
  // Three creators the fresh-install overlay needed and existing databases
  // may equally lack (merged ≠ applied, again):
  //   ai_trace_chain — the ONLY creator of ai_threads + the provenance chain
  //     (8 live server files query them); was in db/migrations on no durable
  //     path, so root file 0011 could never ALTER ai_threads on fresh DBs.
  //   cmc_projects reconstruction — code-derived (C-11 pattern) creator for a
  //     table with NO DDL anywhere, yet INSERTed by the CMC blueprint route
  //     (retired 2026-10-05) and FK-referenced by
  //     migrations/0006_regulatory_atoms.sql, which keeps it needed.
  //   fk_delete_policies port — guarded port of root 0008, whose first pair
  //     targets retired user_sessions and aborted the file's 16 live FK
  //     delete-policies on every fresh install.
  // All idempotent (IF NOT EXISTS / DROP CONSTRAINT IF EXISTS + re-ADD /
  // to_regclass guards).
  'db/migrations/20260224_ai_trace_chain.sql',

  /* verifier_flags on ai_claims — written by the chat send-message path
     (`INSERT INTO ai_claims (… verifier_flags)`) and read by the IVDR pack
     manifest's flagged-claim counts. The column was on no applier, so both
     raised 42703 on every deployed database: claim persistence failed and the
     manifest could not count flags. Measured 2026-09-20 against a database
     built by install-fresh plus the whole set. Immediately after its creator so
     the replay order is create-then-widen (CLAUDE.md RULE 1); guarded and
     idempotent. */
  'db/migrations/20260224_ai_claims_verifier_flags.sql',

  'db/migrations/20260730_cmc_projects_reconstruction.sql',
  'db/migrations/20260730_manufacturing_processes_reconstruction.sql',
  'db/migrations/20260730_fk_delete_policies_port.sql',

  /* The governed-action ledger's `command` vocabulary. 20260527_mutation_primitives
     created c2c_ana_actions with a CHECK enumerating only the twelve original
     universal mutations, and recordGovernedAction has since been adopted platform-
     wide with a free `command: string` — 'create', 'update', 'review', 'approve',
     'reaffirm', 'transmittal_rollback', 'apply-sample-size', 'task.create' and more.
     Every one of those INSERTs raises 23514 and rolls back the WHOLE governed
     transaction, so the domain mutation fails and no audit row is written.

     The fix was written on 2026-07-30 and never reached a database: the file was
     left out of this list, so it ran on no applier. ci:migration-reachability does
     not catch it because that guard asks whether a TABLE the server queries is
     created by something an applier runs — this migration creates no table, it
     replaces a constraint, so it was invisible to every gate.

     Measured 2026-09-08 against a database with all 253 entries of this set
     applied: the narrow CHECK was still in force and
     POST /api/biostat-bridge/designs/:id/apply-sample-size answered 500 (23514).
     Positioned AFTER 20260527 so the replay order is create-then-widen, per the
     ordering rule in CLAUDE.md RULE 1; both files are idempotent. */
  'db/migrations/20260730_c2c_ana_actions_command_vocab.sql',

  // eSTAR filing journey — client registration (the four FDA prerequisites),
  // the program-agnostic filing tracker (status + review clock), and the
  // project link that joins tracking to the PM spine. Order matters: the
  // project-link ALTER requires estar_submissions to exist. All idempotent
  // (CREATE TABLE / ADD COLUMN / CREATE INDEX ... IF NOT EXISTS).
  'migrations/20260730_estar_registration.sql',
  'migrations/20260730_estar_submission.sql',
  'migrations/20260730_estar_submission_project_link.sql',
  // WO-8 Phase 3: every administrative field of the official eSTAR has a
  // governed home. Device-level facts (common name, classification name,
  // regulation number, associated product codes, IFU citation) are columns on
  // regulatory_programs — created at index 1 of this set by
  // 20260524_program_workbench_schema. Org-level correspondent / Declaration
  // of Conformity facts are columns on estar_registrations, so that ALTER
  // MUST stay after 20260730_estar_registration above. Both are ADD COLUMN IF
  // NOT EXISTS on existing tenant tables — no new table, so no RLS sweep entry.
  'migrations/20260903_regulatory_programs_estar_device_fields.sql',
  'migrations/20260903_estar_registration_correspondent.sql',
  // The Declaration of Conformity's company NAME, beside the address the file
  // above added. The DoC is signed by one legal entity, so its name and
  // address must come from one row; the name used to be read from the
  // applicant's workspace, which holds no address. Same table, so this MUST
  // stay after 20260730_estar_registration; ADD COLUMN IF NOT EXISTS on an
  // existing tenant table — no new table, so no RLS sweep entry.
  'migrations/20260904_estar_registration_declaration_company_name.sql',

  // Work items: source_ref for string/UUID-keyed sources (correspondence
  // issues), so those rows stop sharing the (source_type, source_id=0) key.
  'migrations/20260730_work_item_source_ref.sql',
  // C2C work items source uniqueness: enforce dedup key via constraint.
  // upsertProjectWorkItem uses read-then-write (SELECT then INSERT/UPDATE),
  // which is racy: concurrent requests can both see no row, both try to INSERT,
  // and one fails. A unique constraint on (org_id, source_type, source_id)
  // prevents both rows from landing and lets the code switch to INSERT ... ON
  // CONFLICT for atomicity. Self-guarding: errors if duplicates exist.
  'db/migrations/20260810_c2c_work_items_source_uniqueness.sql',

  // ── Deploy-dead creators, wired (ledger C-32) ────────────────────────────
  // Five files that CREATE tables live server code queries, but that sat on no
  // durable apply path at all: not `_gcc_`, not in the drizzle journal, not in
  // install-fresh's named lists, and their tables are not on the drizzle push
  // surface either. Every table below therefore existed on NO real database and
  // its endpoints 500'd with missing-relation errors — while `ci:unbacked-tables`
  // reported them "backed", because that guard counts any non-archived .sql file
  // as a creator regardless of whether an applier ever runs it (the blind spot
  // ci:migration-reachability now closes).
  //
  // All five were verified before wiring: applied twice against a blank Postgres
  // (idempotent, clean re-run), every CREATE TABLE/INDEX is IF NOT EXISTS, every
  // CREATE POLICY sits in a pg_policies-guarded DO block, and every FOREIGN KEY
  // is self-referential — so they carry no ordering dependency on anything
  // outside themselves and cannot abort a deploy on a missing FK target.
  //
  // 082 backs the eCTD submission-agent surface (server/services/
  // ectd-submission-agent.ts behind the MOUNTED ectd-submission-agent.routes),
  // and C-32 adds its tenant_isolation_policy block — 0021 has already run on
  // this path and would never revisit these new tables, which under
  // RLS_ENFORCE=on would leave every tenant's submission history cross-tenant
  // readable. Its ectd_submissions also feeds the C-31 sequence-continuity gate.
  'db/migrations/082_ectd_submission_agent.sql',
  // The four 20260730 "resolution" files: written to clear referenced-but-
  // uncreated table debt (see the ratchet note in referenced-tables-baseline.json,
  // which credits them with resolving 20 missing tables) — but never put on an
  // applier, so the debt was marked resolved while the tables still reached no
  // database. Each already carries its own tenant_isolation_policy DO block.
  'db/migrations/20260730_cmc_evidence_tables.sql',
  'db/migrations/20260730_submission_center_tables.sql',
  'db/migrations/20260730_graphrag_knowledge_tables.sql',
  'db/migrations/20260730_licensing_ip_tables.sql',

  // ── Deploy-dead creators, batch 2 (ledger C-33) ──────────────────────────
  // Forty more files in the C-32 class: they CREATE tables live server code
  // queries, and sat on no durable apply path, so those tables existed on no real
  // database. Selected mechanically from the ci:migration-reachability baseline
  // and verified the same way — each was applied TWICE against a BLANK Postgres
  // in isolation and came up clean, which proves three things at once: every
  // CREATE TABLE/INDEX is idempotent (the re-run is a no-op), the file is
  // self-contained (it needs no table, schema or extension it does not itself
  // create — nothing here can abort a deploy on a missing dependency), and it
  // carries no non-integer tenant key (see the sweep note below).
  //
  // Excluded by that same screen, deliberately:
  //   • files needing prerequisites a blank DB lacks (organizations/users, the
  //     `vector`/`pgcrypto` extensions, the predicate/precedent/core schemas) —
  //     they may well be fine on a real database, but "probably fine" is how this
  //     class of defect got here; they stay baselined until verified against a
  //     real base schema.
  //   • 20260125_ai_provider_audit_log / 20260324_ana_kernel_decision_log /
  //     20260326_conversation_os_durability_phase2 — uuid/text tenant keys, the
  //     same identity-model collision as C-27/C-29. Wiring them would provision
  //     tenant tables the integer-keyed RLS model cannot police. Needs a
  //     decision, not a wiring.
  //   • db/migrations/_consolidated/** — ledger C-29 Class 3 (its only creators
  //     also redefine users/tenants with TEXT keys).
  'db/migrations/022_stability_v2.sql',
  'db/migrations/024_stability_step3.sql',
  'db/migrations/030_stability_results.sql',
  'db/migrations/20260129_phase5_intelligent_document_system.sql',
  'db/migrations/20260206_phase5_contradiction_scanner.sql',
  'db/migrations/20260206_phase5_evidence_fabric.sql',
  'db/migrations/20260207_phase6_6_predicate_intelligence.sql',
  'db/migrations/20260223_ivdr_binder_packs.sql',

  /* source_type / source_atom_id / source_retrieval_chunk_id on
     ivdr_binder_evidence — the IVDR pack manifest SELECTs all three and
     ai-claims-routes INSERTs source_type, so attaching evidence to a claim and
     building the manifest both raised 42703. Same pair of 2026-02-24/25 files
     that fell off the applier together; same measurement.
     Moved here, directly after its creator, 2026-09-26 (W2 / D1): it stood 25
     entries earlier, so on a database the set was building for the first time
     its to_regclass guard found no table and skipped, and the columns, CHECK and
     indexes arrived only on the SECOND deploy. ci:replay-rebuilds-nothing
     measured it (5 objects created by a replay). */
  'db/migrations/20260224_binder_evidence_source_types.sql',

  /* The artifact hashes, sizes and warnings ivdr-pack-worker writes in its
     final promotion step (`UPDATE ivdr_packs SET … manifest_sha256 … zip_sha256,
     has_warnings, warnings_jsonb`). Ten columns, all absent because this file
     was on no applier — so every IVDR pack build did its whole job and then
     failed 42703 at the last statement. Same date, same measurement, same
     create-then-widen ordering. */
  'db/migrations/20260225_ivdr_pack_warnings_artifact_hashes.sql',
  'db/migrations/20260306_chat_tool_runs.sql',
  'db/migrations/20260317_global_regulatory_compliance.sql',
  'db/migrations/20260322_regulatory_precedent_intelligence.sql',
  'db/migrations/20260323_reactive_dependency_layer.sql',
  'db/migrations/20260324_ai_goal_plan_runs.sql',
  'db/migrations/20260324_ai_kernel_agent_protocol_events.sql',
  'db/migrations/20260324_ai_kernel_decision_records.sql',
  'db/migrations/20260324_ai_kernel_policy_outcomes.sql',
  'db/migrations/20260325_ai_goal_plan_step_events.sql',
  'db/migrations/20260325_decision_receipts.sql',
  'db/migrations/20260326_conversation_os_durability.sql',
  'db/migrations/20260508_ana_submission_chat_proposals.sql',
  'db/migrations/20260520_ana_failure_learning.sql',
  'db/migrations/20260520_document_templates.sql',
  'db/migrations/20260520_regulatory_intelligence_layer.sql',
  // Nonclinical study-summary display fields (duration_label, key_finding,
  // finding_class). This file was in the tree but in NO list — neither wired
  // here nor recorded as deliberately unwired — so it was silently never
  // applied, which is precisely the "merged ≠ applied" gap this set exists to
  // close. server/services/nonclinical/nonclinical-service.ts selects
  // s.duration_label and s.key_finding in two statements, and Postgres rejects
  // an unknown column at plan time, so GET /api/nonclinical/studies returned
  // 500 "column s.duration_label does not exist" on every request against a
  // correctly provisioned database.
  //
  // Safe to wire: the migration is additive, nullable, non-destructive, wrapped
  // in `IF to_regclass(...) IS NOT NULL` and uses ADD COLUMN IF NOT EXISTS, so
  // it is a no-op on a schema that predates the table and idempotent everywhere
  // else. Ordered after 20260610_nonclinical_send.sql creates the table.
  'db/migrations/20260716_nonclinical_display.sql',
  'db/migrations/20260717_agency_meetings_store.sql',
  'db/migrations/20260717_design_controls_store.sql',
  'db/migrations/20260717_evidence_asks_store.sql',
  'db/migrations/20260717_evidence_objects_store.sql',
  'db/migrations/20260717_human_factors_store.sql',
  'db/migrations/20260717_labeling_pi_store.sql',
  'db/migrations/20260717_maa_module1_store.sql',
  'db/migrations/20260717_nda_m1_docs_store.sql',
  'db/migrations/20260717_nda_rtf_store.sql',
  'db/migrations/20260717_program_journey_store.sql',
  'db/migrations/20260718_pediatric_orphan_cards.sql',
  'db/migrations/20260718_smpc_sections_store.sql',
  'db/migrations/20260724_qms_change_control_store.sql',
  'db/migrations/20260730_cmc_change_control_store.sql',
  'db/migrations/20260801_hf_files_store.sql',
  'db/migrations/20260801_market_access_store.sql',
  'db/migrations/20260801_reg_change_store.sql',
  // Landed the same day as this batch, with a live writer (labeling-pi-service.ts
  // via POST /api/labeling-pi) and no applier — a fresh instance of the very class
  // C-32's guard exists to catch, caught by that guard. Same screen: idempotent,
  // self-contained on a blank DB, integer organization_id.
  'db/migrations/20260801_labeling_pi_store.sql',
  // Same story again, hours later: a real program-journey store with a live
  // writer (program-journey-service.ts) and no applier, flagged by the guard on
  // rebase. Same screen: idempotent, self-contained, integer organization_id.
  'db/migrations/20260801_program_journey_store.sql',

  // ── Deploy-dead creators, batch 3 (ledger C-34) ──────────────────────────
  // The fifteen files C-33 left baselined as "needs a prerequisite a blank DB
  // lacks". C-33 refused to wire them on the assumption they would be fine on a
  // real database; C-34 stops assuming and verifies them against a BASE-SCHEMA
  // FIXTURE instead — the drizzle journal's 290 CREATE TABLE blocks, the contrib
  // extensions a real cluster has (pgcrypto / pg_trgm / uuid-ossp / citext), the
  // named schemas, and then the whole C2C set applied ahead of them, i.e. the
  // state a deploy actually presents. Each was then applied TWICE and checked for
  // a non-integer tenant key, exactly as batches 1-2 were.
  //
  // Order matters here and is the order they were verified in: several depend on
  // tables the entries ABOVE create (026_stability_step4 needs stab_studies from
  // 022_stability_v2; 20260520_growth_mindset_extensions needs
  // intelligence.failure_patterns from 20260520_ana_failure_learning), which is
  // precisely why they failed the blank-DB screen and pass this one.
  'db/migrations/026_stability_step4.sql',
  // ── Stability tenant isolation + backing (relocated here from ~line 146) ──
  // Placed AFTER the stab_* core creators (022/024/030/026) so the isolation
  // sweep sees the existing stab_* tables to policy, and the backing file's
  // v_stab_* view guards (stab_timepoints/stab_conditions) are satisfied on a
  // fresh DB. Both remain far before the two final 20260801 isolation sweeps.
  // ── Stability module tenant isolation (High-severity security fix) ────────
  // docs/security/STABILITY_TENANT_ISOLATION_FINDING.md. The stability router scoped
  // GMP data by surrogate id with no tenant predicate, and its
  // set_config('app.tenant_id', …) calls were inert because the app's RLS keys on
  // app.current_tenant_id. This brings every EXISTING stab_* base table under the
  // uniform tenant_isolation_policy (the 0021 shape) with ENABLE + FORCE RLS, and
  // defaults tenant_id from the request so the router's INSERTs auto-tag.
  //
  // ORDER MATTERS: this MUST precede the backing-tables entry below. It opens with
  // BEGIN; — applyMigrationFiles' selfTransacting detection handles that, so it is
  // not double-wrapped. Catalog-driven, so it is a no-op (not an error) on a
  // database where the stab_* tables do not exist yet.
  'db/migrations/20260728_stability_tenant_isolation.sql',
  // Backs the seven previously-unbacked stab_* tables, the shared cmc_methods
  // catalog and the two v_stab_* views, tenant-isolated FROM BIRTH (tenant_id
  // INTEGER NOT NULL defaulting from app.current_tenant_id, plus the same policy
  // loop). Backing them without that isolation would convert a fail-safe 500 into a
  // real cross-tenant leak, which is why it follows the migration above. cmc_methods
  // is deliberately created WITHOUT a tenant column: it is a global methods catalog
  // joined by id and never tenant-filtered, and scoping it would hide every method.
  'db/migrations/20260728_stability_backing_tables.sql',
  'db/migrations/081_grdhe_regulatory_mapping_layer.sql',
  'db/migrations/20260209_phase6_6a_fda_ingest_runs.sql',
  'db/migrations/20260211_phase6_6d_defense_packets.sql',
  'db/migrations/20260211_phase6_6e_proof_pack_exports.sql',
  'db/migrations/20260211_phase7_0a_render_jobs.sql',
  'db/migrations/20260220_user_intelligence_platform.sql',
  'db/migrations/20260322_quality_checkpoints.sql',
  'db/migrations/20260326_artifact_compute_plane.sql',
  'db/migrations/20260331_communication_center_scaffold.sql',
  'db/migrations/20260331_regulatory_correspondence_os.sql',
  'db/migrations/20260401_submission_center_items.sql',
  'db/migrations/20260508_artifact_citations.sql',
  'db/migrations/20260520_growth_mindset_extensions.sql',
  'db/migrations/20260621_weekly_usage_limits.sql',

  // ── C-40: reconcile databases that ALREADY have the broken shape ─────────
  // MUST precede the two corrected migrations below. C-36 and C-38 express their
  // fixes as CREATE TABLE IF NOT EXISTS — right for a database that lacks the
  // table, and a NO-OP for one that has it in the uuid shape. At least one real
  // database is in exactly that state: reports/phase0/db_inventory.txt lists
  // ai_provider_audit_log, lumen_knowledge_graph_edges and lumen_atom_versions.
  // Without this step both fixes would ship and change nothing there — the same
  // "merged, green, never applied" failure, one level deeper.
  //
  // It drops such a table ONLY when it is empty (the next migrations recreate it
  // canonically); a populated one is left untouched with a loud WARNING, because
  // discarding audit attribution to satisfy a type change is not a decision a
  // deploy script may make (21 CFR Part 11 §11.10(e)).
  'db/migrations/20260801_atom_identity_existing_db_reconciliation.sql',

  // ── C-36: enhanced cortex, unblocked by fixing the identity conflict ─────
  // Six tables behind five live services (knowledgeGraphService, atomVersion-
  // Service, atomQualityService, conflictDetectionService, enhancedEmbedding-
  // Service). C-34 left it baselined because its atom foreign keys were declared
  // UUID while the canonical lumen_data_atoms.id is `serial` — the FK was
  // literally unimplementable, and even without it the services' own
  // `... JOIN lumen_atom_quality_scores q ON a.id = q.atom_id` would have failed
  // with "operator does not exist: integer = uuid". The file was written against
  // an imagined uuid-keyed atom store that does not exist on any database.
  // C-36 converts every ATOM-id reference to INTEGER to match the canonical key
  // (each table's own `id UUID PRIMARY KEY` is untouched — those are their own
  // identities, not atom references). Verified against the base fixture: applies
  // twice, all six tables created, both previously-impossible FKs now present,
  // and the services' real JOIN typechecks.
  'db/migrations/20260125_enhanced_cortex_schema.sql',
  //
  // Five remain unwired, each for a named reason rather than an unexamined
  // "probably fine" (they stay in the ci:migration-reachability baseline):
  // ── C-37: the pgvector trio, verified on a REAL Postgres ─────────────────
  // C-33/C-34 left these baselined as "unverifiable" because the PGlite harness
  // cannot load the `vector` extension. That was a limitation of the harness, not
  // a property of the files — so C-37 replaced the harness rather than accepting
  // the gap: a real PostgreSQL 16 + pgvector 0.6.0 instance, seeded with the
  // drizzle journal base schema and the whole C2C set, then each file applied
  // TWICE. All three come up clean and idempotent.
  //
  // Wiring them is consistent with what the deploy path ALREADY assumes: two
  // files needing `vector` (20260730_fix_atom_embedding_dimension and
  // 20260730_graphrag_knowledge_tables) are long-standing members of this list,
  // and 001_gcc_core.sql creates the extension. Each file below also issues its
  // own CREATE EXTENSION IF NOT EXISTS vector.
  //
  // Order is a real dependency: risk_rollups reads predicate.fda_510k_clearances,
  // which the clearance-universe file creates — which is exactly why it failed
  // the earlier screen in isolation.
  //
  // The FDA 510(k) clearance universe carries NO tenant column: public reference
  // data every tenant reads, so the isolation sweep correctly leaves it alone.
  // precedent.regulatory_precedents carries a NULLABLE organization_id (NULL =
  // public precedent, else private to that org), added and policied by the
  // 20260617 file directly below.
  'db/migrations/20260207_phase6_6a_fda_clearance_universe.sql',
  'db/migrations/20260306_precedent_engine.sql',
  // Wired 2026-09-22, and it must follow its creator: before 20260306 its
  // IF EXISTS guard would no-op on a blank database and the column would arrive
  // only on the SECOND deploy. It was on no applier until then, so every corpus
  // search raised 42703 (`column "organization_id" does not exist`) on every
  // database, swallowed to [] — precedent search could only ever answer "none".
  'db/migrations/20260617_precedent_org_isolation.sql',
  'db/migrations/20260208_phase6_6a_risk_rollups.sql',

  // ── C-38: the three identity collisions, reconciled to canonical ─────────
  // C-33 excluded these because their tenant keys were uuid/text, which the
  // integer-keyed RLS sweep cannot police — wiring them would have provisioned
  // tenant tables with no isolation. The right resolution was never "leave them
  // dead"; it was to reconcile them to the canonical identity, which the code
  // ALREADY uses:
  //   • ai_provider_audit_log.organization_id was UUID — canonical organizations.id
  //     is `serial`. user_id/project_id were UUID too, and canonical users.id /
  //     projects.id are also `serial`, so a real id would have been REJECTED by
  //     those columns. All three are now INTEGER.
  //   • ana_kernel_decision_log.tenant_id was TEXT. Nothing writes the table and
  //     no query filters on tenant_id (server/src/control-plane/persistent-
  //     queries.ts issues three aggregate reads), so the conversion is safe and
  //     is what lets the sweep isolate it.
  //   • conversation_os_accepted_artifact_versions.organization_id was TEXT, while
  //     server/routes/conversation-os.ts does `String(authUser.organizationId)` on
  //     the way in and `Number(ctx.organizationId)` on the way out — the identity
  //     was always an integer org id; only the column disagreed.
  // Each verified on a real PostgreSQL 16: applies twice, clean.
  'db/migrations/20260125_ai_provider_audit_log.sql',
  'db/migrations/20260324_ana_kernel_decision_log.sql',
  'db/migrations/20260326_conversation_os_durability_phase2.sql',

  // ── C-39: the _consolidated tree's live tables, extracted ────────────────
  // C-29 Class 3 quarantined db/migrations/_consolidated wholesale. Auditing it
  // file by file showed the blanket was too wide (only 001_create_core_tables
  // redefines users/organizations) but that wiring the rest was still wrong:
  // 012_document_authoring_schema creates a rival `doc_revisions` against the
  // canonical authoring subsystem, and programs/literature_entries/maud_* all
  // carry uuid/text tenant keys the integer RLS sweep cannot police.
  //
  // So the ten live tables are EXTRACTED into one canonical migration and the
  // tree stays quarantined. The extraction also fixes two definition-vs-consumer
  // mismatches that provisioning alone would not have: `templates` had no
  // `sections` column though the (since-deleted, D11b) cerGenerator selected
  // it, and `doc_sections` keyed on
  // `section_id` though command-executor selects `id`. Verified on a real
  // PostgreSQL 16: applies twice, and every consumer's actual query executes.
  'db/migrations/20260801_consolidated_tree_reconciliation.sql',

  // ── Character-span lineage (the "every span traces to a source" rule) ───────
  // The first table able to state (document, char_start, char_end) → source +
  // how used. Anchored to cre_evidence_sources through the same
  // source/reference_id/payload_sha256 convention authoring_citations uses, so
  // the canonical Data Room identity stays the one identity; see the migration
  // header for why none of the six existing primitives can carry this.
  //
  // MUST stay ABOVE 20260801_tenant_isolation_sweep.sql: the sweep policies the
  // tenant-scoped tables the set has created by the time it runs, and this one
  // is tenant-scoped (organization_id). Added after the sweep it would be
  // created but never isolated.
  'db/migrations/20260803_document_span_lineage.sql',

  // ── Draft-accept store for automated span-level source attribution ──────────
  // Parks an AI draft's retrieved chunks (content + resolved cre_evidence_sources
  // .id) so the accept endpoint can re-verify quotes VERBATIM against them inside
  // the section-content transaction (SOURCE_ATTRIBUTION_AUTOMATED_DESIGN.md Phase
  // 3a). Tenant-scoped (organization_id); it declares RLS inline AND sits above
  // the sweep — belt and suspenders — for the same reason document_span_lineage
  // must precede the sweep: added after it, the table would exist but never be
  // isolated on an already-provisioned database.
  'db/migrations/20260809_source_attribution_draft_candidates.sql',

  // ── Rule-pack outlines: the five stubs replaced with real trees ────────────
  // 20260529_phase9_backfill seeded nda/bla/maa/jnda/denovo as five top-level
  // rows apiece and said the full outlines would land "in a later kit". They
  // never did, so a biotech org creating its BLA — the segment's headline
  // pathway — was scaffolded a five-node dossier by scaffoldProjectDocuments()
  // and the Vault tree, the outline endpoint and the authoring canvas all
  // faithfully rendered those five nodes.
  //
  // Data-only: INSERTs the full packs as NEW versions and marks the stubs
  // superseded, so documents already built against 'ich-m4-v2.0' keep the pack
  // they were actually built from (Part 11) while new projects get the real
  // outline. Wrapped in a to_regclass guard, so on a database that never had
  // the Phase 9 schema it raises a NOTICE and skips rather than aborting the
  // deploy — the same bare-CI-safe pattern 20260529 uses.
  'migrations/20260804_phase9_rule_pack_outlines.sql',
  'migrations/20260806_cta_ema_ctr536_outline.sql',
  // Widens the c2c_documents doc_type CHECK to admit 'anda' and 'ide' and seeds
  // both packs. The widening is a strict superset of the previous IN-list, so no
  // existing row can be invalidated by it — which is why it needs no backfill
  // and is safe to re-apply. Same to_regclass guard as the two above; the CHECK
  // half additionally uses DROP CONSTRAINT IF EXISTS, because on a drizzle-push
  // database the table exists while the named constraint does not.
  'migrations/20260806b_anda_ide_filing_types.sql',
  // pma:fda was six flat sections from 20260528 and never revisited — the same
  // hollow-outline defect 20260804 fixed for five other packs. Replaces it with
  // the real 21 CFR 814.20(b) tree as a NEW version and supersedes the stub, so
  // documents already built against fda-pma-2024 keep the pack they were built
  // from. Same to_regclass guard as its three siblings.
  'migrations/20260810_pma_fda_814_20_outline.sql',
  // EU MDR 2017/745 and IVDR 2017/746 technical documentation. Widens the
  // doc_type CHECK for 'mdr' and 'ivdr' (a strict superset, so no existing row
  // can be invalidated) and seeds both packs. Thirteen EU device and diagnostics
  // filing types were scaffolding US NDAs before this.
  'migrations/20260810b_eu_mdr_ivdr_outlines.sql',
  // Records what each rule pack was built FROM. Every outline in the table was
  // presented to a filer with identical authority, but an ICH M4 spine, a
  // transcription of 21 CFR 814.20(b) and a reasoned construction against a
  // regulation that enumerates nothing are three different kinds of claim.
  // Backfills the conservative value first so an unenumerated pack under-claims,
  // and marks every pack 'unreviewed' — including the FDA ones, because none has
  // had a regulatory professional's sign-off. Must run AFTER the pack seeds
  // above so the backfill sees them. Same to_regclass guard as its siblings.
  'migrations/20260810c_rule_pack_provenance.sql',
  // 20260810c recorded WHETHER a pack was reviewed and set every one to
  // 'unreviewed'. It did not constrain what a future write could claim: nothing
  // stopped review_status='reviewed' with no record of who, when, or against
  // what tree. 'reviewed' is the one value in this schema a filer is entitled
  // to rely on, so an unattributed one would carry a professional's authority
  // while representing nobody. This adds reviewed_by / reviewed_at /
  // review_scope / reviewed_sections_sha, a CHECK that refuses an unattributed
  // sign-off, a CHECK that refuses leaving a reviewer's name on a withdrawn
  // one, and a view reporting reviewed-but-changed when the tree moves out from
  // under an honest review. Marks nothing reviewed. Must run AFTER 20260810c.
  'migrations/20260810d_rule_pack_review_attribution.sql',
  // ind:fda re-seeded as ich-m4-v2.1: Module 1 numbered per the FDA eCTD Module 1
  // Specification v2.3 (1.20 general investigational plan, 1.14.4.1 IB, 1.12.14
  // environmental analysis) and Modules 2–5 at ICH M4 leaf granularity. The
  // v2.0 pack stopped at four M1 headings, so the compile gate's required
  // 1.20 / 1.14.4.x could never be satisfied from the editor. Supersedes v2.0.
  'migrations/20260901_ind_fda_m1_v2_3_outline.sql',
  // ind:fda ich-m4-v2.2: same outline, two initial-IND flags corrected now that
  // the compile/validate/readiness gates read the pack's mandatory flags —
  // 1.3.1 (post-initial contact changes) and 5.2 (prior-study listing) are
  // optional for an initial IND. Supersedes v2.1.
  'migrations/20260902_ind_fda_outline_v2_2_initial_ind_flags.sql',
  // k510:fda and denovo:fda re-seeded to the eSTAR-era structure: the retired
  // Form 3514 cover sheet and the De Novo ToC are gone; the Part 807 mandatory
  // items (510(k) summary/statement, truthful & accuracy, Class III cert,
  // financial cert) and cybersecurity / EMC / human factors sections exist.
  'migrations/20260901b_estar_510k_denovo_outlines.sql',
  // LIFE-03: ind_icsr_transmissions gains transport_receipt_id — the gateway
  // receipt that alone justifies status = 'transmitted'. Additive, nullable,
  // guarded on the table existing (a fresh install gets it via drizzle push).
  'migrations/20260902_ind_icsr_transmissions_transport_receipt.sql',
  // LIFE-01: rendered_leaf_files — the retained bytes of a server-rendered
  // filing document. The lifecycle routes rendered the safety/annual report,
  // kept an md5 and discarded the bytes, so every filed lifecycle sequence
  // assembled with zero leaf files and was permanently dispatch-blocked. New
  // table only; no backfill (nothing records what pre-existing rows contained).
  'migrations/20260903_rendered_leaf_files.sql',
  //   • 068_regulatory_schema_alignment — creates only regulatory.information_
  //     requests, which C-35's schema-qualification fix showed is not referenced
  //     by server code at all. It is dead schema, not a live gap; the "missing
  //     regulatory.submissions creator" C-34 recorded here was an artifact of the
  //     guard bug C-35 fixed. Left unwired because nothing needs it.
  //   • 20260125_enhanced_cortex_schema — RESOLVED by C-36 and intentionally
  //     excluded; its UUID-vs-serial atom-key conflict cannot be replayed
  //     against the canonical integer atom schema. The reconciliation path
  //     above owns those tables now.

  // ── Performance indexes on hot-path tables (added 2026-08-10) ────────────────
  // Indexes on the 30 most-queried tables targeting organization_id (tenant
  // isolation), projectId (project-scoped queries), status+type (common filters),
  // and createdAt DESC (pagination). All use CREATE INDEX CONCURRENTLY IF NOT
  // EXISTS for idempotent application. This file was written into migrations/ but
  // WAS NOT on this list, so it was never applied to production databases despite
  // being essential for query performance. Landing it here closes that gap.
  'migrations/20260331_performance_indexes.sql',

  // ── unified_documents / workflow_document_versions (ledger C-29, #1239/#1242) ──
  // Both tables are defined in Drizzle (shared/schema/unified_workflow.ts) but
  // that module is NOT re-exported by shared/schema.ts, so drizzle-kit push
  // never creates them on a fresh install; the only raw creator
  // (db/migrations/_consolidated/…complete_schema.sql) redefines users/tenants
  // with TEXT keys (the C-29 collision) and lives where the install-fresh
  // overlay never walks. So this trio is the SOLE durable path to both tables on
  // every real database — fresh or incremental — exactly the merged-≠-applied
  // gap this list exists to close. The two ALTERs previously sat in the
  // ops-audit KNOWN_UNLISTED baseline on the (false) premise that push would
  // reproduce them; it cannot, so they move onto the durable path here too.
  //
  // ORDER MATTERS: _provision creates both tables (integer-keyed, IF NOT EXISTS);
  // _org_id adds organization_id nullable and backfills it from the parent
  // document; _org_not_null tightens it to NOT NULL. All idempotent (CREATE
  // TABLE/INDEX and ADD COLUMN IF NOT EXISTS; backfill guarded on IS NULL;
  // SET NOT NULL no-ops once set, and every row has a NOT-NULL FK parent so the
  // backfill leaves none behind). MUST precede the tenant-isolation sweep so the
  // new integer-org tables come under RLS.
  // ── regulatory_twin_simulations (runtime DDL → durable path) ────────────────
  // Was created by CREATE TABLE IF NOT EXISTS at module load inside
  // server/routes/regulatory-digital-twin.ts, inside a try/catch that warned and
  // continued — so it existed only where the app had booted, never on a
  // provisioning-only database, and ci:tables-live-schema flagged the route's
  // queries as reading a table nothing creates. The runtime DDL is removed in the
  // same change; this list is now its only creator.
  'migrations/20260821_regulatory_twin_simulations.sql',

  'migrations/20260729_unified_documents_provision.sql',
  // The same trio's remaining three tables — module_documents,
  // document_audit_logs, document_attachments — for the same reason. They are
  // defined only in shared/schema/unified_workflow.ts, so push does not create
  // them on a fresh install and no other raw file creates them at all. They were
  // simply absent everywhere, which is why 0004_workflow_performance_indexes.sql
  // (needs document_audit_logs) and 0007_tenant_isolation_fixes.sql (needs
  // module_documents) were carried as expected install-time skips. Sorted 'b' so
  // it follows _provision, whose unified_documents every table here references,
  // and still precedes the tenant sweep — module_documents is integer-org-keyed
  // and must come under RLS.
  'migrations/20260729b_unified_workflow_companion_tables.sql',
  'migrations/20260730_workflow_doc_versions_org_id.sql',
  'migrations/20260731_workflow_doc_versions_org_not_null.sql',

  // ── Tenant isolation for the NON-PUBLIC uuid-keyed tables (ledger C-46) ──────
  // The public sweep below is integer-keyed and public-only. The non-public
  // schemas use a uuid tenant key and were policied per-subsystem; the subsystems
  // that never added RLS (core.programs, manufacturing.*, regulatory_intel.*,
  // regulatory_harmonization.*, and gaps in cortex/compliance/global_dossier/
  // federated_ml) are closed here with the context-less-safe COALESCE policy the
  // rest of the non-public schemas already use. Explicit (schema, table, column)
  // list — the tenant key differs per table and two tables are deliberately
  // exempt (federation_participants, audit.event_log). Order-independent w.r.t.
  // the public sweep (disjoint schemas); ordered BEFORE it so the integer-keyed
  // sweep stays the final entry — ledger C-33 requires the sweep to run last
  // (asserted by tenant-isolation-sweep.contract.test.ts).
  // NOTE: migrations/20260728_authoring_reviews.sql is intentionally NOT on this
  // list (it was, redundantly, and that tripped the authoring-guard in
  // tests/ops/apply-c2c-migrations-manifest.test.mjs — table creation on the
  // authoring path belongs to the subsystem lineage, not this applier). The
  // authoring_reviews table is authoritatively created by the authoring-subsystem
  // provisioner: db/migrations/20260730_authoring_subsystem_schema.sql is in
  // AUTHORING_SUBSYSTEM_FILES and applyAuthoringSubsystem() runs on BOTH
  // install-fresh (step 4) and deploy-migrate (before this list) — so its
  // CREATE TABLE IF NOT EXISTS here was a no-op on every path. The file stays on
  // disk (applied by the install-fresh root overlay too) and is declared in the
  // test's KNOWN_UNLISTED with this same reason.

  // ── Collaboration & tasking GA (assessment D24/D25) ────────────────────────
  // Soft delete on the canonical task store: additive nullable tombstone
  // columns; every read-model filters deleted_at IS NULL; archive replaces
  // hard delete (Part 11 retention).
  'db/migrations/20260807_unified_tasks_soft_delete.sql',
  // Durable section locks: the process-local lock Map becomes a shared table
  // so restarts don't drop locks and replicas can't double-grant. Tenant-keyed
  // (tenant_id) — MUST stay ABOVE the tenant-isolation sweep so its RLS policy
  // is attached.
  'db/migrations/20260807_collab_section_locks.sql',
  // Tenant column on the task graph tables (task_dependencies /
  // cross_module_task_links) with backfill from the endpoint tasks — the
  // tables join the RLS regime via the sweep below (assessment D20).
  'db/migrations/20260807_task_graph_org_columns.sql',

  // ── 21 CFR Part 11 tamper-proof store (added 2026-08-13) ──────────────────
  // audit.tamper_proof_log had NO migration: its only creator was runtime DDL in
  // server/lib/tamper-proof-audit.ts, run on the request pool. As the
  // non-superuser app_service role that can never succeed — `audit` is granted
  // append-only (SELECT, INSERT) precisely to preserve tamper-evidence, so DDL
  // there is what must be refused — and the failure was swallowed as
  // "(non-fatal)" with a console fallback. Verified by booting the production
  // build against a database provisioned by install-fresh + deploy-migrate:
  // to_regclass('audit.tamper_proof_log') returned MISSING. The Part 11 store a
  // QA unit audits first did not exist, and the platform reported itself healthy.
  //
  // Placed BEFORE the two isolation steps because it CREATES a table, and they
  // are the final pair by contract (ledger C-33: the sweep runs last so it sees
  // everything the set creates). It needs nothing from them — the table lives in
  // the `audit` schema with no tenant column by design, an estate-wide immutable
  // ledger protected by the mutation trigger and withheld UPDATE/DELETE rather
  // than by RLS — so the ordering costs it nothing.
  'db/migrations/20260813_audit_tamper_proof_log.sql',

  // ── Knowledge-graph tenant keys (added 2026-08-13) ────────────────────────
  // knowledge_graph_nodes / _edges / lumen_knowledge_graph_edges carried NO
  // tenant column and no RLS, while their siblings (extracted_graph_edges,
  // rag_knowledge_graph, section_graph_nodes) all carry organization_id WITH
  // RLS — drift, not design. server/routes/graphrag.ts writes document entities
  // into them and reads them back with no tenant predicate, so one tenant's
  // extracted entity names were reachable by another's semantic search.
  //
  // BEFORE the two isolation steps, like every other table-creating/altering
  // migration: the sweep must see the organization_id this adds. It is also why
  // the policy here and the sweep's cannot conflict — both are guarded on
  // pg_policies, so whichever runs first wins and the other no-ops.
  'db/migrations/20260813_knowledge_graph_tenant_keys.sql',
  // ── Tenant offboarding lifecycle ────────────────────────────────────────────
  // ADD COLUMN IF NOT EXISTS only, on `organizations` — a table that predates
  // every entry above — so it has no ordering dependency of its own.
  //
  // It sits BEFORE the two isolation steps because "the isolation steps are the
  // tail of the set" is an invariant, not a default: C-33 requires the integer
  // sweep to be the very last entry, and the uuid step immediately before it
  // (tests/schema-contract/tenant-isolation-sweep.contract.test.ts,
  // uuid-tenant-isolation.contract.test.ts). An earlier revision of this entry
  // sat after the sweep, reasoning that a migration creating no TABLE has
  // nothing for the sweep to policy and is therefore exempt. That reasoning is
  // true of THIS file and is still the wrong rule to encode: "sweep last,
  // always" holds without anyone having to audit each new entry for whether it
  // creates a table, and it is the version the contract tests enforce.
  'migrations/20260813_tenant_offboarding_lifecycle.sql',

  // ── AI gateway provenance ledger (added 2026-08-13) ──────────────────────
  // ai.gateway_audit_log had no migration at all. Its only creator was runtime
  // DDL in server/services/ai-gateway/audit.ts (`CREATE SCHEMA IF NOT EXISTS ai`
  // + CREATE TABLE), run lazily on the first persist and swallowed by a catch —
  // and Postgres checks database-level CREATE BEFORE the IF NOT EXISTS
  // short-circuit, so the non-superuser runtime role was refused on statement
  // one even though the `ai` schema already exists (059_gcc_vector_embeddings).
  // scripts/ci/tables-live-schema-baseline.json confirmed it against a real
  // provisioned database: absent. Every AI call reported itself audited and
  // wrote nothing.
  //
  // BEFORE the two isolation steps, like every other table-creating entry
  // (C-33). The sweep will find no organization_id to key on — the column is
  // VARCHAR(64), inherited from the runtime DDL and left alone here so the
  // writer's `organizationId?.toString()` bind keeps working — so it will SKIP
  // with a NOTICE rather than policy it. That is the intended outcome: this is
  // an operational ledger read by admin/ops surfaces across tenants, not
  // tenant-facing data.
  'db/migrations/20260813_ai_gateway_audit_log.sql',

  // (The parent-scoped child RLS, 20260813_child_table_parent_scoped_rls.sql,
  // stood here until 2026-09-29. It now runs in the isolation tail — see
  // CHILD_TABLE_PARENT_SCOPE — because here it ran before the uuid step and
  // before every table added below it, so a blank database's first deploy left
  // regulatory_harmonization.export_job_audit_log unscoped.)
  // Export receipts — what turns the purge's `finalExportDigest` precondition
  // from "a non-empty string was supplied" into "an export of THIS tenant was
  // actually produced". Creates one table, so it must precede the isolation
  // steps below (C-33: the sweep has to see everything the set creates).
  'migrations/20260813b_tenant_export_receipts.sql',

  // ── IVDR consolidation, D11d (added 2026-08-13) ───────────────────────────
  // ivdr_classifications was CREATE TABLE IF NOT EXISTS'd by three files with
  // two incompatible column shapes, so the surviving shape was decided by
  // migration order per environment (ledger C-29; duplicate-table-ddl
  // baseline). None of the IVDR creators was on THIS list, so an
  // already-provisioned database never received the tables at all and every
  // /api/ivdr surface 503'd or 500'd.
  //
  // ORDER MATTERS, and it is deliberately reconciliation-FIRST:
  //   20260813c  reconciles a pre-existing legacy (shape-1) table to the
  //              canonical shape — adds program_id BEFORE 20260508 attempts an
  //              index over it — backfills legacy → canonical column values,
  //              deprecates the legacy names, creates ivdr_gspr_assessments
  //              (previously runtime DDL), and hardens the module detail
  //              tables. Every statement no-ops where the tables are absent.
  //   20260508   THE canonical creator: ivdr_classifications (canonical
  //              shape), ivdr_per_documents, cdx_pairings/concordance,
  //              ivd_analytical_performance / ivd_clinical_performance, CLIA,
  //              LDT. All CREATE TABLE/INDEX IF NOT EXISTS — no-ops wherever
  //              push or history already provisioned them.
  //   001        the IVDR module detail tables (analytical validations,
  //              clinical evidence, CDx workflows + immutable histories) —
  //              FK-dependent on ivdr_classifications, hence after 20260508.
  //              Its rival shape-1 CREATE of ivdr_classifications is deleted,
  //              which is also what lets install-fresh apply it (it was
  //              classified-skipped before this consolidation).
  // All three precede the isolation tail (C-33) so the sweep policies the
  // org-keyed tables they create.
  'migrations/20260813c_ivdr_schema_reconciliation.sql',
  'migrations/20260508_ivd_diagnostic_surfaces.sql',

  // The MDX beta surfaces — `software_lifecycle_items` (IEC 62304 / FD&C §524B
  // software lifecycle), and the sibling of 20260508 above.
  //
  // It was on NO durable applier. `deploy-migrate` applies only this array, so
  // on every database provisioned by a deploy the table simply never existed —
  // which is exactly the `relation "software_lifecycle_items" does not exist`
  // the MDX UAT hit, rendered raw into the browser. Its IVD twin (20260508)
  // was listed and its tables were fine; the asymmetry is the whole bug.
  //
  // install-fresh created it anyway via the root-tree overlay, so a
  // locally-provisioned database looked healthy while every deployed one did
  // not. That divergence between "what a human ran" and "what a deploy runs" is
  // the failure mode this array exists to close.
  // …and the same asymmetry one level up: 20260507 declares
  // `q_submission_id uuid NOT NULL REFERENCES q_submissions(id)`, but the
  // migration that CREATES q_submissions was itself never listed. The child was
  // added to this set without its parent, so applying the set to a database
  // that has not had the root-tree overlay run against it fails outright with
  // `relation "q_submissions" does not exist` — exactly the divergence the note
  // above describes, one dependency deeper.
  //
  // install-fresh hides it because readdirSync applies the whole root tree and
  // 20260501 sorts before 20260507. Only deploy-migrate, which applies this
  // array alone, sees the gap — which is why the C-33 sweep contract (the one
  // test that replays this set against a blank database) is where it surfaced.
  //
  // Fully idempotent: every CREATE in it is IF NOT EXISTS, so it is a no-op on
  // any database the overlay already provisioned. The db/migrations/ copy is
  // byte-identical; the root-tree one is listed to match its dependent.
  'migrations/20260501_q_sub.sql',
  'migrations/20260507_mdx_beta_surfaces.sql',
  'migrations/001_create_ivdr_tables.sql',

  // ── The tenant key 20260813d indexes, which nothing ever created ─────────
  // electronic_signatures.organization_id is declared in shared/schema.ts and
  // REQUIRED by server/services/part11/signature-persistence.ts (it throws
  // without it), but no migration created it — the drizzle-push substrate and
  // this lineage had diverged. Two things were broken by that: 20260813d below
  // fails 42703 building its index, which takes out EVERY file after it in this
  // list including the isolation sweep; and the sweep skips tables with no
  // tenant column, so the Part 11 signature record sat unpoliced rather than
  // mis-policied. MUST stay immediately before 20260813d.
  'migrations/20260813c2_electronic_signatures_tenant_key.sql',

  // ── Single e-signature write path, D6 (added 2026-08-13) ─────────────────
  // The governed sign action (/api/c2c/actions/sign) now persists an
  // electronic_signatures row in the same transaction as its ledger write.
  // Governed targets are typed pointers, not documents rows, so this relaxes
  // document_id/version_id to nullable, adds signed_target + binding_basis,
  // and installs the fail-closed anchor CHECK. Additive; ALTERs only. MUST be
  // applied before code that writes signed_target/binding_basis is live —
  // both /api/esignature/sign and the governed sign fail closed (503/500)
  // until it lands.
  'migrations/20260813d_esignature_governed_unification.sql',

  // ── Program anchor, Document Identity Contract slice C1 (added 2026-08-14) ─
  // projects.regulatory_program_id — the column live code has assumed exists
  // for a long time and that NO migration created. mdx-vault.ts filtered on it
  // while claiming "added by the MDX migration", so every program-scoped Vault
  // request raised 42703 and 500'd. That is now an honest 422 until this lands,
  // and this is what lets the real filter come back.
  //
  // MUST be on this list, not merely in migrations/: the root tree reaches only
  // fresh databases, and it is the EXISTING ones whose governed exports are
  // landing audited-but-unplaced. CREATE TABLE IF NOT EXISTS cannot add a
  // column to a table that already exists, so the guarded ALTER here is the
  // only path by which it reaches them.
  //
  // Placed with the other pre-sweep entries (C-33: the two isolation steps are
  // the tail of the set, always). It creates no table, so the sweep has nothing
  // new to policy — `projects` is a base table policied long ago — and the
  // ordering costs it nothing. No dependency on any entry above: it ALTERs
  // `projects` (a drizzle-push base table deploy-migrate asserts as a sentinel)
  // and its backfill self-guards on regulatory_programs. (Corrected 2026-09-26:
  // this said that table's creator, 20260524_program_workbench_schema.sql, is
  // not on this path. It is entry 1 of this set.)
  'migrations/20260814_projects_regulatory_program_anchor.sql',

  // ── Literature screening trail, GA ledger L4 (added 2026-08-14) ──────────
  // literature_screening_decisions — the MEDDEV 2.7/1 Rev 4 include/exclude
  // appraisal record. Literature search and recording were already end-to-end,
  // but `literature_entries` is purely bibliographic (no status column, no
  // jsonb), so a reviewer's decision and its exclusion reason were lost with
  // the session and the write path said so out loud rather than faking it.
  // The screening trail is the part a notified body audits.
  //
  // MUST be on this list, not merely in migrations/: the root tree reaches only
  // fresh databases, and it is the EXISTING ones running clinical evaluations.
  // Until it lands, POST /api/cerv2/literature/screen refuses 422 with the real
  // reason (relation absent) — it never pretends to have persisted a decision.
  //
  // MUST stay ABOVE the isolation sweep below: this is the entry that creates a
  // NEW integer-keyed tenant table, and the sweep is what attaches
  // tenant_isolation_policy to it. Below the sweep it would be provisioned
  // cross-tenant readable under RLS_ENFORCE=on. No dependency on any entry
  // above — it is FK-free by the same reasoning as 20260814 (its parents
  // `literature_entries` and `regulatory_programs` differ in column type across
  // lineages / reach no durable applier respectively).
  'migrations/20260814b_literature_screening_decisions.sql',

  // ── GSPR catalog + post-market authoring, MDR/IVDR Annex I ───────────────
  // The route and Drizzle schema already exist in the application, but this
  // migration was never on a durable apply path. Keep it before PMCF
  // enrollment, whose records point to post-market documents by convention.
  'migrations/20260429_gspr_postmarket.sql',

  // ── PMCF enrolment progress, GA ledger L5 (added 2026-08-14) ─────────────
  // pmcf_enrollment_records — the EU MDR Annex XIV Part B §6.2 / MDCG 2020-7
  // execution evidence behind the CER's post-market section. The PMCF PLAN was
  // already real (post_market_documents + pmcf-plan-generator.ts); what a
  // notified body actually audits is plan-vs-actual — which activities were
  // committed to, how many subjects are enrolled against each planned sample
  // size, as of when. That had no backend at all, so the workbench rendered kit
  // fixtures behind the sample gate and said so in prose.
  //
  // MUST be on this list, not merely in migrations/: the root tree reaches only
  // fresh databases, and it is the EXISTING ones carrying CE-marked devices
  // under active follow-up. Until it lands, the read path answers 422 naming
  // the unapplied migration and the write path refuses — neither pretends.
  //
  // MUST stay ABOVE the isolation sweep below: this creates a NEW integer-keyed
  // tenant table and the sweep is what attaches tenant_isolation_policy to it.
  // Below the sweep it would be provisioned cross-tenant readable under
  // RLS_ENFORCE=on. No dependency on any entry above — FK-free by the same
  // reasoning as 20260814b, and for a stronger reason: BOTH of its would-be
  // parents (`regulatory_programs`, `post_market_documents`) are absent from
  // this list, so a REFERENCES would abort the whole set on any database
  // missing either.
  'migrations/20260814c_pmcf_enrollment_records.sql',

  // ── Document alias map, GA ledger L10 / identity contract slice C2 ───────
  // c2c_document_aliases — the identity-only bridge between a canonical
  // document uuid and each store's native key. Fixes consequences 3 and 4 of
  // docs/DOCUMENT_IDENTITY_CONTRACT_2026-08.md: a filed snapshot can record
  // real lineage back to its source instead of prose, and editor deep-links
  // resolve by identity rather than by title — title matching is not identity,
  // since two sections legitimately share a title and a rename breaks the link
  // silently.
  //
  // HOLDS NO ATTRIBUTES, and that is the whole design. The registry that owned
  // identity AND metadata AND placement was built here once and reverted
  // because it competed with the stores that already own those things. The
  // invariant is enforced by scripts/ci/check-document-alias-attribute-free.mjs
  // rather than by intention — the way it would erode is one reasonable-looking
  // column at a time, not a decision to rebuild the registry.
  //
  // MUST stay ABOVE the isolation sweep below: a NEW integer-keyed tenant table
  // that the sweep attaches tenant_isolation_policy to. Below it, the table
  // would be provisioned cross-tenant readable under RLS_ENFORCE=on — and a
  // caller who knows a native id would learn another tenant's canonical
  // identity. FK-free by the same reasoning as its neighbours, and for a
  // reason particular to it: `native_id` is text precisely because it addresses
  // several stores with different key types, so it could not carry a REFERENCES
  // even if every target table were present on every database.
  'migrations/20260814d_document_alias_map.sql',

  // ── cerv2_section_versions.updated_at (added 2026-08-17) ────────────────────
  // Reconciles the SQL lineage with shared/schema.ts, which declares this
  // column while no migration created it. section-version.ts enumerates
  // `updated_at` in its INSERT, so on a migration-provisioned database every
  // POST /api/cerv2-sections answered 500 (42703 at PLAN time) while a
  // drizzle-push database worked — the two provisioning paths disagreed, and
  // only one of them is what deployment runs. ADD COLUMN IF NOT EXISTS,
  // nullable with a default, guarded on the table existing so an environment
  // without the CERV2 bundle no-ops instead of aborting a stopOnFirstFailure run.
  'migrations/20260817_reconcile_declared_updated_at_columns.sql',

  // ── Submission leaf source pin, GA ledger L23 (added 2026-08-14) ─────────
  // Two nullable columns on submission_leaves recording the SHA-256 of the
  // source document's content at the moment a leaf was filed, and when that was
  // taken. The leaf already carried `document_id` (which resolves to the
  // document as it is NOW) and `checksum` (MD5 of RENDERED bytes, for the eCTD
  // index) — neither answers "is the document behind this filed leaf still what
  // went to the agency?".
  //
  // ADD COLUMN only, no backfill, and the absence of a backfill is the point: a
  // pin computed today from current content would manufacture agreement for
  // every existing leaf, including any whose document has since been edited —
  // exactly the case the column exists to detect. Pre-existing leaves report
  // "not pinned", which is true.
  //
  // Position is not load-bearing (it creates no table, so the isolation sweep
  // below has nothing to attach), but it stays with its siblings above the
  // sweep for readability.
  'migrations/20260814e_submission_leaf_source_pin.sql',

  // ── Section version AnA backlink, GA ledger L36 (added 2026-08-14) ───────
  // CREATE OR REPLACE of c2c_snapshot_section_version() so the version trigger
  // writes ana_action_id — a column declared in the Phase-9 schema with a FK to
  // c2c_ana_actions and written by nothing since, leaving "which AnA action
  // produced this version?" permanently unanswerable.
  //
  // Function replacement only: no table, no column, no data. It MUST run after
  // the Phase-9 schema that defines the original function, which it does by
  // position. The trigger resolves the id against c2c_ana_actions before using
  // it and writes NULL otherwise, so a stale GUC can never turn a section save
  // into an FK violation.
  'migrations/20260814f_section_version_ana_action_backlink.sql',

  // ── Section version reason required, GA ledger L34 (added 2026-08-14) ────
  // Another CREATE OR REPLACE of c2c_snapshot_section_version(), so it MUST run
  // after 20260814f — it carries that migration's ana_action_id handling
  // forward and adds the reason check on top. Position, not luck: replacing
  // these out of order would silently drop the backlink.
  //
  // The trigger now RAISES on a missing reason exactly as it already did on a
  // missing actor, instead of COALESCEing to the literal 'content change'. Both
  // current writers guarantee a non-empty reason, so nothing in the product can
  // trip it; it exists for the next writer. Function replacement only — no
  // table, no column, no data, and existing placeholder rows are left alone
  // because they truthfully record that nothing was captured.
  'migrations/20260814g_section_version_reason_required.sql',

  // ── An unstated author is recorded as unspecified, not as a human ──────────
  // The same fix as 20260814g one column over: the section save defaulted an
  // omitted `draftSource` to 'human' and the trigger's CASE fell through to
  // 'human' for NULL, so a save that said nothing about where its text came
  // from filed a version row asserting a named person wrote it. MUST stay last
  // of the five definitions of c2c_snapshot_section_version() — it is built on
  // 20260814g's body and carries its mandatory-reason RAISE.
  'migrations/20260822_section_version_author_kind_unspecified.sql',

  // ── A revised source document is linked to the one it replaces (L21) ───────
  // checksum is written once and never updated, so a revision is ingested as a
  // wholly NEW row with nothing pointing back at what it replaced. That made
  // the Source Tracer's "changed since cited" branch unreachable. Additive
  // columns only, and no backfill: nothing in the existing data says which row
  // superseded which, and inferring it would manufacture a lineage the system
  // never observed.
  'migrations/20260829_cre_source_versioning.sql',
  // VR-16 (D2/D5): the data room's capture record is append-only. Triggers on
  // cre_evidence_sources (checksum and lineage write-once, retirement one-way,
  // no TRUNCATE, DELETE only by the owner). After the file that adds its
  // versioning columns; no table, no column, no DROP.
  'migrations/20261001_cre_evidence_sources_capture_immutability.sql',

  // Constraint repair only: no table, no column, no data. 0001_phase13_full
  // meant to widen concept2cure_review_tasks.task_type to include
  // 'approval_task' but added a second CHECK instead of replacing phase13's
  // inline one, so the effective domain stayed the intersection and the value
  // was never insertable. Must run after both of those, which it does by
  // position. Widening a CHECK cannot invalidate an existing row.
  'migrations/20260814h_review_task_type_domain_repair.sql',

  // ── Draft generator capture, GA ledger L33 (added 2026-08-14) ────────────
  // ADD COLUMN on authoring_ai_draft_candidates so a parked AI draft carries
  // what produced it — model, provider, and a SHA-256 of the prompt actually
  // sent. All three existed at draft time and reached only the browser, so
  // "what produced this text?" survived about as long as the tab.
  //
  // Server-side with the source chunks, deliberately: a generator round-tripped
  // through the client would be a client claim, and which model wrote a
  // regulatory section is exactly the sort of claim that must not be forgeable.
  //
  // Nullable, no backfill. Nothing recorded the generator for earlier drafts,
  // and filling it from the model registry's current default would attribute
  // text to a model that may never have seen it. The table has a 2-hour TTL, so
  // the unrecorded window closes on its own.
  'migrations/20260814i_draft_candidate_generator.sql',

  // ── Draft candidates carry the model's paraphrase assertions (Phase 4) ──────
  // Adds `assertions` JSONB alongside the parked chunks + generator: the model's
  // self-reported [{quote, sourceId}] claims about which source it DERIVED a
  // passage from. The accept path records each still-present, still-resolvable
  // claim as a usage='paraphrased' span — an assertion, never a verified quote,
  // and only for a source that was actually retrieved. Nullable, no backfill; the
  // 2-hour TTL closes the unrecorded window on its own. ADD COLUMN IF NOT EXISTS,
  // so re-running is a no-op.
  'migrations/20260906c_draft_candidate_assertions.sql',

  // ── Span lineage: accepted machine drafts are the machine's, not the author's ─
  // Every governed write recorded each clause it could not tie to a Data Room
  // source as the human actor's `author_assertion` — including the clauses AnA
  // drafted and the human merely accepted — so the Data Origins panel and PDF
  // read "Asserted by the author" over model prose. Adds the
  // `accepted_machine_draft` kind (machine_author_id + the accepting human) by
  // widening the two CHECKs with the DROP CONSTRAINT IF EXISTS / ADD CONSTRAINT
  // idiom (RULE 1: a CHECK holds no data; re-running converges) and ADD COLUMN
  // IF NOT EXISTS. Must run after db/migrations/20260803 (the table), which it
  // does; guarded on the table existing.
  'migrations/20260907_span_lineage_accepted_machine_draft.sql',

  // ── Span lineage: a machine draft nobody has accepted is not an assertion ──
  // 20260907 covered the human-accepted case. AnA's own tool writes were the
  // worse one: write_q_sub_section inserts draft_source='ana', accepted_at=NULL
  // and answers "Awaiting human accept", then recorded every clause as the
  // REQUESTING user's author_assertion in the same transaction — two records of
  // one act contradicting each other. Adds the `machine_draft` kind, whose
  // CHECK requires asserted_by/asserted_at to be NULL: nobody has stood behind
  // it, and no later caller can quietly fill that in. Supersedes 20260907's two
  // CHECK definitions, so it must run after it — it does.
  'migrations/20260908_span_lineage_machine_draft.sql',

  // ── Apps catalog additions, GA ledger L40 (added 2026-08-14) ─────────────
  // Eight built, routed, API-backed surfaces that appeared in no catalog, so a
  // user could reach them only by knowing the URL. INSERT … ON CONFLICT DO
  // NOTHING, so re-running is a no-op and an entry an operator has since edited
  // keeps their version rather than being reset.
  //
  // Position is not load-bearing (no table, no column), but it must run after
  // the 2026-08-10 reconcile that seeds the rest of the catalog, which it does.
  // Guarded on available_modules existing, since the catalog table is not on
  // every lineage.
  'migrations/20260814j_catalog_missing_product_surfaces.sql',
  'migrations/20260814k_catalog_mission_control.sql',
  'migrations/20260814l_catalog_filing_strategy.sql',
  'migrations/20260814m_regulatory_intel_platform_tier.sql',
  'migrations/20260814n_seed_regulatory_intel_platform_knowledge.sql',

  // Same guard: descriptions only, no module added or removed (ledger L41).
  'migrations/20260814m_catalog_honest_module_descriptions.sql',

  // The document-approval workflow tables. Declared as Drizzle models in
  // shared/schema/unified_workflow.ts and read by six services, but created by
  // nothing: `drizzle-kit push` reads only shared/schema.ts, which does not
  // re-export that module, and no raw migration creates them either — the
  // three files that mention `document_workflows` only index or add policies
  // TO it. GET /api/approval-workflows/pending answered 500 on every request.
  'migrations/20260815_workflow_approval_tables.sql',

  // Retires the duplicate 'ind-lifecycle' catalog row added by 20260814j: the
  // same IndLifecycle surface was already catalogued as 'ind-checklist', so one
  // module was listed — and separately entitleable — twice. Deprecates rather
  // than deletes (organization_modules cascades).
  'migrations/20260814o_catalog_retire_duplicate_ind_lifecycle.sql',

  // ── 21 CFR Part 11 §11.10(e): audit trail immutability, at the DB engine ──
  // Both files were authored, reviewed, and left UNREACHABLE. Neither carries the
  // `_gcc_` infix the psql loop matches, and neither was in this list — so no
  // apply path installed them, and `audit_events` / `audit_logs` were MUTABLE on
  // every deployed database while the platform reported the control as present.
  // `provision-app-role.mjs` grants the runtime role the default
  // ['SELECT','INSERT','UPDATE','DELETE'] on `public`, where both tables live,
  // so the application role itself could rewrite audit history.
  //
  // The reachability CI check did not catch it: it only flags migrations whose
  // sole-created TABLE is unreachable, and these create only triggers.
  //
  // Safe to install (verified against the tree, not assumed):
  //   * INSERT is untouched — the chained writer only ever INSERTs.
  //   * No production code UPDATEs either table. The only UPDATEs are PGlite
  //     tests that build `audit_logs` inline with their own CREATE TABLE (so they
  //     never see these triggers) and scripts/db-verify/verify-audit-chain.ts, a
  //     manual tamper-demo not wired into CI.
  //   * Nothing TRUNCATEs either table anywhere in the repo.
  //   * DELETE on audit_logs stays possible for the retention/archival service
  //     only, via the fail-closed `app.audit_archive_bypass` GUC it already sets
  //     with SET LOCAL on one dedicated connection.
  // Ordered BEFORE the tenant-isolation sweeps, which must remain last (C-33).
  /* The hash chain the immutability triggers below were meant to protect.
     Added 2026-09-10; it had been on NO applier — not _gcc_-named so not
     install-fresh step 6 or the CI psql loop, not in the root migrations/ tree
     so not the step-3 overlay, not matching db_migrate.sh's 0NN_ glob, and not
     in this list. Verified against a canonically provisioned database: the
     three immutability triggers are present and trg_audit_events_hash_chain is
     absent, as is the audit_events_hash_chain() function.

     So the immutability half of the Part 11 audit design shipped and the
     integrity half did not, and 20260617_audit_events_hmac_seal.sql below seals
     rows whose chain columns are never populated. Every chain surface therefore
     reports 'unverified' on a canonical database — correctly, since no row
     carries a record_hash (server/services/audit/signedAuditExport.ts counts
     hashed vs unhashed rather than reporting 'intact' over an unchecked chain).

     Ordered BEFORE the immutability entry because the chain must exist before
     the table is sealed against modification. Its backfill was REMOVED as part
     of this change — see the header of that file for why; in short, hashing
     historical rows from their current contents manufactures an integrity
     claim, and the UPDATE it used would have raised P0A01 against the
     already-deployed no-update trigger. */
  'db/migrations/20260222_audit_events_hash_chain.sql',

  'db/migrations/20260222_audit_events_immutability.sql',
  'db/migrations/20260617_audit_logs_immutability.sql',

  /* The charter-domain audit trail's own immutability, added 2026-09-11.
     Same shape as the two entries above and the hash chain below them: an
     append-only guarantee that a fresh install had and no replaying applier
     re-asserted.

     WHAT IS AND IS NOT WRONG HERE — WO-15 finding 3 says the four charter
     tables "are on no deploy path" and so "may not exist" on a populated
     database. The second half is WRONG and is corrected in that work order:
     project_charters, charter_sections, timeline_phases, project_commitments
     AND charter_audit_events all EXIST on a canonically provisioned database —
     verified by querying one.

     CORRECTED 2026-09-17: this entry used to add "so drizzle-kit push creates
     them at install-fresh step 2". That is FALSE. They are declared in
     shared/schema/project-charter.ts, but drizzle.config.ts names only
     shared/schema.ts, ana-intelligence.ts and report-os.ts, and
     project-charter.ts is re-exported from shared/schema/index.ts, which is not
     an entrypoint and is not reachable from one — the same NOT-re-exported
     pattern already noted at the two entries above. The charter tables are
     outside the push surface entirely. They come from install-fresh's step-3
     overlay: 0012_project_charter_timeline.sql for project_charters, and
     20260629_charter_tables_rebuild.sql for the other four.

     The fix below is unaffected — it is guarded on the table existing, not on
     what created it — but the reason it gives was wrong, and a wrong reason is
     how the next person reaches a wrong conclusion. The consequence of the real
     mechanism is WO-15 finding 2: project_charters is frozen at 0012's 27
     columns while the declaration names 48.

     What Drizzle CANNOT express is a trigger. charter_audit_events_no_update
     and charter_audit_events_no_delete existed only in
     migrations/20260629_charter_tables_rebuild.sql, which runs on install-
     fresh's overlay and nowhere else — so a database deploy-migrate maintains
     has the audit table and none of its protection, and if either trigger is
     dropped by a restore or a schema tool, nothing puts it back and the charter
     audit trail silently becomes mutable.

     WHY THE SMALL FILE AND NOT THE REBUILD. Listing 20260629 itself was tried
     first and is WRONG, for a reason its live-database proof could not reach:
     the rebuild is NOT self-contained. It has five REFERENCES
     project_charters(id) clauses and does not create project_charters — that
     table comes from drizzle push, and nothing in this set creates it.
     Applying the set in order to a database that has not been pushed dies at
     the first FK with `relation "project_charters" does not exist`.
     tests/schema-contract/tenant-isolation-sweep.contract.test.ts C-33 applies
     the set exactly that way and caught it; the live proof passed only because
     that database already carried project_charters from install-fresh, so it
     could not expose a dependency the set does not satisfy.

     And the rebuild's other 367 lines buy nothing: every table it creates is
     CREATE TABLE IF NOT EXISTS against a table push has already made, so the
     DDL no-ops on any real database. The function and the two triggers are the
     whole delta. Carrying the rest would put a second, independent definition
     of four Drizzle-owned tables on the replaying applier in exchange for
     nothing. So the triggers are lifted verbatim into the guarded file below
     and 20260629 stays on install-fresh only.

     NEVER add migrations/20260611_drop_charter_staging_tables.sql to the set.
     It DROPs project_commitments, charter_sections and timeline_phases — RULE
     1's create-then-drop hazard exactly: replayed every deploy, it would
     destroy those tables' contents every time, green.

     Replay-safety: CREATE OR REPLACE FUNCTION is idempotent and each trigger is
     DROP … IF EXISTS then CREATE in the same file, the idiom
     check-migration-drop-safety.mjs recognises. The trigger installs are
     guarded on charter_audit_events existing, so the file is a documented
     no-op — RAISE NOTICE, no claim of immutability — on a database that lacks
     the table, which is what makes it self-contained where the rebuild was not.

     NOT claimed: this converges no column. It installs enforcement, nothing
     else; databases whose shape came from push keep that shape. */
  'migrations/20260911_charter_audit_immutability.sql',

  /* contradiction_consequence_log / contradiction_findings — column
     convergence, added 2026-09-11 (WO-15 finding 7).

     db/migrations/20260323_assumption_decision_contradiction.sql (index 42
     above) was amended in place the same day: its consequence-log column
     `execution_notes` renamed to `notes`, and a `detected_by TEXT NOT NULL
     DEFAULT 'system'` reduced to plain `TEXT`. Both sit inside CREATE TABLE IF
     NOT EXISTS blocks, so the amendment governs only a database that does not
     yet have the tables. This file is the other half: the ALTERs that reach a
     database which already does.

     The column name mattered because four INSERTs in
     contradiction-resolution-orchestrator.ts named `execution_notes` and no
     provisioned database has ever had that column — deploy-migrate refuses an
     unprovisioned database, so install-fresh builds them all and its overlay's
     migrations/20260524_contradiction_engine_schema.sql creates the table with
     `notes`. 20260323 then runs against an existing table and no-ops. Those
     four writes raised 42703 every time, into catch blocks that discard the
     error, on a table nothing ever reads. Confirmed by executing one verbatim
     against a canonically provisioned database.

     The default mattered because no code writes detected_by, so 'system' would
     be an attribution nothing recorded.

     Expected to be a no-op on every real database — that is what the guards
     and the IF NOT EXISTS are for, and why it is safe to carry. */
  'migrations/20260911_contradiction_consequence_log_convergence.sql',

  /* The SAME §11.70 seal column on audit_events, the SIEM/export-facing audit
     table. 20260609 added it to audit_logs and is on the applier; this one was
     not, so server/services/audit/chain.ts's verifyAuditEventsChainSeals —
     SELECT … hmac_seal FROM audit_events — raises 42703 on every deployed
     database, and no audit_events row can ever carry a seal. Measured
     2026-09-08 against a database built by install-fresh plus the whole set.
     Fully guarded (table and column existence checked) and idempotent. */
  'db/migrations/20260617_audit_events_hmac_seal.sql',

  // ── AnA's own memory: the tables her selfhood writes to (added 2026-08-20) ──
  // All three sat in the root migrations/ tree on NO durable apply path: not
  // journaled, not `_gcc_`, not in this set — so install-fresh's overlay was the
  // only thing that ever created them, i.e. fresh installs only. On every
  // database maintained by deploy-migrate:
  //   * ana_relational_profiles (20260612) did not exist. Both halves of
  //     relational-profile-service swallow the resulting 42P01, so AnA's
  //     per-user/per-project relational memory — the RELATIONAL CONTEXT block
  //     her personality core promises — was silently dead, along with the
  //     external_intelligence_findings/runs tables the nightly sweep writes.
  //   * conversation_working_memory.embedding (20260602) did not exist, so
  //     ENABLE_SEMANTIC_WORKING_MEMORY could never actually embed (the writer
  //     probes the column and quietly falls back to recency-only).
  //   * 20260820 is new with this change: project attribution on thread-keyed
  //     working memory, which is what makes the live AnA chat path's rows
  //     eligible for nightly consolidation into project_memory_entries at all.
  //     It also owns the CREATE TABLE IF NOT EXISTS for conversation_working_
  //     memory (a push-surface table no journal file creates), so it runs
  //     FIRST — 20260602's ALTER needs the table to exist on a set-only
  //     database. 20260602 stays pgvector-dependent (vector(1536) column):
  //     PGlite harnesses must name it alongside the C-37 trio; real-cluster
  //     coverage is verify-migration-set.mjs, same as those.
  // Ordered before the tenant-isolation sweeps so ana_relational_profiles and
  // conversation_working_memory get tenant policies from the same run that
  // creates them. The external-intel tables are global by design (no
  // organization_id) and are skipped by the sweep. All three files are
  // IF NOT EXISTS-idempotent and safe on databases where install-fresh
  // already applied them.
  'migrations/20260820_working_memory_project_id.sql',
  'migrations/20260602_working_memory_embeddings.sql',
  'migrations/20260612_ana_relational_external_intel.sql',

  // ── RIM learned patterns get real tables (added 2026-08-20, ledger L70→) ──
  // Graduates the learning loop's persistence from a JSON blob in
  // project_memory_entries (the documented stopgap) to per-pattern rows with an
  // append-only observation trail — the shape a Part 11 reviewer can actually
  // inspect. The loader lazily imports any blob the stopgap wrote, so nothing
  // learned in the interim is lost. Ordered before the sweep so both tables are
  // policied in the deploy that creates them.
  'migrations/20260820b_rim_learned_patterns.sql',

  // ── AnA outcome log + capability registry (added 2026-08-20, ledger L77) ──
  // ana_outcome_log is READ by session bootstrap ("AnA's past lessons") and
  // now WRITTEN by the feedback interceptor — and the whole 0013 family sat on
  // no durable apply path (fresh-install overlay only), so on deploy-migrated
  // databases the reader queried a missing table and the writer would have
  // too. Fully IF NOT EXISTS-idempotent; its trailing DO block is guarded on
  // project_intelligence_profiles actually existing, so it is safe on a
  // set-only database where that push-surface table never appears. Ordered
  // before the sweep so the org-scoped tables get tenant policies.
  'migrations/0013_ana_intelligence_system.sql',

  // ── The v2 module-catalog seed joins the durable path (found via BP-W1-5) ──
  // db/migrations/20260810_reconcile_module_catalog.sql seeds/reconciles the
  // v2 Apps catalog (available_modules) — including the maa-cockpit row the
  // update below edits — and sat on NO apply path: not in this set, not in
  // install-fresh's overlay, not gcc-named. Merged ≠ applied, the exact drift
  // this list exists to close. Idempotent (ON CONFLICT (module_id) DO UPDATE).
  'db/migrations/20260810_reconcile_module_catalog.sql',

  // ── provision_org_modules() repair (added 2026-08-23) ──────────────────────
  // Two defects, each of which masks the other. The function called
  // jsonb_array_elements_text() on available_modules.metadata, which is `json`
  // — no implicit cast exists, so it raised on EVERY call and
  // POST /api/module-subscriptions/provision has never written a row. And its
  // tier test was `=` rather than `>=`, so with the cast fixed a professional
  // org would receive professional modules but NOT standard ones — an inverted
  // ladder, disagreeing with provisionModulesForTier, getModuleCatalog and
  // canAccessModule, all three of which are inclusive.
  //
  // Ordered after the catalog reconcile above (it reads available_modules) and
  // after 20260220_user_intelligence_platform.sql, which first defines the
  // function. Function bodies only — no DDL, nothing for the sweep to policy.
  'db/migrations/20260823_fix_provision_org_modules_tier_ladder.sql',

  // ── Commercial packaging applied to the catalog (added 2026-08-23) ────────
  // 20260810 seeded all 84 modules unrestricted and said the tiering was "a
  // business decision ... deliberately left to be applied later". This applies
  // it: one min_tier per module, derived from boundaries already committed in
  // billing.ts PRICING[].features, license-manager.ts FEATURE_TIER_MAP and
  // entitlements/mdx-entitlements.ts. Data-only, no DDL. MUST come after the
  // provision_org_modules repair above — before it, a non-empty `tiers` is what
  // the broken function chokes on.
  'db/migrations/20260823_module_catalog_commercial_packaging.sql',

  // ── Catalog descriptions become customer copy (added 2026-08-23) ──────────
  // The 20260810 seed copied each surface's registry `notes` verbatim into
  // `description`, which the Apps catalog renders to CUSTOMERS — so 33 of 84
  // cards told a prospect the product was unfinished ("In progress.",
  // "Partially built in ui_kits/home") or leaked repository internals.
  // Display text only; nothing keys on it. scripts/ci/check-catalog-copy.mjs
  // stops it recurring.
  'db/migrations/20260823_module_catalog_customer_copy.sql',

  // ── The two MDX design registers finally get catalog rows (2026-08-23) ────
  // `design-controls` and `human-factors` are built, reachable surfaces with no
  // row in available_modules, so they were unsellable (no tier can name a module
  // that is not in the catalog), ungatable (module_subscriptions FKs into it, so
  // an admin decision about them could not even be written down) and, by the
  // client's correct "an unknown id is not licensable" rule, silently free on
  // every tier. The 20260810 seed missed them because it was derived from
  // SEGMENT_MODULES and both ids sit in NAV_HIDDEN instead.
  //
  // POSITION IS LOAD-BEARING — it must stay after BOTH the catalog seed and the
  // packaging migration, and this is why. 20260810 step 1 stamps
  // {"deprecated": true} on every catalog row absent from its protected id list,
  // and these two ids are absent from it, so every re-apply retires them again.
  // The packaging file then raises 'catalog modules with no tier assigned' for
  // any LIVE row its fixed 84-id list does not name — which these two are not.
  // The two cancel only in this order: the seed's retire step hides the rows
  // from the packaging assertion, and this file, running last, clears the flag
  // and restores them with their own tier and their own customer copy. Verified
  // by execution both ways — packaging applies clean with the flag set, and
  // raises on exactly these two ids when they are live.
  //
  // Moving this entry above the packaging migration therefore breaks the next
  // deploy. The tidier end state is one change to two files that are not this
  // one: add both ids to 20260810's protected list AND to the packaging file's
  // module_packaging list. Doing only the first breaks the deploy.
  'db/migrations/20260823_module_catalog_mdx_registers.sql',

  // ── CMC / Module 3 moves to the professional band (pricing decision) ──────
  // MUST stay after the reconcile (resets tiers to []) and packaging (sets
  // 'standard') entries above — the professional band is the final catalog
  // word on cmc. Grandfathers exactly-standard orgs with explicit grants
  // BEFORE the band moves, so no entitled org loses the filing path.
  'db/migrations/20260824_cmc_professional_tier.sql',

  // ── BP-W1-5: the MAA cockpit catalog row stops calling Module 1 one thing ──
  // Name + description only (adds Swissmedic to the modeled-agency list); no
  // entitlement change. Idempotent UPDATE keyed on module_id.
  'migrations/20260820c_catalog_maa_module1_regional.sql',

  // ── The submission-orchestrator catalog row is retired (2026-09-07) ───────
  // This entry briefly SEEDED that row, for a surface that should never have
  // been created: `ectd-compile` is already the assemble-the-submission
  // surface, so a second one was the parallel path the zero-duplication rule
  // forbids. The surface is deleted and its panels folded into EctdCompile;
  // the file is amended IN PLACE to deprecate the row rather than seed it
  // (RULE 1 — a follow-up DROP in a set that replays every deploy either
  // reverts or re-creates-then-removes forever).
  'db/migrations/20260907_module_catalog_submission_orchestrator.sql',

  // Moved here from AFTER the sweep, where it was appended upstream. C-33 and
  // three contract tests require the two isolation steps to be the final pair;
  // a file that ALTERs tables after the sweep has run is never swept. This one
  // reshapes vault.documents, so it has to precede them like everything else.
  // ── W0-6: vault.documents had two definitions and the wrong one won ───────
  // 044c_gcc_vault_schema.sql creates an 11-column table with CREATE TABLE IF
  // NOT EXISTS; shared/schema/vault.ts declares the 28-column shape the product
  // is written against. The migration runs first, so the model's version is a
  // silent no-op and POST /api/vault/ingest — the only endpoint that persists
  // bytes + a SHA-256 — INSERTs sixteen columns that do not exist. Every
  // document upload 500s. This reconciles the table additively; it must run
  // AFTER 044c, which the overlay applies.
  'migrations/20260821_vault_documents_canonical_shape.sql',

  // ── Vault filing: dossier placement on vault.documents ─────────────────────
  // Adds folder_id / evidence_kind / ctd_section / placement_status (+
  // confidence, rationale, placed_by/placed_at) so every ingested document
  // carries a dossier placement: the classifier proposes ('suggested'), a
  // person confirms or moves ('confirmed', audited), and the unplaceable stay
  // visibly 'unfiled'. Additive, guarded on to_regclass('vault.documents');
  // must run AFTER the canonical-shape reconciliation above.
  'migrations/20260823_vault_document_placement.sql',

  // ── Document catalog: comprehension + read-coverage on vault.documents ────
  // Two tables. vault.document_catalog records per document HOW its text was
  // extracted (or the recorded reason extraction failed — a failure is a row
  // that says so, never an absent row) and, once AnA has read the whole file,
  // WHAT it is: kind, purpose, summary, key_data, embedding.
  // vault.document_read_receipts records every character span AnA was served,
  // keyed to content_hash; the catalog write refuses below full coverage, so a
  // sampled page can never be recorded as "reviewed". Additive, guarded on
  // to_regclass('vault.documents'); must run AFTER the canonical-shape
  // reconciliation and placement entries above (same table, same discipline).
  'migrations/20260905_document_catalog.sql',

  // ── Vault passage retrieval: the chunk store the RAG reader queries ───────
  // advancedRAGPipeline's 'vault' corpus reads vault.document_chunks, which
  // existed only in the drizzle install-fresh baseline — on every deploy-
  // migrated database the platform's default retrieval corpus had no table at
  // all. Creates it durably with the reader's exact shape + indexes, carries
  // its own RLS policy set (070_gcc only runs on fresh installs), and adds the
  // chunk_status/chunk_count/chunk_error ledger to vault.document_catalog so
  // a document whose passages could not be indexed says so. Must follow the
  // catalog entry above (it ALTERs that table); additive and guarded like it.
  'migrations/20260905b_vault_document_chunks.sql',

  /* execution_evidence on the GDPR data-subject-request table. Written
     2026-09-05 and left off the applier, so gdprComplianceService's
     `UPDATE gdpr_data_subject_requests SET … execution_evidence = $2` raises
     42703 — every DSAR completion fails on a deployed database. Additive,
     to_regclass-guarded, idempotent. */
  'db/migrations/20260905_gdpr_dsar_execution_evidence.sql',

  // ── Time-limited module grants ─────────────────────────────────────────────
  // Adds a nullable `expires_at` (+ who set it, when) to module_subscriptions,
  // so a grant can be opened until a date instead of only on or off. Strictly
  // additive: every pre-existing grant keeps NULL and stays perpetual.
  //
  // Entitlement resolution reads the column at read time — nothing sweeps these
  // rows — so `server/services/license-manager.ts` SELECTs it and this entry
  // must be applied before that code is deployed, or getLicenseInfo throws on a
  // missing column and fails every org closed.
  'db/migrations/20260824_module_grant_expiry.sql',

  // ── Access requests from a locked module ──────────────────────────────────
  // The route is live and reads/writes module_access_requests. The migration
  // therefore belongs on the same durable deploy path as the route, before the
  // final tenant-isolation sweep so its integer organization_id receives the
  // standard RLS policy in the same run. Keeping the SQL in db/migrations/
  // without this entry creates a deploy-dead table definition: unit tests pass,
  // while every real request fails with 42P01.
  'db/migrations/20260824_module_access_requests.sql',

  // ── The enforcement mode becomes a governed setting ───────────────────────
  // Creates platform_settings, the store the Master Licensing console writes
  // the route-enforcement mode into. Seeds NO row: an empty table means the
  // deployment's own configuration still decides, so applying this changes no
  // deployment's behaviour. Read by
  // server/services/entitlements/enforcement-mode.ts, which treats a missing
  // relation as "nothing stored" — so applying it late is safe, but until it is
  // applied the console cannot store a decision.
  'db/migrations/20260824_enforcement_mode_setting.sql',

  // ── Both entries below must precede the two isolation steps ────────────────
  // The last two entries of this list are, and must remain, the uuid non-public
  // step and the integer sweep — C-33 requires the sweep to see everything the
  // set creates, and uuid-tenant-isolation.contract.test.ts pins both into the
  // final pair. The tenant column added below has to come under the sweep, and
  // the cast heal has to establish the guarded identity.current_org_id() before
  // the uuid step creates policies that call it. So they sit immediately before
  // the pair, never inside it.
  // ── regulatory_twin_simulations gets a tenant key ───────────────────────────
  // The table had none, and the route listed from it with no predicate, so every
  // tenant's stored submission_profile was visible to every tenant. Adds
  // organization_id (+FK, +index) and tightens it to NOT NULL when no row is left
  // unattributed. Ordered before the sweep so the new integer tenant column comes
  // under tenant_isolation_policy in the same run.
  'db/migrations/20260821_regulatory_twin_simulations_tenant_scope.sql',

  // ── uuid org-GUC cast heal (must precede the sweep's own run) ───────────────
  // Repoints every policy that casts app.current_org_id straight to UUID at the
  // guarded identity.current_org_id(), and re-asserts that function's guarded
  // body. Needed on the deploy path specifically: the fixed definitions live in
  // the governed-content tree, which deploy-migrate does not apply, so an
  // existing database would keep raising `invalid input syntax for type uuid: ""`
  // on every super-admin / null-orgUuid scope. Idempotent — it matches nothing
  // once the inline casts are gone.
  'db/migrations/20260821_uuid_org_guc_cast_heal.sql',

  // core.get_program_org_id must resolve the canonical program registry
  // (regulatory_programs → organizations.uuid), or every vault.documents RLS
  // policy denies the runtime role on a fresh install (core.programs is empty
  // there). Proven by tests/db/vault-ingest.dbtest.ts.
  'db/migrations/20260828_program_org_resolution_canonical.sql',

  // ── Orphaned org-GUC policies on the IND section-tracking tables ───────────
  // 20260220_ind_section_tracking.sql created five *_org_policy policies keyed
  // on `app.organization_id`, a GUC nothing in the application sets — so they
  // have never granted anyone access. They are not an outage (the canonical
  // tenant_isolation_policy is PERMISSIVE and ORs alongside them, measured: own
  // org sees its row, another org sees none) but their cast is unguarded, so
  // one `set_config('app.organization_id','')` anywhere takes all five tables
  // down with 22P02 — both expressions are evaluated no matter which one grants.
  // Dropped rather than repaired: a repair would restate what the sweep already
  // says. Ordered before the sweep so a table is never left without a policy.
  'db/migrations/20260828_drop_orphaned_org_guc_policies.sql',

  // ── Non-public tenant policies must fail CLOSED (ordered before the sweep) ──
  // The gcc 074-078 migrations and the earlier form of the non-public sweep
  // emitted `<col> = COALESCE(<resolver>, <col>)`, which collapses to
  // `<col> = <col>` — TRUE for every row — whenever the org GUC is unset, empty
  // or not a uuid. Measured as app_service with app.rls_enforce=on: an unset
  // GUC and a GUC of '42' each returned BOTH tenants' rows. This rewrites them
  // to the shadow-clause form the 793 public policies already use, so they do
  // not filter when enforcement is off and filter strictly when it is on.
  // Idempotent; matches on shape, not on policy name.
  'db/migrations/20260828_fail_closed_org_coalesce_policies.sql',

  // ── concept2cure_artifact_versions.updated_at (GA ledger L38) ─────────────
  // artifactVersionStore.ts names updated_at in both of its INSERTs and
  // shared/schema.ts declares it, but none of the three migrations that create
  // this table do — so the column exists on a drizzle-push (install-fresh)
  // database and not on a migration-provisioned one, and the 42703 lands on the
  // long-lived deployments. Reproduced by dropping the column and replaying the
  // writer's own column list. Idempotent ADD COLUMN with the model's exact
  // type, nullability and default.
  'db/migrations/20260828_artifact_versions_updated_at.sql',

  // ── Five more columns the app writes that no migration creates ────────────
  // Same class as the entry above, found by diffing a drizzle-pushed database
  // against every column the migration files create and keeping only those a
  // raw INSERT in server/ actually names: concept2cure_signatures and
  // regulatory_audit_logs (created_at/updated_at — the Part 11 signature and
  // the audit row beside it) and concept2cure_submission_snapshots.updated_at.
  // Each confirmed by hand; the detection also flagged the knowledge-graph
  // tenant columns, which turned out to be added dynamically by
  // 20260813_knowledge_graph_tenant_keys.sql and are NOT included.
  'db/migrations/20260828_align_written_columns_with_migrations.sql',

  // ── file_uploads.checksum_sha256 (GA ledger L25) ──────────────────────────
  // Nothing recorded a digest for an uploaded document, so no stored file was
  // verifiable after the fact — bytes altered on disk, a truncated write or a
  // bad restore were all served as the original, and keeping file_size
  // consistent was enough to hide it. loadUploadedFile now re-derives SHA-256
  // over the bytes it read and REFUSES a mismatch. Existing rows stay NULL by
  // design: hashing today's bytes would record corruption as authentic.
  'db/migrations/20260828_file_uploads_checksum.sql',

  // ── ectd_compilations.submission_id (lifecycle predecessor key) ───────────
  // The file shipped with the eCTD lifecycle work but was never added to this
  // manifest, so an existing estate never gained the column — and the compile
  // path's INSERT names it, failing every spine-backed compile with 42703
  // ("column submission_id does not exist", 0 leaves rendered). Fresh installs
  // get it from shared/schema.ts via drizzle-kit push; this is the
  // existing-database half. Idempotent ADD COLUMN IF NOT EXISTS + index.
  'db/migrations/20260828_ectd_compilations_submission_id.sql',

  // ── reg_questions.response_doc_id (correspondence → drafted response) ─────
  // "Draft response" creates a governed authoring document; this column links
  // it back to the agency question so the correspondence file can OPEN the
  // draft it says exists. Verified org-scoped at write time (no FK — the
  // authoring tables are ensure-DDL'd lazily). Idempotent ADD COLUMN.
  'db/migrations/20260830_reg_questions_response_doc.sql',
  // Must follow the sweep above: that one keys on polqual (USING), which an
  // INSERT policy does not have, so every write-only policy slipped through
  // with its fail-open COALESCE intact. This closes them on polwithcheck.
  'db/migrations/20260828_fail_closed_insert_withcheck_policies.sql',

  // ── CMC container closure + reference standard registers ─────────────────
  // The two canonical source types the Module 3 composer has demanded since it
  // was modelled and no table anywhere held, so 3.2.S.5 / 3.2.S.6 / 3.2.P.6 /
  // 3.2.P.7 could never leave zero completeness. Both registers store `scope`
  // (drug_substance | drug_product | both) so the section a record files into
  // is stored rather than guessed, and both carry project_id as a column so the
  // canonical write-through does not depend on the client having sent one.
  'db/migrations/20260901_cmc_container_closure_reference_standard_registers.sql',

  // ── CMC register store parity + the dead third change-control store
  //    (2026-08-23; root-tree files wired here 10 days late) ─────────────────
  // Both sat in the root tree on no durable applier, so every database upgraded
  // by deploy-migrate (every provisioned tenant) never got them: the Module 3
  // Specifications register 500'd on create/update/approve (no
  // quality_specifications), and the batch register rejected every create on
  // the columns batchRecordRoutes writes. KNOWN_UNLISTED in the manifest test
  // was not an honest home: quality_specifications is declared in
  // shared/cmc-schema.ts and cmc_batch_records in shared/schema/
  // regulatory-atoms.ts, neither of which drizzle.config.ts pushes; and a
  // DROP CONSTRAINT + ADD COLUMN block on an existing table is exactly what
  // push cannot reproduce.
  // Order: after 20260730_cmc_evidence_tables (specification_audit_log, which
  // the spec routes write with every row), after 20260730_cmc_change_control_
  // store (the store that superseded c2c_cmc_changes), after 20260401_cmc_
  // convergence_os (adds tenant_id to the batch table where it exists), and
  // above the isolation pair below so quality_specifications.tenant_id INTEGER
  // gets a policy. The spec routes now filter strictly `tenant_id = $n` (the
  // old `OR tenant_id IS NULL` disjunct made an unattributed row readable and
  // writable by every org, which was looser than the policy behind it); the
  // required-tenant constraint below closes the store half.
  // cmc_batch_records is created ONLY by root migrations/0006 (fresh installs),
  // so the parity file's ALTER block is IF EXISTS-guarded: a database without
  // the table gets a NOTICE and quality_specifications, not a halted deploy.
  // Follow-up, out of scope here: 0006's batch table still has no durable
  // creator, so the batch register stays honestly 42P01 on such a database.
  'migrations/20260823_cmc_register_store_parity.sql',
  // quality_specifications.tenant_id is required from here on: a tenant-less
  // row belongs to nobody, not to everybody. CHECK ... NOT VALID, so legacy
  // NULL rows (20260401 added the column to an already-populated table with no
  // backfill) stay in place and stay invisible rather than aborting the deploy.
  // Must follow the parity file, which creates the table on databases that
  // never had it.
  'migrations/20260907_quality_specifications_tenant_required.sql',
  // DROP TABLE IF EXISTS c2c_cmc_changes (seed-only demo content, zero live
  // references). Its creator db/migrations/20260718_cmc_changes_store.sql is on
  // no applier, so there is no create-then-drop ordering hazard; same shape as
  // the 20260901 audit-table drop below.
  'migrations/20260823_drop_dead_c2c_cmc_changes.sql',

  // ── CMC impurity + dissolution registers ─────────────────────────────────
  // The other two source types the Module 3 composer demands and nothing
  // produced: 3.2.S.3 / 3.2.S.4 read impurity_profile, 3.2.P.2 / 3.2.P.5 read
  // dissolution_profile. Both store the column the section rules scope on
  // (scope / purpose) so a drug-substance impurity cannot green a drug-product
  // section and a development profile cannot green the release specification.
  'db/migrations/20260902_cmc_impurity_dissolution_registers.sql',
  // The Clinical Operations surface's store. Its router used to CREATE SCHEMA
  // and CREATE TABLE on the first request, which the non-superuser runtime role
  // must refuse (42501) — so every call 500'd. Ordered after the CMC registers
  // and before the sweep; it only needs public.organizations, which exists long
  // before this point.
  'db/migrations/20260902_clinical_ops_schema.sql',
  // manufacturing.responses. Its router created the table on the first request
  // — the comment there said so, naming migration 066's omission as the reason
  // — which the runtime role may not do, so the finding-response surface 500'd.
  'db/migrations/20260902_manufacturing_responses.sql',

  // ── CMC material spec + formulation registers ────────────────────────────
  // The producers for the composer's excipient, raw_material_spec and
  // formulation_record source types. One table serves the two material types,
  // keyed on material_role; `origin` is what lets 3.2.A.3 answer the
  // human/animal-origin question from data instead of a regex over free text.
  'db/migrations/20260903_cmc_material_formulation_registers.sql',

  // ── CMC manufacturing process + characterisation registers ───────────────
  // The last two source types the composer demanded with no producer:
  // 3.2.S.2 reads manufacturing_process, 3.2.S.3 reads characterization.
  // The manufacturing half ALTERs the existing manufacturing_processes table
  // rather than adding one: that table already has two live readers
  // (ich-compliance-checker, qbd-analyzer) and is cmc_process_steps' FK
  // target, so it must be the table the writer fills. MUST stay after
  // db/migrations/20260730_manufacturing_processes_reconstruction.sql, which
  // creates it.
  'db/migrations/20260903_cmc_manufacturing_characterization_registers.sql',

  // ── The route of administration on the impurity register ─────────────────
  // ICH Q3D sets a different permitted daily exposure per route, so an
  // elemental impurity cannot be assessed without it. MUST stay after
  // db/migrations/20260902_cmc_impurity_dissolution_registers.sql, which
  // creates the table.
  'db/migrations/20260903_cmc_impurity_route_of_administration.sql',

  // ── Durable CMC interview sessions ───────────────────────────────────────
  // The guided CMC interview's FlowState, persisted per step and committed to
  // the registers on completion (CMC capture evaluation item 5). Leaf table:
  // FKs only to organizations and users. public + integer organization_id, so
  // the isolation sweep at the end of this list policies it.
  'db/migrations/20260906_cmc_interview_sessions.sql',
  'db/migrations/20260906_cmc_impurity_m7_inputs.sql',
  'db/migrations/20260906_cmc_formulation_development.sql',
  'db/migrations/20260907_qc_testing_batch_attribution.sql',

  // ── Drop the audit-shaped tables that survived a from-scratch liveness
  //    re-check (ledger L13; docs/AUDIT_STORE_INVENTORY_2026-08.md §5.1) ─────
  // MUST stay near the end, and specifically AFTER every entry above that
  // CREATEs one of its targets — 20260524_program_workbench_schema (index 1),
  // 081_grdhe_regulatory_mapping_layer (112) and
  // 20260211_phase6_6e_proof_pack_exports (115). The set is replayed whole on
  // every deploy, so a drop ordered before its creator would be undone by the
  // creator's own CREATE TABLE IF NOT EXISTS on the same run.
  //
  // It is empty-only and fails soft: a table holding rows is KEPT with a NOTICE,
  // because an audit table with records is Part 11 evidence with a retention
  // obligation regardless of whether anything still writes it. Re-running after
  // the records are dispositioned picks it up with no edit.
  'db/migrations/20260901_drop_dead_audit_tables.sql',

  // vault.documents gains a tenant key, backfilled from the owning program, with
  // unattributable rows left NULL and indexed rather than guessed. Ordered here
  // because it must run after every file that shapes vault.documents (044c
  // creates it; 20260821 reconciles its columns; 20260823 adds the placement
  // columns) and after regulatory_programs exists to backfill from.
  //
  // Purely additive: no policy, no FORCE, no NOT NULL. Neither isolation sweep
  // will pick it up — the integer sweep is public-only and the non-public one is
  // an explicit uuid-keyed list — which is stated in the migration's own header
  // so nobody reads the column as isolation it does not provide.
  'migrations/20260905_vault_documents_organization_id.sql',

  // Full-text index over vault.documents, plus the one named definition of "the
  // searchable text of a vault document" that the search route must match
  // character-for-character to use it. Ordered after the organization_id file
  // only for readability — it depends on nothing that file adds.
  'migrations/20260906_vault_documents_fulltext.sql',
  // c2c_artifact_section_map: de-duplicate (artifact, section) rows and add the
  // unique index shared/schema.ts declares. Was in no applier, so the schema's
  // "the database no longer permits" a duplicate mapping was not true anywhere.
  'migrations/20260906_artifact_section_map_unique.sql',

  // Legal holds. Lands while the retention sweep is still inert (nothing writes
  // retention_until), which is the point: the guard has to exist before the
  // clock starts, not after the first record is destroyed.
  'migrations/20260906b_vault_legal_holds.sql',
  'migrations/20260906c_vault_documents_content_hash_idx.sql',
  'migrations/20260917_vault_documents_storage_version.sql',
  'migrations/20260917b_submission_leaf_document_uuid.sql',

  /* vault.evidence_citations — the RAG provenance store, added 2026-09-11
     (WO-15 finding 8). Placed after the vault chunk store above because its
     two chunk FKs target it.

     advancedRAGPipeline.ts:1316 INSERTs into this table on every retrieval
     that requests citation persistence, and the table existed on no
     provisioned database. Its only creator was
     db/migrations/_legacy/042_gcc_evidence_vault.sql, which no applier reaches:
     not this set, and not the *_gcc_* psql loops in install-fresh or CI, both
     of which are non-recursive and never descend into _legacy/. drizzle-kit
     push emits no vault DDL either, so the shared/schema/vault.ts declaration
     created nothing.

     The failure was invisible twice over: the INSERT's 42P01 is caught into a
     console.warn at advancedRAGPipeline.ts:1533, so the RAG answer returns
     normally with no provenance recorded; and install-fresh's push-surface
     check matched only pgTable('name') and queried only table_schema='public',
     so all six vault tables were outside its view while it reported the surface
     verified. That half is fixed in scripts/db/lib/declared-tables.mjs.

     Shape taken verbatim from the two existing definitions, which agree with
     each other. Guarded on vault.documents, RLS-policied through it on the
     20260905b pattern, idempotent. */
  'migrations/20260911_vault_evidence_citations.sql',

  /* vault.documents record guard, added 2026-09-26 (VR-06, row D5). A row
     trigger refuses any change to a recorded version's identity, hash, uploader
     or lineage, and to a write-once field once it holds a value; a statement
     trigger refuses TRUNCATE. Nothing below the application stopped the
     runtime role rewriting a recorded version's content_hash.

     Placed after every file in this set that writes vault.documents
     (20260821_vault_documents_canonical_shape, 20260905_vault_documents_
     organization_id), and those write only `WHERE x IS NULL`, which the
     write-once rule admits; so a replay passes the guard. CREATE OR REPLACE for
     the functions, each trigger created only when absent: replayable, no DROP.
     Proven by tests/db/vault-record-immutability.dbtest.ts (red before this
     file, green after). The code that may still UPDATE the table is named in
     scripts/ci/check-vault-document-writers.mjs. */
  /* The deletion archive and retention policies (plan critique 13,
     2026-10-01). vault.document_archives is the snapshot the retention job
     writes before it disposes of a document; it was on no applier, so a
     database built by deploy-migrate had no archive to write to. CREATE ...
     IF NOT EXISTS only: replayable, no DROP. Just before the next file, which
     guards it (append-only, owner-only delete, row security) and has the
     tenant purge erase it. */
  'migrations/20260608_vault_retention.sql',
  'migrations/20260926_vault_documents_record_immutability.sql',
  // VR-08 (D2): a version names its predecessor only inside its own family,
  // and has at most one live successor. A trigger, plus a partial unique index
  // created only when no version is already forked (NOTICE otherwise). After
  // VR-06's file: it guards the same table's lineage column. No table, no
  // column, no FK, no DROP.
  'migrations/20260930_vault_documents_version_lineage.sql',

  /* c2c_template_specs + its doc_types column, added 2026-09-17 (WO-15
     finding 5). Self-contained: this file creates the base table IF NOT EXISTS
     (byte-identical to 20260531_template_specs.sql modulo comments — verified)
     and then ADDs the column, so listing it alone covers both. 20260531 is a
     strict subset and stays unlisted.

     The table has NO Drizzle definition — zero hits under shared/ — so push
     creates nothing, and both creators ran on install-fresh's step-3 overlay and
     nowhere else. The table therefore exists on every freshly provisioned
     database and was re-asserted on none. A database provisioned BEFORE
     20260716 was written has the table from 20260531 and no doc_types, and no
     applier would ever have added it.

     Proven before the fix: dropped doc_types on a canonically provisioned
     database, ran deploy-migrate, it reported "safe to roll services" and the
     column did NOT come back.

     The absence is silent rather than loud, which is why it survived: no
     statement names doc_types (INSERT lists twelve columns without it, UPDATE
     sets four, reads are SELECT *), so nothing raises 42703 — row.doc_types is
     undefined and templateStore.ts:47 maps it to []. Every template reports
     zero document types, indistinguishable from one that has none.

     NOT claimed: that this makes document-type chips appear. Nothing in the
     repository writes doc_types — the column is inert on every database,
     with-column or without. Recorded in the work order as its own finding
     rather than fixed by inventing a writer. */
  'migrations/20260716_template_doc_types.sql',

  /* project_charters — the 21 declared columns no applier ever created, added
     2026-09-17 (WO-15 finding 2).

     server/routes/charters.ts issues an unqualified d.select().from(
     projectCharters), which expands to all 48 columns the declaration names.
     migrations/0012_project_charter_timeline.sql is the ONLY creator of this
     table in the repository and makes 27, so that select raised 42703 on every
     database. server/routes/pma-workflow-routes.ts names pma_config explicitly
     in raw SQL three times, so the PMA workflow-progress feature could not work
     anywhere.

     CORRECTION TO AN EARLIER NOTE IN THIS FILE: the charter entry above once
     said drizzle-kit push creates the charter tables. It does NOT.
     drizzle.config.ts names shared/schema.ts, ana-intelligence.ts and
     report-os.ts; shared/schema/project-charter.ts is re-exported only from
     shared/schema/index.ts, which is not an entrypoint and is not reachable
     from one. The charter tables are outside the push surface entirely and come
     from install-fresh's overlay — 0012 for project_charters, 20260629 for the
     other four. The finding-3 fix above is unaffected (it is guarded on the
     table existing, not on what created it), but its reasoning is corrected
     here and in the file itself.

     Additive and idempotent: ADD COLUMN IF NOT EXISTS throughout, guarded on
     the table. The 27 pre-existing columns' jsonb/timestamp-vs-json/timestamptz
     divergence from the declaration is NOT touched — that is a retype with data
     implications and belongs to WO-1. */
  'migrations/20260917_project_charters_declared_columns.sql',

  /* ── KNOWN_UNLISTED triage, 2026-09-17 ──────────────────────────────────────
     Ten root migrations creating SIXTEEN tables that reached a database only
     through install-fresh's step-3 overlay. Every one of the sixteen is: not on
     the drizzle push surface, created by no other file in this set, present on a
     canonically provisioned database, and referenced by live non-test code
     (3-44 references each). Nothing re-asserted any of them, and any later
     change to these files would have reached new installs only.

     They were exempted from the applier allowlist by KNOWN_UNLISTED in
     tests/ops/apply-c2c-migrations-manifest.test.mjs, whose stated reason is
     that such files' "objects come from shared/schema.ts via drizzle-kit push
     and they carry nothing an existing database additionally needs". Neither
     half held for any of these ten. That list's own comment sets the rule:
     "Removing an entry (by listing the file in the applier) is always safe;
     adding one requires the reason above to actually hold."

     Safe to replay, verified per file rather than assumed: ZERO DROP statements
     across all ten, every CREATE and ALTER guarded by IF NOT EXISTS, and every
     table carries organization_id/org_id. Their only external FK targets are
     `organizations` and `users` — base tables that 39 files already in this set
     also reference and that the schema-contract harness provisions via
     FK_PREREQUISITES, so the C-33 bare-database replay is satisfied. (That is
     the finding-3 trap checked and cleared: project_charters failed it because
     it is NOT a base table and is not in that prerequisite set.)

     NOT claimed: that these tables gain RLS policies by being listed here. None
     of the ten defines any, which is the status quo on a provisioned database
     today — listing them changes nothing about it. The tenant sweep stays the
     final pair of this set.
     ─────────────────────────────────────────────────────────────────────────── */
  'migrations/20260701_protocol_soa.sql', // protocol_soa_assessments, protocol_soa_cells
  'migrations/20260702_protocol_budget.sql', // protocol_budget_items, protocol_budget_params
  'migrations/20260703_dmsp.sql', // dms_plans, dms_plan_elements
  'migrations/20260704_biosketch.sql', // biosketches, biosketch_sections
  'migrations/20260704_other_support.sql', // other_support_documents, other_support_entries
  'migrations/20260705_export_control.sql', // export_control_reviews
  'migrations/20260705_invention_disclosure.sql', // invention_disclosures
  'migrations/20260705_research_agreements.sql', // research_agreements
  'migrations/20260728_chat_thread_store.sql', // chat_threads, chat_messages
  'migrations/20260731c_canonical_documents.sql', // canonical_documents
  // VR-03 (D5): the lifecycle trail only grows, signatures are written once,
  // nothing is deleted. Triggers only, created when absent; no table, no DROP.
  'migrations/20260925_canonical_documents_append_only.sql',
  // VR-13 (D5): one lifecycle record per Vault version. A unique index on the
  // version a record names, created only when no version already has two
  // (NOTICE otherwise). After the table's own file; no table, no column, no DROP.
  'migrations/20261001_canonical_documents_vault_version.sql',

  // The three IVDR append-only history tables carry no tenant column of their
  // own — their tenant is their parent's, reached by foreign key — so BOTH
  // sweeps below are blind to them: the integer sweep matches on
  // organization_id/org_id/tenant_id, and the non-public one is an explicit
  // uuid-keyed list. They sat with relrowsecurity = false and zero policies.
  //
  // Measured on the dev database as the app role `c2c` with rls_enforce='on'
  // and current_tenant_id='9002': the policied PARENT returned 1 of 2 rows and
  // the history table returned 2 of 2, the second reading "org 9001 secret LoD".
  // One IVD manufacturer could read another's limit-of-detection history.
  //
  // It installs a parent-scoped policy, which the sweep's own header names as a
  // shape it will not clobber (C-30's doc-scoped policies key on a parent's
  // tenant the same way). It therefore runs BEFORE the sweeps, so their
  // pg_policies guard sees it and leaves it alone.
  'migrations/20260906_ivdr_history_tenant_isolation.sql',

  // §3.2.P.8's only producer of `comparabilityStatus` had no creator on THIS
  // applier (its DDL lives in migrations/0006_regulatory_atoms.sql, which
  // install-fresh applies and deploy-migrate does not) and, where it did exist,
  // an FK pinning project_id to the empty cmc_projects table — so every write
  // from a real program answered 500 and the section could never complete.
  // Creator + a drop of that constraint; 0006 was amended in place to stop
  // declaring it, so the drop cannot be undone by a replay.
  'migrations/20260907_cmc_comparability_register_reachable.sql',

  // §3.2.A.2's six inputs. The section reads modality, biological origin,
  // source organism, cell line, the ICH Q5A(R2) viral safety evaluation and the
  // TSE/BSE status, and no table held any of them — so for a biologic it was
  // composed from the substance's NAME. Additive and nullable; a small-molecule
  // programme records none of them.
  'migrations/20260908_drug_substance_biologic_origin.sql',
  // ── regulatory_programs.application_number (WO-9 Click 1) ──────────────────
  // The agency-assigned IND / NDA / BLA / MAA number, distinct from the sponsor's
  // own program code. Additive, IF NOT EXISTS, nullable — never fabricated.
  'migrations/20260907_regulatory_programs_application_number.sql',

  // ── compliance_tracking.organization_id backfill ──────────────────────────
  // The rows the CMC project routes wrote carry no organization_id (the drizzle
  // model they bind maps none), so the check-rules read widened to
  // `OR organization_id IS NULL` to find them — and served every sponsor's
  // compliance findings to every other sponsor. Unlike the quality_specifications
  // case, these rows ARE attributable: project_id is NOT NULL with an FK to
  // cmc_projects, whose organization_id is NOT NULL. Guarded on IS NULL, so a
  // replay is a no-op.
  'migrations/20260908_compliance_tracking_organization_backfill.sql',

  // ── estar_submissions: what the filing was filed WITH (roadmap item 3) ────
  // Two additive columns binding a `filed` transition to the retained eSTAR in
  // the program vault: the vault.documents id and the SHA-256 of its bytes,
  // both written by the server. Before them, "filed" was a status, a
  // client-supplied date and a free-text tracking number pointing at nothing.
  // Additive, IF NOT EXISTS; a replay is a no-op.
  'migrations/20260908b_estar_submissions_filed_artifact.sql',

  // ── contradiction_links: restore a table this repo stopped creating ───────
  // Its only creator was migrations/0010_operating_system_foundation.sql, which
  // is dead on deploy-migrate but was NEVER dead on install-fresh (that overlay
  // reads every migrations/*.sql). Retiring 0010 in 9a47438b6 therefore removed
  // the table from every future fresh install, and no repository-only gate saw
  // it — ci:tables-live-schema caught it against a real provisioned database.
  // Listed HERE, not restored to the root tree, so RULE 1's replay carries it to
  // databases that already exist. Must stay ABOVE the sweep so the sweep
  // policies it — and above the uuid step too, because ci:migration-set-order
  // pins the FINAL PAIR to the two isolation steps. See ADR-0007 point 6.
  'db/migrations/20260910_contradiction_links_port.sql',

  // ── ana_runs: a live AnA turn survives the process that started it ───────
  // Run control lived in a process-local Map with a 30-minute TTL, so pausing
  // or stopping her 404'd after a restart and, on a second instance without
  // sticky routing, never bound to the right run at all. public +
  // organization_id INTEGER NOT NULL, so the sweep below policies it — and
  // ABOVE that sweep, because a table ordered after it is never swept, ships
  // with no RLS policy, and the policy COUNT still goes up, which is what makes
  // the mistake invisible without ci:migration-set-order.
  'db/migrations/20260917_ana_runs.sql',
  // ── RBM author attribution, for the Part 11 two-person rule ──────────────
  // rbm_risk_assessments and rbm_monitoring_plans shipped with approved_by and
  // no created_by, so the approval path could not ask whether the signer was
  // the author. Additive and IF NOT EXISTS, so it replays as a no-op; above the
  // final pair because ci:migration-set-order pins those two last.
  'migrations/20260918_rbm_author_attribution.sql',
  // ── CMC playbook: the five tables /api/cmc/blueprint/playbook/* queried ──
  // RETIRED SURFACE, 2026-10-05: /api/cmc/blueprint (blueprintRoutes.ts) and
  // the playbook router under it (playbookRoutes.ts) were deleted with no
  // caller (server/api/cmc/__tests__/cmc-retired-routers.contract.test.ts), so
  // nothing reads or writes these tables now. The file STAYS on the set: every
  // entry re-runs on every deploy, and removing schema is not a DROP (CLAUDE.md
  // RULE 1); the tables stay swept, and tenant offboarding still purges them.
  // What follows is the note as written when the surface was live.
  // The surface is live and unconditionally mounted (register-core-routes.ts:68
  // → blueprintRoutes.ts:748), and none of its tables existed on any
  // provisioned database, so every one of its endpoints returned 500. A correct
  // DDL file already sat at server/database/cmc-playbook-schema.sql on NO
  // applier — which is exactly why the tables were missing; it is deleted in
  // the same change rather than left as a second creator. All five are public +
  // organization_id INTEGER NOT NULL so the sweep below policies them, and
  // ABOVE that sweep for the reason the ana_runs note gives.
  'migrations/20260919_cmc_playbook_schema.sql',

  // ── CAPA / complaint / MDR display codes: per program, not global ─────────
  // complaints_code_uq, mdr_events_code_uq and capa_records_code_uq were each
  // unique on the code column ALONE, while nextCode() generates those codes per
  // program (`count(*) WHERE program_id = $1`, formatted CAPA-<year>-0001). The
  // second program in the deployment to open its first CAPA of a year therefore
  // got a code that already existed and the insert died 23505 — the normal path,
  // not a race, and across tenants one customer's numbering blocked another's.
  // Proven on the live schema: two inserts differing only in program_id, the
  // second rejected.
  //
  // Its creator, migrations/20260504_capa_mdr.sql, was amended in place per
  // RULE 1 so fresh installs are correct from birth — but that creator is
  // overlay-only (install-fresh step 3) and is NOT in this set, so it never
  // re-runs on an already-provisioned database. Hence this companion file, which
  // IS in the set. Every statement in it is guarded on the LIVE index
  // definition, so it converts only a still-old index and no-ops on a fresh
  // install and on every deploy after the first: it cannot fight the amended
  // creator in either ordering, which is why it is a conversion and not the
  // recurring DROP rule 1 forbids. Above the final pair because
  // ci:migration-set-order pins those two last.
  'migrations/20260919_capa_code_uniqueness_per_program.sql',

  // ── Claude connector (D8): OAuth 2.1 clients, PKCE codes, refresh tokens ──
  // server/mcp/ is an MCP resource server that must also act as the OAuth
  // authorization server (the platform had none). Two of the three tables are
  // public + organization_id INTEGER NOT NULL so the sweep below policies them,
  // and each grant row also cascades from the organization_users membership
  // that authorised it, so removing a member revokes their connector grants
  // and tenant off-boarding purges them through the cascade ci:purge-coverage
  // measures. Above the final pair because ci:migration-set-order pins those
  // two last. Additive and IF NOT EXISTS throughout.
  'migrations/20260920_mcp_oauth.sql',

  // ── Protocol documents: sponsor + principal investigator (WO, 2026-09-21) ─
  // Two nullable TEXT columns on protocol_documents, ADD COLUMN IF NOT EXISTS,
  // no DROP. The creator (migrations/20260621_protocol_development.sql) is on
  // the install-fresh overlay only, so the ALTER is guarded on to_regclass and
  // NOTICE-skips on a database the set alone provisioned. Above the final pair
  // because ci:migration-set-order pins those two last.
  'migrations/20260921_protocol_documents_sponsor_pi.sql',

  // ── Protocol document → study design link (PROTOCOL-CONVERGENCE, 2026-09-22) ─
  // Three nullable columns + one partial index on protocol_documents, all
  // ADD/CREATE ... IF NOT EXISTS, no DROP. It is the link that makes the
  // protocol a projection of the design-as-data spine
  // (docs/design/PROTOCOL_DESIGN_CONVERGENCE.md step 1). Deliberately a SOFT
  // link: the FK target, cdisc_prm_studies(study_id), is created by the
  // Drizzle schema install-fresh pushes and by NO file in this set, so a
  // REFERENCES clause would be the same defect the IRB file above had to have
  // removed before it could be registered. Guarded on to_regclass because
  // protocol_documents is overlay-only, so it NOTICE-skips on a set-only
  // database. Above the final pair because ci:migration-set-order pins those
  // two last.
  'migrations/20260922_protocol_document_study_design.sql',

  // ── The ICH M11 discontinuation / withdrawal section, backfilled ─────────
  // Registered 2026-09-22. SECTION_TEMPLATES.clinical claimed ICH M11 as the
  // basis of all twelve of its sections and covered neither discontinuation of
  // trial intervention nor participant withdrawal, so a protocol could pass
  // the finalize gate with every required section complete and say nothing
  // about either. The template now carries it; this file fixes the documents
  // already in a deployed database. Replayable: the inserted row is its own
  // guard, so a document that has the section is skipped including the
  // order_index shift. Finalized and superseded protocols are left alone --
  // rewriting an approved record to improve its score is the opposite of the
  // point. Guarded on to_regclass; above the final pair, which
  // ci:migration-set-order pins last.
  'migrations/20260922b_protocol_discontinuation_section.sql',

  // ── The design as it stood when an amendment was opened ─────────────────
  // Registered 2026-09-22. EU CTR 536/2014 Article 16 makes a modification
  // substantial by its EFFECT, which needs a before and an after. Nothing
  // captured a before: protocol_versions.snapshot holds sections only, and the
  // bound design is overwritten in place as it is edited. Three additive
  // columns, ADD COLUMN IF NOT EXISTS, no DROP and no backfill -- an amendment
  // that predates the column keeps a NULL snapshot and its assessment reports
  // not-assessed rather than comparing against an invented baseline. Guarded on
  // to_regclass; above the final pair, which ci:migration-set-order pins last.
  'migrations/20260922c_amendment_design_snapshot.sql',

  // ── IRB / IEC submissions, reviews, amendments, reportable events ────────
  // Registered 2026-09-22. The file was written on 2026-06-10 with a service,
  // three deterministic engines and nine mounted routes — and was never put on
  // an applier, so on every deployed database the tables did not exist and the
  // whole capability was dead. Six tables, all CREATE TABLE IF NOT EXISTS, no
  // DROP. Its hard FK to clinical_studies was removed in place before this
  // registration (see the file's dated note): nothing on the applier creates
  // that table and it is not in the schema install-fresh pushes, so the
  // constraint would have failed the first deploy to run this file. Above the
  // final pair so the tenant sweep policies these six tables.
  'migrations/20260610_irb_submissions.sql',

  // ── The four facts an IRB package manifest needs (registered 2026-09-22) ──
  // Four columns on irb_submissions: involves_children, is_ind_study, uses_phi,
  // uses_recruitment_material. package-manifest.ts gates five artifact slots on
  // them (assent, Form FDA 1572, financial disclosure, HIPAA authorization,
  // recruitment material) and the table recorded none, so all five came back
  // `undetermined` on every submission and a package could never be ready.
  //
  // All four are NULLABLE with NO DEFAULT, deliberately, and that is the point
  // of the file rather than an oversight: three states have to survive to the
  // manifest — true (required), false (a RECORDED statement, not required) and
  // NULL (NOT RECORDED, stays undetermined). `NOT NULL DEFAULT false` would
  // collapse "nobody answered" into "the sponsor said no" and drop Form FDA
  // 1572 out of a package on a claim nobody made, which is the exact failure
  // package-manifest.ts was written to prevent. The sibling columns on this
  // table are NOT NULL DEFAULT false and that is correct for them; it is the
  // pattern that must not be copied here. Pinned by a test that fails if a
  // default or a NOT NULL is ever added.
  //
  // Additive: ADD COLUMN IF NOT EXISTS, no DROP, no backfill — a row predating
  // the file keeps NULL and keeps reporting undetermined. Guarded on
  // to_regclass with every statement including the COMMENTs inside the DO
  // block. Ordered after its creator above and above the final pair, which
  // ci:migration-set-order pins last.
  'migrations/20260922d_irb_submission_context.sql',

  // ── Amendment consent/risk declarations: NULL = not declared ────────────
  // Registered 2026-09-22. affects_consent / affects_risk were NOT NULL
  // DEFAULT false and the writer sent `?? false`, so every amendment the
  // product's form created (it never asked either question) was stored as a
  // sponsor declaration of "affects neither", and substantiality.ts accused
  // sponsors of contradicting it. DROP NOT NULL + DROP DEFAULT only: no DROP of
  // any object, no backfill (a pre-change false cannot be told from a real
  // No). Idempotent. The creator, 20260629_protocol_amendments.sql, is
  // install-fresh-only and was amended in place to match. Guarded on
  // to_regclass; above the final pair, which ci:migration-set-order pins last.
  'migrations/20260922e_amendment_declarations_nullable.sql',

  // ── Every organisation gets its own client workspace ─────────────────────
  // The repair half of the fix for NO_CLIENT_WORKSPACE. The three organisation
  // creators now write the workspace inside their own transaction
  // (services/c2c/organization-default-workspace.ts); this sweep covers the
  // organisations that already exist, including any a seed script wrote
  // directly. Without it, projects.client_workspace_id — NOT NULL — has no
  // value to take, ensureProgramProjectAnchor skips for EVERY program in that
  // tenant, and its governed artifacts never reach concept2cure_artifacts.
  //
  // Creates no table, so it needs nothing from the isolation sweep below; it is
  // placed before the final pair because it is a data repair, not a sweep. It
  // writes only where an organisation has NO workspace: a second one would turn
  // the anchor writer's unambiguous case into AMBIGUOUS_CLIENT_WORKSPACE and
  // stop anchoring programs that anchor today. Its only prerequisites,
  // organizations and client_workspaces, are far earlier in the set.
  'migrations/20260923_organization_default_client_workspace.sql',

  // ── A TOTP code is accepted once (RFC 6238 §5.2; D6, VSR-001 §13.3 item 1) ─
  // Registered 2026-09-23. users.mfa_totp_last_step: the time step of the last
  // accepted code, compared-and-set by mfaService so a verified code cannot open
  // a second session. ADD COLUMN IF NOT EXISTS only, nullable, no backfill.
  // public.users has no tenant column and no policy, so nothing for the sweep.
  // Must precede any server carrying shared/schema.ts's mfaTotpLastStep (bare
  // select().from(users) expands to every declared column — the C-20 mode).
  'migrations/20260923_users_mfa_totp_last_step.sql',

  // ── An approval does not outlive the status that carries it (W5/D7) ──────
  // Registered 2026-09-23 (final pass). A BEFORE INSERT OR UPDATE trigger on
  // concept2cure_artifacts clears approved_version_id and published_version_id
  // whenever the status is not approved/locked, so a revoked approval
  // (approved → review, locked → draft, → archived) cannot be resurrected by a
  // later arrival at 'approved' that is not the governed approval act, plus a
  // backfill of rows that already break that rule. No DROP: the trigger is
  // created only when absent (the 20260921_audit_logs_chain_seq idiom). No new
  // table, nothing for the sweep. concept2cure_artifacts is a push-provisioned
  // base table; the file NOTICE-skips where it is absent.
  'migrations/20260923b_artifact_approval_follows_status.sql',

  // ── Protocol deviations: unassessed is NOT ASSESSED, not "minor" ─────────
  // Registered 2026-09-22. severity / category / is_reportable were NOT NULL
  // with defaults that stored an unassessed deviation as minor and not
  // reportable. DROP NOT NULL + DROP DEFAULT, plus ADD COLUMN IF NOT EXISTS for
  // affects_safety and the assessment record. No DROP of any object, no
  // backfill: legacy rows keep their values and read as "assessment required"
  // because affects_safety is NULL. The creator, 20260629_protocol_deviations,
  // is install-fresh-only and was amended in place to match. Guarded on
  // to_regclass; above the final pair, which ci:migration-set-order pins last.
  'migrations/20260922f_protocol_deviation_assessment.sql',

  // ── C-48 Stage 1: unify the two org-uuid identity spaces ─────────────────
  // Backfills identity.organizations from public.organizations.uuid (the
  // canonical per-tenant uuid) + a forward-sync trigger, so a single
  // app.current_org_id serves both the COALESCE-family tables and the
  // identity-FK-bound family instead of the two disjoint uuid spaces deny-alling
  // each other. Additive, idempotent, and a no-op on a fresh DB (public.organizations
  // is empty); it does NOT set the GUC or flip enforcement (C-48 Stage 2/3). Placed
  // before the final isolation pair — it is a backfill, not a sweep; prerequisites
  // (identity.organizations from 051, organizations.uuid from 20260129) are far
  // earlier in the set.
  C48_STAGE1_IDENTITY_ORG_BRIDGE,
  // ── license_requests: the enterprise onboarding intake (D2, 2026-09-24) ──
  // POST /api/auth/license-request — Onboarding's "Request Enterprise
  // onboarding", a launch shell surface — INSERTed here while nothing created
  // the table; its runtime CREATE TABLE fallback is refused to the production
  // runtime role ("permission denied for schema public"), so every request was
  // lost in production and only on production. This file is now the only
  // creator. It has NO tenant column by design — the row is written before any
  // organisation exists — so the sweeps below never touch it; it carries its
  // own insert-only-for-the-public, read-only-for-the-platform policy.
  'migrations/20260924_license_requests.sql',

  // ── identity.org_relationships: a grant is the sponsor's to make (D3) ────
  // Every vault.documents / vault.document_chunks policy honours a live
  // sponsor → delegate row here, and the table had no RLS: as app_service with
  // RLS enforcing, a tenant wrote itself a grant from another tenant and read
  // and rewrote that tenant's vault. Sponsor writes, both parties read. Two-key,
  // so the one-column uuid sweep below cannot express it. Its creator, 051, is
  // applied by deploy-migrate ahead of this set; guarded on to_regclass.
  // Evidence docs/evidence/D3/2026-09-24-vault-program-ownership/.
  'migrations/20260924_org_relationships_sponsor_rls.sql',

  // ── public.organizations: the tenant key is immutable (D3) ───────────────
  // organizations.uuid is the tenant key of every uuid-keyed schema, and what
  // core.get_program_org_id maps a program's org to. The table has no RLS and
  // the runtime role may write it: as app_service with RLS enforcing, a tenant
  // gave another org its own uuid and read that org's vault. id and uuid are
  // now immutable once set (a trigger). Narrowing writes to the other columns
  // is recorded and handed on, not done here; see the file.
  // Evidence docs/evidence/D3/2026-09-25-organizations-tenant-key/.
  'migrations/20260925_organizations_tenant_key_immutable.sql',

  // ── public.organizations: own-org-or-platform writes (D3) ─────────────────
  // UPDATE/DELETE by the row's own tenant or the platform scope (the canonical
  // expression keyed on id); SELECT/INSERT open (pre-auth lookups, signup). Lands
  // with its precondition: platform staff editing ANOTHER org now run in the
  // system scope (server/middleware/staffCrossOrgScope.ts), without which this
  // policy made one route answer success while writing nothing.
  // Evidence docs/evidence/D3/2026-09-26-organizations-writes/.
  'migrations/20260926_organizations_own_writes.sql',

  // ── public.organization_users: own-org-or-platform writes (D3) ────────────
  // Memberships decide tenancy (authMiddleware admits a token on one row) and
  // "platform staff" is a role on that row. No RLS, runtime role may write it:
  // a member's scope placed its user in another tenant and minted super_admin
  // in its own. Stays on RLS_ALLOWLIST (reads stay unscoped: the pre-auth
  // membership check, a user's organization list); writes are own-org or
  // platform, and a staff role is minted by the platform scope only (trigger).
  // Signup, persona and tenant-users' cross-org admin writes moved into the
  // membership's own organization in the same change.
  // Evidence docs/evidence/D3/2026-09-26-memberships/.
  'migrations/20260926_organization_users_own_writes.sql',

  // ── public.users: a tenant scope reaches its own members only (D3) ────────
  // The table holds every account's password hash, MFA secret, backup codes,
  // reset token and OTP hash, and had no RLS: tenant A's scope read and
  // rewrote tenant B's. SELECT/UPDATE/DELETE now need a membership
  // (organization_users, the entry above, whose reads stay open) in the scope's
  // organization, or a tenant-less scope — pre-auth (sign-in, reset, OTP) and
  // system (SCIM, platform administration). INSERT from any scope. Plus
  // user_id_for_email(), id only, for tenant-users' existing-account check.
  // Not org-keyed, so the sweep below neither covers nor heals it.
  // Evidence docs/evidence/D3/2026-09-28-users-rls/.
  'migrations/20260928_users_membership_rls.sql',

  // ── public.platform_role_grants: platform-scope writes only (D3) ─────────
  // One active row makes a user a platform operator (requirePlatformAdmin,
  // requireBusinessAdmin, master-admin). No RLS, runtime role may write it: a
  // plain member's tenant scope wrote itself super_admin and the Access
  // Management console admitted it. SELECT stays open (the check runs in the
  // caller's tenant scope); INSERT/UPDATE/DELETE need app_super_admin — the
  // console runs in the system scope. No tenant column: the sweep skips it.
  // Evidence docs/evidence/D3/2026-09-28-platform-role-grants/.
  'migrations/20260928_platform_role_grants_platform_writes.sql',

  // ── organization_invitations: the invitee finds their own (D3) ───────────
  // An invitation to another organization lives in THAT organization's rows,
  // behind the FORCEd tenant policy, so an invitee signed into their own
  // organization saw an empty list and got 404 on accept and decline.
  // invitations_for_member(user) reads the invitations naming a member of the
  // calling scope's organization, and nobody else's; accept and decline then
  // run in the inviting organization's scope (tenant-users.ts). The table's
  // policy is unchanged. Evidence docs/evidence/D3/2026-09-28-invitation-acceptance/.
  'migrations/20260928_invitations_for_member.sql',

  // ── actor_name(): the audit trail names people who acted and left (D3) ───
  // audit_logs keeps an actor id and no name; after the users policy a tenant
  // scope resolves only current members, so the audit-trail ledger read
  // `user <id>` for anyone who had left. actor_name returns name and email only,
  // for members of the calling organization and actors in its own audit trail,
  // nobody else. Plus audit_logs_tenant_actor_idx, created only when absent.
  // Evidence docs/evidence/D3/2026-09-29-actor-names/.
  'migrations/20260929_actor_names.sql',

  // ── user_presence: row security before its first writer (D3, 2026-10-04) ─
  // A person's presence (IP address, user agent, current page and document)
  // was readable and writable from any scope. Members read their colleagues';
  // only the person (a bound pre-auth scope) or the platform writes. No reader
  // or writer exists yet; the policy ships first. Evidence
  // docs/evidence/D3/2026-10-04-user-presence/.
  'migrations/20261004_user_presence_rls.sql',

  // ── submissions.program_id: a submission carries its project (LX-22) ─────
  // The project → submission link was guessed from product names; two projects
  // for one product shared a filing spine. Additive column, a composite
  // (program, org) FK added NOT VALID, and a one-to-one backfill from the
  // creation audit rows. No DROP; replay decides nothing twice.
  'migrations/20260925b_submissions_program_anchor.sql',

  // ── ai_placement_policies: the tenant's AI placement floor (D6, 2026-09-25) ─
  // Vendor / substrate allow-lists, residency, zero retention and the
  // public-source switches the AI gateway enforces on every dispatch
  // (server/services/ai-gateway/providers/org-placement-db.ts). Until this entry
  // only install-fresh applied the file, so a database upgraded by
  // deploy-migrate alone had no table, and the gateway read every tenant as
  // "no policy". Additive and IF NOT EXISTS-guarded: CREATE TABLE, then ADD
  // COLUMN for the three 2026-09-25 columns, ENABLE/FORCE RLS and its own
  // tenant policy (DROP POLICY IF EXISTS + CREATE of the same policy, replayed
  // every deploy by design). organizations, its FK target, comes from the
  // schema push that runs before this set. Public schema, integer
  // organization_id, so the sweep below covers it too.
  'migrations/20260608_ai_placement_policies.sql',

  // ── AnA turn records: one immutable record per turn (D5) ─────────────────
  // What the person asked, what the model was given, what AnA did and what
  // she answered, stored as the exact canonical JSON that was hashed, with the
  // hash carried by a chained audit_logs row in the same transaction. The
  // engine refuses UPDATE, DELETE and TRUNCATE for every role; the record does
  // not go with its thread. public + organization_id INTEGER, so the sweep
  // below polices it. Evidence docs/evidence/D5-ANA-RECORD/2026-09-26/.
  'migrations/20260926_ana_turn_records.sql',

  // ── Governed decision transition log (2026-09-28) ────────────────────────
  // This file was on NO applier, so the table existed on no deployed database
  // — it is on developer boxes only because someone applied it by hand. That
  // absence was not inert: getProjectReviewQueue reads this table and THROWS on
  // failure by design (fail closed), so on every deployed database the 42P01
  // propagated through hasUnresolvedGovernedDecisions to
  // buildCanonicalGovernedState, and the CMC final-export gate answered
  // `governedStateEvaluated: false, fabricBlocks: true` — permanently, for
  // every project. Reproduced by renaming the table away on a working box:
  // readiness flipped governedStateEvaluated true -> false and the guard
  // returned canonicalGovernedState {error: "Canonical governed-state
  // evaluation failed", degraded: true, blocked: true}.
  //
  // Public schema, organization_id INTEGER, so the sweep below polices it.
  // Its project key is project_ref TEXT with no foreign key — see the dated
  // note in the file for why the integer FK could not hold a Module 3 project.
  'migrations/0011_governed_decision_transitions.sql',

  // ── Data lineage + evidence chain (2026-09-28) ───────────────────────────
  // Same class as 0011 above: the only DDL for data_lineage_records and
  // evidence_chain_records, on NO applier, so neither table existed on a
  // deployed database. lineage-dossier's loadDataLineage hits 42P01, which
  // isMissingTable DOES match, so it silently returns [] and
  // computeLineageConfidence silently withholds its +10 — a sealed lineage
  // report scoring lower for a table that was never provisioned rather than
  // for evidence that was never recorded. GET /api/data-lineage/coverage/:type/:id
  // answers 500.
  //
  // Fully IF NOT EXISTS-guarded (13 guarded statements, no unguarded CREATE),
  // so it is replay-safe as-is and needs no in-place amendment. Public schema,
  // organization_id INTEGER NOT NULL on both tables, so the sweep below
  // polices them — which it could not while they were invisible to it.
  'migrations/20260327_data_lineage_tracking.sql',

  // ── An artifact's signatures and lock snapshots are append-only (2026-09-29)
  // concept2cure_signatures (the approval and release signatures the
  // readiness engine, the Artifacts Center and the DOCX signature block read)
  // and concept2cure_submission_snapshots (each lock's record) were protected
  // only by triggers in db/migrations/_legacy/ and by a migration on no
  // applier, so an UPDATE could rewrite a signer's name and a DELETE, or the
  // ON DELETE CASCADE from the artifact, could remove a signature. UPDATE,
  // DELETE and TRUNCATE are now refused for every role; no server code does
  // either (census in the file). Creates no table. Idempotent (CREATE OR
  // REPLACE FUNCTION, CREATE TRIGGER only when absent, to_regclass guarded);
  // required at boot by server/services/audit/audit-immutability-triggers.ts.
  // Evidence docs/evidence/D5/2026-09-29-artifact-signatures-append-only/.
  'migrations/20260929_concept2cure_signatures_append_only.sql',

  // ── A record names a project of its own organization only (PF-04, D3) ────
  // One composite key per store, (project key, org) → regulatory_programs (id,
  // organization_id): projects, authoring_documents, cre_evidence_sources,
  // c2c_documents, cdisc_prm_studies. NOT VALID (legacy rows are listed by
  // scripts/db/program-same-org-preflight.mjs, not scanned by the deploy), ON
  // DELETE SET NULL (key) so a tenant purge un-anchors instead of failing —
  // except c2c_documents, NO ACTION like the key it already has.
  // After every creator it keys: 20260524, 20260528/29, the cre spine and its
  // scope, the authoring scope, 20260814, and 20260925b's unique index (which it
  // also creates when that file skipped). authoring_documents comes from the
  // authoring subsystem deploy-migrate applies before this set. Creates no
  // table, so the sweep has nothing new to policy; it adds one column
  // (cdisc_prm_studies.program_id) to an existing table. No DROP.
  'migrations/20260926b_program_same_org_keys.sql',

  // ── The same rule for the integer project key (PF-03, D3, 2026-10-01) ─────
  // (project_id, org) → projects (id, organization_id) on concept2cure_artifacts
  // and c2c_submission_packages, on a unique index it creates when absent.
  // NOT VALID (legacy rows listed by program-same-org-preflight.mjs), ON DELETE
  // CASCADE like each table's existing project_id key, so a project delete is
  // unchanged. After every creator: 0000 (artifacts), 0002 (packages). Creates
  // no table; adds one index and two keys. No DROP.
  'migrations/20261001_integer_project_same_org_keys.sql',

  // ── A program has at most one anchor row (PF-08, 2026-10-01) ──────────────
  // Partial unique index on projects (regulatory_program_id), created only when
  // no program has two anchors; otherwise a NOTICE names them and the deploy
  // proceeds. After 20260814, which creates the column. Creates no table. No
  // DROP.
  'migrations/20261001b_projects_one_anchor_per_program.sql',

  // ── An AnA conversation names its project, by key (PF-10 S1, 2026-10-01) ──
  // chat_threads.program_id, held to the thread's organization by a NOT VALID
  // composite key (ON DELETE SET NULL (program_id)), with a CHECK, an index,
  // and a same-organization-only backfill from metadata->>'programId'. After
  // 20260728 (chat_threads) and 20260926b (regulatory_programs_id_org_uq,
  // created here too when absent). Creates no table. No DROP.
  'migrations/20261001c_chat_threads_program_key.sql',

  // ── RBQM: signed records stay signed; QTLs bite in their direction; a
  //    duplicate metric load is refused (2026-09-30) ─────────────────────────
  // Ported from the abandoned #1120 / #1123 / #1130 (+ #1166's UNIQUE replay
  // index). Each ALTERs a table 20260629 / 20260630 / 20260726 above create
  // with CREATE TABLE IF NOT EXISTS, so each ships as its own additive file
  // (the 20260918 note explains why an in-place amendment would reach no
  // deployed tenant). All ADD COLUMN / CREATE INDEX IF NOT EXISTS, constraints
  // added only when absent, to_regclass-guarded, no DROP; the plan-version
  // backfill runs only on the apply that adds the column, so a replay never
  // renumbers. Create no table, so the sweep has nothing new to policy. Above
  // the final pair because ci:migration-set-order pins those two last.
  'migrations/20260930_rbm_qtl_direction.sql',
  'migrations/20260930_rbm_plan_versioning.sql',
  'migrations/20260930_rbm_ingest_idempotency.sql',

  // ── The report type registry reaches a deployed database (2026-09-30, D2) ─
  // report_runs.report_type_id references report_type_registry(type_id), and
  // nothing on any applier inserted into it — its only writer,
  // POST /api/report-os/taxonomy/seed, was refused in production, and was
  // deleted in review round 1, leaving this file the one writer — so the
  // registry was empty on every provisioned database and every report run
  // answered 404. Generated from the in-code report types by
  // scripts/db/generate-report-type-registry-seed.ts (drift test beside the
  // taxonomy). INSERT … ON CONFLICT (type_id) DO UPDATE of every descriptive
  // column except `enabled`, so each deploy mirrors the code and an operator's
  // disable survives; ends with a row-count assertion. Raises when the table is
  // missing (drizzle-kit push creates it). Data only: no DDL, no DROP, creates
  // no table, so the sweep has nothing new to policy — the registry is global
  // by design (install-fresh's surface list, tenantColumn: null). Above the
  // final pair because ci:migration-set-order pins those last.
  // Evidence docs/evidence/D2-REPORTING-LAUNCH-APP/2026-09-30/report-os/.
  'migrations/20260930_report_type_registry_seed.sql',
  'migrations/20261001_organization_retention_settings.sql', // P1-22-org (ADR-0014 §6): one public org-keyed table, no DROP; above the pair so the sweep gives it RLS
  'migrations/20261001_domain_history_append_only.sql', // P1-24 (DP-15/16): append-only triggers on workflow_history, document_audit_logs, regulatory_audit_logs, c2c_ana_actions, authoring_signatures; after every creator; no table, no DROP
  'migrations/20261001_users_sessions_ended_at.sql', // P0-4b (IAM-04 b): users.sessions_ended_at + a trigger stamping it when status leaves 'active'; additive, no table, no DROP of anything the set creates
  // ── QMS/labeling and inspection stores reach deployment (2026-10-13, W1/D2) ─
  // Resolves D-2 in docs/evidence/reviews/2026-10-11-reporting-coverage/
  // DECISIONS-2026-10-12.md. Existing launch Quality routes read these stores;
  // they previously reached only install-fresh, so migration-only deployments
  // could not load the controlled-document register or inspection records.
  //
  // Order is load-bearing: raw-journal electronic_signatures lacks created_at.
  // The prerequisite adds it without backfilling historical signature times,
  // sets only FUTURE inserts' transaction-clock default and asserts all seven
  // columns. Both creators then run before the deferred signature guard, so
  // the same deploy provisions the stores and refuses unsigned status changes.
  // ci:migration-guard-order and the real-journal QMS deployment contract pin it.
  //
  // All 13 creator tables are public + organization_id INTEGER NOT NULL; their
  // IF NOT EXISTS DDL is replayable and the final sweep policies them. No rival
  // store is introduced. The same-org key file below also checks retained
  // parentage before adding nine VALIDATED organization-bound child keys.
  'migrations/20261013_electronic_signature_created_at_prerequisite.sql',
  'migrations/20260511_qms_and_labeling.sql',
  'migrations/20260610_inspection_readiness.sql',

  'migrations/20261001_qms_document_signature_required.sql', // P0-18 (DP-01 residual): deferred constraint triggers refusing qms_documents → effective/retired without a same-transaction signature; after 20260813d (signed_target); no table, no DROP
  'migrations/20261013b_qms_inspection_same_org_keys.sql', // W1/D2: preflight retained parentage; nine validated same-org QMS/labeling/inspection FKs, no data rewrite or DROP

  // ── IND lifecycle and assessment tables reach every deployed database (2026-10-01, D1) ─
  // Five tables existed only on databases installed after their 20260615
  // files. install-fresh overlays every top-level migrations/*.sql, so a new
  // install creates them. deploy-migrate applies only this array, and they
  // were not in it. drizzle-kit push does not create them either: their models
  // live in shared/schema/*.ts modules that drizzle.config.ts does not push. A
  // database provisioned before 2026-06-15 therefore never got them, and on
  // that database the IND amendment and annual-report registers
  // (server/routes/ind-lifecycle/registers.routes.ts) answer "relation does not
  // exist". Each file is CREATE TABLE/INDEX IF NOT EXISTS only, with no DROP, in
  // public and keyed by organization_id INTEGER NOT NULL. So it is a no-op where
  // the table exists, and the sweep below gives it its tenant policy where it
  // was missing. Replayed twice on PGlite: 0 of 5 tables before, 5 of 5 after.
  // (report_subscriptions, the sixth 20260615 file, is created by the report-os
  // push.)
  'migrations/20260615_ind_amendments.sql',
  'migrations/20260615_ind_annual_reports.sql',
  'migrations/20260615_ind_icsr_transmissions.sql',
  'migrations/20260615_regulatory_assessments.sql',
  'migrations/20260615_tmf_artifact_filings.sql',

  // ── Shared state across API tasks: continuity baseline and presence roster
  //    (2026-10-01, D1, audit W2 fix units U14 + U16) ───────────────────────
  // Production runs two API tasks behind an ALB with no stickiness. AnA
  // Command's continuity baseline and the Authoring presence roster each lived
  // in one task's memory, so the trend verdict and the roster depended on
  // which task answered and reset on every deploy. Each file creates one table
  // in public keyed by organization_id INTEGER NOT NULL (CREATE TABLE/INDEX IF
  // NOT EXISTS only, no DROP), so the sweep below gives it its tenant policy.
  // collab_presence sits in db/migrations beside its precedent,
  // 20260807_collab_section_locks.sql. Above the final pair because
  // ci:migration-set-order pins the tail. Evidence
  // docs/evidence/W2/2026-09-24-multi-task/u14-u16-shared-state.md.
  'migrations/20261001_project_continuity_snapshots.sql',
  'db/migrations/20261001_collab_presence.sql',

  // ── Scheduled jobs run once per window, not once per process (2026-10-01,
  //    D1, audit W2 fix unit U19) ────────────────────────────────────────────
  // The advisory lease stopped overlapping runs only; a tick on another task
  // that did not overlap ran the same window again (retention archived and
  // audited each disposition up to three times; the sentinel notified three
  // times an hour). One claim row per (organization, job, window), in public
  // with organization_id INTEGER NOT NULL so the sweep below gives it its
  // tenant policy. IF NOT EXISTS only, no DROP. Evidence
  // docs/evidence/W2/2026-09-24-multi-task/u19-scheduler-windows.md.
  'migrations/20261001d_scheduled_job_claims.sql',

  // ── Sign-in sessions shared by every server process (2026-10-01, D1, audit
  //    W2 fix unit U20) ─────────────────────────────────────────────────────
  // Production runs no Redis (decision B6); session activity, the session
  // registry and superseded markers lived in each process's memory, so every
  // deploy signed out everyone signed in longer than the idle window. One row
  // per session, in public with organization_id INTEGER NOT NULL (always 0,
  // system scope only) so the sweep below gives it its tenant policy. IF NOT
  // EXISTS only, no DROP. Evidence
  // docs/evidence/W2/2026-09-24-multi-task/u20-sessions-across-tasks.md.
  'migrations/20261001e_session_activity.sql',

  // ── AnA action locks and per-organisation slots shared by every process
  //    (2026-10-01, D1, audit W2 fix unit U21) ─────────────────────────────
  // Decision B6 (no Redis): the write-action target lock and the per-org cap
  // held per process, so two writes on one document ran on two tasks. Leases
  // carry the acting organisation (organization_id INTEGER NOT NULL, public)
  // so the sweep below gives the table its tenant policy. IF NOT EXISTS only.
  // Evidence docs/evidence/W2/2026-09-24-multi-task/u21-action-leases.md.
  'migrations/20261001f_coordination_leases.sql',

  // ── A review comment is fixed once posted (2026-10-01, D5) ────────────────
  // concept2cure_thread_comments (the Review surface's threads) could be
  // rewritten in place, soft-deleted and overwritten by the GDPR erasure, with
  // no record of what a comment said. Triggers only: the words, author and
  // place fixed, deleted_at set once (a retraction), DELETE and TRUNCATE
  // refused. Creates no table, so the sweep has nothing new to policy. Above
  // the final pair because ci:migration-set-order pins the tail. Evidence
  // docs/evidence/D5-ANA-RECORD/2026-10-01-review-comments/.
  'migrations/20261001_review_comments_record.sql',
  'migrations/20261001_compliance_review_records.sql', // P1-25 + P1-43 (ADR-0014 §8): one public org-keyed table (audit-trail and access reviews), signed through the ceremony, fixed once signed; after electronic_signatures' creators; no DROP of anything another file creates; above the pair so the sweep gives it RLS
  /* Vault document relationships (plan critique 15, D2, 2026-10-01): the
     replacement for parentDocumentId. One public, org-keyed table (Rule 1),
     frozen identity, one-way removal with a reason, no TRUNCATE, DELETE only
     by cascade or the owner. Reached by the tenant purge through ON DELETE
     CASCADE from regulatory_programs and vault.documents. Above the pair so
     the sweep gives it row security. No DROP. */
  'migrations/20261001_vault_document_relationships.sql',
  /* Review annotations on a Vault version (plan critique 15, D2/D5,
     2026-10-01): public, org-keyed (Rule 1), posted-open and checked in SQL
     (version, organisation, content hash, body and passage SHA-256 in code
     points, page against page count), frozen words and anchor, write-once
     outcome, author-only retraction, DELETE only by the owner once the version
     is gone, no TRUNCATE. Above the pair so the sweep gives it row security.
     No DROP. */
  'migrations/20261001_vault_version_annotations.sql',

  // ── Which account an organisation's submissions go out under (2026-10-01,
  //    D7, founder decision) ───────────────────────────────────────────────
  // Per organisation, agency gateway and environment: the platform's gateway
  // account or the client's own (credentials encrypted, never returned). Read
  // by the guarded transmit, which records the mode and sender on every
  // transmittal. One public table, organization_id INTEGER NOT NULL, so the
  // sweep below gives it its tenant policy. IF NOT EXISTS only, no DROP.
  // Evidence docs/evidence/D7/2026-10-01-gateway-account-choice/.
  'migrations/20261001g_organization_gateway_accounts.sql',

  // ── The six core CMC registers carry their program (2026-10-05, D2, CMC/
  //    Module 3 lane) ───────────────────────────────────────────────────────
  // drug_substances, drug_products, stability_studies, analytical_methods,
  // process_validation and cmc_change_control gain a nullable project_id and an
  // index; a backfill fills NULLs only where cmc_source_objects names exactly
  // one program for the row. ADD COLUMN IF NOT EXISTS + NULL-only backfill, no
  // DROP, replay-safe. The tables already carry organization_id and their
  // tenant policy. Evidence docs/evidence/CMC-M3-GA/2026-10-05/05-registers-carry-their-program/.
  'migrations/20261005_cmc_core_registers_project.sql',

  // ── CMC source evidence (2026-10-05, row D2) ──────────────────────────────
  // The Vault document a CMC record was taken from: one append-only link from
  // a cmc_source_objects key to a Vault version of the same program, with the
  // version's content hash at link and the person's reason. Removal is
  // one-way and needs a reason; DELETE only by the purge's cascade. A
  // superseded or withdrawn linked version holds the sections that read the
  // record at approval and at the export gate. public + organization_id
  // INTEGER NOT NULL, so the sweep below gives it row security. CREATE IF NOT
  // EXISTS, no DROP. Evidence docs/evidence/CMC-M3-GA/2026-10-05/08-cmc-evidence-from-the-vault/.
  'migrations/20261005b_cmc_source_evidence.sql',

  // ── Module 3 history append-only (2026-10-05, DP-84; rows D2, D5, D6) ──────
  // The signed section snapshots (cmc_module3_section_versions) and the Module 3
  // provenance trail (cmc_provenance_events) refuse UPDATE, DELETE and TRUNCATE
  // for every role, through public.domain_history_append_only() from
  // 20261001_domain_history_append_only.sql above. Census in the file: every
  // writer INSERTs only. Creates no table, drops nothing another file creates.
  // Evidence docs/evidence/CMC-M3-GA/2026-10-05/19-module3-history-append-only/.
  'migrations/20261005c_cmc_module3_history_append_only.sql',

  // ── Module 1 filed where FDA and PMDA file it (2026-10-05, D2) ─────────────
  // nda:fda and bla:fda ich-m4-v2.2, anda:fda fda-anda-21cfr314-94-v1.1 and
  // jnda:pmda ich-m4-v2.2 as NEW versions superseding v2.1 / v1.0: the gates
  // required '1.19 Environmental analysis' of an NDA (FDA 1.19 is Pre-EUA and
  // EUA; environmental analysis is 1.12.14), 1.14.4/1.14.5 for carton labels and
  // SPL (investigational / foreign labeling), and of an ANDA patent
  // certification under 1.15 (Promotional material); the J-NDA outline had no
  // 1.11 draft RMP. Modules 2–5 unchanged. ON CONFLICT DO NOTHING, the
  // 20260810c provenance UPDATE (so after 20260810c), guarded supersede, a
  // row-count RAISE; no DROP, no edit of 20260804/20260806b. Documents bound to
  // the old versions keep their outline. maa:ema not minted (decision 3).
  // Evidence docs/evidence/D2-ANA-DOCUMENT-INTELLIGENCE/2026-10-05-record/g-fda-jnda-rule-pack-m1-v2-2-*.
  'migrations/20261005_fda_jnda_m1_outline_v2_2.sql',

  // ── The PMA outline names FDA's software Documentation Level (2026-10-05, D2)
  // pma:fda fda-pma-21cfr814-20-v1.1: v1.0 node for node except C.4, which read
  // "Software description and level of concern" — the 2005 construct FDA's
  // June 2023 device-software guidance replaced with the Basic/Enhanced
  // Documentation Level. ON CONFLICT DO NOTHING, provenance UPDATE after
  // 20260810c, supersede of exactly v1.0, a 67-node / C.4 / live-pack RAISE; no
  // DROP. 20260810's supersede was amended in place in the same change to name
  // 'fda-pma-2024' only — its `version <> v1.0` form re-superseded this row on
  // every replay. Documents bound to v1.0 keep their outline (decision 6).
  // Evidence docs/evidence/D2-ANA-DOCUMENT-INTELLIGENCE/2026-10-05-record/g-pma-pack-software-doc-level-*.
  'migrations/20261005b_pma_fda_outline_v1_1_software_documentation_level.sql',

  // ── The 510(k) and De Novo outlines carry the user fee and risk management (2026-10-05, D2)
  // k510:fda fda-estar-510k-v1.1 (v1.0 + A9 MDUFA user fee / Form FDA 3601,
  // mandatory; + D6 Benefits, Risks and Mitigation Measures, optional — eSTAR
  // v7.0 shows it for a Special 510(k) only) and denovo:fda
  // fda-estar-denovo-v1.1 (v1.0 + A7 user fee). v1.0 had no section for two
  // slots the eSTAR mapper requires, so a fully authored governed 510(k) could
  // never score complete. ON CONFLICT DO NOTHING, provenance UPDATE after
  // 20260810c, supersede of exactly v1.0, an exact-tree / node-count / one-live
  // RAISE; no DROP, 20260901b not edited. Documents bound to v1.0 keep their
  // outline (decision 6).
  // Evidence docs/evidence/D2-ANA-DOCUMENT-INTELLIGENCE/2026-10-05-record/g-k510-denovo-pack-v1-1-*.
  'migrations/20261005c_k510_denovo_estar_outline_v1_1.sql',

  // W2/D2 + D5: append-only typed logical file/extracted-data dispositions.
  // Source/Vault/lineage rows and physical retention remain intact. Before the
  // final RLS sweeps because this is public + organization_id INTEGER.
  'migrations/20261006_document_data_dispositions.sql',

  // ── Every program has its project record (2026-10-08, P-19) ──────────────
  // Inserts the projects row intake inserts (ensureProgramProjectAnchor's
  // values and workspace rule) for each live program that no projects row
  // anchors: programs a seed or a pre-anchor intake wrote. Skips, with a
  // NOTICE, an organisation whose workspace is ambiguous, and a program another
  // organisation's row names. After 20260814 (whose code/name link runs first),
  // 20260923, 20260926b and 20261001b. INSERT … WHERE NOT EXISTS … ON CONFLICT
  // DO NOTHING; creates no table, drops nothing. Evidence
  // docs/evidence/QA-2026-10-08/program-anchor/.
  'migrations/20261008_program_project_anchor_backfill.sql',

  // ── The 1571's sponsor address and IND type, on the program (2026-10-08) ──
  // P-20 follow-up: two nullable TEXT columns on regulatory_programs, which the
  // IND forms panel saves (PUT /api/ind-forms/program-facts) and the 1571 build
  // reads. ADD COLUMN IF NOT EXISTS only; no CHECK (the IND type is validated
  // against the forms registry by the route), no DROP. regulatory_programs is
  // public + organization_id INTEGER, so it creates nothing the sweeps below
  // must reach. Evidence docs/evidence/QA-2026-10-08/ind-reporting-3/.
  'migrations/20261008b_regulatory_programs_sponsor_address_ind_type.sql',

  // ── The Data Room keeps the text it read, and is searchable (2026-10-08) ──
  // Data Room catalog S2 (D2): extracted_text, char_count, page_count and
  // text_extracted_at on cre_evidence_sources, plus a GIN full-text index over
  // vault.document_search_vector for client documents. ADD COLUMN / CREATE
  // INDEX IF NOT EXISTS, each guarded; no DROP. The table is public with
  // organization_id INTEGER and already policied. Evidence
  // docs/evidence/D2-DATA-ROOM-CATALOG/2026-10-08-s2-processed-searchable/.
  'migrations/20261008c_data_room_source_text.sql',

  // ── A capture names its study, of its own organization (2026-10-08) ──
  // Data Room catalog S3 (D2): study_ref on cre_evidence_sources, a unique
  // (id, tenant_id) index on cdisc_prm_studies, and a NOT VALID same-org key
  // ON DELETE SET NULL (study_ref). Each guarded; no DROP; nothing new for the
  // sweeps to reach. After 20260926b, which keys the study to its program.
  'migrations/20261008d_cre_source_study_ref.sql',

  // ── AnA's catalog record is a suggestion a person confirms (2026-10-08) ──
  // Data Room catalog S4 (D5): catalog_state, the proposer (agent, model,
  // thread, turn) and the person's confirmation or correction on
  // vault.document_catalog, with a CHECK added only when absent. ADD COLUMN
  // IF NOT EXISTS; no DROP; no row rewritten. After 20260905_document_catalog.
  'migrations/20261008e_document_catalog_attribution.sql',

  // ── A computed figure names its stored, reproducible run (2026-10-08) ──
  // Data Room catalog S5b (D2): public.stats_computation_runs (inputs, outputs,
  // their SHA-256, engine, version, seed), organization_id INTEGER NOT NULL for
  // the sweeps below, and same-organization keys to the project and the study
  // design ON DELETE SET NULL of their own column. IF NOT EXISTS; no DROP.
  // After 20261008d, whose cdisc_prm_studies (id, tenant_id) index it keys to.
  'migrations/20261008f_stats_computation_runs.sql',
  // ── The readiness digest's registry context, on the project record ───────
  // (2026-10-08, QA second walk j8). Adds registryId / submissionType keys to
  // projects.metadata where the program's own organisation's record holds
  // none: the program's recorded wizard choice, else the entry its filing type
  // and agency fix (PROGRAM_TYPE_REGISTRY, server/services/c2c/program-
  // registry-context.ts). After 20261008, whose anchor rows it completes in
  // the same deploy. UPDATE … WHERE no context; never overwrites, creates no
  // table, drops nothing. Evidence docs/evidence/QA-2026-10-08/intake-readiness/.
  'migrations/20261008c_projects_registry_context.sql',

  // ── A review task raised on an authoring document is on its project ──────
  // (2026-10-08, QA second walk j1). Sets unified_tasks.project_id where NULL
  // for tasks whose source is an authoring document, to that document's
  // program's project record in the same organisation (lowest id, as
  // readProgramAnchorRow reads it) — the rule POST /api/tasks/tasks now applies
  // (services/tasking/task-project.ts). After 20261008, whose anchors it reads.
  // UPDATE … WHERE project_id IS NULL; creates nothing, drops nothing.
  // Evidence docs/evidence/QA-2026-10-08/intake-readiness/.
  'migrations/20261008d_unified_tasks_authoring_review_project.sql',

  // ── An attached Module 1 form records the forms engine's check ───────────
  // (2026-10-08, QA second walk j7). rendered_leaf_files.required_fields_missing
  // text[]: '{}' complete, non-empty attached-not-complete, NULL never checked
  // (never complete). The IND checklist counts a sponsor-attached form only on
  // '{}'. ADD COLUMN IF NOT EXISTS; no backfill (earlier attachments were never
  // checked); drops nothing. After 20260903 (the table). Evidence
  // docs/evidence/QA-2026-10-08/intake-readiness/.
  'migrations/20261008e_rendered_leaf_files_required_fields_missing.sql',

  // ── AnA detach DT1: the live turn's timeline mirror (2026-10-08) ─────────
  // public.ana_run_events: append-only (guard trigger), deleted only through
  // three SECURITY DEFINER doors owned by the NOLOGIN ana_run_events_purger
  // role (release after the record is sealed, legal-hold-aware expiry, the
  // tenant purge). After 20260917 (ana_runs, its FK parent, amended in place
  // the same day with six columns) and 20260926 (ana_turn_records, which the
  // guard and the doors read). public + organization_id INTEGER NOT NULL, so
  // it sits above the final sweeps, which give it its tenant policy. Creates
  // only; drops nothing. docs/design/ANA_DETACH_2026-10-08.md §3; evidence
  // docs/evidence/ANA-SUMMARY/2026-10-08/DT1-run-events/.
  'migrations/20261008f_ana_run_events.sql',
  // A submission leaf names the study it belongs to and its STF file-tag, so a US
  // sequence can satisfy FDA validation 1789 rather than be refused by it (D2).
  'migrations/20261012_submission_leaf_stf_study_tagging.sql',

  // ── A European device programme can record its own class (2026-10-12) ─────
  // eu_mdr_class and eu_ivdr_class on regulatory_programs. device_class is the
  // US class and is printed on US forms, so until now a European programme
  // could be configured in every respect except its classification — which
  // AnA's interview asks, the Annex VIII engine derives, and the conformity
  // routes are offered from. Additive, IF NOT EXISTS, no CHECK (the two
  // vocabularies are shared/regulatory/device-class.ts's and the write
  // validates against them). public + organization_id INTEGER, so it creates
  // nothing the sweeps below must reach. Evidence
  // docs/evidence/ANA-QUESTIONS/2026-10-12-eu-classes/.
  'migrations/20261012b_regulatory_programs_eu_device_classes.sql',

  // Exact source text admitted by the AnA host budget: tenant-owned immutable
  // metadata, not provider-delivery or scientific-review evidence. Replay-safe
  // ledger and controlled legal-hold-aware purge door; no legacy backfill.
  // Public integer tenant key, created before the final isolation sweeps.
  'migrations/20261014_ana_source_read_receipts.sql',

  UUID_TENANT_ISOLATION_NONPUBLIC,

  // ── Parent-scoped RLS for child tables (added 2026-08-13; moved 2026-09-29)
  // 21 tables held tenant data with NO tenant column, NO RLS and NO policy —
  // readable by every tenant (chat_messages the sharpest: every tenant's
  // conversation bodies). The FK is the evidence of ownership, so these get a
  // PARENT-scoped policy rather than a tenant column of their own; the list has
  // grown since (see the file's dated notes).
  //
  // Here, not mid-set (D3, 2026-09-29): its chained list delegates to parents'
  // own policies, and some of those come from the uuid step just above, so run
  // earlier it logged "the parent is not scoped … skipping" and a blank
  // database's first deploy left regulatory_harmonization.export_job_audit_log
  // unscoped until the second. And a child or parent created by any entry
  // above is now present when it runs. It creates no table, so the sweep below
  // still sees everything the set creates. ci:migration-set-order pins the
  // tail. Evidence docs/evidence/D3/2026-09-29-child-scope-first-deploy/.
  CHILD_TABLE_PARENT_SCOPE,

  // ── Tenant isolation for everything the set just created (ledger C-33) ───
  // MUST BE LAST. 0021_enable_rls_everywhere runs once, on install-fresh, and
  // policies only the tables that exist at that moment. Every table added by the
  // set above lands on an already-provisioned database where 0021 has long since
  // run and will never revisit it — and under RLS_ENFORCE=on a table with no RLS
  // is fully readable across tenants. This sweep is 0021's loop made re-runnable
  // and deploy-safe: it only ADDS a policy where none exists (never clobbering a
  // subsystem's own, including C-30's parent-scoped ones), and it SKIPS a
  // non-integer tenant key with a NOTICE instead of aborting the deploy.
  TENANT_ISOLATION_SWEEP,
];

/** Files that open their own transaction must not be wrapped in a second one. */
const selfTransacting = sql => /^\s*BEGIN\s*;/im.test(sql);

/* ── Lock waits on a live database (2026-09-25, W2 / D1) ──────────────────────
   deploy-aws.yml runs this set while the previous API tasks are still serving,
   and every file re-runs on every deploy (Rule 1). A replay that changes nothing
   still takes ACCESS EXCLUSIVE on 151 tables in 114 of the 309 files, measured
   on a provisioned PostgreSQL 16 database — projects, organizations, users,
   audit_logs, vault.documents among them: `ALTER TABLE … ADD COLUMN IF NOT
   EXISTS` takes the lock before it checks. Uncontended that is milliseconds.
   Contended, PostgreSQL queues the ALTER behind any open transaction that has
   read the table, and queues every later query on the table behind the ALTER.
   With no lock_timeout the wait was the blocker's to end — up to the runtime
   pool's 30 s statement timeout, 60 s for an idle transaction — and for that
   long every request that touched the table hung. tests/db/migration-lock-
   timeout.dbtest.ts measured 3998 ms against a 4000 ms reader.

   So each lock wait is capped, and a file that hits the cap is rolled back and
   retried with backoff: the application waits at most one lock_timeout, the
   migration waits as long as the blocker needs within a bounded budget, and a
   lock that never frees fails the deploy naming the file. Retrying a file is
   safe for the reason Rule 1 exists: every file here already re-runs on every
   deploy. Defaults: 2 s per wait, 12 attempts, backoff from 1 s doubling to a
   10 s cap — about 110 s in all, past the runtime's 60 s idle-transaction
   limit and far inside the migrate task's 30-minute deadline. */
const LOCK_NOT_AVAILABLE = '55P03';

/** The lock-wait policy, from the environment, with the defaults above. */
export function migrationLockPolicy(env = process.env) {
  const positive = (value, fallback) => {
    const n = Number.parseInt(value ?? '', 10);
    return Number.isFinite(n) && n > 0 ? n : fallback;
  };
  return {
    lockTimeoutMs: positive(env.C2C_MIGRATION_LOCK_TIMEOUT_MS, 2000),
    lockAttempts: positive(env.C2C_MIGRATION_LOCK_ATTEMPTS, 12),
    lockBackoffMs: positive(env.C2C_MIGRATION_LOCK_BACKOFF_MS, 1000),
  };
}

/** True for a statement that gave up waiting for a lock (also when wrapped as `cause`). */
export const isLockTimeout = err =>
  err?.code === LOCK_NOT_AVAILABLE || err?.cause?.code === LOCK_NOT_AVAILABLE;

/**
 * Run `attempt` (which must roll itself back on failure) until it succeeds, or
 * fails with anything but a lock timeout, or has timed out `attempts` times.
 */
export async function retryOnLockTimeout(attempt, { label, attempts, backoffMs, log = () => {} }) {
  for (let n = 1; ; n++) {
    try {
      return await attempt();
    } catch (err) {
      if (!isLockTimeout(err)) throw err;
      if (n >= attempts) {
        throw new Error(
          `${label}: could not take its table locks in ${attempts} attempts (each bounded by ` +
            `lock_timeout). A transaction on the live database is holding a table it alters; ` +
            `it was rolled back each time. ${err.message}`,
          { cause: err },
        );
      }
      const wait = Math.min(backoffMs * 2 ** (n - 1), 10_000);
      log(`… ${label}: lock not available (attempt ${n}/${attempts}); rolled back, retrying in ${wait} ms`);
      await new Promise(resolve => setTimeout(resolve, wait));
    }
  }
}

/** Who has held a transaction open longer than the lock wait: the likely blockers. */
async function describeLongTransactions(pool, olderThanMs) {
  try {
    const { rows } = await pool.query(
      `SELECT pid, usename, state, round(extract(epoch FROM now() - xact_start))::int AS seconds,
              left(regexp_replace(query, '\\s+', ' ', 'g'), 120) AS query
         FROM pg_stat_activity
        WHERE datname = current_database() AND pid <> pg_backend_pid()
          AND xact_start < now() - make_interval(secs => $1 / 1000.0)
        ORDER BY xact_start LIMIT 5`,
      [olderThanMs],
    );
    return rows.map(r => `pid ${r.pid} (${r.usename}, ${r.state}, ${r.seconds}s): ${r.query}`);
  } catch {
    return [];
  }
}

/**
 * Apply `files` (repo-relative) against `pool`, one transaction per file.
 *
 * `stopOnFirstFailure` is the difference between the two callers. The manual
 * applier reports every problem in one run (false) so an operator sees the full
 * picture; the deploy applier stops at the first failure (true) so a faulted
 * migration never leaves a deploy applying further DDL on top of a schema it has
 * already failed to move — the half-applied state is the one nobody can reason
 * about.
 *
 * @returns {Promise<{ applied: string[], failures: Array<{ file: string, error: string }> }>}
 */
export async function applyMigrationFiles(
  pool,
  repoRoot,
  files,
  { log = () => {}, error = () => {}, stopOnFirstFailure = false, ...lockOptions } = {}
) {
  const applied = [];
  const failures = [];
  const defaults = migrationLockPolicy();
  const lockTimeoutMs = lockOptions.lockTimeoutMs ?? defaults.lockTimeoutMs;
  const lockAttempts = lockOptions.lockAttempts ?? defaults.lockAttempts;
  const lockBackoffMs = lockOptions.lockBackoffMs ?? defaults.lockBackoffMs;
  /* Every NOTICE and WARNING the migrations raise, SURFACED.
     node-postgres delivers server notices only to a 'notice' listener, and no
     applier registered one — so a migration whose DO block skipped a table
     (the child-table RLS sweep leaving a pair unpolicied, the tenant sweep's
     drift branch, the atom-identity reconciliation's WARNING about a table it
     will not touch) printed nothing but "✓ applied". A deploy that policied
     forty tables and one that policied one were the same clean green run.
     The messages are the only signal these files produce; they belong in the
     deploy log next to the file that raised them. */
  const noticeListener = msg => {
    const text = String(msg?.message ?? '').trim();
    if (!text) return;
    const severity = String(msg?.severity ?? 'NOTICE').toUpperCase();
    /* A NOTICE saying an object already exists is the IF NOT EXISTS guard
       working as designed, on every replay of every idempotent file — noise
       that would bury the ones that matter. */
    if (severity === 'NOTICE' && /already exists, skipping|will create implicit/i.test(text))
      return;
    (severity === 'WARNING' || severity === 'ERROR' ? error : log)(`    [${severity}] ${text}`);
  };
  /* Attached to whatever the caller passed: deploy-migrate hands in a CLIENT
     (which is what emits 'notice'), apply-c2c-migrations hands in a POOL, whose
     clients emit it — so a pool is covered through 'connect'. A fresh pool
     opens its first connection on the first query below, after this line. */
  const attachNotices = target => target?.on?.('notice', noticeListener);
  attachNotices(pool);
  pool.on?.('connect', attachNotices);

  // Provision the ledger table once per run. Best-effort for the same reason the
  // per-file record is: a journal that cannot be created must not stop migrations
  // from applying. When this fails, each recordApplied below fails the same way and
  // is reported per file.
  try {
    await ensureJournal((text, params) => pool.query(text, params));
  } catch (journalErr) {
    if (process.env.C2C_MIGRATION_JOURNAL_STRICT === '1') throw journalErr;
    error(`  (migration journal unavailable: ${journalErr.message})`);
  }

  /* Session-level, so it also bounds the files that open their own
     transaction; restored in `finally`. deploy-migrate passes one client. The
     manual applier passes a Pool it uses serially, which therefore runs every
     statement on the one connection it opened. */
  const priorLockTimeout = (await pool.query('SHOW lock_timeout')).rows[0].lock_timeout;
  await pool.query(`SELECT set_config('lock_timeout', $1, false)`, [`${Number(lockTimeoutMs)}ms`]);

  try {
    for (const file of files) {
      const full = path.join(repoRoot, file);
      if (!fs.existsSync(full)) {
        failures.push({ file, error: 'missing from repo' });
        error(`✗ missing: ${file}`);
        if (stopOnFirstFailure) return { applied, failures };
        continue;
      }
      const sql = fs.readFileSync(full, 'utf8');
      const wrap = !selfTransacting(sql);
      try {
        await retryOnLockTimeout(
          async () => {
            try {
              if (wrap) await pool.query('BEGIN');
              await pool.query(sql);
              if (wrap) await pool.query('COMMIT');
            } catch (err) {
              await pool.query('ROLLBACK').catch(() => {});
              throw err;
            }
          },
          { label: file, attempts: lockAttempts, backoffMs: lockBackoffMs, log: error },
        );
        applied.push(file);
        // Applied-file ledger + content-hash drift signal. The deploy mechanism
        // records THAT migrations ran; this records WHICH file ran and the sha256 of
        // the SQL that ran, so a file edited after it was applied is detectable
        // instead of silently diverging. Sited here rather than in either caller so
        // both the out-of-band applier and the deploy path are covered.
        //
        // `sql` is the already-read contents — deliberately not re-derived from a
        // path inside the journal module (that read tripped a path-traversal SAST
        // rule and there is no reason to touch the filesystem twice).
        //
        // Best-effort by default: a journal outage must not fail an otherwise good
        // migration run. Set C2C_MIGRATION_JOURNAL_STRICT=1 to make it fatal.
        try {
          await recordApplied((text, params) => pool.query(text, params), file, sql);
        } catch (journalErr) {
          if (process.env.C2C_MIGRATION_JOURNAL_STRICT === '1') throw journalErr;
          error(`  (journal skipped for ${file}: ${journalErr.message})`);
        }
        log(`✓ applied: ${file}`);
      } catch (err) {
        // The attempt above has already rolled its transaction back.
        const detail = `${err.message}${err.detail ? ` (${err.detail})` : ''}`;
        failures.push({ file, error: detail });
        error(`✗ failed:  ${file} — ${detail}`);
        if (isLockTimeout(err)) {
          for (const line of await describeLongTransactions(pool, lockTimeoutMs)) error(`    open transaction: ${line}`);
        }
        if (stopOnFirstFailure) return { applied, failures };
      }
    }

    return { applied, failures };
  } finally {
    await pool
      .query(`SELECT set_config('lock_timeout', $1, false)`, [priorLockTimeout])
      .catch(() => {});
    /* Removed on every path, including the early returns above: the pool
       outlives this call, and a listener left behind would double-print the
       next caller's notices. */
    pool.removeListener?.('notice', noticeListener);
    pool.removeListener?.('connect', attachNotices);
  }
}
