/**
 * /api/c2c/project-vault/:id — Vault (DMS) surface read-model.
 *
 * Serves the display shape that client/src/concept2cure/v2/surfaces/Vault.tsx
 * renders (its `Spine` of VaultFolder / VaultDoc), populated from REAL,
 * org-scoped data:
 *
 *   regulatory_programs      → project name + product modality (→ vault view)
 *   c2c_documents            → one top-level folder per active document build
 *   c2c_rule_packs           → the required-section spec tree for each build
 *   c2c_document_sections    → LIVE section status / version / owner / timestamp
 *   users                    → real owner attribution (section & document owner_id)
 *   concept2cure_artifacts   → the "Module 3 (CMC)" branch: governed §3.x
 *                              artifacts the CMC compile bridge files, via the
 *                              program→project anchor
 *   vault.documents          → the "Uploaded files" branch: what this surface's
 *                              own Upload button ingests
 *
 * This is the same document/section data the existing
 * `GET /api/c2c/projects/:id/vault-structure` endpoint reads, but mapped
 * SERVER-SIDE straight into the Vault.tsx display shape (folder tree of
 * VaultDoc/VaultFolder) so the surface can render it with a single fetch and
 * no client-side converter — and with real owner + relative-modified
 * provenance instead of the client converter's placeholders.
 *
 * Response envelope: { success: true, data: <displayShape> }.
 *
 * HONESTY (regulated product): every field is projected or faithfully derived
 * from a real column. Nothing is fabricated. The fixture-only "cross-cutting"
 * DMS folders (Agency correspondence, Templates, Working drafts, Sources &
 * evidence, Audit) and the surface's client-synthesized corpus-indexing / chunk
 * counts are NOT emitted here — they have no backing store in this model. See
 * the route module's design notes / PR caveats.
 *
 * Mounted (by the central bootstrap) at /api/c2c/project-vault behind
 * authMiddleware, which supplies org context on req. Uses its own sub-prefix
 * (not stacked on /api/c2c/projects) to avoid a second authMiddleware pass on
 * the shared prefix — matching the per-surface read-model convention in
 * register-inline-routes.ts.
 *
 * @module server/routes/c2c/project-vault
 */

import { Router, type Request, type Response } from 'express';
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { createHash } from 'node:crypto';

import { pool } from '../../db.js';
import type { PoolClient } from 'pg';
import { createScopedLogger } from '../../utils/logger.js';
import { productTypesToSegments } from '../../services/report-os/segment.js';
import {
  foldersForView,
  VAULT_FOLDER_PRESETS,
  VAULT_VIEWS,
  VAULT_DOC_KINDS,
  type VaultViewId,
  vaultIngestTypeLabel,
  vaultSpineLabel,
} from '../../../shared/constants/domain/vault-taxonomy.js';
import { sectionHasContentSql, sectionCompletionPct } from '../../services/c2c/section-content.js';
import {
  resolveOrgVaultView,
  folderLabel,
} from '../../services/vault/vault-filing.service.js';
import { listClientDocuments } from '../../services/clinical-regulatory-evidence/evidence-spine.service.js';
import { sourceReadView } from '../../../shared/data-room-processing-status.js';
import { sourceProcessingSummary } from '../../services/clinical-regulatory-evidence/data-room-processing-read.js';
import { readVaultCoverage, type VaultCoverage } from '../../services/vault/vault-coverage.js';
import { normalizeCtdCode, compareSectionCode } from '../../../shared/regulatory/section-code.js';
import { writeChainedAuditRow } from '../../services/auditService.js';
import { readRecordAuditHistory } from '../audit-trail-ledger.routes.js';
import { readVersionFamily, supersededSql, versionCountLateral } from '../../services/vault/vault-version-family.js';
import { readVaultLifecycles, vaultVersionNotTransmittable } from '../../services/vault/vault-lifecycle.js';
import { countDataRoomStages, fileDataRoomSources, readFiledAs } from '../../services/vault/vault-data-room-filing.js';
import { vaultDataEligibleSql, vaultBinaryAvailableSql, vaultDispositionChoiceSql } from '../../services/document-data-disposition/eligibility.js';
import { searchVaultDocuments } from '../../services/vault/vault-search.js';
import { setTenantContextTx } from '../../services/tenant/governed-tenant-context.js';
import { governedActorId, requireEditorAccess } from '../../middleware/orgMembership.js';
import { getStorageProvider, getStorageProviderFor } from '../../services/storage/index.js';
/* The one translation from a CMC TEXT project id to the integer the
   governed artifact registry FKs to. Its contract requires every caller to
   branch on the resolution and keep an honest degraded path. */
import { resolveCmcArtifactProject } from '../../services/cmc/resolve-cmc-artifact-project.js';
import { programInOrganization } from '../../services/c2c/program-access';
import { resolveUserId } from '../../types/auth-request';

const logger = createScopedLogger('c2c-project-vault-routes');

// ─── Display-shape types (mirror client Vault.tsx VaultDoc / VaultFolder) ──────

interface VaultDoc {
  id: string;
  num: string;
  title: string;
  type: string;
  status: string;
  /** Authoring completion, 0–100. Null for an upload: it has none, and a 0
   *  there was read to AnA as "0% complete". */
  pct: number | null;
  owner: string;
  ver: string;
  updated: string;
  preview: string;
  blocker?: boolean;
  flag?: string;
  /** Discriminator: an authored section vs an uploaded vault.documents row. */
  src?: 'authored' | 'upload';
  /** Upload-only extras (all projected from real columns). */
  docId?: string;
  originalFileAvailable?: boolean;
  disposition?: 'keep_data' | 'remove_data' | 'supersede' | null;
  sizeLabel?: string;
  hash?: string;
  /** vault.documents.mime_type, verified against the magic bytes at ingest.
   *  The surface offers "Place into submission" only for a PDF: the packager
   *  refuses any other leaf. */
  mimeType?: string | null;
  filing?: UploadFiling;
  /** The version's recorded descriptive fields, as stored (uploads only):
   *  what Edit details starts from. */
  details?: { documentTitle: string | null; documentType: string | null; classification: string | null };
  /** How many versions the document has (VR-09); the leaf is its current one. */
  versionCount?: number;
  /** vault.documents.document_code (uploads only): a 409 at this code offers a check-in (VR-09). */
  documentCode?: string | null;
  /** This version's lifecycle stage (uploads only, VR-13): null when it has no record, i.e. not reviewed. */
  lifecycleStage?: string | null;
}

/** The placement block for an uploaded document — mirrors vault-ingest. */
interface UploadFiling {
  folderId: string | null;
  folderLabel: string;
  evidenceKind: string | null;
  ctdSection: string | null;
  placementStatus: string;
  confidence: string | null;
  rationale: string | null;
}

interface VaultFolder {
  id: string;
  code: string;
  label: string;
  children: Array<VaultFolder | VaultDoc>;
}

/** One Data Room source with its derived pipeline stage. */
interface DataRoomRow {
  id: number;
  title: string;
  kind: string;
  sizeLabel: string;
  addedAt: string;
  /** captured → classified → filed; DERIVED, never stored guesswork:
   *  'filed' = its checksum matches a vault document in this program,
   *  'classified' = the classifier proposed a folder for it,
   *  'needs_review' = the classifier ran and refused to propose one,
   *  'captured' = the classifier has not run on it.
   *  ("Classified" used to mean "the classifier ran", so a refusal read as a
   *  classification.) */
  stage: 'captured' | 'needs_review' | 'classified' | 'filed';
  readState: string;
  suggestedFolder: string | null;
  suggestedFolderLabel: string;
  evidenceKind: string | null;
  confidence: string | null;
  needsReview: boolean;
  /** Which Vault version its bytes became (VR-16): `supersededBy` names the
   *  family's current version when a later one replaced it. Null when not filed. */
  filedAs: { version: string | null; supersededBy: string | null } | null;
}

interface DataRoomBlock {
  captured: number;
  /** Sources the classifier placed, filed ones included (the pipeline is cumulative). */
  classified: number;
  filed: number;
  /** Sources the classifier refused to place: a person has to decide. */
  needsReview: number;
  sources: DataRoomRow[];
  /** The lane LISTS the newest DATA_ROOM_WINDOW current sources. The counts
   *  above cover every current source of the project (countDataRoomStages,
   *  2026-10-08), whatever the window shows. */
  window: { shown: number; truncated: boolean };
}

/** How many current sources the lane reads. One more is asked for, so a full
 *  window can say it is full without a second query. */
const DATA_ROOM_WINDOW = 200;

interface VaultDisplayShape {
  program: string;
  spine: string;
  standard: string;
  /** Documents, not tree leaves: the sum of `documentCounts` over the branches
   *  that could be read. */
  documentCount: number;
  /**
   * What `documentCount` is made of. A branch that could not be read is null —
   * unknown, not zero (`unavailable` says why). Absent on the pending-store
   * answer, which has no branches at all.
   */
  documentCounts?: {
    /** Authored documents — one each, however many rule-pack sections. */
    authored: number;
    /** Governed Module 3 (CMC) artifacts filed for the programme. */
    cmcArtifacts: number | null;
    /** Uploads in the whole programme, not the page the tree carries. */
    uploads: number | null;
  };
  tree: VaultFolder[];
  /**
   * What the Vault holds against the program's required sections (VR-15):
   * counts of confirmed filings from the one resolver, with where the list
   * came from, or why there is no figure. Not a readiness figure.
   */
  coverage?: VaultCoverage;
  /** Honest signal: the c2c document store is not provisioned in this env. */
  pendingStore?: boolean;
  /** Uploaded documents awaiting a person's filing decision. Counted over the
   *  WHOLE program, not over `uploadsWindow` — a queue derived from a capped
   *  page would shrink as the backlog grew. */
  unfiledCount?: number;
  /** Documents in a suggested folder that no person has confirmed (VR-11b).
   *  Counted over the whole program, like `unfiledCount`. Absent when the
   *  uploads store could not be read. */
  awaitingConfirmationCount?: number;
  /**
   * How much of the filing cabinet the tree above actually carries. The vault
   * is unbounded and the tree read is capped (VAULT_TREE_MAX_DOCS), so a
   * surface that rendered the page without saying so would state a partial
   * cabinet as the whole one. `truncated` is the difference; `total` is the
   * real count. Absent when the uploads store is unavailable — that case is
   * reported through `unavailable`, and an absent window must not be read as
   * an empty vault.
   */
  uploadsWindow?: { shown: number; total: number; truncated: boolean };
  /** The capture→classify→file pipeline over the project's Data Room. */
  dataRoom?: DataRoomBlock;
  /**
   * Branches that could not be served, with why. A vault that silently omits
   * "Uploaded files" because its store is unprovisioned reads exactly like a
   * vault with no uploads — this field is the difference. The ONE degradation
   * contract for every derived branch (Module 3, the filing cabinet, the data
   * room); a real failure — anything but a missing store — is a 500, never a
   * silent degrade.
   */
  unavailable?: Array<{ branch: string; reason: string }>;
}

// ─── Row shapes (what the SQL projects) ────────────────────────────────────────

interface ProjectRow {
  id: string;
  name: string | null;
  product_type: string | null;
  program_type?: string | null;
  primary_agency?: string | null;
}

interface DocRow {
  id: string;
  doc_type: string | null;
  agency: string | null;
  rule_pack_version: string | null;
  title: string | null;
  status: string | null;
  readiness: number | null;
  updated_at: string | Date | null;
  owner_name: string | null;
  required_sections: unknown;
}

interface SectionSpec {
  key: string;
  parent_key?: string | null;
  label?: string | null;
  mandatory?: boolean | null;
  path_order?: number | null;
}

interface LiveSection {
  section_key: string;
  status: string | null;
  version: number | null;
  updated_at: string | Date | null;
  has_content: boolean;
  owner_name: string | null;
}

interface SpecNode {
  spec: SectionSpec;
  children: SpecNode[];
}

/**
 * Record a governed download BEFORE the bytes leave — 21 CFR 11.10(e).
 *
 * This handler served a governed document with no audit row of any kind:
 * nothing recorded who read what, or when, while the sibling filing route
 * already wrote a hash-chained row for a MOVE — so a document's placement
 * changes were attributable and its disclosures were not.
 *
 * Returns false rather than throwing, and the caller refuses the download on
 * false. A read that cannot be recorded is refused rather than served
 * unrecorded: an inspector asking "who has had this document" must not be
 * answered with a gap, and an audit trail that drops writes under load is not
 * one. The filing path takes the same position by writing inside its
 * transaction.
 *
 * In a transaction of its own, because the chain requires one
 * (services/audit/chain.ts): the position lock and the INSERT must share it.
 * Written through the pool, each ran as its own statement and the audit_logs
 * trigger recorded every download as a LEGACY row (chain_seq NULL), outside
 * the sequenced chain every other governed Vault event joins.
 */
export async function recordVaultDownload(
  req: Request,
  d: {
    orgId: number;
    programId: string;
    documentId: string;
    documentTitle: string | null;
    fileName: string | null;
    fileSize: string | number | null;
    contentHash: string | null;
  },
): Promise<boolean> {
  let client: PoolClient | undefined;
  try {
    client = await pool.connect();
    await client.query('BEGIN');
    await writeChainedAuditRow(client, {
      tenantId: d.orgId,
      userId: (req as any).user?.id ?? undefined,
      action: 'vault.document.download',
      resourceType: 'vault_document',
      resourceId: d.documentId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      details: {
        programId: d.programId,
        documentTitle: d.documentTitle,
        fileName: d.fileName,
        fileSize: d.fileSize,
        // The hash of the bytes actually served, already verified by the
        // caller, so the trail records WHICH edition left rather than only
        // that one did.
        contentHash: d.contentHash,
      },
    });
    await client.query('COMMIT');
    return true;
  } catch (auditErr) {
    await client?.query('ROLLBACK').catch(() => undefined);
    logger.error('vault download refused: audit write failed', {
      documentId: d.documentId,
      err: auditErr instanceof Error ? auditErr.message : String(auditErr),
    });
    return false;
  } finally {
    client?.release();
  }
}

/** The four shapes a `folderId` can arrive in, mapped to what the service reads. */
function normalizeFolderId(raw: unknown): string | null | undefined {
  if (raw === undefined) return undefined;
  if (raw === null) return null;
  return typeof raw === 'string' ? raw : '';
}

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// ─── Helpers ───────────────────────────────────────────────────────────────────

/** Org id from tenant/user context (integer — c2c tables key on numeric org). */
function resolveOrgId(req: Request): number | null {
  const r = req as any;
  const raw = r.tenantId ?? r.organizationId ?? r.user?.organizationId;
  if (raw == null) return null;
  const n = typeof raw === 'string' ? parseInt(raw, 10) : Number(raw);
  return Number.isFinite(n) ? n : null;
}

/** ISO/Date → "3d ago"; empty/invalid → em dash. Never fabricates a time. */
function relativeTime(value: unknown): string {
  if (!value) return '—';
  const t = value instanceof Date ? value.getTime() : new Date(String(value)).getTime();
  if (!Number.isFinite(t)) return '—';
  const mins = Math.round((Date.now() - t) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  if (days < 7) return `${days}d ago`;
  const wks = Math.round(days / 7);
  if (wks < 5) return `${wks}w ago`;
  const mos = Math.round(days / 30);
  return `${mos}mo ago`;
}

/**
 * Normalize the c2c section/document status vocabulary
 * (todo | drafted | review | approved | locked) into the vocabulary the Vault
 * surface's status chip understands (vaultStatus: final | approved | reviewed |
 * review | draft | not_started | ...). A faithful semantic mapping of a real
 * value — not a fabricated status. When no live status exists, fall back on the
 * real content-presence flag.
 */
function normalizeStatus(raw: string | null | undefined, hasContent: boolean): string {
  if (!raw) return hasContent ? 'draft' : 'not_started';
  switch (raw) {
    case 'approved': return 'approved';
    case 'locked':   return 'final';
    case 'review':   return 'review';
    case 'drafted':  return 'draft';
    case 'todo':     return 'not_started';
    default:         return hasContent ? 'draft' : 'not_started';
  }
}

/** Bytes → '3.4 MB' (real size only; null → em dash, never invented). */
function prettySize(bytes: unknown): string {
  const n = typeof bytes === 'string' ? Number(bytes) : (bytes as number);
  if (!Number.isFinite(n) || n < 0) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} kB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

const KIND_LABEL = new Map(VAULT_DOC_KINDS.map(k => [k.value as string, k.label]));

export interface UploadRow {
  original_file_available?: boolean;
  disposition?: 'keep_data' | 'remove_data' | 'supersede' | null;
  id: string;
  document_code: string | null;
  document_title: string | null;
  document_type: string | null;
  classification?: string | null;
  version: string | null;
  file_name: string | null;
  file_size: string | number | null;
  mime_type: string | null;
  content_hash: string | null;
  folder_id: string | null;
  evidence_kind: string | null;
  ctd_section: string | null;
  placement_status: string | null;
  placement_confidence: string | null;
  placement_rationale: string | null;
  updated_at: string | Date | null;
  owner_name: string | null;
  /** Versions back through valid predecessors, this one included (VR-09). */
  version_count?: number | null;
  /** This version's lifecycle stage; null when it has no record: not reviewed (VR-13). */
  lifecycle_stage?: string | null;
}

/**
 * What a reader is told an uploaded document IS: the one label every surface
 * shows (tree leaf, list, uploads lane, header).
 *
 * The recorded document type comes first, because Edit details is what changes
 * it and a re-typed document must read as its new type. The classifier's
 * evidence kind is only the guess made at upload; it stays on the filing block
 * for the "Looks like" line. It is the label when no type is recorded.
 *
 * 'OTHER' counts as no type. It is the ingest schema's "I was not told", and
 * rendering it as a type would dress an absent answer as a given one. An
 * unrecognised type token still comes back as itself: ugly but true, where
 * 'Other' would be a classification nobody made. 'File' is the honest floor.
 *
 * Its own function because it is three fallbacks deep and reading it inline is
 * what carried uploadLeaf over the complexity limit.
 */
function uploadTypeLabel(row: UploadRow): string {
  if (row.document_type && row.document_type !== 'OTHER') {
    return vaultIngestTypeLabel(row.document_type);
  }
  if (row.evidence_kind) return KIND_LABEL.get(row.evidence_kind) ?? row.evidence_kind;
  return 'File';
}

/** Where the leaf sits among its document's versions (VR-09) and in review (VR-13). */
function versionFacts(row: UploadRow): Pick<VaultDoc, 'versionCount' | 'documentCode' | 'lifecycleStage'> {
  return {
    versionCount: row.version_count ?? 1,
    documentCode: row.document_code,
    lifecycleStage: row.lifecycle_stage ?? null,
  };
}

/** An uploaded vault.documents row → a VaultDoc leaf (all real columns).
 *  Exported for the tree-merge regression test. */
function uploadPreview(row: UploadRow, title: string, size: string): string {
  return `${row.file_name ?? title} · ${size}` +
    (row.original_file_available === false ? ' · Original file unavailable; extracted data retained' : '') +
    (row.content_hash ? ` · SHA-256 ${row.content_hash.slice(0, 12)}…` : '');
}

export function uploadLeaf(view: VaultViewId, row: UploadRow): VaultDoc {
  const placementStatus = row.placement_status || 'unfiled';
  const title = row.document_title || row.file_name || 'Document';
  const size = prettySize(row.file_size);
  const leaf: VaultDoc = {
    id: `up-${row.id}`,
    num: row.ctd_section ?? '—',
    title,
    type: uploadTypeLabel(row),
    status: placementStatus,
    // Uploads have no authoring completion, so no figure at all. It was 0,
    // "rather than a fabricated figure" — but 0 is a figure, and AnA's screen
    // context reported every uploaded file as 0% complete.
    pct: null,
    owner: row.owner_name ?? '—',
    ver: row.version ? `v${row.version}` : '—',
    updated: relativeTime(row.updated_at),
    preview: uploadPreview(row, title, size),
    src: 'upload',
    docId: row.id,
    originalFileAvailable: row.original_file_available ?? true,
    disposition: row.disposition ?? null,
    sizeLabel: size,
    hash: row.content_hash ?? undefined,
    mimeType: row.mime_type ?? null,
    filing: {
      folderId: row.folder_id,
      folderLabel: folderLabel(view, row.folder_id),
      evidenceKind: row.evidence_kind,
      ctdSection: row.ctd_section,
      placementStatus,
      confidence: row.placement_confidence,
      rationale: row.placement_rationale,
    },
    details: {
      documentTitle: row.document_title,
      documentType: row.document_type,
      classification: row.classification ?? null,
    },
    ...versionFacts(row),
  };
  if (placementStatus === 'unfiled') {
    leaf.flag = row.placement_rationale ?? 'Not filed into the dossier yet.';
  }
  return leaf;
}

/**
 * A filed folder's leaves, in a stable order, each with its index number
 * (VR-15). In a CTD view the number is the normalized section, since a dotted
 * folder ordinal there would read as a CTD code ('3.1' for a Module 3
 * document); a leaf with no section is '—' until it has one. Outside a CTD
 * view the number is the folder's ordinal and the leaf's position. Ordered by
 * section (CTD order), then title, then id, so the same documents number the
 * same on every read.
 */
function indexedLeaves(view: VaultViewId, ordinal: number, rows: UploadRow[]): VaultDoc[] {
  const ctd = view === 'pharma' || view === 'biotech';
  const code = (r: UploadRow) => normalizeCtdCode(r.ctd_section);
  const title = (r: UploadRow) => r.document_title || r.file_name || '';
  const sorted = [...rows].sort((a, b) => {
    const ca = code(a);
    const cb = code(b);
    if (ca !== cb) {
      if (ca === null) return 1;
      if (cb === null) return -1;
      return compareSectionCode(ca, cb);
    }
    return title(a).localeCompare(title(b)) || String(a.id).localeCompare(String(b.id));
  });
  return sorted.map((r, i) => ({ ...uploadLeaf(view, r), num: ctd ? (code(r) ?? '—') : `${ordinal}.${i + 1}` }));
}

/** A folder id's label and the view it belongs to, for a folder the current
 *  view does not have. Names the raw id only when no view knows it. */
function whereFiled(folderId: string): string {
  for (const v of VAULT_VIEWS) {
    const f = (VAULT_FOLDER_PRESETS[v.value] ?? []).find(x => x.id === folderId);
    if (f) return `“${f.label}” (${v.label} view)`;
  }
  return `a folder this vault no longer defines (${folderId})`;
}

/**
 * The filing cabinet: the program's vault-view folder taxonomy with every
 * uploaded document placed where its (suggested or confirmed) filing says,
 * plus an always-visible Unfiled queue. Folders render even when empty — the
 * cabinet IS the dossier shape a regulatory associate expects to see.
 * Exported for the tree-merge regression test.
 */
export function filingCabinet(view: VaultViewId, uploads: UploadRow[]): VaultFolder {
  const unfiled = uploads.filter(u => !u.folder_id || (u.placement_status || 'unfiled') === 'unfiled');
  const inView = new Set(foldersForView(view).map(f => f.id));
  const byFolder = new Map<string, UploadRow[]>();
  /* Filed to a folder this view does not have. The view is resolved per read
     and not stored on the row, so a document filed under a device folder on a
     program that now reads as pharma (or one filed while the view lookup had
     fallen back) belongs to no folder here. It used to be dropped from the tree
     while still counted; it is shown, with where it was filed. */
  const otherView: UploadRow[] = [];
  for (const u of uploads) {
    if (!u.folder_id || (u.placement_status || 'unfiled') === 'unfiled') continue;
    if (!inView.has(u.folder_id)) {
      otherView.push(u);
      continue;
    }
    const list = byFolder.get(u.folder_id) ?? [];
    list.push(u);
    byFolder.set(u.folder_id, list);
  }
  const children: Array<VaultFolder | VaultDoc> = [];
  children.push({
    id: 'cab-unfiled',
    code: '',
    label: 'Unfiled · needs review',
    // Not in the index: a section here is the classifier's suggestion, not a place.
    children: unfiled.map(u => ({ ...uploadLeaf(view, u), num: '—' })),
  });
  foldersForView(view).forEach((folder, i) => {
    children.push({
      id: `cab-${folder.id}`,
      code: '',
      label: folder.label,
      children: indexedLeaves(view, i + 1, byFolder.get(folder.id) ?? []),
    });
  });
  if (otherView.length > 0) {
    children.push({
      id: 'cab-other-view',
      code: '',
      label: 'Filed under another view · needs review',
      children: otherView.map(u => ({
        ...uploadLeaf(view, u),
        num: '—',
        flag: `Filed to ${whereFiled(u.folder_id!)}, which is not a folder in this program's current view. Move it to a folder here, or check the program's product type.`,
      })),
    });
  }
  return {
    id: 'cabinet',
    code: '',
    label: 'Source files · filing cabinet',
    children,
  };
}

/**
 * How a LIVE section row renders — status, completion, owner, version, time.
 *
 * Separated from leafDoc because every field here is the same question asked of
 * one optional row ("what does the live section say, and what do we show when
 * there is no live section"), while the rest of leafDoc is about the rule-pack
 * spec. Reading them interleaved hid that, and the mix put leafDoc over the
 * complexity limit.
 */
function liveSectionPresentation(
  live: LiveSection | undefined,
  hasContent: boolean,
): Pick<VaultDoc, 'status' | 'pct' | 'owner' | 'ver' | 'updated'> {
  const status = live?.status ?? null;
  return {
    status: normalizeStatus(status, hasContent),
    // Completion, on the SAME definition the document row beside this one uses
    // (c2c_documents.readiness = % of sections approved/locked). This used to be
    // `hasContent ? 100 : 0`, so one typed sentence reported a finished section
    // next to a document reporting 0%. Drafting progress is still carried by
    // `status` and by the mandatory-without-content blocker in leafDoc.
    pct: sectionCompletionPct(status),
    // Owner is resolved ONLY from a real user (section owner_id); unattributed
    // sections stay '—' rather than borrowing the target agency's name.
    owner: live?.owner_name ?? '—',
    ver: live?.version != null ? `v${live.version}` : '—',
    updated: live ? relativeTime(live.updated_at) : '—',
  };
}

/** A rule-pack section spec merged with its live row → a VaultDoc leaf. */
function leafDoc(doc: DocRow, spec: SectionSpec, live: LiveSection | undefined): VaultDoc {
  const hasContent = live?.has_content ?? false;
  const mandatory = spec.mandatory ?? false;
  const docTitle = doc.title || doc.doc_type || 'Document';
  const label = spec.label ?? spec.key;
  const leaf: VaultDoc = {
    id: `sec-${doc.id}-${spec.key}`,
    num: spec.key,
    title: label,
    type: mandatory ? 'Required' : 'Optional',
    ...liveSectionPresentation(live, hasContent),
    preview: `${docTitle} · ${spec.key} · ${label}${mandatory ? ' · mandatory section' : ''}`,
  };
  if (mandatory && !hasContent) {
    leaf.blocker = true;
    leaf.flag = 'Mandatory section — no content yet';
  }
  return leaf;
}

/** Fallback leaf for a document with no rule-pack section spec. */
function docLevelLeaf(doc: DocRow): VaultDoc {
  const readiness = typeof doc.readiness === 'number' ? doc.readiness : 0;
  const docTitle = doc.title || doc.doc_type || 'Document';
  return {
    id: `doc-${doc.id}`,
    num: '—',
    title: docTitle,
    type: 'Document',
    status: normalizeStatus(doc.status, readiness > 0),
    pct: readiness,
    owner: doc.owner_name ?? '—',
    ver: '—',
    updated: relativeTime(doc.updated_at),
    preview: docTitle + (doc.agency ? ` · ${doc.agency}` : ''),
  };
}

/** Build the nested VaultFolder/VaultDoc tree for one document's sections. */
function sectionsToNodes(
  doc: DocRow,
  specs: SectionSpec[],
  live: Map<string, LiveSection>,
): Array<VaultFolder | VaultDoc> {
  const sorted = [...specs].sort(
    (a, b) => (a.path_order ?? 0) - (b.path_order ?? 0),
  );
  const byKey: Record<string, SpecNode> = {};
  const roots: SpecNode[] = [];
  for (const spec of sorted) byKey[spec.key] = { spec, children: [] };
  for (const spec of sorted) {
    const node = byKey[spec.key];
    const parent = spec.parent_key ? byKey[spec.parent_key] : undefined;
    if (parent) parent.children.push(node);
    else roots.push(node);
  }
  const toNode = (n: SpecNode): VaultFolder | VaultDoc => {
    if (n.children.length > 0) {
      return {
        id: `sec-${doc.id}-${n.spec.key}`,
        code: n.spec.key,
        label: n.spec.label ?? n.spec.key,
        children: n.children.map(toNode),
      };
    }
    return leafDoc(doc, n.spec, live.get(n.spec.key));
  };
  return roots.map(toNode);
}

/** One document → its top-level VaultFolder. */
function documentFolder(doc: DocRow, live: Map<string, LiveSection>): VaultFolder {
  const specs = Array.isArray(doc.required_sections)
    ? (doc.required_sections as SectionSpec[])
    : [];
  const children = specs.length > 0
    ? sectionsToNodes(doc, specs, live)
    : [docLevelLeaf(doc)];
  return {
    id: `vaultdoc-${doc.id}`,
    code: (doc.doc_type ?? '').toUpperCase(),
    label: doc.title || doc.doc_type || 'Document',
    children,
  };
}

/** Missing table (42P01) / missing column (42703) — a store this environment
 *  has not provisioned. The branch degrades honestly instead of 500ing. */
function isMissingStore(err: unknown): boolean {
  const code = (err as { code?: string } | null)?.code;
  return code === '42P01' || code === '42703';
}

interface M3ArtifactRow {
  id: string | number;
  artifact_id: string;
  title: string | null;
  ctd_section: string;
  status: string | null;
  version: number | null;
  updated_at: string | Date | null;
}

/**
 * Read a vault document's bytes and prove they are the bytes that were
 * recorded, or say precisely why not.
 *
 * Extracted from the download handler rather than left inline. In a governed
 * store the integrity check is the load-bearing part of serving a file — "the
 * row's content_hash is verified against the bytes on disk before they are
 * sent", as that handler's own docblock puts it — and a check that exists only
 * as thirty lines in the middle of a route cannot be reused by the next reader
 * of the same bytes, or tested on its own.
 *
 * Every refusal is 409 rather than 404 on purpose: the RECORD exists in all
 * three cases, so answering "not found" would be a different, false statement.
 * The distinct codes let a caller tell a catalogued-without-content row from a
 * missing file from an altered one — three different operational problems.
 *
 * Returns a discriminated result rather than throwing, so the caller owns the
 * response shape and no failure escapes as a 500 that reads like an outage.
 */
export type VerifiedVaultBytes =
  | { ok: true; bytes: Buffer }
  | { ok: false; status: number; error: string; message?: string };

/**
 * Where a vault document's bytes live. A row has ONE of these, never neither:
 *   - `storageVersionId` — written through `getStorageProvider()`, the canonical
 *     seam. This is the shape every new upload takes.
 *   - `storageKey` — the legacy relative path in `s3_key`, for every row written
 *     before the vault moved onto the provider.
 * Both are carried because this is a DUAL-READ, not a cutover: no bytes were
 * moved when the write path changed, so old documents must keep working
 * unchanged until a deliberate backfill says otherwise.
 */
export interface VaultByteSource {
  /** `vault.documents.storage_version_id` — NULL on rows predating the provider. */
  storageVersionId: string | null;
  /** `vault.documents.s3_key` — NULL on rows written through the provider. */
  storageKey: string | null;
  /** The caller's organization. Required: object storage sits outside Postgres
   *  RLS, so for provider-backed bytes this argument IS the tenant boundary. */
  organizationId: number;
  /** `vault.documents.storage_provider`: the store the bytes were written to,
   *  which is where they are read from (NULL on rows predating the column). */
  storageProvider: string | null;
}

export async function readVerifiedVaultBytes(
  source: VaultByteSource,
  recordedHash: string | null,
  documentId: string,
): Promise<VerifiedVaultBytes> {
  let bytes: Buffer;

  if (source.storageVersionId) {
    // Provider-backed. `get()` returns null both for "no such version" and for
    // "belongs to another organization" — the interface refuses to distinguish
    // them, because a 403 on a foreign id confirms the id exists. Either way
    // there are no bytes to serve, and that is what we report.
    let store: ReturnType<typeof getStorageProvider>;
    try {
      store = getStorageProviderFor(source.storageProvider);
    } catch (err) {
      // The recorded store cannot be opened here. Not "missing": the bytes may
      // exist, and asking the configured store instead would answer for a
      // different one. The provider is named in the log, not to the user.
      logger.error('vault download: the store this document was saved in cannot be opened', {
        documentId,
        recorded: source.storageProvider,
        reason: err instanceof Error ? err.message : 'unknown',
      });
      return {
        ok: false,
        status: 409,
        error: 'STORED_FILE_UNREADABLE',
        message:
          'The vault record exists, but this server cannot open the store its file was saved in. Nothing was downloaded.',
      };
    }
    let got: Awaited<ReturnType<ReturnType<typeof getStorageProvider>['get']>>;
    try {
      got = await store.get(source.storageVersionId, source.organizationId);
    } catch (err) {
      logger.error('vault download: storage provider read failed', {
        documentId,
        reason: err instanceof Error ? err.message : 'unknown',
      });
      return {
        ok: false,
        status: 409,
        error: 'STORED_FILE_MISSING',
        message:
          'The vault record exists but its stored file could not be read. Nothing was downloaded.',
      };
    }
    if (!got) {
      logger.error('vault download: stored version not readable for this organization', {
        documentId,
      });
      return {
        ok: false,
        status: 409,
        error: 'STORED_FILE_MISSING',
        message:
          'The vault record exists but its stored file could not be read. Nothing was downloaded.',
      };
    }
    bytes = got.bytes;
  } else if (source.storageKey) {
    const resolved = path.resolve(process.cwd(), source.storageKey);
    // Refuse a key that escapes the storage root. `s3_key` is written by this
    // codebase today, but a path-traversal read is not a risk worth carrying on
    // the assumption that it always will be.
    const root = path.resolve(process.cwd(), 'uploads');
    if (!resolved.startsWith(root + path.sep)) {
      logger.error('vault download refused: storage key escapes the uploads root', { documentId });
      return { ok: false, status: 409, error: 'NO_STORED_FILE' };
    }

    try {
      bytes = await fs.readFile(resolved);
    } catch {
      logger.error('vault download: stored file missing on disk', {
        documentId,
        key: source.storageKey,
      });
      return {
        ok: false,
        status: 409,
        error: 'STORED_FILE_MISSING',
        message:
          'The vault record exists but its stored file could not be read. Nothing was downloaded.',
      };
    }
  } else {
    // Neither address. The row was recorded without bytes reaching storage,
    // which the ingest path refuses to do — so this is a corrupt record, and
    // serving nothing with an explanation beats serving a zero-byte file.
    logger.error('vault download refused: record carries no storage address', { documentId });
    return { ok: false, status: 409, error: 'NO_STORED_FILE' };
  }

  // Verified the same way whichever address served the bytes. `content_hash` in
  // the database is authoritative; the provider reports a hash of its own, but
  // checking the bytes against the RECORD is what catches a store that returned
  // the wrong object as well as one that returned altered bytes.
  if (recordedHash) {
    const actual = createHash('sha256').update(bytes).digest('hex');
    if (actual !== recordedHash) {
      logger.error('vault download refused: content hash mismatch', {
        documentId, recorded: recordedHash.slice(0, 12), actual: actual.slice(0, 12),
      });
      return {
        ok: false,
        status: 409,
        error: 'CONTENT_HASH_MISMATCH',
        message:
          'The stored file does not match the hash recorded for it, so it was not served. Report this — the vault copy may have been altered.',
      };
    }
  }

  return { ok: true, bytes };
}

/**
 * The Module 3 (CMC) branch: governed §3.x artifacts the CMC compile bridge
 * files into concept2cure_artifacts, reached through the program→project
 * anchor (the same EXISTS idiom mdx-vault.ts uses — org predicate repeated on
 * projects so a mis-anchored row can never pull another tenant's data in).
 * These rows were invisible in this surface even though the CMC module's
 * "vault" affordances pointed here — the data room now lists what the
 * pipeline files, organized by CTD section.
 */
/**
 * What the Module 3 branch read found — three answers, not two.
 *
 * `null` used to carry both "this program is anchored and nothing has been
 * filed yet" and "this program has no PM-spine anchor, so the artifact
 * registry cannot be asked about it at all", and the surface rendered them
 * identically: no Module 3 section. The second is a state the user has to be
 * told about — the artifact query below joins through
 * `projects.regulatory_program_id`, so with no anchor it CANNOT match however
 * much has been compiled and approved. CLAUDE.md's working agreement: an error
 * is never rendered as an empty result.
 */
type Module3BranchResult =
  | { kind: 'branch'; folder: VaultFolder }
  /** Addressable, and nothing filed. The honest empty state. */
  | { kind: 'empty' }
  /** The registry cannot be addressed for this program. Carries the reason. */
  | { kind: 'unaddressable'; reason: string };

async function module3Branch(programId: string, orgId: number): Promise<Module3BranchResult> {
  /* Ask the spine resolver BEFORE the artifact query, through the one module
     that owns the translation (services/cmc/resolve-cmc-artifact-project.ts).
     Its own contract requires callers to "skip the registry query and say why,
     never substitute the raw id, and never render the absence as a plain empty
     result" — which is exactly what this branch was doing. */
  const spine = await resolveCmcArtifactProject(orgId, programId);
  if (spine.state !== 'linked') {
    return { kind: 'unaddressable', reason: spine.detail };
  }

  const artRes = await pool.query(
    `SELECT a.id, a.artifact_id, a.title, a.ctd_section, a.status, a.version, a.updated_at
       FROM concept2cure_artifacts a
      WHERE a.organization_id = $2
        AND a.status != 'archived'
        AND a.ctd_section LIKE '3.%'
        AND EXISTS (SELECT 1 FROM projects p
                     WHERE p.id = a.project_id
                       AND p.organization_id = a.organization_id
                       AND p.regulatory_program_id = $1::uuid)
      ORDER BY a.ctd_section, a.version DESC`,
    [programId, orgId],
  );
  if (artRes.rows.length === 0) return { kind: 'empty' };
  const children: VaultDoc[] = (artRes.rows as M3ArtifactRow[]).map((a) => ({
    id: `m3art-${a.id}`,
    num: a.ctd_section,
    title: a.title || a.ctd_section,
    type: 'Governed artifact',
    // The same status vocabulary the artifact registry stores, mapped through
    // the one normalizer; completion is the section-approval definition the
    // rest of this read-model uses (approved/locked = 100, else 0).
    status: normalizeStatus(a.status === 'draft' ? 'drafted' : a.status, true),
    pct: sectionCompletionPct(a.status),
    owner: '—',
    ver: a.version != null ? `v${a.version}` : '—',
    updated: relativeTime(a.updated_at),
    preview: `${a.title || a.ctd_section} · CTD §${a.ctd_section} · compiled from CMC canonical sources`,
  }));
  return { kind: 'branch', folder: { id: 'm3-cmc', code: 'M3', label: 'Module 3 (CMC)', children } };
}

/* The Uploaded-files branch is the filing cabinet (uploadLeaf / filingCabinet
   above): the same vault.documents rows the flat "Uploaded files" list showed,
   carrying their dossier PLACEMENT — the classifier's suggested folder, the
   person-confirmed filing, or the visible Unfiled queue — instead of a single
   undifferentiated bucket. One uploads branch; two never merged. */

// ─── Router factory ─────────────────────────────────────────────────────────────

/** The newest entries a document's history shows; the response says when there are more. */
const HISTORY_WINDOW = 200;

/**
 * A document's history across its versions (VR-09) and their review and
 * approval (VR-13): the audit rows recorded against each version, and those
 * recorded against each version's lifecycle record (its transitions and
 * sign-offs), as one list, newest first. Each entry names the version it was
 * recorded against. A deleted version has no live family, so its own trail is
 * read, as before.
 */
async function readFamilyHistory(
  client: PoolClient,
  orgId: number,
  family: Awaited<ReturnType<typeof readVersionFamily>>,
  documentId: string,
) {
  const versionIds = family ? family.map((v) => v.id) : [];
  // One more row than the window is asked for, so a cut is known and said
  // (the response's `truncated`), never a silent cap.
  const history = await readRecordAuditHistory(client, orgId, {
    tableName: 'vault_document',
    recordId: family ? versionIds : documentId,
    limit: HISTORY_WINDOW + 1,
  });
  const lifecycles = family ? await readVaultLifecycles(client, orgId, versionIds) : new Map();
  const records = [...lifecycles.entries()].map(([vaultId, l]) => ({ vaultId, canonicalId: l.canonicalId as string }));
  const lifecycle = records.length > 0
    ? await readRecordAuditHistory(client, orgId, {
        tableName: 'canonical_document', recordId: records.map((r) => r.canonicalId), limit: HISTORY_WINDOW + 1,
      })
    : { data: [] as typeof history.data };
  const keys = [
    ...(family ?? []).map((v) => ({ key: v.id, version: v.version })),
    ...records.map((r) => ({ key: r.canonicalId, version: family?.find((v) => v.id === r.vaultId)?.version ?? null })),
  ];
  const versionOf = (e: { target?: string | null; targetRef?: string | null }) =>
    keys.find((k) => [e.target, e.targetRef].some((t) => typeof t === 'string' && t.endsWith(k.key)))?.version ?? null;
  const order = (e: { seq?: number | null; at?: string | null }) => [e.seq ?? -1, e.at ?? ''] as const;
  const newestFirst = (a: { seq?: number | null; at?: string | null }, b: { seq?: number | null; at?: string | null }) => {
    const [sa, ta] = order(a);
    const [sb, tb] = order(b);
    return sa !== sb ? sb - sa : tb.localeCompare(ta);
  };
  const sources = [history.data, lifecycle.data];
  const truncated = sources.some((rows) => rows.length > HISTORY_WINDOW);
  // A source that was cut ends at its oldest kept row; the other source's
  // older rows are dropped too, so what is shown is one unbroken newest run.
  const cutAt = sources
    .filter((rows) => rows.length > HISTORY_WINDOW)
    .map((rows) => [...rows].sort(newestFirst)[HISTORY_WINDOW - 1])
    .sort(newestFirst)[0];
  const entries = [...history.data, ...lifecycle.data]
    .sort(newestFirst)
    .filter((e) => !cutAt || newestFirst(e, cutAt) <= 0)
    .slice(0, HISTORY_WINDOW)
    .map((e) => ({ ...e, version: versionOf(e) }));
  return { entries, chain: history.meta.chain, truncated };
}

export default function createProjectVaultRoutes(): Router {
  const router = Router();

  /**
   * GET /api/c2c/project-vault/search?q=&limit=&offset=&includeSuperseded=
   * Library search (plan critique 15): the project search's query across every
   * program the organisation holds (vault-search.ts), each hit naming its
   * program. Registered before GET /:id, which would otherwise take "search"
   * for a project id. An empty query is not "match everything"; an error is
   * never an empty result.
   */
  router.get('/search', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '25'), 10) || 25, 1), 100);
    const offset = Math.max(parseInt(String(req.query.offset ?? '0'), 10) || 0, 0);
    const includeSuperseded = req.query.includeSuperseded === 'true';
    if (!q) {
      return res.json({ success: true, data: { query: '', results: [], total: 0, limit, offset, reason: 'EMPTY_QUERY' } });
    }
    try {
      const found = await searchVaultDocuments(pool, { organizationId: orgId, programId: null, q, limit, offset, includeSuperseded });
      return res.json({
        success: true,
        data: {
          query: q, total: found.total, limit, offset, includeSuperseded,
          results: found.results.map((r) => ({ ...r, size: prettySize(r.sizeBytes) })),
        },
      });
    } catch (err) {
      logger.error('vault library search failed', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({
        success: false,
        error: 'SEARCH_FAILED',
        message: 'The library could not be searched. This is not an empty result — nothing was searched.',
      });
    }
  });

  /**
   * GET /api/c2c/project-vault/:id
   * The Vault (DMS) surface display shape for one project, from real data.
   */
  router.get('/:id', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });

    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    // Guard the uuid cast — a non-uuid id would otherwise throw 22P02 → 500.
    if (!UUID_RE.test(id)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

    try {
      // 1) Project (org-scoped) → name + product modality.
      const projRes = await pool.query(
        `SELECT id, name, product_type, program_type, primary_agency
           FROM regulatory_programs
          WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL
          LIMIT 1`,
        [id, orgId],
      );
      if (projRes.rows.length === 0) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
      const project = projRes.rows[0] as ProjectRow;

      // 2) Derive the vault view (project product_type → segment; else the org
      //    union; else the cross-sponsor service view). Same mapping the
      //    ingest path uses (vault-filing.service), so a file cannot be
      //    classified against one view and rendered under another — computed
      //    from the project row already fetched, not a second read.
      const projSegs = project.product_type ? productTypesToSegments([project.product_type]) : [];
      const view: VaultViewId = projSegs[0] ?? (await resolveOrgVaultView(orgId));

      // 3) The project's active document builds + their rule-pack section specs.
      //    Owners are named through public.actor_name, not users, so an owner who
      //    has left is still named (D3, 2026-09-29; docs/evidence/D3/2026-09-29-actor-names/).
      const docsRes = await pool.query(
        `SELECT d.id, d.doc_type, d.agency, d.rule_pack_version, d.title,
                d.status, d.readiness, d.updated_at,
                COALESCE(du.name, du.email) AS owner_name,
                rp.required_sections
           FROM c2c_documents d
           LEFT JOIN c2c_rule_packs rp
             ON rp.doc_type = d.doc_type AND rp.agency = d.agency
                AND rp.version = d.rule_pack_version
           LEFT JOIN LATERAL public.actor_name(d.owner_id) du ON TRUE
          WHERE d.project_id = $1 AND d.org_id = $2
          ORDER BY d.updated_at DESC`,
        [id, orgId],
      );

      // 4) Per-document live section status (+ owner + timestamp) → display tree.
      const tree: VaultFolder[] = [];
      // ONE query for every document's sections, not one per document. This
      // was a round trip per authored document inside a loop — the tree read
      // cost grew with the programme, on the surface whose whole job is to show
      // a programme's documents. The predicate is the only thing that changed
      // shape (`= $1` became `= ANY($1::text[])`); the EXISTS org re-assertion
      // is carried over verbatim, because it is what keeps the section read
      // from widening past the caller's tenant.
      const docIds = (docsRes.rows as DocRow[]).map((d) => d.id);
      const liveByDoc = new Map<string, Map<string, LiveSection>>();
      if (docIds.length > 0) {
        const secRes = await pool.query(
          // The document ids were already resolved from the org-filtered
          // c2c_documents query above; the EXISTS re-asserts that ownership
          // inline (defense in depth + explicit org_id scoping).
          `SELECT ds.document_id, ds.section_key, ds.status, ds.version, ds.updated_at,
                  ${sectionHasContentSql('ds.content')} AS has_content,
                  COALESCE(u.name, u.email) AS owner_name
             FROM c2c_document_sections ds
             LEFT JOIN LATERAL public.actor_name(ds.owner_id) u ON TRUE
            WHERE ds.document_id = ANY($1::text[])
              AND EXISTS (SELECT 1 FROM c2c_documents d
                           WHERE d.id = ds.document_id AND d.org_id = $2)`,
          [docIds, orgId],
        );
        for (const r of secRes.rows as Array<LiveSection & { document_id: string }>) {
          let forDoc = liveByDoc.get(r.document_id);
          if (!forDoc) {
            forDoc = new Map<string, LiveSection>();
            liveByDoc.set(r.document_id, forDoc);
          }
          forDoc.set(r.section_key, r);
        }
      }
      for (const doc of docsRes.rows as DocRow[]) {
        // A document with no rows in the result has no live sections — the same
        // empty map the per-document query produced for it.
        tree.push(documentFolder(doc, liveByDoc.get(doc.id) ?? new Map<string, LiveSection>()));
      }

      // 5) Derived branches: what the pipelines file for this program. ONE
      //    degradation contract for all of them — a store this environment has
      //    not provisioned is REPORTED in `unavailable`, never rendered as an
      //    empty branch (which would read as "no documents"); any other
      //    failure is a real error and 500s.
      const unavailable: Array<{ branch: string; reason: string }> = [];
      let cmcArtifacts: number | null = null;
      try {
        const m3 = await module3Branch(id, orgId);
        if (m3.kind === 'branch') {
          tree.push(m3.folder);
          cmcArtifacts = m3.folder.children.length;
        } else if (m3.kind === 'empty') {
          cmcArtifacts = 0;
        } else if (m3.kind === 'unaddressable') {
          // Not an empty branch: the registry cannot be asked about this
          // program at all, and the resolver's own sentence says why and what
          // to do. Reported through the same contract a missing store uses.
          unavailable.push({ branch: 'Module 3 (CMC)', reason: m3.reason });
        }
      } catch (err) {
        if (!isMissingStore(err)) throw err;
        unavailable.push({
          branch: 'Module 3 (CMC)',
          reason: 'The governed artifact registry (or its program anchor) is not provisioned in this environment.',
        });
      }

      // 6) Uploaded files → the filing cabinet: the same vault.documents rows
      //    the Upload button ingests, placed where their (suggested or
      //    confirmed) filing says, plus the always-visible Unfiled queue.
      //
      //    BOUNDED, because a program's vault is not. This read fetched every
      //    vault.documents row for the program and held them all in memory to
      //    render one tree; at data-room scale (the scale this product is for)
      //    that is the request that takes the server down.
      //
      //    A cap is only honest if the facts derived ALONGSIDE it keep
      //    describing the vault rather than the page, so both moved into SQL:
      //
      //      - `unfiledCount` is an aggregate over the whole program. Counted
      //        from a fetched page it would FALL as the vault grew past the
      //        cap — a review queue that empties itself as work piles up.
      //      - a data-room source's `filed` stage is answered by asking the
      //        database whether that source's checksum exists in this
      //        program's vault (step 7). Derived from a page it would report
      //        filed documents as unfiled once the vault outgrew the cap.
      //        That is a compliance answer, not a display detail.
      //
      //    The window itself is reported so the surface can say it is showing
      //    part of a larger cabinet instead of implying it is the whole of it.
      const uploadsCap = Math.min(
        Math.max(parseInt(String(process.env.VAULT_TREE_MAX_DOCS ?? '2000'), 10) || 2000, 1),
        20000,
      );
      /** The program+tenant predicate, shared by the page and its aggregates so
       *  a count can never be taken over a different set than the rows. */
      const uploadsWhere = `d.program_id = $1 AND d.deleted_at IS NULL
              AND ${vaultDataEligibleSql('d')}
              AND EXISTS (
                SELECT 1 FROM regulatory_programs rp
                 WHERE rp.id = d.program_id
                   AND rp.organization_id = $2
                   AND rp.deleted_at IS NULL
              )`;
      /** The tree lists a document once, at its current version (VR-09): a row
       *  a later live version of its family supersedes is not a document of its
       *  own. The checksum join below keeps the whole program, every version. */
      const headsWhere = `${uploadsWhere} AND NOT ${supersededSql('d')}`;
      let uploads: UploadRow[] = [];
      let uploadsStoreMissing = false;
      let uploadsWindow: { shown: number; total: number; truncated: boolean } | undefined;
      let unfiledCount = 0;
      let awaitingConfirmationCount: number | undefined;
      try {
        // cap + 1 detects the overflow without a second round trip.
        const upRes = await pool.query(
          `SELECT d.id, d.document_code, d.document_title, d.document_type, d.classification::text AS classification,
                  d.version, d.file_name, d.file_size, d.mime_type, d.content_hash,
                  d.folder_id, d.evidence_kind, d.ctd_section,
                  d.placement_status, d.placement_confidence, d.placement_rationale,
                  d.updated_at,
                  ${vaultBinaryAvailableSql('d')} AS original_file_available,
                  ${vaultDispositionChoiceSql('d')} AS disposition,
                  COALESCE(u.name, u.email) AS owner_name,
                  vc.version_count,
                  lc.stage AS lifecycle_stage
             FROM vault.documents d
             LEFT JOIN LATERAL public.actor_name(d.created_by) u ON TRUE
             ${versionCountLateral('d')}
             LEFT JOIN LATERAL (
               SELECT c.stage FROM canonical_documents c
                WHERE c.organization_id = $2 AND c.source_refs ? 'vault_documents'
                  AND c.source_refs -> 'vault_documents' ->> 'nativeId' = d.id::text
                ORDER BY c.created_at, c.canonical_id LIMIT 1
             ) lc ON TRUE
            WHERE ${headsWhere}
            ORDER BY d.updated_at DESC
            LIMIT $3`,
          [id, orgId, uploadsCap + 1],
        );
        const truncated = upRes.rows.length > uploadsCap;
        uploads = (upRes.rows as UploadRow[]).slice(0, uploadsCap);

        // Program-wide totals. Always taken, so `unfiledCount` means the same
        // thing whether or not the page was truncated.
        const cntRes = await pool.query(
          `SELECT COUNT(*)::int AS total,
                  COUNT(*) FILTER (
                    WHERE d.folder_id IS NULL
                       OR COALESCE(d.placement_status, 'unfiled') = 'unfiled'
                  )::int AS unfiled,
                  COUNT(*) FILTER (
                    WHERE d.folder_id IS NOT NULL AND d.placement_status = 'suggested'
                  )::int AS suggested
             FROM vault.documents d
            WHERE ${headsWhere}`,
          [id, orgId],
        );
        const counts = (cntRes.rows[0] ?? {}) as { total?: number; unfiled?: number; suggested?: number };
        unfiledCount = counts.unfiled ?? 0;
        awaitingConfirmationCount = counts.suggested ?? 0;
        uploadsWindow = {
          shown: uploads.length,
          total: counts.total ?? uploads.length,
          truncated,
        };
        tree.push(filingCabinet(view, uploads));
      } catch (err) {
        if (!isMissingStore(err)) throw err;
        uploadsStoreMissing = true;
        unavailable.push({
          branch: 'Uploaded files',
          reason: 'The vault document store (vault.documents) is not provisioned in this environment.',
        });
      }

      // 7) The Data Room pipeline: every captured source with its DERIVED
      //    stage — 'filed' is a checksum join against the uploads, computed
      //    not stored, so it cannot go stale. With the uploads store missing
      //    that join cannot be derived, and a room whose Filed count silently
      //    read zero would be the error-as-empty lie — so the room is
      //    reported unavailable alongside it.
      let dataRoom: DataRoomBlock | undefined;
      if (uploadsStoreMissing) {
        unavailable.push({
          branch: 'Data room',
          reason: "The 'filed' stage joins captured sources against the uploads store, which is not provisioned — pipeline stages cannot be derived.",
        });
      } else {
        try {
          /* Current sources only: a re-upload retires its predecessor
             (is_current = false), and counting both made one file two. One
             past the window, so a program with more says so; the reader's
             default cap was 200 and nothing said when it was reached. */
          const read = await listClientDocuments(orgId, {
            programId: id,
            currentOnly: true,
            limit: DATA_ROOM_WINDOW + 1,
          });
          const truncated = read.length > DATA_ROOM_WINDOW;
          const sources = (truncated ? read.slice(0, DATA_ROOM_WINDOW) : read)
            .filter(s => s.dataEligible !== false && s.originalFileAvailable !== false);
          // `filed` asks whether THIS source's bytes already exist in the
          // program's vault. Ask the database that, about exactly these
          // checksums, instead of deriving it from the page of documents
          // fetched for the tree above: that page is capped, and once a vault
          // outgrew the cap a filed document would start reporting as unfiled.
          // Bounded by the source list, which the caller already holds.
          const sourceChecksums = Array.from(
            new Set(sources.map(s => s.checksum).filter((h): h is string => Boolean(h))),
          );
          // …and as which version (VR-16): the version its bytes are, and the
          // family's current version when a later one replaced it.
          // One join for the stage and for "File into Vault" (VR-11), so the
          // two cannot disagree about what is filed.
          const vaultHashes = await readFiledAs(pool, id, orgId, sourceChecksums);
          const rows: DataRoomRow[] = sources.map(s => {
            const meta = (s.metadata ?? {}) as Record<string, unknown>;
            const dossier = (meta.dossier ?? null) as
              | { evidenceKind?: string | null; suggestedFolder?: string | null;
                  confidence?: string | null; needsReview?: boolean }
              | null;
            const match = s.checksum ? vaultHashes.get(s.checksum) : undefined;
            const filedAs = match ? { version: match.version, supersededBy: match.supersededBy } : null;
            const filed = filedAs !== null;
            const proposed = Boolean(dossier?.suggestedFolder);
            const stage: DataRoomRow['stage'] =
              filed ? 'filed' : proposed ? 'classified' : dossier ? 'needs_review' : 'captured';
            const mime = typeof meta.mimeType === 'string' ? meta.mimeType : '';
            const kind =
              /pdf/i.test(mime) ? 'PDF'
              : /word|docx?/i.test(mime) ? 'Word'
              : /sheet|excel|csv/i.test(mime) ? 'Sheet'
              : /image/i.test(mime) ? 'Image'
              : /text|markdown/i.test(mime) ? 'Text'
              : 'File';
            const readState = sourceReadView({ ...s, processing: s.processing ?? sourceProcessingSummary(meta) }).label;
            const suggestedFolder = dossier?.suggestedFolder ?? null;
            return {
              id: s.id,
              title: s.title ?? 'Untitled source',
              kind,
              sizeLabel: prettySize(meta.fileSize),
              addedAt: relativeTime(s.createdAt),
              stage,
              readState,
              suggestedFolder,
              suggestedFolderLabel: folderLabel(view, suggestedFolder),
              evidenceKind: dossier?.evidenceKind ?? null,
              confidence: dossier?.confidence ?? null,
              needsReview: Boolean(dossier?.needsReview),
              filedAs,
            };
          });
          // Exact, over the whole project: the rows are a window, the counts are not.
          const counts = await countDataRoomStages(pool, id, orgId);
          dataRoom = {
            ...counts,
            sources: rows,
            window: { shown: rows.length, truncated },
          };
        } catch (err) {
          if (!isMissingStore(err)) throw err;
          unavailable.push({
            branch: 'Data room',
            reason: 'The data room store (cre_evidence_sources) is not provisioned in this environment.',
          });
        }
      }

      /* Documents, not leaves. `countDocs(tree)` counted every leaf: each
         rule-pack section of an authored document (one IND with a 40-section
         pack read "40 documents") and the capped uploads page rather than the
         programme's uploads — beside a note saying the page was partial. */
      const documentCounts = {
        authored: docsRes.rows.length,
        cmcArtifacts,
        uploads: uploadsWindow ? uploadsWindow.total : null,
      };
      // 8) Vault coverage (VR-15): never throws; a store it cannot read is
      //    reported as unavailable, not as zero.
      const coverage = await readVaultCoverage(pool, {
        view,
        programType: project.program_type,
        primaryAgency: project.primary_agency,
        programId: id,
        organizationId: orgId,
      });
      const data: VaultDisplayShape = {
        program: project.name || 'Vault',
        spine: vaultSpineLabel(view, project.program_type),
        standard: view,
        documentCount:
          documentCounts.authored + (documentCounts.cmcArtifacts ?? 0) + (documentCounts.uploads ?? 0),
        documentCounts,
        tree,
        coverage,
        unfiledCount,
        ...(awaitingConfirmationCount !== undefined ? { awaitingConfirmationCount } : {}),
        ...(uploadsWindow ? { uploadsWindow } : {}),
        ...(dataRoom ? { dataRoom } : {}),
        ...(unavailable.length ? { unavailable } : {}),
      };
      return res.json({ success: true, data });
    } catch (err: unknown) {
      // Fail closed on a not-yet-provisioned store (missing table) → honest,
      // empty vault so the surface degrades to its fixture rather than 500ing.
      if ((err as { code?: string })?.code === '42P01') {
        const empty: VaultDisplayShape = {
          program: 'Vault',
          spine: '',
          standard: 'service',
          documentCount: 0,
          tree: [],
          pendingStore: true,
        };
        return res.json({ success: true, data: empty });
      }
      logger.error('project vault read error', {
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({ success: false, error: 'Failed to build project vault' });
    }
  });

  /**
   * POST /api/c2c/project-vault/:id/file — commit a filing decision.
   *
   * The classifier only ever SUGGESTS; this is where a person confirms the
   * suggestion, moves the document to another folder, or explicitly unfiles
   * it. The placement change and its hash-chained Part 11 audit row commit in
   * one transaction — a filing decision is a governed act on a regulated
   * corpus, not a UI preference.
   *
   * Body:
   *   documentId  vault.documents uuid (required)
   *   confirm     true → keep the suggested folder, mark it confirmed
   *   folderId    move to this folder (must exist in the program's view
   *               taxonomy) · null → unfile
   *   evidenceKind / ctdSection  optional refinements recorded with the move
   *   note        optional reason, recorded as the placement rationale
   */
  /**
   * GET /api/c2c/project-vault/:id/documents/:documentId/download
   *
   * Hand back the bytes of one uploaded vault document.
   *
   * The Vault's own "Download" button did `onAsk('Download ' + sel.title)` —
   * it typed a sentence into the assistant rail. On a document management
   * system, on the control labelled Download, next to a download icon. No file
   * ever left the vault through this surface, and the ingest path had been
   * writing the bytes to disk all along (vault-ingest.ts stores them at
   * `s3_key` and treats a write failure as FATAL precisely so a content hash
   * never describes bytes nobody holds).
   *
   * Scoped exactly like every other read here: the program is re-checked
   * against the caller's organization, and the document against the program.
   * The row's content_hash is verified against the bytes on disk before they
   * are sent — a governed document store that serves a file it cannot prove is
   * the file it recorded is not a governed store, and a silent mismatch is how
   * a superseded or tampered copy leaves the building.
   */
  /**
   * GET /:id/search?q=&limit=&offset=
   *
   * Search a program's vault by CONTENT and metadata.
   *
   * ── Why this exists ────────────────────────────────────────────────────────
   * The Vault surface had no search input at all. Its only text filtering was a
   * client-side substring match over the rows already in memory, which cannot
   * match document content and silently misses everything the tree did not
   * happen to load. On a document management system, a reviewer who cannot find
   * a document concludes it is absent.
   *
   * Ranked full text over title, file name and extracted body, using the SAME
   * expression the GIN index is built on (migrations/20260906_vault_documents_fulltext.sql)
   * — a retyped variant still returns correct rows, by sequential scan, and the
   * only symptom is a slow endpoint once the corpus is large.
   *
   * Paginated, because a vault is not a page. `total` is the real count, so the
   * surface can say "12 of 340" rather than implying the first page is all of it.
   */
  router.get('/:id/search', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });

    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    if (!UUID_RE.test(id)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '25'), 10) || 25, 1), 100);
    const offset = Math.max(parseInt(String(req.query.offset ?? '0'), 10) || 0, 0);
    // Current versions only unless asked (VR-09): an earlier version is the same
    // document, and listing it beside its successor reads as two.
    const includeSuperseded = req.query.includeSuperseded === 'true';

    /* An empty query is not "match everything" — that is the browse view, which
       is what GET /:id already serves. Returning the whole vault here would make
       an empty search box look like a search that found everything. */
    if (!q) {
      return res.json({
        success: true,
        data: { query: '', results: [], total: 0, limit, offset, reason: 'EMPTY_QUERY' },
      });
    }

    try {
      // The program must be this org's before any of its documents are listed —
      // the same guard the read and download routes apply.
      if (!(await programInOrganization(pool, id, orgId))) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

      // The one search query (vault-search.ts), here scoped to this program; the
      // library search below asks the same query across the organisation.
      const found = await searchVaultDocuments(pool, { organizationId: orgId, programId: id, q, limit, offset, includeSuperseded });
      return res.json({
        success: true,
        data: {
          query: q,
          total: found.total,
          limit,
          offset,
          includeSuperseded,
          results: found.results.map((r) => ({
            id: r.id,
            title: r.title,
            fileName: r.fileName,
            documentType: r.documentType,
            size: prettySize(r.sizeBytes),
            folderId: r.folderId,
            ctdSection: r.ctdSection,
            placementStatus: r.placementStatus,
            version: r.version,
            current: r.current,
            originalFileAvailable: r.originalFileAvailable,
            disposition: r.disposition,
            snippet: r.snippet,
          })),
        },
      });
    } catch (err) {
      /* An error is never an empty result. A search that failed and a search that
         found nothing are the same screen otherwise, and the second is the one a
         reviewer will believe. */
      logger.error('vault search failed', {
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({
        success: false,
        error: 'SEARCH_FAILED',
        message: 'The vault could not be searched. This is not an empty result — nothing was searched.',
      });
    }
  });

  /* ── GET /:id/documents/:documentId/versions ─────────────────────────────
     Every version of the document, newest first, from any of its versions
     (VR-09): version, SHA-256, size, uploader, date, which one is current, and
     whether its link to a predecessor is one the database rules admit
     (vault-version-family.ts). The tree lists only the current version, so this
     is where an earlier one is found; any version downloads through the one
     hash-verified, audited route below. The document must be this program's
     and this organization's, as for a download. */
  router.get('/:id/documents/:documentId/versions', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    const documentId = String(req.params.documentId ?? '');
    if (!UUID_RE.test(id) || !UUID_RE.test(documentId)) {
      return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    }
    try {
      const family = await readVersionFamily(pool, { programId: id, organizationId: orgId, documentId });
      if (!family) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
      // Each version's review and approval (VR-13): its lifecycle record's stage
      // and sign-offs, or none (not reviewed). An unreadable stage fails the
      // read: "not reviewed" would be a claim about a record not read.
      const lifecycles = await readVaultLifecycles(pool, orgId, family.map((v) => v.id));
      // Where each version is placed (VR-14a): the live submission leaves that
      // name it. An unreadable placement list fails the read, as the stage does:
      // "placed nowhere" would be a claim about leaves not read.
      const { readVaultPlacements, readVaultEstarUses, readVaultCmcEvidenceUses } = await import('../../services/vault/vault-where-used.js');
      const ids = family.map((v) => v.id);
      const placements = await readVaultPlacements(pool, orgId, ids);
      const estarUses = await readVaultEstarUses(pool, orgId, ids);
      // The CMC records that cite each version as their source (row D2).
      const cmcEvidence = await readVaultCmcEvidenceUses(pool, orgId, ids);
      // Why each version would not be transmitted, in the words the transmit
      // refusal prints (VR-14's one rule, read for display), or null. Placement
      // is not refused on it; freeze, dispatch and transmit are. An unreadable
      // verdict fails the read, as the stage does.
      const refusals = await Promise.all(family.map((v) => vaultVersionNotTransmittable(pool, orgId, v.id, v.contentHash ?? '')));
      const versions = family.map((v, i) => ({
        ...v,
        lifecycle: lifecycles.get(v.id) ?? null,
        placements: placements.get(v.id) ?? [],
        estarUses: estarUses.get(v.id) ?? [],
        cmcEvidence: cmcEvidence.get(v.id) ?? [],
        transmitRefusal: refusals[i],
      }));
      // Who may sign a review or an approval here (QA 2026-10-08, walk 2, j3):
      // the reader's own authority from the check the sign route applies, and
      // the members who hold it, so the page names them instead of offering a
      // signature the server refuses after the password.
      const { readSigningPosture } = await import('../../services/vault/vault-signing-posture.js');
      const signing = await readSigningPosture(pool, orgId, resolveUserId(req));
      return res.json({ success: true, data: { versions, signing } });
    } catch (err) {
      if (isMissingStore(err)) {
        return res.status(503).json({ success: false, error: 'STORE_UNAVAILABLE',
          message: 'The vault uploads store is not provisioned in this environment.' });
      }
      logger.error('vault versions read failed', { documentId, err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({ success: false, error: 'VERSIONS_UNAVAILABLE',
        message: "This document's versions could not be read. Nothing is shown rather than an incomplete list." });
    }
  });

  /* ── GET /:id/documents/:documentId/compare?against=<versionId> ──────────
     What changed between two versions of one document (plan critique 15):
     the changed lines of their extracted text, unchanged runs collapsed, and
     the recorded details that differ (vault-version-compare.ts). Both must be
     in the same family; another document's version is refused, another
     organisation's document reads as not found. */
  router.get('/:id/documents/:documentId/compare', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const id = String(req.params.id ?? '');
    const documentId = String(req.params.documentId ?? '');
    const against = typeof req.query.against === 'string' ? req.query.against : '';
    if (!UUID_RE.test(id) || !UUID_RE.test(documentId)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    if (!UUID_RE.test(against)) {
      return res.status(400).json({ success: false, error: 'AGAINST_REQUIRED', message: 'Name the version to compare with (?against=<version id>).' });
    }
    try {
      const { compareVaultVersions } = await import('../../services/vault/vault-version-compare.js');
      const out = await compareVaultVersions(pool, { programId: id, organizationId: orgId, documentId, againstId: against });
      if (!out.ok) return res.status(out.status).json({ success: false, error: out.code, message: out.message });
      return res.json({
        success: true,
        data: { from: out.from, to: out.to, sameBytes: out.sameBytes, details: out.details, text: out.text },
      });
    } catch (err) {
      if (isMissingStore(err)) {
        return res.status(503).json({ success: false, error: 'STORE_UNAVAILABLE',
          message: 'The vault uploads store is not provisioned in this environment.' });
      }
      logger.error('vault version compare failed', { documentId, err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({ success: false, error: 'COMPARE_UNAVAILABLE',
        message: 'The two versions could not be compared. Nothing is shown rather than a partial comparison.' });
    }
  });

  /* ── GET /:id/documents/:documentId/history ──────────────────────────────
     The document's own audit trail (VR-01, docs/design/VAULT_VEEVA_PARITY_PLAN_2026-09-24.md):
     every chained audit_logs row recorded against it — ingest, filing
     decisions, downloads — newest first, each with its hash and its
     predecessor in the tenant chain, plus the server's verdict on that chain.
     Read from the one ledger (readRecordAuditHistory beside readAuditLedger),
     in a transaction stamped with the tenant so RLS sees the org the SQL names.
     The document must be this program's and this org's before anything is
     read, exactly as for a download. */
  router.get('/:id/documents/:documentId/history', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    const documentId = String(req.params.documentId ?? '');
    if (!UUID_RE.test(id) || !UUID_RE.test(documentId)) {
      return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    }
    let client: PoolClient | undefined;
    try {
      const docRes = await pool.query(
        `SELECT d.id FROM vault.documents d
          WHERE d.id = $1 AND d.program_id = $2
            AND EXISTS (
              SELECT 1 FROM regulatory_programs rp
               WHERE rp.id = d.program_id AND rp.organization_id = $3 AND rp.deleted_at IS NULL
            )
          LIMIT 1`,
        [documentId, id, orgId],
      );
      if (docRes.rows.length === 0) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

      // Every version's trail (VR-09). A deleted version has no live family,
      // so its own trail is read, as before.
      const family = await readVersionFamily(pool, { programId: id, organizationId: orgId, documentId });
      client = await pool.connect();
      await client.query('BEGIN');
      await setTenantContextTx(client, orgId);
      const { entries, chain, truncated } = await readFamilyHistory(client, orgId, family, documentId);
      await client.query('COMMIT');
      return res.json({ success: true, data: { entries, chain, truncated } });
    } catch (err) {
      await client?.query('ROLLBACK').catch(() => undefined);
      logger.error('vault document history read failed', {
        documentId,
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({
        success: false,
        error: 'HISTORY_UNAVAILABLE',
        message: "This document's history could not be read. Nothing is shown rather than an incomplete history.",
      });
    } finally {
      client?.release();
    }
  });

  router.get('/:id/documents/:documentId/download', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });

    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    if (!UUID_RE.test(id)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    const documentId = String(req.params.documentId ?? '');
    if (!UUID_RE.test(documentId)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

    try {
      // The program must be this org's before any document of it is served.
      if (!(await programInOrganization(pool, id, orgId))) return res.status(404).json({ success: false, error: 'NOT_FOUND' });

      const docRes = await pool.query(
        `SELECT d.id, d.file_name, d.document_title, d.mime_type, d.file_size, d.s3_key,
                d.storage_version_id, d.storage_provider, d.content_hash
           FROM vault.documents d
          WHERE d.id = $1 AND d.program_id = $2 AND d.deleted_at IS NULL
            AND ${vaultBinaryAvailableSql('d')}
            AND EXISTS (
              SELECT 1 FROM regulatory_programs rp
               WHERE rp.id = d.program_id
                 AND rp.organization_id = $3
                 AND rp.deleted_at IS NULL
            )
          LIMIT 1`,
        [documentId, id, orgId],
      );
      if (docRes.rows.length === 0) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
      const doc = docRes.rows[0] as {
        id: string; file_name: string | null; document_title: string | null;
        mime_type: string | null; file_size: string | number | null;
        s3_key: string | null; storage_version_id: string | null; storage_provider: string | null; content_hash: string | null;
      };

      if (!doc.storage_version_id && !doc.s3_key) {
        // A row with NEITHER address describes a document whose bytes were never
        // kept. Say that rather than 404 — the record exists, the file does not.
        // Both are checked because this is a dual-read: new uploads carry a
        // provider version id and no s3_key, rows written before the vault moved
        // onto the storage provider carry the reverse, and testing only the old
        // one would refuse every new upload as "catalogued without content".
        return res.status(409).json({
          success: false,
          error: 'NO_STORED_FILE',
          message: 'This vault record has no stored file — it was catalogued without content.',
        });
      }

      const read = await readVerifiedVaultBytes(
        {
          storageVersionId: doc.storage_version_id,
          storageKey: doc.s3_key,
          organizationId: orgId,
          storageProvider: doc.storage_provider,
        },
        doc.content_hash,
        documentId,
      );
      if (!read.ok) {
        return res.status(read.status).json({
          success: false,
          error: read.error,
          ...(read.message ? { message: read.message } : {}),
        });
      }
      const bytes = read.bytes;

      const recorded = await recordVaultDownload(req, {
        orgId,
        programId: id,
        documentId,
        documentTitle: doc.document_title,
        fileName: doc.file_name,
        fileSize: doc.file_size,
        contentHash: doc.content_hash,
      });
      if (!recorded) {
        return res.status(500).json({
          success: false,
          error: 'AUDIT_WRITE_FAILED',
          message:
            'The download was not served because it could not be recorded in the audit trail. Nothing was sent.',
        });
      }

      const name = doc.file_name || doc.document_title || 'document';
      const safe = name.replace(/[^A-Za-z0-9_.-]+/g, '_').replace(/^_+|_+$/g, '') || 'document';
      res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${safe}"`);
      res.setHeader('Content-Length', String(bytes.length));
      // The recorded hash travels with the file, so a caller can check the copy
      // it received against the record without a second request.
      if (doc.content_hash) res.setHeader('X-Content-SHA256', doc.content_hash);
      return res.send(bytes);
    } catch (err) {
      logger.error('vault download failed', {
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({ success: false, error: 'DOWNLOAD_FAILED' });
    }
  });

  /* Filing decision. The write itself — ownership guards, the FOR UPDATE, the
     taxonomy check, the UPDATE and its §11 audit row in one transaction — lives
     in vault-placement.service.ts, because AnA now files documents too and a
     second copy of a governed write is how the two drift apart. This handler
     parses the request and renders the outcome.

     ROLE-GATED, unlike everything above it. This router is mounted with
     `authenticateToken` and nothing else (register-clinical-intel-routes.ts:187),
     so until now ANY member of the organization could commit a filing decision —
     including a `viewer`, the one organization role whose whole meaning is that
     it does not write. The decision is governed: it moves a regulatory document
     to a dossier folder and writes a Part 11 audit row naming the person as
     having made it, so a viewer could author an attributable governed record.

     The READS above are deliberately left open. A viewer enumerating and
     downloading their own organization's dossier is the viewer role working as
     intended, not a gap — the gap was only ever the write.

     `requireEditorAccess` is the repo's ONE governed-write gate (the comment on
     it records the four drifted copies it replaced); using it rather than a
     local role check is the whole point of it existing. */
  router.post('/:id/file', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const userId: number | null = (req as any).user?.id ?? null;

    const id = Array.isArray(req.params.id) ? (req.params.id[0] ?? '') : req.params.id;
    const body = (req.body ?? {}) as {
      documentId?: unknown; confirm?: unknown; folderId?: unknown;
      evidenceKind?: unknown; ctdSection?: unknown; note?: unknown;
    };
    const str = (v: unknown): string | null =>
      typeof v === 'string' && v.trim() ? v.trim() : null;

    try {
      const { placeVaultDocument } = await import('../../services/vault/vault-placement.service.js');
      const outcome = await placeVaultDocument({
        programId: id,
        documentId: typeof body.documentId === 'string' ? body.documentId.trim() : '',
        organizationId: orgId,
        userId,
        confirm: body.confirm === true,
        /* Four inputs, four meanings, all of which the inline handler
           distinguished and none of which may collapse into another: absent
           (confirm in place), null (unfile), a string (file there, blank
           included so it still reaches NO_TARGET), and anything else — which
           is not a folder, and is normalized to a blank string so it is
           refused rather than read as an unfile. */
        folderId: normalizeFolderId(body.folderId),
        evidenceKind: str(body.evidenceKind),
        ctdSection: str(body.ctdSection),
        note: str(body.note),
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      if (!outcome.ok) {
        return res
          .status(outcome.status)
          .json({ success: false, error: outcome.code, message: outcome.message });
      }
      return res.json({ success: true, filing: outcome.filing });
    } catch (err: unknown) {
      if ((err as { code?: string })?.code === '42P01' || (err as { code?: string })?.code === '42703') {
        return res.status(409).json({
          success: false,
          error: 'STORE_PENDING',
          message: 'The vault uploads store is not provisioned in this environment.',
        });
      }
      logger.error('project vault file error', {
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({ success: false, error: 'Failed to record the filing decision' });
    }
  });

  /* POST /:id/data-room/file — File into Vault (VR-11, D2).
     Captured sources, chosen in the data room, each filed through the one
     upload-to-Vault orchestration (vault-data-room-filing.ts). Behind the same
     governed-write gate as filing, so a viewer is refused before any byte is
     read. 200 carries a result per source; `complete: false` when any was
     refused. */
  router.post('/:id/data-room/file', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const outcome = await fileDataRoomSources({
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        programId: String(req.params.id),
        sourceIds: (req.body ?? {}).sourceIds,
        // Sources the person adds as the next version of a named document (QA-2026-10-08).
        newVersionOf: (req.body ?? {}).newVersionOf,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!outcome.ok) {
        return res.status(outcome.status).json({ success: false, error: outcome.code, message: outcome.message });
      }
      return res.json({ success: true, complete: outcome.complete, items: outcome.items });
    } catch (err: unknown) {
      logger.error('data room file error', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({
        success: false,
        error: 'FILING_FAILED',
        message: 'The files could not be filed. Check the data room before trying again: some may have been filed.',
      });
    }
  });

  /* POST /:id/file-batch — Confirm N suggested (VR-11b, D2).
     The suggested filings in one folder, confirmed by a person with one
     reason (vault-placement-batch.ts): each through placeVaultDocument, each
     with its own chained row carrying the reason. 422 without a reason;
     otherwise 200 with an answer per document, `complete: false` when any was
     refused. */
  router.post('/:id/file-batch', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    try {
      const { confirmSuggestedFilings } = await import('../../services/vault/vault-placement-batch.js');
      const outcome = await confirmSuggestedFilings({
        programId: String(req.params.id),
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        folderId: body.folderId,
        documentIds: body.documentIds,
        note: body.note,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!outcome.ok) {
        return res.status(outcome.status).json({ success: false, error: outcome.code, message: outcome.message });
      }
      return res.json({ success: true, complete: outcome.complete, items: outcome.items });
    } catch (err: unknown) {
      logger.error('project vault file-batch error', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({
        success: false,
        error: 'CONFIRM_FAILED',
        message: 'The filings could not be confirmed. Reload the Vault before trying again: some may have been confirmed.',
      });
    }
  });

  /* POST /:id/fixity — re-prove every stored version (plan critique 15, D5).
     Each version is read through readVerifiedVaultBytes, the verifier a
     download uses, and its verdict is written to the audit chain as its own
     vault.document.fixity row (vault-fixity.ts). Behind the governed-write
     gate, because each verdict is a record attributed to the person. */
  router.post('/:id/fixity', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { checkProgramFixity } = await import('../../services/vault/vault-fixity.js');
      const out = await checkProgramFixity({
        programId: String(req.params.id),
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!out.ok) return res.status(out.status).json({ success: false, error: out.code, message: out.message });
      return res.json({
        success: true,
        data: { checkedAt: out.checkedAt, checked: out.checked, counts: out.counts, findings: out.findings, truncated: out.truncated },
      });
    } catch (err) {
      logger.error('vault fixity check failed', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({
        success: false,
        error: 'FIXITY_FAILED',
        message: 'The check did not finish. No result is shown; the verdicts recorded before it stopped are in each document\'s history.',
      });
    }
  });

  /* POST /:id/documents/:documentId/details — Edit details (VR-05, D5).
     A version's title, type and classification, changed by a person with a
     reason for change. The writer (vault-metadata-edit.service.ts) checks the
     role, the reason, the vocabularies and program ownership, and records each
     field's before and after with the reason in one chained audit row; this
     route only carries the request to it, behind the same governed-write gate
     as filing. */
  router.post('/:id/documents/:documentId/details', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    const text = (v: unknown): string | undefined => (typeof v === 'string' ? v : undefined);
    try {
      const { editVaultDocumentMetadata } = await import('../../services/vault/vault-metadata-edit.service.js');
      const outcome = await editVaultDocumentMetadata({
        programId: String(req.params.id),
        documentId: String(req.params.documentId),
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        documentTitle: text(body.documentTitle),
        documentType: text(body.documentType),
        classification: text(body.classification),
        reason: body.reason,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!outcome.ok) {
        return res.status(outcome.status).json({ success: false, error: outcome.code, message: outcome.message });
      }
      return res.json({ success: true, unchanged: outcome.unchanged, changes: outcome.changes });
    } catch (err: unknown) {
      logger.error('project vault details error', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({ success: false, error: 'The details could not be saved. Nothing was changed.' });
    }
  });

  /* ── The catalog record: AnA's suggestion, a person's decision (S4, D5) ──
     What AnA recorded about the current version (kind, purpose, summary, key
     data), who proposed it (model, turn) and whether a person confirmed or
     corrected it. The writer (document-catalog-governance.service.ts) checks
     the role, the reason, the vocabulary and program ownership, and commits
     each decision with one chained audit row; these routes only carry it. */
  router.get('/:id/documents/:documentId/catalog', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { readCatalogRecord } = await import('../../services/vault/document-catalog-governance.service.js');
      const record = await readCatalogRecord({
        programId: String(req.params.id ?? ''), documentId: String(req.params.documentId ?? ''), organizationId: orgId,
        userId: governedActorId(req),
      });
      if (!record) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
      return res.json({ success: true, data: record });
    } catch (err) {
      logger.error('vault catalog record read failed', { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({ success: false, error: 'CATALOG_UNAVAILABLE',
        message: "This document's catalog record could not be read. Nothing is shown rather than a record that may be wrong." });
    }
  });

  const reviewCatalog = (action: 'confirm' | 'correct') => async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    const text = (v: unknown): string | undefined => (typeof v === 'string' ? v : undefined);
    if ('expectedExtractedTextSha256' in body && typeof body.expectedExtractedTextSha256 !== 'string') {
      return res.status(400).json({ success: false, error: 'INVALID_EXTRACTED_TEXT_HASH',
        message: 'The shown source text must be identified by its SHA-256 digest.' });
    }
    try {
      const { reviewCatalogRecord } = await import('../../services/vault/document-catalog-governance.service.js');
      const outcome = await reviewCatalogRecord({
        programId: String(req.params.id ?? ''),
        documentId: String(req.params.documentId ?? ''),
        organizationId: orgId,
        // From the session only; the service refuses a request with none.
        userId: governedActorId(req),
        action,
        expectedContentHash: text(body.contentHash),
        expectedExtractedTextSha256: text(body.expectedExtractedTextSha256),
        expectedRevision: text(body.revision),
        documentKind: text(body.documentKind),
        purpose: text(body.purpose),
        summary: text(body.summary),
        reason: body.reason,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!outcome.ok) {
        return res.status(outcome.status).json({ success: false, error: outcome.code, message: outcome.message });
      }
      return res.json({ success: true, state: outcome.state, changes: outcome.changes });
    } catch (err) {
      logger.error(`vault catalog ${action} failed`, { err: err instanceof Error ? err.message : String(err) });
      return res.status(500).json({ success: false, error: 'CATALOG_NOT_SAVED', message: 'The catalog record could not be saved. Nothing was changed.' });
    }
  };
  router.post('/:id/documents/:documentId/catalog/confirm', requireEditorAccess, reviewCatalog('confirm'));
  router.post('/:id/documents/:documentId/catalog/correct', requireEditorAccess, reviewCatalog('correct'));

  /* ── Document relationships (plan critique 15, D2) ─────────────────────
     One version names the documents that support it, that it references or
     that it is based on: the replacement for the parentDocumentId VR-05
     refused. vault-relationships.ts checks the role, the organisation and the
     vocabulary, and writes each change with a chained row on both documents.
     A relationship is removed with a reason, never deleted. */
  const relationshipFailure = (res: Response, err: unknown, what: string) => {
    logger.error(`vault relationships ${what} failed`, { err: err instanceof Error ? err.message : String(err) });
    return res.status(500).json({ success: false, error: 'RELATIONSHIPS_UNAVAILABLE',
      message: what === 'read'
        ? "This document's relationships could not be read. Nothing is shown rather than an incomplete list."
        : 'The relationship could not be saved. Nothing was changed.' });
  };

  router.get('/:id/documents/:documentId/relationships', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const id = String(req.params.id ?? '');
    if (!UUID_RE.test(id)) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    try {
      const { listRelationships } = await import('../../services/vault/vault-relationships.js');
      const out = await listRelationships(pool, { programId: id, organizationId: orgId, documentId: String(req.params.documentId ?? '') });
      if (!out.ok) return res.status(out.status).json({ success: false, error: out.code, message: out.message });
      return res.json({ success: true, data: { relationships: out.relationships } });
    } catch (err) {
      return relationshipFailure(res, err, 'read');
    }
  });

  router.post('/:id/documents/:documentId/relationships', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    try {
      const { addRelationship } = await import('../../services/vault/vault-relationships.js');
      const out = await addRelationship({
        programId: String(req.params.id),
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        documentId: String(req.params.documentId ?? ''),
        toDocumentId: body.toDocumentId,
        type: body.type,
        note: body.note,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!out.ok) return res.status(out.status).json({ success: false, error: out.code, message: out.message });
      return res.status(201).json({ success: true, data: { id: out.id } });
    } catch (err) {
      return relationshipFailure(res, err, 'write');
    }
  });

  router.post('/:id/relationships/:relationshipId/remove', requireEditorAccess, async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    try {
      const { removeRelationship } = await import('../../services/vault/vault-relationships.js');
      const out = await removeRelationship({
        programId: String(req.params.id),
        organizationId: orgId,
        userId: (req as any).user?.id ?? null,
        relationshipId: String(req.params.relationshipId ?? ''),
        reason: body.reason,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
      if (!out.ok) return res.status(out.status).json({ success: false, error: out.code, message: out.message });
      return res.json({ success: true });
    } catch (err) {
      return relationshipFailure(res, err, 'write');
    }
  });

  /* ── Review annotations (plan critique 15, D2/D5) ──────────────────────
     A reviewer annotates a version with a comment or a change request,
     anchored to the whole version, a page, or a passage of its extracted
     text; others reply; it is resolved with a note or retracted by its
     author with a reason (vault-annotations.ts, and the record's own guards
     in migrations/20261001_vault_version_annotations.sql). Reading the text
     to choose a passage is recorded, or nothing is served. Writes are behind
     the governed-write gate; the service checks the role again. */
  const annotationFailure = (res: Response, err: unknown, what: 'read' | 'write') => {
    const message = err instanceof Error ? err.message : String(err);
    if (isMissingStore(err)) {
      return res.status(503).json({ success: false, error: 'ANNOTATIONS_STORE_UNAVAILABLE',
        message: `Review annotations are not provisioned in this environment. ${what === 'read' ? 'Nothing is shown.' : 'Nothing was changed.'}` });
    }
    if (/^(VAULT_ANNOTATION_REFUSED|IMMUTABILITY_VIOLATION)/.test(message)) {
      logger.warn('vault annotation refused by its record', { message });
      return res.status(409).json({ success: false, error: 'ANNOTATION_REFUSED', message: 'The annotation record refused this change. Nothing was changed.' });
    }
    logger.error(`vault annotations ${what} failed`, { err: message });
    return res.status(500).json({ success: false, error: 'ANNOTATIONS_UNAVAILABLE',
      message: what === 'read'
        ? "This document's annotations could not be read. Nothing is shown rather than an incomplete list."
        : 'The annotation could not be saved. Nothing was changed.' });
  };
  const annotationActor = (req: Request) => ({
    programId: String(req.params.id ?? ''),
    organizationId: resolveOrgId(req) as number,
    userId: governedActorId(req),
    ipAddress: req.ip,
    userAgent: req.headers['user-agent'],
  });
  const answer = (res: Response, out: { ok: boolean } & Record<string, unknown>, created = false) => {
    if (!out.ok) return res.status(out.status as number).json({ success: false, error: out.code, message: out.message });
    const data = Object.fromEntries(Object.entries(out).filter(([k]) => k !== 'ok'));
    return res.status(created ? 201 : 200).json({ success: true, data });
  };

  router.get('/:id/documents/:documentId/annotations', async (req: Request, res: Response) => {
    const orgId = resolveOrgId(req);
    if (!orgId) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { listAnnotations } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await listAnnotations(pool, {
        programId: String(req.params.id ?? ''), organizationId: orgId, documentId: String(req.params.documentId ?? ''),
      }));
    } catch (err) {
      return annotationFailure(res, err, 'read');
    }
  });

  router.get('/:id/documents/:documentId/text', async (req: Request, res: Response) => {
    if (!resolveOrgId(req)) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { readAnnotatableText } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await readAnnotatableText({
        ...annotationActor(req), documentId: String(req.params.documentId ?? ''), from: req.query.from, length: req.query.length,
      }));
    } catch (err) {
      if ((err as { code?: unknown })?.code === 'AUDIT_WRITE_FAILED') {
        logger.error('vault text read not recorded', { err: err instanceof Error ? err.message : String(err) });
        return res.status(500).json({ success: false, error: 'AUDIT_WRITE_FAILED',
          message: 'The text was not shown because the read could not be recorded in the audit trail. Nothing was sent.' });
      }
      return annotationFailure(res, err, 'read');
    }
  });

  router.post('/:id/documents/:documentId/annotations', requireEditorAccess, async (req: Request, res: Response) => {
    if (!resolveOrgId(req)) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    try {
      const { postAnnotation } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await postAnnotation({
        ...annotationActor(req), documentId: String(req.params.documentId ?? ''), kind: body.kind, body: body.body, anchor: body.anchor,
      }), true);
    } catch (err) {
      return annotationFailure(res, err, 'write');
    }
  });

  router.post('/:id/annotations/:annotationId/replies', requireEditorAccess, async (req: Request, res: Response) => {
    if (!resolveOrgId(req)) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { replyToAnnotation } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await replyToAnnotation({
        ...annotationActor(req), annotationId: String(req.params.annotationId ?? ''), body: (req.body ?? {}).body,
      }), true);
    } catch (err) {
      return annotationFailure(res, err, 'write');
    }
  });

  router.post('/:id/annotations/:annotationId/resolve', requireEditorAccess, async (req: Request, res: Response) => {
    if (!resolveOrgId(req)) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    const body = (req.body ?? {}) as Record<string, unknown>;
    try {
      const { resolveAnnotation } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await resolveAnnotation({
        ...annotationActor(req), annotationId: String(req.params.annotationId ?? ''), note: body.note,
        addressedInVersionId: body.addressedInVersionId,
      }));
    } catch (err) {
      return annotationFailure(res, err, 'write');
    }
  });

  router.post('/:id/annotations/:annotationId/retract', requireEditorAccess, async (req: Request, res: Response) => {
    if (!resolveOrgId(req)) return res.status(403).json({ success: false, error: 'FORBIDDEN' });
    try {
      const { retractAnnotation } = await import('../../services/vault/vault-annotations.js');
      return answer(res, await retractAnnotation({
        ...annotationActor(req), annotationId: String(req.params.annotationId ?? ''), reason: (req.body ?? {}).reason,
      }));
    } catch (err) {
      return annotationFailure(res, err, 'write');
    }
  });

  return router;
}
