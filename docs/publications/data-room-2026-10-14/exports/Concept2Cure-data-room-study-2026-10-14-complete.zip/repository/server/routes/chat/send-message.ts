/**
 * Send-message handler — the 9-step provenance-tracked RAG pipeline.
 *
 * Steps: RESOLVE_ORG → THREAD → USER_MSG → RETRIEVE → PROMPT → GENERATE →
 * PERSIST → CLAIMS → CITATIONS.
 *
 * Extracted from the monolithic server/routes/chat.ts as part of Phase 4
 * architecture consolidation. Behavior is byte-for-byte preserved.
 *
 * @module server/routes/chat/send-message
 */

import type { Request, Response } from 'express';
import { getPool, pool } from '../../db.js';
import { currentTenantOrgUuid } from '../../db/currentTenant.js';
import {
  getOrCreateThread,
  getThreadMessages,
  ThreadAccessError,
  saveChatMessage as saveMessage,
} from '../../services/chat-thread-helpers.js';
import { getEmbeddingService } from '../../services/enhancedEmbeddingService.js';
import { getIntelligencePrefix } from '../../services/lumen-context-builder.js';
import { pendingSignoffFromToolResult, settleActionBlocks } from '../../services/ana-guidance-executor.js';
import type { CommandResult } from '../../services/ana-ri/command-executor.js';
import { logKernelDecision } from '../../services/kernel-decision-record.js';
import { planKernelExecution } from '../../services/kernel-router.js';
import {
  getKernelPolicyHint,
  recordKernelPolicyOutcome,
} from '../../services/kernel-adaptive-policy.js';
import { interceptChatResponse } from '../../services/intelligence/rim-interceptors.js';
import { governedToolsetFor } from '../../services/ana/governed-toolset.js';
import { selectToolsForTurn, SELF_DRIVE_TOOLS } from '../../services/ana/tool-selection.js';
import { executeAgenticLoop } from '../../services/ana/AnaToolExecutor.js';
import { loopToolCollector, recordLoopTurn } from '../../services/ana/turn-record-loop.js';
import type { TurnRecordStatus } from '../../services/ana/turn-record.js';
import { requestsGovernedDraft } from '../../services/ana/governed-write-tools.js';
import { resolveMaxRounds } from '../../services/ana/agentic-loop.js';
import {
  isSubstantiveTurn,
  resolveModelTier,
  resolveTierModel,
} from '../../services/ai-gateway/reasoning.js';
import { logToolRun } from '../../services/toolRegistry.js';
import type { AnaGatewayResponse } from '../../services/ai-gateway/types.js';
import { buildMemoryContextForChat, type MemoryAssemblyDiagnostics } from '../../services/memory-context-assembler.js';
import { summarizeAndStoreWorkingMemoryForThread } from '../../services/working-memory.js';
import { getProjectInstructionsBlock } from '../../services/projects/project-instructions.js';
import {
  getProjectRetrievalMode,
  assembleProjectKnowledgeCorpus,
} from '../../services/projects/retrieval-mode.js';
import { getCachedSignalReliability } from '../../services/intelligence/learning-loop-service.js';
import type { SignalReliability } from '../../services/intelligence/learning-loop-service.js';
import { orchestrate, type OrchestratorOutput } from '../../services/ana-ri/orchestrator.js';
import {
  directiveFromToolResult,
  surfaceActionFromToolResult,
  toNavigationActions,
  toSurfaceActionChips,
  type NavigationAction,
  type SurfaceActionChip,
  type DemoStartChip,
  demoStartFromToolResult,
  toDemoStartChips,
  type DemoStartDirective,
} from '../../services/ana-ri/navigation-actions.js';
import type { NavigationDirective } from '../../../shared/navigation/index.js';
import type { SurfaceActionDirective } from '../../../shared/navigation/surface-actions.js';
import {
  handleSubmissionChat,
  isPostSectionGenerationTurn,
} from '../../services/ana/submission-chat-handler.js';
import { ensureGateway, normalizeBody } from './shared.js';
import { sha256, stableStringify } from './provenance.js';
import { verifyClaim, type VerifierFlag } from './verifier.js';
import { evidencePromptBlock, type RetrievalStatus } from './retrieval-evidence-block';
import { admitAnaProjectScope, AnaProjectScopeError } from '../../services/ana/project-scope-admission';
import { assertAnaUploadAccess } from '../../services/ana/source-context-admission';

// ── Retrieval + generation tuning (externalized for runtime changes) ────────
const RETRIEVAL_TOP_K = parseInt(process.env.ANA_RETRIEVAL_TOP_K ?? '5', 10);
const RETRIEVAL_THRESHOLD = parseFloat(process.env.ANA_RETRIEVAL_THRESHOLD ?? '0.7');
const GENERATION_MAX_TOKENS = parseInt(process.env.ANA_GENERATION_MAX_TOKENS ?? '4096', 10);
// Projects spec A2: dark-launch flag for in-context full-corpus injection. Off
// by default — the retrieval mode is still computed and surfaced via the
// knowledge endpoint; this flag only controls whether the chat path injects the
// full project corpus into the prompt (pending cost/cache validation in a live
// environment). When off, this path does zero extra work.
const INCONTEXT_INJECTION_ENABLED =
  process.env.PROJECT_INCONTEXT_INJECTION_ENABLED === 'true';

/**
 * POST /api/chat/send-message  (and POST /api/chat via root alias)
 * Main chat endpoint — 9-step provenance-tracked RAG pipeline.
 */
export const sendMessageHandler = async (req: Request, res: Response) => {
  normalizeBody(req);
  try {
    const { message, thread_id, file_id, system_prompt, project_id: rawProjectId, preferred_provider, selected_tools, tool_context } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({
        error: 'Message is required',
        code: 'INVALID_MESSAGE',
      });
    }

    // ── STEP 1: RESOLVE ORG (from session only — no header fallback for org) ──
    const orgId = (req as any).tenantId || (req as any).tenantContext?.organizationId;
    const rawUserId = (req as any).userId || (req as any).user?.id;
    const userId: number | string = rawUserId ?? 'anonymous';
    const numericOrgId = orgId ? (typeof orgId === 'string' ? Number(orgId) : orgId) : null;
    const numericUserId = typeof userId === 'string' ? Number(userId) : userId;
    const project_id = rawProjectId ?? req.body.context?.projectId ?? req.body.project_context?.projectId;
    // Check the explicit scope and attachment before any thread, source or
    // model work. An unreadable access decision never becomes org-wide chat.
    const admittedProject = await admitAnaProjectScope(getPool(), { organizationId: numericOrgId,
      userId: numericUserId, projectRef: project_id });
    await assertAnaUploadAccess(getPool(), { organizationId: numericOrgId, userId: numericUserId,
      fileIds: file_id == null || file_id === '' ? [] : [file_id] });

    // The org's UUID tenant key, from the same session scope. Both uses below —
    // Data Room retrieval and AnA's document tools — used to fall back to the
    // client's x-org-uuid header, and with neither ran the search across every
    // tenant. No key, no turn.
    const orgUuid = await currentTenantOrgUuid(pool);
    if (!orgUuid) {
      return res.status(403).json({ error: 'Tenant context required', code: 'TENANT_CONTEXT_REQUIRED' });
    }

    // ── STEP 2: CREATE / VALIDATE THREAD ─────────────────────────────────────────
    const requestedThreadId = Array.isArray(thread_id) ? thread_id[0] : thread_id;
    // Resolved AS THE CALLER: in this organization, and to this user's own
    // thread. A colleague's thread id is refused; an unknown or foreign id
    // mints a fresh thread rather than touching a row nothing verified.
    let threadId: string;
    try {
      threadId = await getOrCreateThread(
        requestedThreadId ?? null,
        (req as any).user?.id,
        'thread',
        numericOrgId
      );
    } catch (e: any) {
      if (e instanceof ThreadAccessError) {
        return res.status(403).json({
          error: 'That conversation belongs to another user',
          code: e.code,
        });
      }
      throw e;
    }

    // Fix B: Enforce thread ownership — if thread_id was supplied, verify org match
    if (requestedThreadId && numericOrgId) {
      try {
        const ownerCheck = await pool.query(
          `SELECT organization_id FROM ai_threads WHERE id = $1`,
          [threadId]
        );
        if (ownerCheck.rows.length > 0) {
          const threadOrg = Number(ownerCheck.rows[0].organization_id);
          if (threadOrg !== numericOrgId) {
            return res.status(403).json({
              error: 'Thread does not belong to this organization',
              code: 'THREAD_ORG_MISMATCH',
            });
          }
        }
      } catch (e: any) {
        // ai_threads table might not exist yet — skip check
        if (e?.code !== '42P01') console.warn('[AnA] Thread ownership check failed:', e.message);
      }
    }

    // Upsert provenance thread (org-scoped)
    if (numericOrgId) {
      try {
        await pool.query(
          `INSERT INTO ai_threads (id, organization_id, project_id, created_by)
           VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO NOTHING`,
          [threadId, numericOrgId, project_id || null, userId]
        );
      } catch (e: any) {
        if (e?.code !== '42P01') throw e;
        console.warn('[AnA] ai_threads table missing — provenance disabled');
      }
    }

    const previousMessages = await getThreadMessages(threadId);

    // ── STEP 2b: SUBMISSION-CHAT AUTO-FLIP ──────────────────────────────
    // If the user supplied an artifactId in context AND the previous assistant
    // turn was a section generation, route this message through the
    // submission-chat handler so retrieval scope expands to the entire
    // dossier instead of just the active document.
    const clientCtxEarly = (req.body.context ?? {}) as Record<string, any>;
    const submissionChatArtifactId =
      clientCtxEarly.artifactId || req.body.artifact_id;
    const submissionChatExplicit = req.body.mode === 'submission-chat';
    const shouldRunSubmissionChat =
      typeof submissionChatArtifactId === 'string' &&
      submissionChatArtifactId.length > 0 &&
      (submissionChatExplicit ||
        isPostSectionGenerationTurn(previousMessages));

    if (shouldRunSubmissionChat) {
      try {
        const sub = await handleSubmissionChat({
          threadId,
          artifactId: submissionChatArtifactId,
          question: message,
          organizationId: numericOrgId ?? null,
          organizationUuid: orgUuid,
          userId: numericUserId || null,
        });

        // Persist user + assistant turn to legacy chat_messages so the thread
        // remains continuous when the next message flips back to normal mode.
        await saveMessage(threadId, 'user', message, sub.model);
        await saveMessage(
          threadId,
          'assistant',
          sub.answer,
          sub.model,
          sub.usage.totalTokens
        );

        return res.json({
          answer: sub.answer,
          response: sub.answer,
          thread_id: threadId,
          model: sub.model,
          provider: sub.provider,
          usage: {
            prompt_tokens: sub.usage.promptTokens,
            completion_tokens: sub.usage.completionTokens,
            total_tokens: sub.usage.totalTokens,
          },
          mode: 'submission-chat',
          citations: sub.citations,
          submissionChat: {
            artifactId: sub.artifactId,
            projectId: sub.projectId,
            intent: sub.intent,
            rewrite: sub.rewrite,
            retrieval: sub.retrieval,
            conversation: sub.conversation,
          },
        });
      } catch (err: any) {
        // Fall through to the normal chat path on failure — the user still
        // gets an answer, just without the cross-dossier scope.
        console.warn(
          '[AnA] submission-chat auto-flip failed, falling back to normal chat:',
          err?.message
        );
      }
    }

    // ── STEP 3: PERSIST USER MESSAGE (provenance chain) ─────────────────
    if (numericOrgId) {
      try {
        await pool.query(
          `INSERT INTO ai_messages (thread_id, role, content) VALUES ($1, 'user', $2)`,
          [threadId, message]
        );
        // Update thread activity timestamp for sort ordering
        await pool
          .query(`UPDATE ai_threads SET updated_at = NOW() WHERE id = $1`, [threadId])
          .catch(err =>
            console.warn('[AnA] thread updated_at touch failed (non-blocking):', err?.message)
          );
      } catch (e: any) {
        if (e?.code !== '42P01') console.warn('[AnA] ai_messages insert failed:', e.message);
      }
    }

    // ── STEP 3a: AUTO-GENERATE THREAD TITLE FROM FIRST MESSAGE ──────────
    if (previousMessages.length === 0 && message) {
      try {
        // Generate a concise title from the first message (no AI call needed)
        const rawTitle = message.replace(/^\/\w+\s*/, '').trim(); // Strip slash commands
        const title =
          rawTitle.length > 60
            ? rawTitle.slice(0, 57).replace(/\s+\S*$/, '') + '...'
            : rawTitle || 'New conversation';
        await pool.query(`UPDATE ai_threads SET title = $1, updated_at = NOW() WHERE id = $2`, [
          title,
          threadId,
        ]);
      } catch (e: any) {
        // Non-blocking — title generation failure doesn't break chat
        if (e?.code !== '42P01') console.warn('[AnA] Thread title update failed:', e.message);
      }
    }

    const normalizedProjectId = project_id
      ? String(project_id).replace(/^proj_/, '')
      : undefined;
    // The integer project this turn's project names, resolved ONCE (PF-10
    // S10b): an integer as itself, a program UUID through its anchor row,
    // anything else as none. Each step below used to parseInt on its own, and
    // parseInt('7abb1c22-…') is 7, a valid, wrong project of the same
    // organization (services/c2c/project-ref.ts).
    const turnProjectId = admittedProject.projectId;

    // ── STEP 4: RETRIEVE (org-scoped + project-scoped when available) ───
    let sources: Array<{ id: string; title: string; content: string; score: number }> = [];
    // 'unavailable' when the search could not run (P1-54): told to the model and
    // returned in retrievalMeta, never rendered as "no sources found".
    let retrievalStatus: RetrievalStatus = 'searched';
    let confidence: number | null = null;
    let retrievalRunId: string | null = null;
    let snapshotHashSha256: string | null = null;
    const chunkRows: Array<{ id: string; rank: number; atomId: string; score: number }> = [];
    try {
      const embeddingService = getEmbeddingService(pool);
      // RETRIEVAL_THRESHOLD is a floor on semantic similarity, and the one
      // recorded in ai_retrieval_runs below; it used to go in as the ranking weight.
      const searchResults = await embeddingService.searchHybrid(message, {
        limit: RETRIEVAL_TOP_K,
        organizationUuid: orgUuid,
        projectId: normalizedProjectId,
        minSemanticScore: RETRIEVAL_THRESHOLD,
      });
      sources = searchResults.map(r => ({
        id: r.id,
        title: r.title,
        content: r.content.length > 500 ? r.content.substring(0, 500) + '…' : r.content,
        score: r.score,
      }));
      if (sources.length > 0) {
        confidence = Math.min(1, sources.reduce((sum, s) => sum + s.score, 0) / sources.length);
      }

      // Persist retrieval run + chunks (provenance chain)
      if (numericOrgId) {
        try {
          const queryHash = sha256(message);
          // Fix C: Snapshot hash includes sourceType + sourceRefId, sorted by rank
          const snapshotData = sources.map((s, i) => ({
            rank: i + 1,
            sourceType: 'atom' as const,
            sourceRefId: s.id,
            score: s.score,
          }));
          snapshotHashSha256 = sha256(stableStringify(snapshotData));

          const rrResult = await pool.query(
            `INSERT INTO ai_retrieval_runs
               (organization_id, project_id, user_id, scope, embedding_model,
                query_text, query_hash_sha256, snapshot_hash_sha256, top_k, threshold, result_count)
             VALUES ($1, $2, $3, $4, 'text-embedding-3-small', $5, $6, $7, $8, $9, $10)
             RETURNING id`,
            [
              numericOrgId,
              project_id || null,
              numericUserId,
              'org', // every search runs under the session's tenant key; there is no 'global' one
              message,
              queryHash,
              snapshotHashSha256,
              RETRIEVAL_TOP_K,
              RETRIEVAL_THRESHOLD,
              sources.length,
            ]
          );
          retrievalRunId = rrResult.rows[0].id;

          // AnA fix F9: batch all retrieval chunks into one multi-row INSERT
          // (replaces a sequential N+1 loop — RETRIEVAL_TOP_K queries became 1).
          if (sources.length > 0) {
            const valuesSql: string[] = [];
            const params: unknown[] = [];
            const paramsPerRow = 7;
            for (let i = 0; i < sources.length; i++) {
              const s = sources[i];
              const o = i * paramsPerRow;
              valuesSql.push(
                `($${o + 1}, $${o + 2}, 'atom', $${o + 3}, $${o + 4}, $${o + 5}, $${o + 6}, $${o + 7})`
              );
              params.push(
                retrievalRunId,
                i + 1,
                s.id,
                s.title,
                sha256(s.content),
                s.content.substring(0, 500),
                s.score
              );
            }
            const crResult = await pool.query(
              `INSERT INTO ai_retrieval_chunks
                 (retrieval_run_id, rank, source_type, atom_id, title,
                  excerpt_hash_sha256, excerpt_preview, score)
               VALUES ${valuesSql.join(', ')}
               RETURNING id, rank, atom_id, score`,
              params
            );
            for (const row of crResult.rows) {
              chunkRows.push({
                id: row.id,
                rank: row.rank,
                atomId: row.atom_id,
                score: Number(row.score),
              });
            }
            chunkRows.sort((a, b) => a.rank - b.rank);
          }
        } catch (e: any) {
          if (e?.code !== '42P01') console.warn('[AnA] Retrieval persist failed:', e.message);
        }
      }
    } catch (srcErr: any) {
      // Non-fatal — chat still works, without grounded evidence, and says so.
      retrievalStatus = 'unavailable';
      console.warn('[AnA] Source retrieval failed:', srcErr.message);
    }

    // ── STEP 5: BUILD EVIDENCE-GROUNDED PROMPT ─────────────────────────
    // If we have retrieved evidence, inject it into the system prompt so
    // the model can ground its answer and cite by [SRC-n] reference.
    let evidenceBlock = '';
    let memoryAtomCount = 0;
    let memoryBlockChars = 0;
    let memoryDiagnostics: MemoryAssemblyDiagnostics | null = null;
    evidenceBlock = evidencePromptBlock(sources, retrievalStatus);

    let assistantMessage: string;
    let model: string;
    let provider = '';
    // The model call whose reply carries the turn's ana-action blocks: its
    // proposals are sealed with it (D5, MC-RL-4; ana-ri/proposal-seal.ts).
    let servingModel: { provider: string; model: string; requestId: string | null } | null = null;
    let usage = { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
    let latencyMs: number | null = null;
    // Hoisted so the response serializer (after the try/catch) can read it.
    // The catch block returns 503, so reaching the response site implies
    // the assignment inside the try succeeded — hence non-null at use.
    let orchestratorResult: OrchestratorOutput | null = null;
    // Validated navigation directives the agentic loop's navigate_to produced
    // this turn. Hoisted for the same reason: collected inside the try (the
    // loop's onToolExecution), offered as chips by the action step after it.
    // This caller used to DROP them silently — AnA resolved a target, told the
    // user she could take them there, and no chip ever reached this client.
    const collectedNavigation: NavigationDirective[] = [];
    // Surface actions ride the same carrier: act_on_screen results become
    // offer-chips here too (this route never applies anything live).
    const collectedSurfaceActions: SurfaceActionDirective[] = [];
    const collectedDemoStarts: DemoStartDirective[] = [];
    // The platform-command proposals the loop's execute_platform_command came
    // back with. This route cannot hold the turn and ask, as the stream does;
    // until P0-12's residual (2026-10-01) the proposal reached only the model,
    // and the person had nothing to confirm. Returned as executedCommands.
    const loopProposals: CommandResult[] = [];
    // The turn's retained record (services/ana/turn-record-loop.ts): the tool
    // calls as the loop reports them, filed when the turn answers or fails.
    const loopCalls = loopToolCollector();
    let loopMessages: Array<{ role: string; content: unknown }> = [];
    const fileTurn = (outcome: 'answered' | 'failed', response?: unknown, error?: unknown): Promise<TurnRecordStatus> =>
      recordLoopTurn(
        getPool(),
        {
          orgId: numericOrgId,
          userId: numericUserId,
          surface: 'api:chat/send-message',
          projectId: project_id ?? null,
          threadId,
          typed: typeof message === 'string' ? message : String(message ?? ''),
          messages: loopMessages,
          calls: loopCalls.calls,
          response: response as Parameters<typeof recordLoopTurn>[1]['response'],
          outcome,
          error,
        },
        { ipAddress: req.ip, userAgent: req.get('user-agent') ?? undefined },
      );

    // ── STEP 6: GENERATE (no silent demo fallback) ─────────────────────
    const gw = ensureGateway();
    if (!gw || gw.getEnabledProviders().length === 0) {
      return res.status(503).json({
        error: 'No AI providers available. Configure ANTHROPIC_API_KEY or OPENAI_API_KEY.',
        code: 'AI_PROVIDER_UNAVAILABLE',
      });
    }

    try {
      // Build conversation history for orchestrator continuity analysis
      const conversationHistory = previousMessages
        .filter((m: any) => m.role === 'user' || m.role === 'assistant')
        .map((m: any) => ({ role: m.role as 'user' | 'assistant', content: m.content }));

      // Pre-fetch decision context for AnA explanation grounding (non-blocking)
      let decisionContext: any[] = [];
      if (project_id) {
        try {
          const { decisionLifecycleService } =
            await import('../../services/decision-lifecycle-service.js');
          // Scoped to the caller's tenant: this context is fed to the
          // orchestrator as grounding, so an unscoped read would not just
          // leak another organization's decisions, it would let the model
          // quote them back in an answer. numericOrgId is resolved above and
          // used throughout this handler; the decision read was the one that
          // did not pass it.
          decisionContext = numericOrgId
            ? decisionLifecycleService.getDecisionContext(String(project_id), {
                limit: 5,
                organizationId: numericOrgId,
              })
            : [];
        } catch {
          /* non-blocking */
        }
      }

      // Run the orchestrator for intent detection, deficiency context, and continuity
      // AnA fix F1: forward project + document + role metadata into the
      // orchestrator so AnA can ground responses on the active project /
      // artifact instead of guessing from message text alone.
      const clientCtx = (req.body.context ?? {}) as Record<string, any>;
      const orchestratorProjectContext = project_id
        ? {
            productName: clientCtx.activeProject || clientCtx.productName,
            therapeuticArea: clientCtx.therapeuticArea,
            submissionType: clientCtx.productType || clientCtx.submissionType,
            targetAgency: clientCtx.targetAgency,
            phase: clientCtx.phase,
          }
        : undefined;
      const orchestratorDocumentContext =
        clientCtx.artifactId || clientCtx.sectionCode || clientCtx.module
          ? {
              documentType: clientCtx.documentType || clientCtx.artifactType,
              section: clientCtx.sectionCode,
              module: clientCtx.module || clientCtx.moduleCode,
            }
          : undefined;

      orchestratorResult = orchestrate({
        message,
        conversationHistory,
        projectContext: orchestratorProjectContext,
        documentContext: orchestratorDocumentContext,
        userRole: clientCtx.userRole,
        authoringContext: project_id
          ? {
              projectId: String(project_id),
              sectionCode: clientCtx.sectionCode,
              moduleCode: clientCtx.module || clientCtx.moduleCode,
              artifactStatus: clientCtx.artifactStatus,
              _decisionContext: decisionContext,
            }
          : undefined,
      });

      console.log(
        `[AnA] Orchestrator: intent=${orchestratorResult.detectedIntent.lens}, ` +
          `submission=${orchestratorResult.detectedSubmissionType || 'none'}, ` +
          `deficiency=${orchestratorResult.orchestrationMeta.deficiencyContextInjected}`
      );

      // Use the orchestrator's enriched system prompt instead of the basic one
      const basePrompt = system_prompt || orchestratorResult.systemPrompt;

      // AnA fix F6: fetch intelligence prefix and persistent-memory context
      // in parallel — they're independent and were previously awaited
      // sequentially, costing ~100–200 ms per chat. AnA fix F10: log silent
      // intelligence-prefix failures instead of swallowing them.
      const [intelligencePrefix, memoryResult] = await Promise.all([
        getIntelligencePrefix(numericOrgId ?? undefined, project_id).catch(err => {
          console.warn(
            '[AnA] intelligence prefix load failed (continuing without):',
            err?.message
          );
          return '';
        }),
        buildMemoryContextForChat({
          threadId,
          organizationId: numericOrgId || undefined,
          projectId: project_id || undefined,
          query: message,
          limitPerLayer: 4,
          maxChars: 3500,
        }),
      ]);
      const { memoryBlock, atoms, diagnostics } = memoryResult;
      memoryAtomCount = atoms.length;
      memoryBlockChars = memoryBlock.length;
      memoryDiagnostics = diagnostics;

      // Session bootstrap — so a conversation never starts cold. At session
      // start rehydrate query-independently: the latest working summary, the
      // most important project/client atoms, AnA's own past lessons, and what
      // files the client has (none of which the query-driven assembler above
      // loads). The gate, the kill-switch and the failure path live in
      // sessionBootstrapBlockFor, because the streaming endpoint needs the same
      // three and a second copy is how the two paths came to differ.
      let sessionBootstrapBlock = '';
      {
        const { sessionBootstrapBlockFor } = await import(
          '../../services/ana-session-bootstrap.js'
        );
        const block = await sessionBootstrapBlockFor({
          priorMessageCount: previousMessages.length,
          organizationId: numericOrgId ?? null,
          userId: numericUserId,
          projectId: turnProjectId ?? undefined,
          projectRef: admittedProject.projectRef,
          threadId,
          atomLimit: 6,
        });
        if (block) sessionBootstrapBlock = `\n\n${block}\n`;
      }

      // ── Submission context (IND / NDA / BLA) ────────────────────────────────────
      // One block for both chat doors, built from the canonical lifecycle brief;
      // the helper owns the type mapping and fails closed for anything else.
      const { submissionContextBlockFor } = await import(
        '../../services/ana/submission-context-block.js'
      );
      const submissionContextBlock = submissionContextBlockFor({
        submissionType: typeof req.body.submission_type === 'string' ? req.body.submission_type : null,
        projectContext: clientCtx,
      });
      // Read by the device block below.
      const detectedType = (orchestratorResult.detectedSubmissionType || '').toUpperCase();
      const contextType = (req.body.context?.productType || '').toUpperCase();

      // ── Device Context Injection ────────────────────────────────────────────────
      // The registry renders the block. CER and IVDR are projections of the
      // canonical outlines (market-specs/cer-structure.ts CER_SECTIONS and
      // per-structure.ts PER_SECTIONS); the client's productType wins over the
      // type detected from the message.
      let deviceContextBlock = '';
      try {
        const { isDeviceSubmissionType, renderDeviceContextBlock } = await import(
          '../../services/device/device-section-registry.js'
        );
        const deviceType = isDeviceSubmissionType(contextType)
          ? contextType
          : isDeviceSubmissionType(detectedType)
            ? detectedType
            : null;
        if (deviceType) {
          const projectContext = req.body.context || {};
          deviceContextBlock = renderDeviceContextBlock(deviceType, {
            activeProject: typeof projectContext.activeProject === 'string' ? projectContext.activeProject : undefined,
          });
        }
      } catch {
        // Device registry not available
      }

      // Project instructions injection (spec A1.1) — read the project's
      // authored instructions + knowledge context and prepend to the system
      // context. Shared helper so this and submission-chat cannot drift; it is
      // tenant-scoped and graceful (empty string when absent or on error).
      const projectInstructionsBlock = await getProjectInstructionsBlock(
        project_id,
        numericOrgId
      );

      // A2 in-context mode (dark-launched behind INCONTEXT_INJECTION_ENABLED):
      // when the project runs in_context, inject the full project knowledge
      // corpus. Off by default → zero extra work and no behaviour change. The
      // mode itself is surfaced separately by GET /projects/:id/knowledge.
      let projectKnowledgeCorpusBlock = '';
      if (INCONTEXT_INJECTION_ENABLED && turnProjectId !== null && numericOrgId) {
        const pidNum = turnProjectId;
        {
          try {
            const modeState = await getProjectRetrievalMode(pidNum, numericOrgId);
            if (modeState.mode === 'in_context') {
              projectKnowledgeCorpusBlock = await assembleProjectKnowledgeCorpus(
                pidNum,
                numericOrgId
              );
            }
          } catch {
            /* non-fatal — fall back to retrieval-only */
          }
        }
      }

      // AnA fix F2: always prepend a CONTEXT SNAPSHOT block so AnA can see
      // exactly what context is loaded right now — including explicit
      // "NOT LOADED" / "NONE" markers when something is missing. The Context
      // Clarity Protocol in the persona forbids inferring what isn't here.
      const snapshotProductName = clientCtx.activeProject || clientCtx.productName;
      const snapshotSubmission = clientCtx.productType || clientCtx.submissionType;
      const snapshotArtifactTitle = clientCtx.artifactTitle;
      const snapshotSection = clientCtx.sectionCode;
      const snapshotUserRole = clientCtx.userRole || 'general';
      const workingMemoryPresent = atoms.some(a => a.layer === 'working_memory');
      const semanticMemoryCount = atoms.filter(a => a.layer !== 'working_memory').length;
      const contextSnapshot =
        '## CONTEXT SNAPSHOT\n' +
        `- Project: ${
          project_id
            ? `${snapshotProductName || 'unnamed'} (${snapshotSubmission || 'submission type unknown'})`
            : 'NOT LOADED'
        }\n` +
        `- Active artifact: ${
          snapshotArtifactTitle
            ? `${snapshotArtifactTitle}${snapshotSection ? ` — ${snapshotSection}` : ''}`
            : 'NONE'
        }\n` +
        `- Memory: working=${workingMemoryPresent ? 'yes' : 'no'}, semantic atoms=${semanticMemoryCount}\n` +
        `- Retrieved sources: ${retrievalStatus === 'unavailable' ? 'UNAVAILABLE (the knowledge-base search could not run)' : sources.length}\n` +
        `- User role: ${snapshotUserRole}\n\n`;

      const systemPrompt =
        contextSnapshot +
        intelligencePrefix +
        projectInstructionsBlock +
        basePrompt +
        submissionContextBlock +
        deviceContextBlock +
        projectKnowledgeCorpusBlock +
        sessionBootstrapBlock +
        memoryBlock +
        evidenceBlock;

      const gwMessages = [
        { role: 'system' as const, content: systemPrompt },
        ...previousMessages
          .filter((m: any) => m.role === 'user' || m.role === 'assistant')
          .map((m: any) => ({
            role: m.role as 'user' | 'assistant',
            content: m.content,
          })),
        { role: 'user' as const, content: message },
      ];

      console.log(`[AnA] Sending through AI Gateway (${sources.length} sources retrieved)...`);
      const routingPlan = planKernelExecution({
        route: '/api/chat',
        messageLength: message.length,
        intentLens: orchestratorResult.detectedIntent.lens,
        intentConfidence: orchestratorResult.detectedIntent.confidence,
        submissionType: orchestratorResult.detectedSubmissionType,
        hasEvidence: sources.length > 0,
        requestedMaxTokens: GENERATION_MAX_TOKENS,
        requestsGovernedDraft: requestsGovernedDraft(message),
      });
      const policyHint = await getKernelPolicyHint({
        organizationId: numericOrgId ?? null,
        route: '/api/chat',
        taskType: routingPlan.taskType,
      });
      const selectedStrategy = policyHint?.preferredStrategy || routingPlan.strategy;

      // Validate preferred_provider if provided
      const VALID_PROVIDERS = ['anthropic', 'openai', 'moonshot'] as const;
      const validatedChatProvider =
        preferred_provider && VALID_PROVIDERS.includes(preferred_provider)
          ? (preferred_provider as (typeof VALID_PROVIDERS)[number])
          : undefined;

      // Cost-tiered model selection — same policy and precedence as the
      // ana-ri paths: yields to an explicit provider preference and to a
      // governance-pinned strategy; opt-out via ANA_MODEL_TIERING=off; tier
      // remap via ANA_TIER_*_MODEL. No effort picker on this path, so it
      // resolves at the default Balanced effort. The pinned model rides the
      // whole agentic loop (the request carries it into every round).
      const chatTieredModel = (() => {
        if (validatedChatProvider) return null; // user pinned a provider
        if (policyHint?.preferredStrategy) return null; // governance owns the strategy
        if ((process.env.ANA_MODEL_TIERING ?? 'on').toLowerCase() === 'off') return null;
        const tier = resolveModelTier({
          effort: 'balanced',
          riskTier: routingPlan.riskTier,
          intentLens: orchestratorResult.detectedIntent?.lens,
          taskType: routingPlan.taskType,
          substantive: isSubstantiveTurn({
            messageLength: typeof message === 'string' ? message.length : 0,
            intentLens: orchestratorResult.detectedIntent?.lens,
          }),
        });
        const enabledModels =
          typeof gw.getModels === 'function' ? gw.getModels().filter((m) => m.enabled) : [];
        return resolveTierModel(tier, enabledModels, process.env);
      })();

      // ── Agentic tool-use loop: AnA can search, check compliance, generate docs ──
      /* The tenant's permitted tool surface, resolved once for the turn. */
      const governedTools = await governedToolsetFor(pool, numericOrgId);
      const baseRequest = {
        taskType: routingPlan.taskType,
        // The kernel's risk judgment; see GatewayRequest.riskTier.
        riskTier: routingPlan.riskTier,
        messages: gwMessages,
        temperature: routingPlan.temperature,
        maxTokens: routingPlan.maxTokens,
        callerModule: 'ana-ri-chat' as const,
        organizationId: numericOrgId ?? undefined,
        userId: numericUserId,
        strategy: selectedStrategy,
        // Offer the tools relevant to this turn's intent + context (the platform
        // command bridge is always included, so nothing is ever truly out of
        // reach), honouring any tools the user pinned in the tool picker.
        /* Tenant deny-list FIRST, then relevance. This call assembled the tool
           surface straight from getAllEnabledTools(), so a tool an organization
           had switched off in anaToolPolicy.deny was still offered here while
           the streaming endpoint honoured the setting — a governance control
           holding on one of two doors. */
        tools: selectToolsForTurn(governedTools, typeof message === 'string' ? message : '', {
          pinned: [
            ...(Array.isArray(selected_tools)
              ? selected_tools.filter((t: unknown): t is string => typeof t === 'string')
              : []),
            /* This route turns navigate_to / act_on_screen / start_product_demo
               results into offer-chips on the response (collectedNavigation
               and its siblings below), so the tools have to reach the model
               whatever the wording scores. They are not always-on in the
               selector — voice and deep investigations share it and can
               render no chip — so a caller that can offer a move pins them. */
            ...SELF_DRIVE_TOOLS,
          ],
          context: tool_context && typeof tool_context === 'object' ? tool_context : undefined,
        }),
        toolChoice: 'auto' as const,
        ...(validatedChatProvider ? { provider: validatedChatProvider } : {}),
        // Mutually exclusive with validatedChatProvider (the tier yields to it).
        ...(chatTieredModel
          ? { provider: chatTieredModel.provider, model: chatTieredModel.model }
          : {}),
        // A2: cache the (large, stable) in-context corpus prefix when injected.
        ...(projectKnowledgeCorpusBlock
          ? { promptCache: { enabled: true, type: 'ephemeral' as const } }
          : {}),
      };

      // Use agentic loop for multi-turn tool execution. This generic path has no
      // effort picker, so it runs at the default (Balanced) round ceiling — up
      // from the old flat 5 so a deeper investigation can run to completion.
      loopMessages = baseRequest.messages as Array<{ role: string; content: unknown }>;
      const gwResponse: AnaGatewayResponse = await executeAgenticLoop(baseRequest, {
        maxRounds: resolveMaxRounds('balanced'),
        toolContext: {
          organizationId: numericOrgId,
          userId: numericUserId || null,
          projectId: turnProjectId,
          // The project as the client sent it: a v2 program's UUID, which the
          // tools that resolve the open project read (PF-10 S7, as the stream).
          projectRef: project_id ? String(project_id).replace(/^proj_/, '') : null,
          // Tenant UUID so the project_knowledge_search tool can scope retrieval.
          organizationUuid: orgUuid,
          // Situational context (surface/project/document type) — same signal the
          // tool selector uses; threaded to handlers for telemetry + tailoring.
          surface: tool_context && typeof tool_context === 'object' ? ((tool_context as any).surface ?? null) : null,
          projectType: tool_context && typeof tool_context === 'object' ? ((tool_context as any).projectType ?? null) : null,
          documentType: tool_context && typeof tool_context === 'object' ? ((tool_context as any).documentType ?? null) : null,
        },
        onToolExecution: (toolName, input, result) => {
          loopCalls.onToolExecution(toolName, input, result);
          // A navigate_to that resolved against the governed registry becomes
          // an offer-chip in the response (same contract as the SSE path;
          // refusals yield null here and never become one).
          const directive = directiveFromToolResult(toolName, result);
          if (directive) collectedNavigation.push(directive);
          // An act_on_screen that resolved against the surface-action registry
          // becomes an offer-chip the same way (refusals yield null).
          const actionDirective = surfaceActionFromToolResult(toolName, result);
          if (actionDirective) collectedSurfaceActions.push(actionDirective);
          // A demonstration fetched without Live Drive becomes a start chip.
          const demoStart = demoStartFromToolResult(toolName, result);
          if (demoStart) collectedDemoStarts.push(demoStart);
          // A write the partition turned into a proposal: put it to the person.
          const proposal = pendingSignoffFromToolResult(toolName, result);
          if (proposal) loopProposals.push(proposal);
          // Persist the invocation for usage analytics. Latency is 0 here
          // because the agentic-loop hook fires post-success without a
          // start timestamp; the streaming path captures real latency.
          // Errors aren't surfaced through this hook either — see
          // AnaToolExecutor.executeAgenticLoop's catch branch.
          void logToolRun({
            threadId,
            projectId: turnProjectId,
            userId: numericUserId || null,
            organizationId: numericOrgId,
            toolName,
            arguments: (input ?? {}) as Record<string, unknown>,
            result: { resultBytes: result.length },
            status: 'success',
            latencyMs: 0,
          });
        },
      });

      assistantMessage =
        gwResponse.content ||
        'I apologize, but I was unable to generate a response. Please try again.';
      model = `${gwResponse.provider}/${gwResponse.model}`;
      provider = gwResponse.provider;
      servingModel = { provider: gwResponse.provider, model: gwResponse.model, requestId: gwResponse.requestId ?? null };
      usage = {
        prompt_tokens: gwResponse.usage.inputTokens,
        completion_tokens: gwResponse.usage.outputTokens,
        total_tokens: gwResponse.usage.totalTokens,
      };
      latencyMs = gwResponse.latencyMs;

      console.log(
        `[AnA] AI Gateway response via ${model} (${latencyMs}ms, req=${gwResponse.requestId})`
      );
      void logKernelDecision({
        requestId: gwResponse.requestId,
        threadId,
        route: '/api/chat',
        organizationId: numericOrgId ?? null,
        userId: numericUserId,
        projectId: turnProjectId,
        plannerVersion: routingPlan.plannerVersion,
        orchestratorName: routingPlan.orchestratorName,
        intentLens: orchestratorResult.detectedIntent.lens,
        intentConfidence: orchestratorResult.detectedIntent.confidence,
        submissionType: orchestratorResult.detectedSubmissionType || null,
        selectedTaskType: routingPlan.taskType,
        selectedProvider: gwResponse.provider,
        selectedModel: gwResponse.model,
        routingStrategy: selectedStrategy,
        selectedTools: [],
        constraints: {
          ...routingPlan.constraints,
          maxTokens: routingPlan.maxTokens,
          temperature: routingPlan.temperature,
          retrievedSources: sources.length,
        },
        decisionRationale: routingPlan.decisionRationale,
        estimatedCostUsd: gwResponse.usage?.estimatedCostUsd ?? null,
        latencyMs: gwResponse.latencyMs,
        outcome: 'success',
      });
    } catch (gwError: any) {
      console.error('[AnA] AI Gateway call failed:', gwError.message);
      void logKernelDecision({
        requestId: `chat-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
        threadId,
        route: '/api/chat',
        organizationId: numericOrgId ?? null,
        userId: numericUserId,
        projectId: turnProjectId,
        orchestratorName: 'kernel-router-v1',
        selectedTaskType: 'chat',
        routingStrategy: 'quality_optimized',
        selectedTools: [],
        decisionRationale: 'AnA chat failed during AI Gateway call.',
        outcome: 'failed',
        errorMessage: gwError?.message || 'AI Gateway call failed',
      });
      const turnRecord = await fileTurn('failed', undefined, gwError);
      return res.status(503).json({
        error: 'AI provider call failed',
        code: 'AI_PROVIDER_UNAVAILABLE',
        turnRecord,
      });
    }

    // ── STEP 6b: AnA's ana-action blocks, as proposals ────────────────
    // Each block AnA is confident in becomes a create_artifact PROPOSAL through
    // the command partition — never a write (P0-12 residual, 2026-10-01; until
    // then this created the artifact, and a review thread in the person's name,
    // unasked). The proposals are returned as `executedCommands`, the envelope
    // the sign-off prompt reads (extractPendingSignoffs); a person's yes goes to
    // POST /api/ana-ri/governed-action, which runs the command.
    let executedActions: Array<NavigationAction | SurfaceActionChip | DemoStartChip> = [];
    let actionBlockProposals: CommandResult[] = [];

    if (numericOrgId && numericUserId) {
      try {
        // The blocks are the platform's, not the answer: taken out when there
        // were any, and the answer says what became of each (settleActionBlocks).
        const settled = await settleActionBlocks(
          assistantMessage,
          {
            // The project resolved once for the turn (PF-10 S10b).
            projectId: turnProjectId,
            organizationId: numericOrgId,
            userId: numericUserId,
            userName: (req as any).user?.name || (req as any).user?.email || undefined,
            threadId,
            servingModel,
          },
          loopProposals,
        );
        actionBlockProposals = settled.proposals;
        assistantMessage = settled.answer;
      } catch (actionErr: any) {
        // Non-fatal — the answer returns as AnA wrote it, blocks included;
        // nothing was written.
        console.warn('[AnA RI] Action-block proposals failed:', actionErr?.message);
      }
    }
    const turnProposals: CommandResult[] = [...loopProposals, ...actionBlockProposals];

    // Navigation chips AFTER guidance actions — same ordering rationale as the
    // SSE path's post-processing: an artifact the turn actually created still
    // leads. Deduped + capped by toNavigationActions (first occurrence wins).
    if (collectedNavigation.length > 0) {
      executedActions = [...executedActions, ...toNavigationActions(collectedNavigation)];
    }

    // Surface-action chips under the identical offered-not-performed contract.
    if (collectedSurfaceActions.length > 0) {
      executedActions = [...executedActions, ...toSurfaceActionChips(collectedSurfaceActions)];
    }
    if (collectedDemoStarts.length > 0) {
      executedActions = [...executedActions, ...toDemoStartChips(collectedDemoStarts)];
    }

    // Save to legacy chat_messages for backward compat
    await saveMessage(threadId, 'user', message, model);
    await saveMessage(threadId, 'assistant', assistantMessage, model, usage.total_tokens);
    const turnRecord = await fileTurn('answered', { content: assistantMessage, model, provider });

    // ── STEP 7: PERSIST GENERATION RUN (provenance chain) ──────────────
    let generationRunId: string | null = null;
    if (numericOrgId) {
      try {
        const answerHash = sha256(assistantMessage);
        const genResult = await pool.query(
          `INSERT INTO ai_generation_runs
             (retrieval_run_id, thread_id, model, provider, answer_hash_sha256,
              prompt_tokens, completion_tokens, total_tokens, latency_ms, is_demo)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, false)
           RETURNING id`,
          [
            retrievalRunId,
            threadId,
            model,
            provider,
            answerHash,
            usage.prompt_tokens,
            usage.completion_tokens,
            usage.total_tokens,
            latencyMs,
          ]
        );
        generationRunId = genResult.rows[0].id;

        // Persist assistant ai_message with generation linkage
        await pool.query(
          `INSERT INTO ai_messages (thread_id, role, content, generation_run_id)
           VALUES ($1, 'assistant', $2, $3)`,
          [threadId, assistantMessage, generationRunId]
        );
      } catch (e: any) {
        if (e?.code !== '42P01') console.warn('[AnA] Generation persist failed:', e.message);
      }
    }

    // ── STEP 8: CLAIM SPLIT (paragraph-level) ─────────────────────────
    const claimTexts = assistantMessage
      .split(/\n\n+/)
      .map(c => c.trim())
      .filter(c => c.length > 0);

    interface ClaimResponse {
      claimId: string | null;
      claimIndex: number;
      claimText: string;
      status: 'SUPPORTED' | 'WEAK' | 'UNSUPPORTED';
      citations: Array<{ chunkId: string; sourceId: string; title: string; score: number }>;
      verifierFlags: VerifierFlag[];
    }
    const claims: ClaimResponse[] = [];

    // ── STEP 9: CITATION LINKAGE + VERIFIER (per-claim) ───────────────
    for (let ci = 0; ci < claimTexts.length; ci++) {
      const claimText = claimTexts[ci];
      const claimHash = sha256(claimText);

      // Find [SRC-n] refs in this specific claim
      const claimRefPattern = /\[SRC-(\d+)\]/g;
      const claimRefs = new Set<number>();
      let refMatch;
      while ((refMatch = claimRefPattern.exec(claimText)) !== null) {
        const idx = parseInt(refMatch[1], 10) - 1;
        if (idx >= 0 && idx < sources.length) claimRefs.add(idx);
      }

      // Initial status: SUPPORTED (≥1 citation), UNSUPPORTED (no citations)
      let status: 'SUPPORTED' | 'WEAK' | 'UNSUPPORTED' =
        claimRefs.size > 0 ? 'SUPPORTED' : 'UNSUPPORTED';

      let claimId: string | null = null;
      const citationLinks: ClaimResponse['citations'] = [];

      if (numericOrgId && generationRunId) {
        try {
          // Collect citation links first (needed for verifier)
          for (const refIdx of claimRefs) {
            const chunk = chunkRows[refIdx];
            if (chunk) {
              citationLinks.push({
                chunkId: chunk.id,
                sourceId: chunk.atomId,
                title: sources[refIdx]?.title || '',
                score: chunk.score,
              });
            }
          }

          // ── STEP 9b: VERIFIER v1 (deterministic) ────────────────────
          const citScores = citationLinks.map(c => c.score);
          const citSnippets = Array.from(claimRefs).map(idx => sources[idx]?.content || '');
          const { flags: verifierFlags, shouldDowngrade } = verifyClaim(
            claimText,
            citScores,
            citSnippets
          );

          // Downgrade SUPPORTED → WEAK if verifier flags it
          if (status === 'SUPPORTED' && shouldDowngrade) {
            status = 'WEAK';
          }

          // Persist claim with final status + verifier flags
          const claimResult = await pool.query(
            `INSERT INTO ai_claims
               (generation_run_id, claim_index, claim_text, claim_hash_sha256, confidence, status, verifier_flags)
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
            [
              generationRunId,
              ci,
              claimText,
              claimHash,
              claimRefs.size > 0 ? confidence : null,
              status,
              JSON.stringify(verifierFlags),
            ]
          );
          claimId = claimResult.rows[0].id;

          // AnA fix F9: persist all citation linkages in one multi-row INSERT
          // per claim (replaces a per-citation sequential loop).
          if (citationLinks.length > 0) {
            const valuesSql: string[] = [];
            const params: unknown[] = [];
            for (let li = 0; li < citationLinks.length; li++) {
              const o = li * 3;
              valuesSql.push(`($${o + 1}, $${o + 2}, $${o + 3})`);
              params.push(claimId, citationLinks[li].chunkId, citationLinks[li].score);
            }
            await pool.query(
              `INSERT INTO ai_claim_citations (claim_id, retrieval_chunk_id, relevance_score)
               VALUES ${valuesSql.join(', ')}`,
              params
            );
          }

          claims.push({
            claimId,
            claimIndex: ci,
            claimText,
            status,
            citations: citationLinks,
            verifierFlags,
          });
          continue; // skip fallback below
        } catch (e: any) {
          if (e?.code !== '42P01') console.warn('[AnA] Claim persist failed:', e.message);
        }
      }

      // Fallback: no org/generation — still run verifier for response
      const fallbackScores = citationLinks.map(c => c.score);
      const fallbackSnippets = Array.from(claimRefs).map(idx => sources[idx]?.content || '');
      const { flags: fallbackFlags, shouldDowngrade: fallbackDown } = verifyClaim(
        claimText,
        fallbackScores,
        fallbackSnippets
      );
      if (status === 'SUPPORTED' && fallbackDown) status = 'WEAK';

      claims.push({
        claimId,
        claimIndex: ci,
        claimText,
        status,
        citations: citationLinks,
        verifierFlags: fallbackFlags,
      });
    }

    // ── BUILD BACKWARD-COMPAT CITATIONS MAP ────────────────────────────
    const citedRefs = new Set<number>();
    const refPattern = /\[SRC-(\d+)\]/g;
    let match;
    while ((match = refPattern.exec(assistantMessage)) !== null) {
      const idx = parseInt(match[1], 10) - 1;
      if (idx >= 0 && idx < sources.length) citedRefs.add(idx);
    }

    const citations = sources.map((s, i) => ({
      id: `SRC-${i + 1}`,
      sourceAtomId: s.id,
      sourceType: 'atom' as const, // Rule 5: explicit source type
      title: s.title,
      snippet: s.content?.length > 500 ? s.content.substring(0, 500) + '…' : s.content,
      relevanceScore: s.score,
      cited: citedRefs.has(i),
    }));

    // Fix D: coverage metrics
    const supportedClaims = claims.filter(c => c.status === 'SUPPORTED').length;
    const citationCoverage = sources.length > 0 ? citedRefs.size / sources.length : 0;
    const supportedClaimRate = claims.length > 0 ? supportedClaims / claims.length : 0;
    void recordKernelPolicyOutcome({
      organizationId: numericOrgId ?? null,
      route: '/api/chat',
      taskType: 'chat',
      strategy: 'quality_optimized',
      threadId,
      modelProvider: provider || null,
      modelName: model || null,
      qualityScore: supportedClaimRate,
      latencyMs,
      estimatedCostUsd: null,
      success: true,
      metadata: {
        citationCoverage,
        sourcesRetrieved: sources.length,
        claims: claims.length,
      },
    });

    // ── RIM: Intercept for regulatory pattern capture (non-blocking) ──
    if (numericOrgId) {
      interceptChatResponse({
        organizationId: numericOrgId,
        projectId: turnProjectId ?? 0,
        userId: (req as any).user?.id,
        sectionCode: (req as any).body?.section_code,
        assistantMessage,
        claimCount: claims.length,
        supportedClaimRate,
        model,
        provider,
      });
    }

    // ── Cached reliability lookup (5-min TTL, surfaced in response) ─────
    let reliability: SignalReliability | null = null;
    if (numericOrgId && turnProjectId !== null) {
      const projectIdNum = turnProjectId;
      {
        try {
          reliability = await getCachedSignalReliability(projectIdNum, numericOrgId);
        } catch {
          // Non-blocking — chat completes without the reliability badge.
        }
      }
    }

    // ── Working-memory write-back (fire-and-forget) ────────────────────
    // Compress multi-turn history into structured working memory once the
    // conversation crosses WORKING_MEMORY_THRESHOLD messages. The helper
    // short-circuits when no refresh is needed so the summarizer only fires
    // every ~20 turns, not per-message.
    if (numericOrgId && threadId) {
      const writebackMessages = [
        ...previousMessages
          .filter((m: any) => m.role === 'user' || m.role === 'assistant')
          .map((m: any) => ({ role: m.role as string, content: m.content as string })),
        { role: 'user', content: message },
        { role: 'assistant', content: assistantMessage },
      ];
      void summarizeAndStoreWorkingMemoryForThread({
        threadId,
        organizationId: numericOrgId,
        messages: writebackMessages,
        projectId: turnProjectId,
      });
    }

    // ── Data Lineage: record retrieval→generation chain (non-blocking) ──
    if (numericOrgId && generationRunId && sources.length > 0) {
      try {
        const { recordLineageBatch } = await import('../../services/data-lineage-service');
        const entries = sources.filter((_s, i) => citedRefs.has(i)).map((s, _i) => ({
          organizationId: numericOrgId,
          projectId: turnProjectId ?? undefined,
          sourceObjectType: 'retrieval_chunk' as const,
          sourceObjectId: s.id || `src-${_i}`,
          sourceTitle: s.title,
          sourceContent: s.content?.substring(0, 500),
          targetObjectType: 'generation_run' as const,
          targetObjectId: String(generationRunId),
          targetField: threadId,
          linkageType: 'cited_by' as const,
          transformationType: 'ai_generation' as const,
          confidenceScore: (s.score ?? 0) * 100,
          confidenceBasis: 'ai_inferred' as const,
          aiModelUsed: model,
          retrievalRunId: retrievalRunId ? Number(retrievalRunId) : undefined,
          generationRunId: Number(generationRunId),
        }));
        if (entries.length > 0) {
          recordLineageBatch(entries).catch(err =>
            console.warn('[AnA] data lineage batch failed (non-blocking):', err?.message)
          );
        }
      } catch { /* non-blocking */ }
    }

    // ── RESPONSE (backward compat + provenance chain) ──────────────────
    res.json({
      answer: assistantMessage,
      response: assistantMessage,
      thread_id: threadId,
      usage,
      model,
      provider,
      sources,
      citations,
      confidence,
      retrievalMeta: {
        status: retrievalStatus,
        retrievedCount: sources.length,
        citedCount: citedRefs.size,
        orgScoped: !!orgUuid,
        citationCoverage,
        supportedClaimRate,
        memoryAtomCount,
        memoryBlockChars,
        memoryDiagnostics,
        reliability,
      },
      // Provenance chain
      retrievalRunId,
      snapshotHashSha256,
      generationRunId,
      claims,
      orchestration: {
        detectedIntent: orchestratorResult!.detectedIntent,
        detectedSubmissionType: orchestratorResult!.detectedSubmissionType,
        appliedRole: orchestratorResult!.appliedRole,
        activeWorkstream: orchestratorResult!.activeWorkstream,
        workstreamHandoff: orchestratorResult!.workstreamHandoff,
        suggestedActions: orchestratorResult!.suggestedActions,
        meta: orchestratorResult!.orchestrationMeta,
      },
      // Offer-chips (navigation, surface actions, demonstrations).
      executedActions: executedActions.length > 0 ? executedActions : undefined,
      // AnA's proposals awaiting a person's confirmation — the loop's and the
      // action blocks' — in the stream's post_done.executedCommands envelope.
      executedCommands: turnProposals.length > 0 ? turnProposals : undefined,
      turnRecord,
    });
  } catch (error: any) {
    if (error instanceof AnaProjectScopeError) return res.status(error.status).json({ error: error.message, code: error.code });
    console.error('[AnA] Chat error:', error);

    // Rule 6: no raw error.message leak
    res.status(500).json({
      error: 'Failed to process message',
      code: 'CHAT_ERROR',
    });
  }
};
