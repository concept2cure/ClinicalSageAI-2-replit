/**
 * server/routes/chat/upload.ts
 *
 * Governed file upload handler for chat.
 *
 * Handles POST /api/chat/upload. Stores file metadata in the `file_uploads` table
 * and, when a valid projectId + organizationId are present, also creates a
 * governed concept2cure_artifact (category='source') for unified Data Room access
 * and embeds the content into lumen_data_atoms for pgvector retrieval.
 *
 * Extracted from the legacy monolithic server/routes/chat.ts as part of the
 * Phase 4 chat-route decomposition. This module exports the handler only; the
 * Express Router wiring lives in the parent chat module.
 */

import {
  writeUploadRetrievalAtom,
  type UploadAtomResult,
} from '../../services/chat-uploads/upload-retrieval-atom.js';
import type { Request, Response } from 'express';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { pool } from '../../db.js';
import { resolveGovernedContext } from '../../services/concept2cure/governedDocumentContractService.js';
import { recordArtifactProvenance } from '../../services/provenance/artifact-provenance';
import { sha256, sha256Bytes } from './provenance.js';
import { createScopedLogger } from '../../utils/logger.js';
import { sha256Hex } from '../../services/ana/uploaded-file-access';
import { programInOrganization } from '../../services/c2c/program-access.js';
import { projectBelongsToTenant } from '../../services/cmc/project-membership.js';
import type { SourceProcessingResult } from '../../services/clinical-regulatory-evidence/data-room-processing.js';

const logger = createScopedLogger('chat-upload');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Resolve an incoming `projectId` into whichever project id-space it belongs to.
 *
 * The platform carries two, and an upload can arrive with either:
 *   - a `regulatory_programs` UUID — what the project management module
 *     (ProjectHome, /api/c2c/projects) selects and what the user actually has
 *     open;
 *   - a numeric workspace id, optionally `proj_`-prefixed — the legacy space.
 *
 * Treating every id as numeric is what made a UUID-scoped upload unusable: it
 * parsed to NaN, and the governed-artifact block rejected the request outright.
 */
function resolveProjectScope(
  projectId: unknown,
): { programId: string | null; workspaceId: number | null } {
  if (projectId == null || projectId === '') return { programId: null, workspaceId: null };
  const raw = String(projectId).trim();
  if (UUID_RE.test(raw)) return { programId: raw, workspaceId: null };
  const numeric = parseInt(raw.replace(/^proj_/, ''), 10);
  return Number.isFinite(numeric)
    ? { programId: null, workspaceId: numeric }
    : { programId: null, workspaceId: null };
}

/** The capture stands when its later derived processing is unavailable. */
async function processUploadCapture(orgId: number, sourceId: number,
  input: Parameters<typeof import('../../services/clinical-regulatory-evidence/data-room-processing.js').processCapturedSource>[2],
): Promise<Omit<SourceProcessingResult, 'extracted'>> {
  try {
    const { processCapturedSource } = await import('../../services/clinical-regulatory-evidence/data-room-processing.js');
    const done = await processCapturedSource(orgId, sourceId, input);
    return { ok: done.ok, processed: done.processed, status: done.status,
      ...(done.reasonCode ? { reasonCode: done.reasonCode } : {}) };
  } catch (err) {
    logger.warn('Captured upload processing unavailable', { sourceId, err: err instanceof Error ? err.message : String(err) });
    return { ok: false, processed: false, status: 'retryable_failure', reasonCode: 'PROCESSING_UNAVAILABLE' };
  }
}

export const uploadHandler = async (req: Request, res: Response) => {
  try {
    const fileBuffer: Buffer | undefined = (req as any).file?.buffer;

    // FAIL CLOSED ON MISSING BYTES.
    //
    // Every field below used to fall back to a request-body value and then to
    // a constant, so a request carrying no file still produced a
    // `file_uploads` row named 'uploaded_file' with file_size 0, a
    // storage_path nothing was written to, a `cre_evidence_sources` row
    // stamped ingestion_status='ingested', and a 200 {status:'ready'}. For the
    // whole time no multipart parser was mounted (see server/routes/chat.ts),
    // that was EVERY upload.
    //
    // Evidence with no bytes is not evidence. There is nothing to checksum,
    // nothing to extract, and nothing a later citation could be verified
    // against — so this refuses rather than recording a document that does not
    // exist. The body-only shape is gone with it: an upload endpoint that
    // accepts a filename and a size without a file has no honest use.
    if (!fileBuffer || fileBuffer.length === 0) {
      logger.warn('Upload rejected — no file bytes received', {
        hasFile: Boolean((req as any).file),
        contentType: req.headers['content-type'] ?? null,
      });
      return res.status(400).json({
        error: {
          code: 'NO_FILE_RECEIVED',
          message:
            'No file bytes were received. Send the file as multipart/form-data under the field name "file".',
        },
      });
    }

    const fileId = `file_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    const fileName = (req as any).file?.originalname || 'uploaded_file';
    const mimeType = (req as any).file?.mimetype || 'application/octet-stream';
    // Trust the buffer's own length over any declared size.
    const fileSize = fileBuffer.length;
    const projectId = req.body?.projectId || req.body?.project_id;
    const userId = (req as any).user?.id || null;
    const orgId = (req as any).tenantId || (req as any).tenantContext?.organizationId;

    // The bytes were verified before this handler ran: signature, name binding
    // and the content scan (fail-closed in production), by assertUploadSafe in
    // server/routes/chat.ts (assertEvidenceSafe). This handler kept its own
    // copy of the first and the last, and its scan failed OPEN.

    // Which project id-space this upload arrived with, resolved once and used
    // by the ownership check here, the governed-artifact block and the source
    // identity below.
    const projectScope = resolveProjectScope(projectId);

    // PROJECT FIRST (PF-02, LX-20). A Data Room file is anchored to a live
    // project of the uploader's organization, or it is not captured. The id
    // was checked for UUID shape only, so a file could be anchored to another
    // organization's project, or to one that does not exist or was deleted.
    // Refused before the bytes are stored or any row is written; 404, not 403,
    // so nothing is learned about another tenant's ids.
    if (projectScope.programId != null && !(await programInOrganization(pool, projectScope.programId, Number(orgId)))) {
      return res.status(404).json({ error: 'Project not found', code: 'PROJECT_NOT_FOUND' });
    }
    // The legacy numeric id-space holds to the same rule (PF-03): a projects
    // row of the uploader's organization. The number was taken as given, and
    // it keys the governed artifact row and the source identity below, so a
    // file could be filed under another organization's project. A lookup that
    // cannot complete throws to the outer catch: nothing is written.
    if (
      projectScope.workspaceId != null &&
      !(await projectBelongsToTenant({ organizationId: Number(orgId), projectId: String(projectScope.workspaceId) }, pool))
    ) {
      return res.status(404).json({ error: 'Project not found', code: 'PROJECT_NOT_FOUND' });
    }

    // SECURITY: tenant-scoped storage path. The legacy `uploads/${fileId}`
    // flat layout meant any process that read by file id alone could
    // retrieve another tenant's file — and the file id, while
    // timestamp-suffixed, is enumerable. By prefixing the org id we
    // ensure a foreign-tenant lookup hits a path the caller's org
    // doesn't own. `orgId` here is the JWT-derived value from
    // req.tenantId / req.tenantContext.organizationId (never body /
    // query). When no org is available we anchor under `unscoped/` so
    // those rows never collide with a real tenant's namespace.
    const orgSegment = orgId != null ? `org-${Number(orgId)}` : 'unscoped';
    const storagePath = `uploads/${orgSegment}/${fileId}`;

    // Store the original bytes before metadata, extraction or Data Room
    // capture. A failed write must not leave a record claiming usable evidence
    // at a dangling storage_path. Missing/empty buffers were refused above.
    try {
      const resolved = path.resolve(process.cwd(), storagePath);
      await fs.mkdir(path.dirname(resolved), { recursive: true });
      await fs.writeFile(resolved, fileBuffer);
    } catch (err) {
      logger.warn('Upload rejected — original bytes could not be stored', {
        fileId,
        reason: err instanceof Error ? err.message : 'unknown',
      });
      return res.status(503).json({
        error: 'The file could not be stored. Try again.',
        code: 'UPLOAD_STORAGE_FAILED',
      });
    }

    // Save metadata to DB.
    //
    // `organization_id` is written alongside the tenant-scoped storage path so
    // both halves of the tenancy contract agree (see
    // migrations/20260726_file_uploads_tenancy.sql). Omitting it — as this
    // INSERT previously did — made every `WHERE organization_id = $n` lookup in
    // the chat/stream paths match zero rows, silently dropping attachments.
    await pool.query(
      `INSERT INTO file_uploads (id, user_id, organization_id, original_name, mime_type, file_size, storage_path, checksum_sha256, status, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'uploaded', NOW())`,
      [
        fileId,
        userId,
        orgId != null ? Number(orgId) : null,
        fileName,
        mimeType,
        fileSize,
        storagePath,
        // SHA-256 of the bytes as received, so loadUploadedFile can later prove
        // the file on disk is still the one that was uploaded. Nothing recorded
        // a digest before this, which is why no stored document was verifiable
        // after the fact (GA ledger L25). Null only if this route ever runs
        // without a buffer — the checksum must describe real bytes or nothing.
        fileBuffer ? sha256Hex(fileBuffer) : null,
      ]
    );

    // ── Text extraction (runs for every upload with a buffer) ──
    // Extract real text once so: (a) the response can report it was read
    // (method + word count) regardless of project scope, and (b) the
    // project-scoped block below reuses it for the artifact + memory atom.
    // Falls back to a filename placeholder on failure.
    /* What the retrieval corpus ends up holding for this file, so the response
       can state it rather than leaving the caller to assume the whole document
       was indexed. Null when no atom path ran (no org, or no extracted text). */
    let atomBounds: UploadAtomResult | null = null;
    let extractionMethod: string | null = null;
    let extractionWords = 0;
    let extractedText = `[Uploaded via chat: ${fileName}] (${mimeType}, ${fileSize} bytes)`;
    // The one Data Room processing step reads the bytes for every capture path
    // (data-room-processing.ts); the upload reads them here, once.
    const { extractCapture, describeCapture } = await import(
      '../../services/clinical-regulatory-evidence/data-room-processing.js'
    );
    const extracted = fileBuffer && fileBuffer.length > 0 ? await extractCapture(fileBuffer, mimeType, fileName) : null;
    if (extracted?.text) {
      extractedText = extracted.text;
      extractionMethod = extracted.method;
      extractionWords = extracted.words;
      logger.info('Upload text extracted', { fileId, method: extracted.method, chars: extracted.text.length });
    } else if (extracted?.error) {
      logger.warn('Upload text extraction failed (non-fatal)', { err: extracted.error, fileId });
    }

    // ── Data Room convergence: create artifact + embed for retrieval ──
    //
    // `concept2cure_artifacts.project_id` is an INTEGER, so this block can only
    // run for the numeric id-space. A UUID-scoped upload skips it and still
    // gets its canonical source identity below — previously it was rejected
    // with a 400, which meant a file could not be uploaded at all while a
    // UUID-keyed program was open.
    let artifactId: string | null = null;
    if (projectId && orgId && projectScope.workspaceId != null) {
      const numericProjectId = projectScope.workspaceId;
      const numericOrgId = parseInt(String(orgId), 10);
      if (isNaN(numericOrgId)) {
        return res.status(400).json({
          error: 'projectId and organizationId must be valid for governed upload',
          code: 'GOVERNED_UPLOAD_CONTEXT_INVALID',
        });
      }

      const artId = `artifact_chat_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      const boundedContent = extractedText.substring(0, 100000);

      const governedResolution = resolveGovernedContext({
        req,
        projectId: numericProjectId,
        artifactId: null,
        documentType: 'source_document',
        generationMode: 'imported',
        lifecycleStatus: 'draft',
        originSurface: 'api_route',
        clientTrack: 'biotech',
        submissionProgram: 'general_ri',
        persona: 'regulatory',
        regulatorScope: 'fda',
        evidenceMode: 'mixed',
        documentClass: 'evidence_memo',
        readinessGate: 'internal_review',
        approvalPathType: 'single_reviewer',
        recommendationSource: 'report_engine',
        workspaceTarget: 'project',
        regulatorIntent: 'evidence_analysis',
        placementContainerId: String(numericProjectId),
        title: fileName,
        content: boundedContent,
        sourceRefs: [`upload:${fileId}`],
        provider: 'chat_upload',
        model: 'file_ingest',
        exportAllowed: false,
        eventType: 'artifact.created',
      });

      if (!governedResolution.validation.valid) {
        return res.status(400).json({
          error: 'Governed document contract validation failed',
          code: 'GOVERNED_CONTRACT_INVALID',
          details: {
            errors: governedResolution.validation.errors,
            warnings: governedResolution.validation.warnings,
            resolved: governedResolution.resolved,
          },
        });
      }

      try {
        const contentHash = sha256(boundedContent);
        const uploadIns = await pool.query<{ id: number }>(
          `INSERT INTO concept2cure_artifacts
             (organization_id, project_id, artifact_id, type, category, title, content, content_hash, version, metadata, created_by_id)
           VALUES ($1, $2, $3, 'source_document', 'source', $4, $5, $6, 1, $7, $8)
           RETURNING id`,
          [
            numericOrgId,
            numericProjectId,
            artId,
            fileName,
            boundedContent,
            contentHash,
            JSON.stringify({
              uploadSource: 'chat',
              fileId,
              mimeType,
              fileSize,
              harness: {
                clientTrack: governedResolution.contract.clientTrack,
                submissionProgram: governedResolution.contract.submissionProgram,
                persona: governedResolution.contract.persona,
                regulatorScope: governedResolution.contract.regulatorScope,
                documentClass: governedResolution.contract.documentClass,
                readinessGate: governedResolution.contract.readinessGate,
                workspaceTarget: governedResolution.contract.workspaceTarget,
                originSurface: governedResolution.contract.originSurface,
                recommendationSource: governedResolution.contract.recommendationSource,
                regulatorIntent: governedResolution.contract.regulatorIntent,
                gateChecks: governedResolution.contract.exportEligibility.gateChecks,
                blockingReasons: governedResolution.contract.exportEligibility.blockingReasons,
                readinessOutcome: governedResolution.contract.exportEligibility.readinessOutcome,
              },
            }),
            userId,
          ]
        );
        artifactId = artId;
        // Uniform provenance: an uploaded source document is a 'source_input'
        // event. Best-effort — inside the existing artifact-persist try, a
        // provenance hiccup must not fail the upload.
        try {
          await recordArtifactProvenance(pool, {
            artifactId: uploadIns.rows[0].id,
            organizationId: numericOrgId,
            eventType: 'source_input',
            eventAction: 'upload',
            actorId: typeof userId === 'number' ? userId : null,
            details: { uploadSource: 'chat', fileId, mimeType, fileSize },
            backendService: 'routes/chat/upload',
          });
        } catch { /* upload provenance is best-effort */ }
      } catch (artErr: any) {
        // Log the raw cause through the scoped logger (redacted by
        // SENSITIVE_KEYS) — never echo it back to the client.
        logger.error('Governed artifact persistence failed', {
          err: artErr?.message,
          fileId,
          orgId,
        });
        return res.status(500).json({
          error: 'Governed artifact persistence failed for upload',
          code: 'ARTIFACT_CONSEQUENCE_REQUIRED',
        });
      }

      // Retrieval atom, through the one writer both upload paths use. It bounds
      // the content and RECORDS the bound, so the row says whether it holds the
      // whole file or its opening — see upload-retrieval-atom.ts.
      //
      // Only real extracted content, as the program branch below already
      // required. This call was unconditional, so a file with no extractable
      // text (a scan, an image OCR could not read) was embedded as the
      // "[Uploaded via chat: …]" placeholder and retrieved as though it were a
      // passage of the document. With nothing read, nothing is embedded, and
      // atomBounds stays null — which the response reports as no atom path.
      if (extractionMethod) {
        atomBounds = await writeUploadRetrievalAtom(pool, {
          organizationId: numericOrgId,
          sourceId: artId,
          fileName,
          text: extractedText,
          tags: ['source', 'chat_upload'],
        });
      }
    }

    // ── Canonical source identity ──────────────────────────────────────────
    //
    // Every uploaded file resolves to ONE `cre_evidence_sources` row of type
    // `client_document`. This is the identity the Data Room, evidence linking
    // and dossier relationships hang off — without it an upload exists only as
    // a `file_uploads` row, a governed artifact and an embedding atom, none of
    // which can answer "which dossier sections use this file, and what changed
    // when it was replaced".
    //
    // Runs for a PROJECT-scoped upload only (PF-07; founder decision
    // 2026-09-26: every governed record belongs to a project). A file attached
    // in chat with no project open stays a conversation file — its bytes and
    // its file_uploads row — and becomes a Data Room source only when it is
    // adopted into a project. It used to become an org-wide source that no
    // project listed.
    //
    // Idempotent on the raw-byte checksum WITHIN the project (PF-07 / VR-10):
    // re-uploading the same document into the same project resolves its source;
    // the same bytes in another project are that project's own source. It used
    // to resolve across the whole organization, so a file dropped into project
    // B silently became project A's record.
    //
    // A project-scoped source that cannot be written fails the request with 503
    // (below): the bytes are stored, and the answer says the Data Room does not
    // hold them. It used to answer 200 "ready" with sourceId null.
    let sourceId: number | null = null;
    let processing: Omit<SourceProcessingResult, 'extracted'> | null = null;
    let sourceWriteFailed = false;
    const scopedToProject = projectScope.programId != null || projectScope.workspaceId != null;
    // The org must resolve to a real numeric id. `tenantContext.organizationId`
    // is not guaranteed numeric, and passing NaN through would write a garbage
    // owner onto the canonical identity — worse than having no identity.
    const numericOrgId = orgId != null ? Number(orgId) : NaN;
    if (scopedToProject && Number.isFinite(numericOrgId) && numericOrgId > 0) {
      try {
        // Checksum the raw bytes, not the truncated extracted text: file
        // identity is the document itself.
        //
        // There is deliberately NO fallback. It used to be
        // `sha256(extractedText)`, and extractedText on that branch was the
        // placeholder built from fileName/mimeType/fileSize — a formatted
        // metadata string, not content. With no multipart parser mounted those
        // three were constants, so the "checksum" was a platform-wide
        // constant: findSourceByChecksum matched the first upload every time,
        // and every subsequent upload in an org adopted that row's id. Four
        // different documents became one source called 'uploaded_file', and
        // any section citing it recorded whichever file happened to be
        // uploaded first.
        //
        // Content identity over anything but content is not identity. The
        // handler now refuses byte-less uploads outright, so this is
        // unconditional.
        const checksum = sha256Bytes(fileBuffer);
        const { createSource, createSupersedingSource, findSourceByChecksum, findSupersededCandidate } =
          await import('../../services/clinical-regulatory-evidence/evidence-spine.service.js');

        const existing = await findSourceByChecksum(numericOrgId, checksum, {
          sourceType: 'client_document',
          clientProgramId: projectScope.programId,
          clientWorkspaceId: projectScope.workspaceId,
        });
        if (existing) {
          sourceId = existing.id;
          logger.info('Upload resolved to an existing source identity', {
            fileId,
            sourceId,
            checksum,
          });
        } else {
          // The platform has two project id-spaces and an upload may arrive
          // with either: a `regulatory_programs` UUID (what the project
          // management module selects) or the numeric workspace id. Stamp
          // whichever we actually got rather than assuming one.
          const scope = projectScope;

          // ── Dossier classification (capture → classify) and declared version ──
          // The same deterministic classifier the Vault ingest runs, stamped
          // into the source's metadata so the Data Room can show WHAT this is
          // and WHERE it likely belongs the moment it lands. A proposal, never a
          // commitment: filing into the vault stays a governed act. The version
          // is only ever one the document DECLARES (ledger L21), never a count
          // of uploads. Both live in data-room-processing.ts, shared with adopt
          // and the spreadsheet edit.
          const { dossier, versionDetermination } = await describeCapture(numericOrgId, scope.programId ?? null, {
            fileName,
            mimeType,
            // The filename placeholder built when extraction fails is metadata,
            // not document text.
            text: extractionMethod ? extractedText : null,
          });
          // Is this a REVISION of a document this project already holds?
          //
          // A new checksum means new bytes, and until now that was the end of
          // it: the revision became an unrelated source row, and every citation
          // of the old one went on reporting "content unchanged since cited"
          // forever, because a source's checksum is never rewritten. Linking the
          // two is what makes a superseded citation visible at all.
          //
          // The lookup is deliberately narrow and declines to decide when two
          // documents in the project share a filename — see
          // findSupersededCandidate. It is also best-effort: on a database
          // without the versioning migration it throws, and "no predecessor
          // known" is the honest fallback rather than a failed upload.
          let supersedes: { id: number } | null = null;
          try {
            supersedes = await findSupersededCandidate(numericOrgId, {
              title: fileName,
              sourceType: 'client_document',
              programId: scope.programId,
              workspaceId: scope.workspaceId,
            });
          } catch (verErr: any) {
            logger.warn('Source version lookup unavailable — treating upload as a new document', {
              fileId,
              err: verErr?.message,
            });
          }

          // Typed against createSource's parameter so pulling the literal out of
          // the call keeps its string-union fields (sourceType, visibilityClass,
          // the two statuses) instead of widening them to string.
          const sourceParams: Parameters<typeof createSource>[1] = {
            sourceType: 'client_document',
            // A Data Room source belongs to its project (only project-scoped
            // uploads reach here).
            visibilityClass: 'project_private',
            clientProgramId: scope.programId,
            clientWorkspaceId: scope.workspaceId,
            title: fileName,
            // The stored blob these bytes live at; the governed artifact (when
            // one exists) is in metadata below.
            storedArtifactRef: storagePath,
            checksum,
            // Null unless the document actually declares one; the determination
            // travels in provenance either way.
            version: versionDetermination.version,
            // Capture is durable; derived text/facts are still pending until
            // the bound processor commits them on this source.
            ingestionStatus: 'ingested',
            extractionStatus: 'pending',
            provenance: {
              origin: 'chat_upload',
              fileUploadId: fileId,
              storagePath,
              extractionMethod,
              extractionWords,
              uploadedByUserId: userId,
              // How the version above was arrived at — including when it could
              // not be. Its ABSENCE on a row means no determination was ever
              // made, which is not the same fact as `declared: false`.
              versionDeclaration: {
                ...versionDetermination.declaration,
                determinedBy: 'chat_upload ingest',
              },
            },
            metadata: {
              originalName: fileName,
              mimeType,
              fileSize,
              artifactId,
              ...(dossier ? { dossier } : {}),
            },
          };

          // How the link was established travels WITH the record. A reviewer
          // asking "why does this say my source was superseded" gets the answer
          // from the row, not from this file.
          const created = supersedes
            ? (await createSupersedingSource(
                numericOrgId,
                {
                  ...sourceParams,
                  provenance: {
                    ...sourceParams.provenance,
                    supersedes: {
                      sourceId: supersedes.id,
                      matchedOn: 'title+projectScope+sourceType',
                      decidedBy: 'chat_upload ingest',
                    },
                  },
                },
                supersedes.id,
              )).source
            : await createSource(numericOrgId, sourceParams);
          sourceId = created.id;
          logger.info(
            supersedes
              ? 'Upload superseded an existing source identity'
              : 'Upload created a canonical source identity',
            { fileId, sourceId, supersededId: supersedes?.id ?? null },
          );
        }
      } catch (sourceErr: any) {
        sourceWriteFailed = true;
        logger.error('Canonical source identity not created for upload', {
          err: sourceErr?.message,
          fileId,
          orgId,
        });
      }
    }
    if (sourceWriteFailed) {
      return res.status(503).json({
        error: 'The file was stored, but it could not be recorded in the project’s Data Room. Try again.',
        code: 'SOURCE_NOT_RECORDED',
        fileId,
      });
    }
    // Both a new capture and a same-byte duplicate use the bound orchestration.
    // The processor verifies the recorded original upload; this new upload ID
    // never replaces an existing source's original provenance.
    if (scopedToProject && sourceId != null) {
      processing = await processUploadCapture(numericOrgId, sourceId, {
        bytes: fileBuffer, fileName, mimeType, programId: projectScope.programId,
        expectedWorkspaceId: projectScope.workspaceId, processedBy: 'chat_upload ingest',
        ...(extracted ? { preExtracted: extracted } : {}),
      });
    }

    // ── Retrieval embedding for program-scoped (UUID) uploads ──────────────
    //
    // The numeric-workspace path above embeds inside its governed-artifact
    // block, but that block is skipped for the UUID id-space because
    // concept2cure_artifacts.project_id is an INTEGER. The Data Room (ProjectHome)
    // opens a `regulatory_programs` UUID, so EVERY upload a real customer makes
    // there took the UUID path: it got a canonical source identity but its
    // extracted text was never embedded — read once, used for a word count, then
    // dropped from the retrieval corpus. That is the foundational gap behind the
    // whole "ingest the sponsor's source data and cite it back" premise: with no
    // atom + embedding, the content is not retrievable by RAG and cannot be cited
    // in authoring.
    //
    // Embed here so program uploads join the corpus too. lumen_data_atoms is
    // org-scoped (no project column) with `tags` for finer scoping, so the atom
    // carries a `program:<uuid>` tag for program-scoped retrieval and is keyed to
    // the canonical source id for idempotency (re-uploading the same file resolves
    // the same source, so the guarded insert is a no-op rather than a duplicate).
    if (
      projectScope.programId != null &&
      extractionMethod && // only real extracted content, never the filename placeholder
      extractedText.trim().length > 0 &&
      Number.isFinite(numericOrgId) &&
      numericOrgId > 0
    ) {
      atomBounds = await writeUploadRetrievalAtom(pool, {
        organizationId: numericOrgId,
        sourceId: sourceId != null ? `cre_source:${sourceId}` : `upload:${fileId}`,
        fileName,
        text: extractedText,
        tags: ['source', 'chat_upload', `program:${projectScope.programId}`],
      });
      if (atomBounds.atomId != null) {
        logger.info('Program-scoped upload embedded into retrieval corpus', {
          fileId,
          sourceId,
          atomId: atomBounds.atomId,
          programId: projectScope.programId,
          embeddedChars: atomBounds.embeddedChars,
          extractedChars: atomBounds.extractedChars,
          truncated: atomBounds.truncated,
        });
      }
    }

    res.json({
      fileId,
      message: 'File uploaded successfully',
      status: 'ready',
      fileName,
      artifactId,
      // Canonical `cre_evidence_sources` id for this document; null when no
      // project was open (a conversation file) or no org context.
      sourceId,
      // Whether the Data Room holds this file (PF-07). With no project open it
      // stays in the conversation until it is adopted into a project.
      dataRoom: scopedToProject && sourceId != null
        ? { recorded: true, readable: processing?.processed === true, processing }
        : {
            recorded: false,
            reason: scopedToProject
              ? 'The organization could not be resolved, so no Data Room source was recorded.'
              : 'No project was open, so this file stays in the conversation. Adopt it into a project to add it to that project’s Data Room.',
          },
      // Extraction summary for the chat UI: which method read the file and how
      // many words this extraction attempt read. Committed Data Room
      // readability is reported separately above.
      extractionMethod,
      extractionWords,
      /* What the retrieval corpus actually holds. An upload's atom is ONE
         embedding over a bounded prefix, so for anything longer than a few
         pages `indexedWholeFile` is false — and saying so here is the
         difference between "your file is searchable" and the truth, which is
         that its opening is. Filing it into the vault indexes all of it. */
      retrieval: atomBounds
        ? {
            embeddedChars: atomBounds.embeddedChars,
            extractedChars: atomBounds.extractedChars,
            indexedWholeFile: !atomBounds.truncated,
            embedded: atomBounds.embedded,
          }
        : null,
    });
  } catch (error: any) {
    logger.error('Upload error', { err: error?.message });
    res.status(500).json({
      error: 'Failed to upload file',
      code: 'UPLOAD_ERROR',
    });
  }
};
