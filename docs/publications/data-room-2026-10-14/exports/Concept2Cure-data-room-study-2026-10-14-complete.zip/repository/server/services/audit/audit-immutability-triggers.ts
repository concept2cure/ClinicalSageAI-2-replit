/**
 * Audit immutability trigger check.
 *
 * The audit stores are append-only because a database trigger refuses UPDATE,
 * DELETE (and, where declared, TRUNCATE) on them — not because the application
 * promises to behave. Those triggers are created by migrations in
 * `C2C_MIGRATION_FILES`, which `deploy-migrate` replays on every deploy, and
 * until this module nothing at boot or in the daily sweep asked whether they
 * were actually there (security audit 2026-09-24 finding DP-06, plan item
 * P0-9a). A database restored from a dump taken before the trigger migrations,
 * a fresh install booted before `deploy-migrate`, or an operator's
 * `ALTER TABLE … DISABLE TRIGGER` all left the stores writable while every
 * integrity surface reported green.
 *
 * `assertAuditImmutabilityTriggers` answers, with one read-only catalog probe,
 * whether every expected trigger exists on its table and is enabled. It
 * returns a report and never throws on a gap: the callers decide the posture —
 * `server/startup/audit-enforcement.ts` refuses a production boot,
 * `server/services/securityHealth.ts` reports it as a critical check, and
 * `server/jobs/auditChainIntegritySweep.ts` raises the tamper-evidence alert.
 *
 * Why pg_trigger and not information_schema.triggers: the standard view omits
 * TRUNCATE triggers and does not expose `tgenabled`, and both migrations'
 * own verification blocks read pg_trigger for the same reason.
 *
 * @compliance FDA 21 CFR Part 11 §11.10(e); EU Annex 11 §9.
 * @module server/services/audit/audit-immutability-triggers
 */

/** One trigger the deploy applier creates and this module requires. */
export interface ExpectedImmutabilityTrigger {
  schema: string;
  table: string;
  trigger: string;
  /** The migration in C2C_MIGRATION_FILES that creates it — the remedy. */
  source: string;
}

/**
 * The triggers, by store. `device_audit_trail` (same esign migration) is not
 * listed: no migration on the applier creates that table, so its trigger is
 * attached only where the table happens to exist and cannot be required.
 */
export const EXPECTED_AUDIT_IMMUTABILITY_TRIGGERS: readonly ExpectedImmutabilityTrigger[] = [
  { schema: 'public', table: 'audit_logs', trigger: 'trg_audit_logs_no_update', source: 'db/migrations/20260617_audit_logs_immutability.sql' },
  { schema: 'public', table: 'audit_logs', trigger: 'trg_audit_logs_no_delete', source: 'db/migrations/20260617_audit_logs_immutability.sql' },
  { schema: 'public', table: 'audit_logs', trigger: 'trg_audit_logs_no_truncate', source: 'db/migrations/20260617_audit_logs_immutability.sql' },
  { schema: 'public', table: 'audit_events', trigger: 'trg_audit_events_no_update', source: 'db/migrations/20260222_audit_events_immutability.sql' },
  { schema: 'public', table: 'audit_events', trigger: 'trg_audit_events_no_delete', source: 'db/migrations/20260222_audit_events_immutability.sql' },
  { schema: 'public', table: 'audit_events', trigger: 'trg_audit_events_no_truncate', source: 'db/migrations/20260222_audit_events_immutability.sql' },
  { schema: 'audit', table: 'tamper_proof_log', trigger: 'trg_prevent_audit_mutation', source: 'db/migrations/20260813_audit_tamper_proof_log.sql' },
  { schema: 'public', table: 'electronic_signatures', trigger: 'trg_electronic_signatures_immutable', source: 'db/migrations/20260730_esign_audit_db_level_immutability.sql' },
  { schema: 'public', table: 'ana_turn_records', trigger: 'trg_ana_turn_records_append_only', source: 'migrations/20260926_ana_turn_records.sql' },
  { schema: 'public', table: 'ana_turn_records', trigger: 'trg_ana_turn_records_no_truncate', source: 'migrations/20260926_ana_turn_records.sql' },
  { schema: 'public', table: 'ana_record_blobs', trigger: 'trg_ana_record_blobs_append_only', source: 'migrations/20260926_ana_turn_records.sql' },
  { schema: 'public', table: 'ana_record_blobs', trigger: 'trg_ana_record_blobs_no_truncate', source: 'migrations/20260926_ana_turn_records.sql' },
  // Exact-source host-budget admission metadata; tenant purge uses its fixed door.
  { schema: 'public', table: 'ana_source_read_receipts', trigger: 'trg_ana_source_read_receipts_append_only', source: 'migrations/20261014_ana_source_read_receipts.sql' },
  { schema: 'public', table: 'ana_source_read_receipts', trigger: 'trg_ana_source_read_receipts_no_truncate', source: 'migrations/20261014_ana_source_read_receipts.sql' },
  // The authoring records. These files are on the authoring subsystem applier
  // (scripts/db/authoring-subsystem.mjs AUTHORING_SUBSYSTEM_FILES), which
  // replays them on every deploy just as C2C_MIGRATION_FILES does.
  { schema: 'public', table: 'authoring_audit_trail', trigger: 'trg_authoring_audit_trail_append_only', source: 'db/migrations/20260725_authoring_audit_trail.sql' },
  { schema: 'public', table: 'authoring_audit_trail', trigger: 'trg_authoring_audit_trail_no_truncate', source: 'db/migrations/20260725_authoring_audit_trail.sql' },
  { schema: 'public', table: 'authoring_comments', trigger: 'trg_authoring_comments_content_fixed', source: 'db/migrations/20260730_authoring_comments_router_columns.sql' },
  { schema: 'public', table: 'doc_revisions', trigger: 'trg_doc_revisions_append_only', source: 'db/migrations/20260817_doc_revisions_immutable_ledger.sql' },
  { schema: 'public', table: 'doc_revisions', trigger: 'trg_doc_revisions_no_truncate', source: 'db/migrations/20260817_doc_revisions_immutable_ledger.sql' },
  // An artifact's approval and release signatures, and each lock's snapshot (2026-09-29, D5).
  { schema: 'public', table: 'concept2cure_signatures', trigger: 'trg_concept2cure_signatures_append_only', source: 'migrations/20260929_concept2cure_signatures_append_only.sql' },
  { schema: 'public', table: 'concept2cure_signatures', trigger: 'trg_concept2cure_signatures_no_truncate', source: 'migrations/20260929_concept2cure_signatures_append_only.sql' },
  { schema: 'public', table: 'concept2cure_submission_snapshots', trigger: 'trg_concept2cure_submission_snapshots_append_only', source: 'migrations/20260929_concept2cure_signatures_append_only.sql' },
  { schema: 'public', table: 'concept2cure_submission_snapshots', trigger: 'trg_concept2cure_submission_snapshots_no_truncate', source: 'migrations/20260929_concept2cure_signatures_append_only.sql' },
  // A review comment's words, author and place, fixed once posted; retraction once (2026-10-01, D5).
  { schema: 'public', table: 'concept2cure_thread_comments', trigger: 'trg_c2c_review_comment_record_guard', source: 'migrations/20261001_review_comments_record.sql' },
  { schema: 'public', table: 'concept2cure_thread_comments', trigger: 'trg_c2c_review_comment_no_truncate', source: 'migrations/20261001_review_comments_record.sql' },
  // A recorded Vault version's identity, hash and lineage (VR-06, 2026-09-26, D5).
  { schema: 'vault', table: 'documents', trigger: 'vault_documents_record_guard', source: 'migrations/20260926_vault_documents_record_immutability.sql' },
  { schema: 'vault', table: 'documents', trigger: 'vault_documents_truncate_guard', source: 'migrations/20260926_vault_documents_record_immutability.sql' },
  // ...and no DELETE but the tenant purge's owner-run function (VR-07, 2026-09-29, D5/D6).
  { schema: 'vault', table: 'documents', trigger: 'vault_documents_delete_guard', source: 'migrations/20260926_vault_documents_record_immutability.sql' },
  // The data room's capture record: checksum and lineage write-once, retirement
  // one-way, no TRUNCATE, DELETE only by the owner (VR-16, 2026-10-01, D2/D5).
  { schema: 'public', table: 'cre_evidence_sources', trigger: 'cre_evidence_sources_capture_guard', source: 'migrations/20261001_cre_evidence_sources_capture_immutability.sql' },
  { schema: 'public', table: 'cre_evidence_sources', trigger: 'cre_evidence_sources_truncate_guard', source: 'migrations/20261001_cre_evidence_sources_capture_immutability.sql' },
  { schema: 'public', table: 'cre_evidence_sources', trigger: 'cre_evidence_sources_delete_guard', source: 'migrations/20261001_cre_evidence_sources_capture_immutability.sql' },
  // The Module 3 signed section snapshots and provenance trail (DP-84, 2026-10-05, D2/D5).
  { schema: 'public', table: 'cmc_module3_section_versions', trigger: 'trg_cmc_module3_section_versions_append_only', source: 'migrations/20261005c_cmc_module3_history_append_only.sql' },
  { schema: 'public', table: 'cmc_module3_section_versions', trigger: 'trg_cmc_module3_section_versions_no_truncate', source: 'migrations/20261005c_cmc_module3_history_append_only.sql' },
  { schema: 'public', table: 'cmc_provenance_events', trigger: 'trg_cmc_provenance_events_append_only', source: 'migrations/20261005c_cmc_module3_history_append_only.sql' },
  { schema: 'public', table: 'cmc_provenance_events', trigger: 'trg_cmc_provenance_events_no_truncate', source: 'migrations/20261005c_cmc_module3_history_append_only.sql' },
];

/** Anything with a `.query` — a pg Pool, a PoolClient, a PGlite instance. */
export interface TriggerCatalogClient {
  query: (sql: string, params?: unknown[]) => Promise<{ rows: Record<string, unknown>[] }>;
}

export interface AuditImmutabilityTriggerReport {
  /** True only when every expected trigger is present AND enabled. */
  ok: boolean;
  /** Number of triggers required. */
  expected: number;
  /** Number found present and enabled. */
  present: number;
  /** `schema.table.trigger` of every expected trigger the catalog does not have (an absent table counts). */
  missing: string[];
  /** `schema.table.trigger` of every trigger that exists but will not fire (DISABLE TRIGGER, or replica-only). */
  disabled: string[];
  /** `schema.table` of every expected store that does not exist. */
  tablesAbsent: string[];
}

const qualifiedTrigger = (t: ExpectedImmutabilityTrigger) => `${t.schema}.${t.table}.${t.trigger}`;
const qualifiedTable = (t: { schema: string; table: string }) => `${t.schema}.${t.table}`;

/**
 * pg_trigger.tgenabled: 'O' fires in origin/local sessions (the default),
 * 'A' always fires, 'D' is disabled, 'R' fires only under
 * session_replication_role = replica. Only 'O' and 'A' protect the table in a
 * normal session.
 */
const FIRING_STATES = new Set(['O', 'A']);

/**
 * One read-only probe of the catalog for every expected trigger. Never throws
 * on a gap — the report carries it — but a failed probe (no connection, no
 * catalog privilege) propagates, because "could not check" is not "ok" and the
 * caller owns that decision.
 */
export async function assertAuditImmutabilityTriggers(
  client: TriggerCatalogClient,
  expected: readonly ExpectedImmutabilityTrigger[] = EXPECTED_AUDIT_IMMUTABILITY_TRIGGERS,
): Promise<AuditImmutabilityTriggerReport> {
  const values = expected
    .map((_, i) => `($${i * 3 + 1}::text, $${i * 3 + 2}::text, $${i * 3 + 3}::text)`)
    .join(', ');
  const params = expected.flatMap((t) => [t.schema, t.table, t.trigger]);

  const { rows } = await client.query(
    `WITH expected(schema_name, table_name, trigger_name) AS (VALUES ${values})
     SELECT e.schema_name, e.table_name, e.trigger_name,
            (c.oid IS NOT NULL) AS table_present,
            (t.oid IS NOT NULL) AS trigger_present,
            t.tgenabled::text   AS tgenabled
       FROM expected e
       LEFT JOIN pg_namespace n ON n.nspname::text = e.schema_name
       LEFT JOIN pg_class c ON c.relnamespace = n.oid
                           AND c.relname::text = e.table_name
                           AND c.relkind IN ('r', 'p')
       LEFT JOIN pg_trigger t ON t.tgrelid = c.oid
                             AND t.tgname::text = e.trigger_name
                             AND NOT t.tgisinternal`,
    params,
  );

  const byName = new Map<string, Record<string, unknown>>();
  for (const r of rows) {
    byName.set(`${r.schema_name}.${r.table_name}.${r.trigger_name}`, r);
  }

  const missing: string[] = [];
  const disabled: string[] = [];
  const tablesAbsent = new Set<string>();
  let present = 0;

  for (const t of expected) {
    const name = qualifiedTrigger(t);
    const row = byName.get(name);
    if (row && row.table_present === false) tablesAbsent.add(qualifiedTable(t));
    // A row that never came back is not a pass: the expected list decides what
    // was checked, not the result set.
    if (!row || row.trigger_present !== true) {
      missing.push(name);
      continue;
    }
    if (!FIRING_STATES.has(String(row.tgenabled ?? ''))) {
      disabled.push(name);
      continue;
    }
    present++;
  }

  return {
    ok: missing.length === 0 && disabled.length === 0,
    expected: expected.length,
    present,
    missing,
    disabled,
    tablesAbsent: [...tablesAbsent],
  };
}

/** The gap in one sentence, with the remedy: which migration creates what is missing. */
export function describeAuditImmutabilityGap(
  report: AuditImmutabilityTriggerReport,
  expected: readonly ExpectedImmutabilityTrigger[] = EXPECTED_AUDIT_IMMUTABILITY_TRIGGERS,
): string {
  const affected = new Set([...report.missing, ...report.disabled]);
  const sources = [...new Set(expected.filter((t) => affected.has(qualifiedTrigger(t))).map((t) => t.source))];
  const parts = [
    `audit immutability triggers are not in force (${report.present}/${report.expected} present and enabled)`,
  ];
  if (report.missing.length) parts.push(`missing: ${report.missing.join(', ')}`);
  if (report.disabled.length) parts.push(`disabled: ${report.disabled.join(', ')}`);
  if (report.tablesAbsent.length) parts.push(`tables absent: ${report.tablesAbsent.join(', ')}`);
  parts.push(
    'without them the audit stores accept UPDATE/DELETE and 21 CFR Part 11 §11.10(e) is not met',
  );
  if (report.missing.length || report.tablesAbsent.length) {
    parts.push(
      `run node scripts/db/deploy-migrate.mjs as the database owner — the triggers are created by ${sources.join(', ')} (every file in C2C_MIGRATION_FILES replays on each deploy)`,
    );
  }
  if (report.disabled.length) {
    parts.push(
      'a disabled trigger was switched off with ALTER TABLE … DISABLE TRIGGER: re-enable it and treat the interval as a potential integrity incident',
    );
  }
  return parts.join('; ') + '.';
}
