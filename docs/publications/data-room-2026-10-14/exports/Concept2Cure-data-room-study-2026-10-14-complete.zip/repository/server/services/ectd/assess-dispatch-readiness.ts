/**
 * Server-side dispatch-readiness assessor (the tamper-proof gate inputs).
 *
 * Binds the pure validators to the canonical core: it loads a sequence's
 * tenant-scoped leaves, computes the structural error count with
 * `computeDispatchReadiness`, counts OPEN CRITICAL Shadow Review findings for the
 * sequence from the database, and runs `evaluateDispatchGate` over both. Every
 * input to the hard gate is therefore computed from server state — a client can
 * no longer pass `validationErrors: 0` to talk the gate out of a blocker.
 *
 * Required-section context: for an original sequence of an application kind
 * the regional Module 1 record models, the record's requirement — a missing
 * section is an error; for a continuing US IND, NDA, BLA or ANDA sequence, its
 * 1.1 application form, as an error; otherwise the region profile's list, as
 * non-blocking warnings (readinessOptionsForSequence).
 *
 * Module 3 of an original US IND is asked separately, because the Module 1
 * record does not model it: its required headings come from the IND profile
 * (required-sections.requiredSectionProfileFor), and a heading with no leaf
 * and no cross-reference covered by a Letter of Authorization blocks
 * (IND_MODULE3_REQUIRED; see originalModule3Requirement).
 *
 * Tenant-scoped + DB-bound. Running it needs a database.
 *
 * @module server/services/ectd/assess-dispatch-readiness
 */

import { ruleView, DISPATCH_GATE_RULE_IDS, type RuleView } from './validation-rule-corpus';
import { and, eq, isNull, lt, sql } from 'drizzle-orm';
import { db } from '../../db';
import { submissionLeaves, ectdSequences, submissions } from '../../../shared/schema/submissions';
import { shadowReviewFindings, shadowReviewRuns } from '../../../shared/schema/shadow-review';
import { indCrossReferences } from '../../../shared/schema/ind-cross-references';
import {
  getSubmissionRegionProfile,
  requiredModule1CodesForRegion,
  regulationRequiredModule1,
} from '../region-profiles/region-profile-service';
import { moduleOfSectionKey, requiredSectionProfileFor } from './required-sections';
import { ichHeadingTitle } from '../ind/ctd/ich-m4-headings';
import {
  computeDispatchReadiness,
  type ComputeReadinessOptions,
  type DispatchReadinessReport,
  type Module3CrossReference,
  type OriginalModule3Requirement,
  type ReadinessFinding,
} from './dispatch-readiness';
import { resolveLeafDocuments } from './leaf-document-resolver';
import {
  evaluateDispatchGate,
  evaluateReleaseApprovalGate,
  mergeDispatchGates,
  evaluateReleaseSignatureGate,
  type DispatchGateResult,
  type ReleaseSignatureGateInput,
  type ReleaseSignatureVerdict,
} from './dispatch-gate';
import {
  resolveReleaseSignatureStatus,
  isReleaseSignatureRequired,
  signingNowResolvesRelease,
  type ReleaseSignatureStatus,
} from './release-signature-status';
import {
  resolveExternalValidator,
  evaluateExternalValidationGate,
  evalidatorRequiredFromEnv,
  type ExternalValidationReport,
  type ExternalValidationGateResult,
  type ExternalValidator,
  type ExternalValidatorKind,
} from './external-validator';

export interface AssessDispatchReadinessParams {
  sequenceId: number;
  organizationId: number;
  /**
   * An already-run external (agency-grade) validation report for this sequence,
   * if the caller materialized + validated the unzipped package. This DB-bound
   * assessor cannot run the validator itself (no package dir), so when absent the
   * fail-closed rule applies under ECTD_REQUIRE_EVALIDATOR in production.
   */
  externalValidationReport?: ExternalValidationReport | null;
  /**
   * ISO date (YYYY-MM-DD) the sequence is judged as at. Defaults to today
   * (UTC) — dispatch files the sequence now, so a date-effective acceptance
   * rule (JP_ECTD_V4_REQUIRED) is judged against the filing day. Tests and
   * replays pass it explicitly.
   */
  asOf?: string;
}

/** Today's date (UTC, YYYY-MM-DD) — the filing day a dispatch assessment is judged as at. */
export function dispatchAsOfDate(now: Date = new Date()): string {
  return now.toISOString().slice(0, 10);
}

/**
 * The Module 1 heading (1.1 Forms) every US submission's application form is
 * filed under, and the form a continuing sequence of each kind carries: a
 * Form FDA 1571 for an IND (21 CFR 312), a Form FDA 356h for an NDA, BLA or
 * ANDA (21 CFR 314 and 601). An original is held to its kind's whole list,
 * which includes 1.1, so this is read for continuing sequences only.
 */
const US_APPLICATION_FORM_SECTION = '1.1';
const US_CONTINUING_FORM: Readonly<Record<string, string>> = Object.freeze({
  ind: 'Every IND submission carries a Form FDA 1571 (21 CFR 312)',
  nda: 'Every submission to an NDA carries a Form FDA 356h (21 CFR 314)',
  bla: 'Every submission to a BLA carries a Form FDA 356h (21 CFR 601)',
  anda: 'Every submission to an ANDA carries a Form FDA 356h (21 CFR 314)',
});

/**
 * The validator options for one stored sequence. The region and as-of date go
 * through so a date-effective, region-scoped acceptance rule can be judged;
 * until 2026-10-05 (g-jp-ectd-v4-dispatch-blocker) neither did, and a new
 * Japanese application in eCTD v3.2.2 read dispatch-clear after PMDA stopped
 * receiving that format for new applications.
 *
 * Required sections, decided per sequence (QA 2026-10-08, j7):
 *   - an ORIGINAL sequence is the application itself, so for an application
 *     kind the regional Module 1 record models (US ind/nda/bla/anda, EU maa,
 *     JP jnda) every heading the record requires of that kind must carry a
 *     leaf, and a missing one is an error (`requiredByRegulation`);
 *   - a CONTINUING sequence of a modelled kind is not held to the
 *     application's requirements: an IND amendment does not re-file the
 *     Investigator's Brochure or the general investigational plan, and the
 *     record makes no per-sequence claim, so nothing is reported as missing
 *     (it used to say "Required section 1.20 has no leaf" of every amendment);
 *   - except its application form: every IND submission carries a Form FDA
 *     1571 (21 CFR 312; P-20 follow-up), and every submission to an NDA, BLA
 *     or ANDA a Form FDA 356h ("Form 356h" follow-up decision; both in
 *     docs/LAUNCH_DEFINITION_OF_DONE.md), so a continuing US sequence of those
 *     kinds is held to the 1.1 form, as an error, and to nothing else.
 *     d155ef099 exempted continuing sequences from every requirement, which let
 *     an amendment or supplement with no form clear the structural gate;
 *   - an unmodelled region or kind keeps the region profile's list as
 *     informative warnings, as before.
 */
export function readinessOptionsForSequence(
  sequence: { region: string; type: string | null; sequenceNumber: string },
  applicationType: string | null,
  asOf: string,
): ComputeReadinessOptions {
  // An original is type 'original' or sequence number '0000'.
  const isOriginalSequence = sequence.type === 'original' || sequence.sequenceNumber === '0000';
  const regulated = regulationRequiredModule1(sequence.region, applicationType);
  const sections: Pick<ComputeReadinessOptions, 'requiredSections' | 'requiredByRegulation'> = !regulated
    ? { requiredSections: requiredModule1Codes(sequence.region, applicationType) }
    : isOriginalSequence
      ? {
          requiredByRegulation: {
            codes: regulated.codes,
            basis:
              `The regional Module 1 record (${regulated.jurisdiction}) requires it in an original ` +
              `${regulated.kind.toUpperCase()} application, so this sequence cannot be validated, frozen or dispatched without it.`,
          },
        }
      : regulated.jurisdiction === 'US' && US_CONTINUING_FORM[regulated.kind]
        ? {
            requiredByRegulation: {
              codes: [US_APPLICATION_FORM_SECTION],
              basis:
                `${US_CONTINUING_FORM[regulated.kind]}, filed under 1.1 (Forms), so this ` +
                'sequence cannot be validated, frozen or dispatched without it.',
            },
          }
        : {};
  return {
    ...sections,
    isOriginalSequence,
    sequenceNumber: sequence.sequenceNumber,
    region: sequence.region,
    asOf,
  };
}

/** A composed dispatch gate, keyed as composeDispatchGates takes it. */
export type DispatchGateKey = keyof typeof DISPATCH_GATE_RULE_IDS;

/** One part of the dispatch verdict, as the corpus rule it enforces. */
export interface DispatchGateView {
  key: DispatchGateKey;
  rule: RuleView | null;
  cleared: boolean;
  blockers: string[];
  /** Set when the gate adds no blocker although no external assessment qualified and
   *  is not required on this installation — the external validator with
   *  ECTD_REQUIRE_EVALIDATOR off. Cleared is still true (it does not block);
   *  this says the check was not made, so no surface reads it as passed. */
  notAssessed?: string;
  /** Actual external assessment, separately from the gate's enforcement policy. */
  assessmentStatus?: ExternalValidationGateResult['assessmentStatus'];
  assessmentNote?: string;
}

/** composeDispatchGates' merge order — the gate views follow it, so the list
 *  reads exactly as the verdict it explains. */
const GATE_ORDER: DispatchGateKey[] = ['structural', 'external', 'shadowPresence', 'releaseSignature'];

/**
 * The dispatch verdict, gate by gate. Every gate the verdict composes appears,
 * named by its corpus rule and carrying its OWN blockers, so a blocker is read
 * as the rule it enforces — not as prose under a pass/fail icon — and the
 * gates' blockers, in order, are exactly the verdict's.
 */
export function dispatchGateViews(
  gates: Record<DispatchGateKey, DispatchGateResult>,
  notAssessed: Partial<Record<DispatchGateKey, string>> = {},
  externalAssessment?: Pick<DispatchGateView, 'assessmentStatus' | 'assessmentNote'>,
): DispatchGateView[] {
  return GATE_ORDER.map((key) => ({
    key,
    rule: ruleView(DISPATCH_GATE_RULE_IDS[key]),
    cleared: gates[key].cleared,
    blockers: [...gates[key].blockers],
    ...(gates[key].cleared && notAssessed[key] ? { notAssessed: notAssessed[key] } : {}),
    ...(key === 'external' && externalAssessment ? externalAssessment : {}),
  }));
}

/** Why the external gate cleared without a qualifying assessment. The dispatch
 *  screen printed "The agency-grade validator's report for this package
 *  carries no errors — Satisfied." over a sequence no validator had run on
 *  (populated-org sweep, 2026-09-28): advisory is not passed. */
export function externalNotAssessed(ext: {
  ran: boolean;
  configured: boolean;
  qualifyingRun?: boolean;
  validatorKind?: ExternalValidatorKind;
  assessmentStatus?: ExternalValidationGateResult['assessmentStatus'];
}): string | undefined {
  if (ext.assessmentStatus === 'failed' || ext.assessmentStatus === 'invalid') return undefined;
  if (ext.qualifyingRun ?? ext.ran) return undefined;
  if (ext.validatorKind === 'internal_subset') {
    return 'The selected adapter is the internal FDA criteria subset; it does not establish an external-engine assessment. External validation is advisory here, so this gate does not block dispatch.';
  }
  return ext.configured
    ? 'The agency-grade validator is configured but did not run for this package, so no report exists. It is not required on this installation, so it does not block dispatch — but the package has not been checked against it.'
    : 'No agency-grade validator is configured on this installation, so no report exists for this package. It is not required here, so it does not block dispatch — but the package has not been checked against it.';
}

/** Bind the DB assessor's supplied report to server-selected configuration.
 * This inspects a report; it does not run or qualify a vendor engine. */
export async function assessExternalValidationReport(
  validator: ExternalValidator,
  report: ExternalValidationReport | null,
  requireEvalidator: boolean,
  environment: 'staging' | 'production',
): Promise<ExternalValidationGateResult & { assessmentNote: string }> {
  const result = evaluateExternalValidationGate({
    report,
    selectedValidator: { name: validator.name, kind: validator.kind },
    configured: await validator.isConfigured(),
    requireEvalidator,
    environment,
  });
  return { ...result, assessmentNote: externalAssessmentNote(result, report) };
}

function externalAssessmentNote(result: ExternalValidationGateResult, report: ExternalValidationReport | null): string {
  const policy = result.enforced
    ? 'External validation is required for production dispatch.'
    : 'External validation is advisory here, so this gate does not block dispatch.';
  const selected = result.selectedValidatorName ?? 'none';
  switch (result.assessmentStatus) {
    case 'passed':
      return `The selected external validator "${selected}" returned a coherent, matching report with no error-severity findings. ${policy} Engine/profile qualification and binding to exact package bytes are separate controls.`;
    case 'failed':
      return `The selected external validator "${selected}" reported ${result.externalErrorCount} error-severity finding(s). ${policy}`;
    case 'invalid':
      return `The supplied external validation report is malformed or does not match the selected engine (selected="${selected}", reported="${result.reportedValidatorName ?? 'none'}"). Its counts do not establish a clean external assessment. ${policy}`;
    case 'not_assessed': {
      const scope = result.validatorKind === 'internal_subset'
        ? `The selected adapter is the internal FDA criteria subset. The supplied report declares ${result.ran ? 'execution' : 'no execution'} from "${result.reportedValidatorName ?? 'none'}"; it does not establish an external-engine assessment.`
        : result.configured ? 'The configured external validator did not supply a qualifying execution.' : 'No configured external-engine assessment is established.';
      const diagnostics = unrunExternalDiagnostics(report);
      return `${scope} ${policy}${diagnostics ? ` Execution diagnostic: ${diagnostics}` : ''}`;
    }
  }
}

function unrunExternalDiagnostics(report: ExternalValidationReport | null): string {
  if (report?.ran !== false || !Array.isArray(report.findings)) return '';
  return report.findings.filter((f) => f && typeof f === 'object' && typeof f.message === 'string').map((f) => f.message).join(' ');
}

function externalValidationView(result: ExternalValidationGateResult & { assessmentNote: string }): DispatchReadinessAssessment['externalValidation'] {
  return {
    configured: result.configured, ran: result.ran, errorCount: result.externalErrorCount,
    errorCountKnown: result.errorCountKnown, cleared: result.cleared, blockers: result.blockers,
    validatorKind: result.validatorKind, selectedValidatorName: result.selectedValidatorName,
    reportedValidatorName: result.reportedValidatorName, qualifyingRun: result.qualifyingRun,
    assessmentStatus: result.assessmentStatus, assessmentNote: result.assessmentNote, enforced: result.enforced,
  };
}

/** Each finding with the corpus rule it is an instance of (null when the corpus names none). */
export function withRules<F extends ReadinessFinding>(findings: F[]): Array<F & { rule: RuleView | null }> {
  return findings.map((f) => ({ ...f, rule: ruleView(f.code) }));
}

/**
 * Whether a sequence recorded as Validated still is, by the validation the
 * assessment just ran. Null for any other status.
 *
 * QA 2026-10-08 (j7, finding 20): sequence 0000 showed the stored stage
 * VALIDATED beside a dispatch-blocked gate. Since 0e50993c5, Validated is
 * reached only through a validation with no error, recorded as
 * validation_status 'passed', and a leaf change returns the sequence to
 * Assembling. A stage stored before that (no verdict), or one whose validation
 * now finds an error a leaf write did not cause (a document emptied in place, a
 * requirement decided since), is the stored label and nothing more: every
 * surface says so from this one answer rather than deriving its own.
 */
export type ValidatedStage =
  | { holds: true; verdictRecorded: boolean }
  | { holds: false; verdictRecorded: boolean; errors: number; reason: string };

/** Pure: the Validated-stage verdict from the stored row and the current error count. */
export function validatedStageOf(
  sequence: { status: string; validationStatus: string | null; sequenceNumber: string },
  errors: number,
): ValidatedStage | null {
  if (sequence.status !== 'validated') return null;
  const verdictRecorded = sequence.validationStatus === 'passed';
  if (Number.isFinite(errors) && errors === 0) return { holds: true, verdictRecorded };
  const n = Number.isFinite(errors) ? errors : NaN;
  const count = Number.isNaN(n) ? 'an undetermined number of errors' : `${n} ${n === 1 ? 'error' : 'errors'}`;
  return {
    holds: false,
    verdictRecorded,
    errors: n,
    reason:
      `Sequence ${sequence.sequenceNumber} is recorded as Validated, but its validation now finds ${count}` +
      `${verdictRecorded ? '' : ', and no validation verdict was recorded when it was marked'}. ` +
      'Validated means the validation found no error: return it to Assembling, resolve the errors and validate again. Freeze refuses it until then.',
  };
}

export interface DispatchReadinessAssessment {
  sequenceId: number;
  region: string;
  sequenceStatus: string;
  /** For a sequence recorded as Validated, whether that still holds; null otherwise. */
  validatedStage: ValidatedStage | null;
  /** Authoritative, server-computed gate inputs. */
  validationErrors: number;
  unacknowledgedShadowCriticals: number;
  /** Completed Shadow Review runs for this sequence. */
  shadowReviewRunCount: number;
  /** Gate clear but no Shadow Review has run — dispatch allowed, never reviewed. */
  shadowReviewMissing: boolean;
  /** External agency-grade (eValidator) gate contribution (P0-4). */
  externalValidation: {
    /** A selected external-engine path is configured; licence/qualification are separate. */
    configured: boolean;
    /** The supplied report declares execution, including internal subsets. */
    ran: boolean;
    /** Reported error tally, including subset diagnostics; consult errorCountKnown/status. */
    errorCount: number;
    /** Whether errorCount is a coherent executed tally rather than a numeric placeholder. */
    errorCountKnown?: boolean;
    /** This gate adds no blocker. */
    cleared: boolean;
    blockers: string[];
    validatorKind?: ExternalValidatorKind;
    selectedValidatorName?: string | null;
    reportedValidatorName?: string | null;
    qualifyingRun?: boolean;
    assessmentStatus?: ExternalValidationGateResult['assessmentStatus'];
    assessmentNote?: string;
    enforced?: boolean;
  };
  /** Release-signature state (21 CFR Part 11 §11.70, §6c). */
  releaseSignature: {
    /** This submission type crosses the §11.70 boundary and must be signed. */
    required: boolean;
    /** Resolved signature state. `undetermined` ≠ `unsigned` — see the gate. */
    verdict: ReleaseSignatureVerdict;
    /** Orchestrator run the verdict came from, when one was found. */
    runId?: string;
    /** electronic_signatures.id when a verifying signature was found. */
    signatureId?: number;
    detail?: string;
    /** This gate adds no blocker. */
    cleared: boolean;
  };
  /** Hard gate verdict for DISPATCH — structural + shadow + external +
   *  release-signature, composed. This is the transmit verdict and the one the
   *  readiness surface reports. */
  gate: DispatchGateResult;
  /** Hard gate verdict for FREEZE — the same gates, except that a release
   *  signature is not REQUIRED to freeze (a tampered one still blocks). Freeze
   *  is not transmit and carries its own Part 11 signature; see
   *  composeDispatchGatesForStep. */
  freezeGate: DispatchGateResult;
  /** The DISPATCH verdict as it will stand once the operator's dispatch
   *  signature is recorded — what the Dispatch button asks. It differs from
   *  `gate` only where the sequence's own new signature would decide the
   *  release (signingNowResolvesRelease): an `unsigned` or `revoked` sequence
   *  spine. Every other blocker, including an `invalid` or `undetermined`
   *  signature and an orchestrator run awaiting its signer, blocks it exactly
   *  as it blocks `gate`. Informational for the client; the server enforces
   *  `gate` at transition, with the new signature on record. */
  dispatchGateOnSigning: DispatchGateResult;
  /** The DISPATCH verdict gate by gate, each as the corpus rule it enforces;
   *  their blockers, in order, are exactly `gate.blockers`. */
  gates: DispatchGateView[];
  /** Full structural breakdown (errors + non-blocking warnings/infos); every
   *  finding carries the corpus rule it is an instance of. */
  readiness: DispatchReadinessReport;
  leafCount: number;
}

/**
 * NODE_ENV values that are RECOGNIZED as non-production. Anything else — unset,
 * misspelled, 'prod' — is treated as production so the fail-closed eValidator
 * rule is not silently disabled by a misconfiguration.
 */
const NON_PRODUCTION_NODE_ENVS = new Set(['development', 'test', 'staging']);

/**
 * Resolve the environment for the fail-closed eValidator rule. Fails toward
 * 'production': only a RECOGNIZED non-production NODE_ENV yields 'staging', so an
 * unset/misspelled value keeps production enforcement on. Pure + exported for test.
 */
export function resolveDispatchEnvironment(
  nodeEnv: string | undefined,
): 'production' | 'staging' {
  return NON_PRODUCTION_NODE_ENVS.has(nodeEnv ?? '') ? 'staging' : 'production';
}

/**
 * Gate on Shadow Review having actually run. Zero completed runs is UNASSESSED,
 * not clean — it must block dispatch, never clear it. Pure + exported for test.
 */
export function evaluateShadowPresenceGate(shadowReviewRunCount: number): DispatchGateResult {
  return shadowReviewRunCount > 0
    ? { cleared: true, blockers: [] }
    : {
        cleared: false,
        blockers: [
          'No completed Shadow Review has run for this sequence. A never-reviewed dossier is not cleared for dispatch — run Shadow Review before transmitting.',
        ],
      };
}

/**
 * Compose every hard gate into the single dispatch verdict.
 *
 * Extracted as a PURE function so the SET of gates is testable without a
 * database. That matters more than it looks: each gate is individually unit
 * tested, but a gate that is never passed to `mergeDispatchGates` blocks
 * nothing, and a purely-unit-tested gate cannot detect its own absence from
 * the composition. This function is the one place the membership is asserted.
 *
 * Pure + exported for test, same idiom as evaluateShadowPresenceGate.
 */
export function composeDispatchGates(gates: {
  structural: DispatchGateResult;
  external: DispatchGateResult;
  shadowPresence: DispatchGateResult;
  releaseSignature: DispatchGateResult;
}): DispatchGateResult {
  return mergeDispatchGates(
    gates.structural,
    gates.external,
    gates.shadowPresence,
    gates.releaseSignature,
  );
}

/** The two governed sequence transitions this composition can be asked about. */
export type GovernedDispatchStep = 'freeze' | 'dispatch';

/**
 * The gate verdict for a specific governed step.
 *
 * ── Why the step matters ─────────────────────────────────────────────────────
 * `transitionSequenceGoverned` applies a composed gate to BOTH governed
 * transitions. Composing the release-signature gate into that one verdict
 * therefore made a TRANSMIT control block the FREEZE — and a release signature
 * comes from a signed package orchestrator run, so freezing any IND / NDA / BLA
 * / MAA sequence required signing a release first. That inverts the order the
 * product works in, for a control whose own module calls itself "the
 * transmit-time re-check" and "the provable pre-transmit rule".
 *
 * Freeze is not transmit: nothing leaves the building, and the step already
 * carries its own Part 11 signature — bound to this sequence, this step, this
 * actor and this leaf manifest (transitionSequenceGoverned Gate 1). So the
 * REQUIREMENT for a release signature governs `dispatch` only.
 *
 * What does NOT change is integrity. `evaluateReleaseSignatureGate` blocks an
 * `invalid` verdict unconditionally, including when a signature is not
 * required, because requiredness governs whether a signature must be PRESENT
 * and never whether a broken one may be ignored. Expressing the freeze case as
 * "not required" rather than "gate omitted" is what keeps that rule intact: a
 * tampered signature still blocks a freeze.
 *
 * Every other gate governs both steps, and the membership is pinned by test —
 * a gate added later cannot be dropped from the freeze verdict by omission.
 */
export function composeDispatchGatesForStep(
  parts: {
    structural: DispatchGateResult;
    external: DispatchGateResult;
    shadowPresence: DispatchGateResult;
    releaseSignature: ReleaseSignatureGateInput;
  },
  step: GovernedDispatchStep,
): DispatchGateResult {
  return composeDispatchGates({
    structural: parts.structural,
    external: parts.external,
    shadowPresence: parts.shadowPresence,
    releaseSignature: evaluateReleaseSignatureGate({
      ...parts.releaseSignature,
      required: step === 'dispatch' && parts.releaseSignature.required,
    }),
  });
}

/**
 * The three verdicts an assessment reports, each for the question a control
 * asks, from ONE set of parts:
 *
 *   • `gate`                  — dispatch now (and transmit): every gate.
 *   • `freezeGate`            — freeze: every gate, the release signature not
 *                               REQUIRED (a tampered one still blocks).
 *   • `dispatchGateOnSigning` — dispatch once the operator's dispatch signature
 *                               is recorded: every gate, with the release
 *                               verdict replaced by `signed` only where
 *                               signingNowResolvesRelease says the new sequence
 *                               signature would decide it.
 *
 * Pure, and the only place the three are composed, so which gates each one
 * carries is pinned by test. That matters because the failure here is not a
 * wrong gate but a MISSING one: a verdict composed without a gate blocks
 * nothing on it, and every test of the gate in isolation still passes. It is
 * also why the client reads these rather than rebuilding any of them — the
 * Freeze and Dispatch buttons each read the wrong one of these for as long as
 * the client carried its own idea of which gate applied.
 */
export function composeStepVerdicts(
  parts: {
    structural: DispatchGateResult;
    external: DispatchGateResult;
    shadowPresence: DispatchGateResult;
    releaseSignature: ReleaseSignatureGateInput;
  },
  releaseStatus: Pick<ReleaseSignatureStatus, 'verdict' | 'decidedBy'>,
): { gate: DispatchGateResult; freezeGate: DispatchGateResult; dispatchGateOnSigning: DispatchGateResult } {
  return {
    gate: composeDispatchGatesForStep(parts, 'dispatch'),
    freezeGate: composeDispatchGatesForStep(parts, 'freeze'),
    dispatchGateOnSigning: composeDispatchGatesForStep(
      {
        ...parts,
        releaseSignature: signingNowResolvesRelease(releaseStatus)
          ? { ...parts.releaseSignature, verdict: 'signed' }
          : parts.releaseSignature,
      },
      'dispatch',
    ),
  };
}

/**
 * Completed Shadow Review runs for a sequence.
 *
 * Zero open criticals means nothing different whether the dossier is clean OR
 * was never reviewed — so the count is read separately and fed to the presence
 * gate, which surfaces that blind spot instead of letting it read as clean.
 *
 * Extracted from assessSequenceDispatchReadiness only to keep that function
 * under the max-lines-per-function ceiling; the query and its filters are
 * unchanged, including `status = 'complete'` and the soft-delete exclusion.
 */
async function countCompletedShadowRuns(
  sequenceId: number,
  organizationId: number,
): Promise<number> {
  const [{ value }] = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(shadowReviewRuns)
    .where(
      and(
        eq(shadowReviewRuns.sequenceId, sequenceId),
        eq(shadowReviewRuns.organizationId, organizationId),
        eq(shadowReviewRuns.status, 'complete'),
        isNull(shadowReviewRuns.deletedAt)
      )
    );
  return value ?? 0;
}

/**
 * Flatten a region profile's Module-1 tree to the section codes marked required
 * for this application type.
 *
 * The walk now lives beside the profile it reads
 * (`region-profile-service.requiredModule1CodesForRegion`) because a second
 * copy of "what Module 1 does this application need" had grown in
 * `ectd4-validator`, as a hand-written literal set that disagreed with this one
 * on four codes. This name is kept as the export the dispatch path already
 * uses; it is now a thin delegation rather than a parallel implementation.
 */
export function requiredModule1Codes(region: string, applicationType?: string | null): string[] {
  return requiredModule1CodesForRegion(region, applicationType);
}

/**
 * The application type decides which Module 1 sections are required (an IND
 * needs its plan and brochure; a marketing application its debarment
 * certification and draft labeling). Tenant-scoped; null when the submission
 * row is not visible to this organization.
 */
async function loadApplicationType(submissionId: number, organizationId: number): Promise<string | null> {
  const [row] = await db
    .select({ applicationType: submissions.applicationType })
    .from(submissions)
    .where(and(eq(submissions.id, submissionId), eq(submissions.organizationId, organizationId)))
    .limit(1);
  return row?.applicationType ?? null;
}

/**
 * The Module 3 headings an original IND must carry, read from the IND profile
 * (required-sections.requiredSectionProfileFor) and never restated here, with
 * their ICH M4 titles. Null for anything that is not a US IND — the scope the
 * CMC launch decision (P-28) ships. Pure + exported for test.
 */
export function originalIndModule3Headings(
  applicationType: string | null,
  region: string,
): Array<{ code: string; title: string | null }> | null {
  const profile = requiredSectionProfileFor(applicationType ?? '', region);
  if (!profile || profile.submissionType !== 'IND') return null;
  return [...profile.sections]
    .filter((code) => moduleOfSectionKey(code) === 'm3')
    .map((code) => ({ code, title: ichHeadingTitle(code) }));
}

/**
 * Is this sequence the original of its application? Sequence 0000 always is.
 * Any other number is only when it is typed 'original' AND no earlier live
 * sequence of the same submission and region exists: the type column defaults
 * to 'original', so a later sequence created without a type reads 'original',
 * and asking an amendment for an original's content would block a filing the
 * agency accepts. Pure + exported for test.
 */
export function isOriginalApplicationSequence(
  sequence: { type: string | null; sequenceNumber: string },
  earlierSequenceExists: boolean,
): boolean {
  return sequence.sequenceNumber === '0000' || (sequence.type === 'original' && !earlierSequenceExists);
}

type SequenceIdentity = { submissionId: number; region: string; type: string | null; sequenceNumber: string };

/** A live sequence of the same submission and region numbered before this one. Tenant-scoped. */
async function hasEarlierSequence(sequence: SequenceIdentity, organizationId: number): Promise<boolean> {
  const [{ value }] = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(ectdSequences)
    .where(
      and(
        eq(ectdSequences.submissionId, sequence.submissionId),
        eq(ectdSequences.organizationId, organizationId),
        eq(ectdSequences.region, sequence.region),
        // Four-digit, zero-padded: string order is numeric order.
        lt(ectdSequences.sequenceNumber, sequence.sequenceNumber),
        isNull(ectdSequences.deletedAt),
      ),
    );
  return (value ?? 0) > 0;
}

/**
 * The submission's recorded cross-references (ind_cross_references, the
 * Module 1.4 register the LOA filing route marks), tenant-scoped. A register
 * that cannot be read is returned as null with the reason — never as an empty
 * register, which would read as "nothing is referenced". The finding stays
 * blocking either way; the reason is what it says.
 */
async function loadModule3CrossReferences(
  submissionId: number,
  organizationId: number,
): Promise<{ refs: Module3CrossReference[] | null; error: string | null }> {
  try {
    const rows = await db
      .select({
        fileType: indCrossReferences.referencedFileType,
        fileNumber: indCrossReferences.referencedFileNumber,
        authorizedSections: indCrossReferences.authorizedSections,
        loaOnFile: indCrossReferences.loaOnFile,
      })
      .from(indCrossReferences)
      .where(and(eq(indCrossReferences.organizationId, organizationId), eq(indCrossReferences.submissionId, submissionId)));
    return {
      refs: rows.map((r) => ({
        fileLabel: `${r.fileType} ${r.fileNumber}`.trim(),
        authorizedSections: Array.isArray(r.authorizedSections) ? r.authorizedSections.map(String) : [],
        loaOnFile: r.loaOnFile === true,
      })),
      error: null,
    };
  } catch (err) {
    return { refs: null, error: err instanceof Error ? err.message : String(err) };
  }
}

/**
 * What an original US IND must carry in Module 3 — its required headings and
 * the cross-references that may stand in for them — or null when the sequence
 * is not one: another application type, another region, or a later sequence.
 * An IND amendment is not asked; 21 CFR 312.23(a)(7) is the initial IND's
 * content. Until 2026-10-05 (CMC-M3-GA item 21) nothing on the dispatch path
 * asked, and an original IND with Module 1 alone read dispatch-clear.
 */
export async function originalModule3Requirement(
  sequence: SequenceIdentity,
  applicationType: string | null,
  organizationId: number,
): Promise<OriginalModule3Requirement | null> {
  const headings = originalIndModule3Headings(applicationType, sequence.region);
  if (!headings || headings.length === 0) return null;
  const earlier =
    sequence.sequenceNumber !== '0000' && sequence.type === 'original'
      ? await hasEarlierSequence(sequence, organizationId)
      : false;
  if (!isOriginalApplicationSequence(sequence, earlier)) return null;
  const { refs, error } = await loadModule3CrossReferences(sequence.submissionId, organizationId);
  return {
    label:
      sequence.sequenceNumber === '0000'
        ? 'the original IND (sequence 0000)'
        : `the original IND (sequence ${sequence.sequenceNumber}, its first sequence)`,
    headings,
    crossReferences: refs,
    crossReferenceError: error,
  };
}

/**
 * Assess whether a sequence is clear to dispatch, computing every gate input from
 * server-side truth. Throws if the sequence is not found in the tenant.
 */
export async function assessSequenceDispatchReadiness(
  params: AssessDispatchReadinessParams
): Promise<DispatchReadinessAssessment> {
  const { sequenceId, organizationId } = params;

  // 1. Tenant-scoped sequence (region + status).
  const [sequence] = await db
    .select()
    .from(ectdSequences)
    .where(and(eq(ectdSequences.id, sequenceId), eq(ectdSequences.organizationId, organizationId)))
    .limit(1);
  if (!sequence) {
    throw Object.assign(new Error('Sequence not found in this organization.'), { code: 'NOT_FOUND' });
  }
  const submissionApplicationType = await loadApplicationType(sequence.submissionId, organizationId);

  // 2. Tenant-scoped, non-deleted leaves.
  const leaves = await db
    .select()
    .from(submissionLeaves)
    .where(
      and(
        eq(submissionLeaves.sequenceId, sequenceId),
        eq(submissionLeaves.organizationId, organizationId),
        isNull(submissionLeaves.deletedAt)
      )
    );

  // 2b. Resolve every leaf's document pointer — by whichever key its table is
  //     addressed by (integer document_id, or document_uuid for the vault) —
  //     in this organization, and compare the content hash pinned at filing
  //     with what the store holds now. ONE resolver, shared with the Builder's
  //     read model; the freeze / dispatch / transmit gates compose this
  //     assessment, so they cannot disagree with it. Until 2026-09-21 the
  //     validator was handed the integer column alone and every vault-backed
  //     leaf read UNRESOLVED_DOCUMENT (MDX demo pack, finding F5).
  const documents = await resolveLeafDocuments(leaves, organizationId);

  // 3. Deterministic structural validation over the canonical core.
  const readiness = computeDispatchReadiness(
    leaves.map((l, i) => ({
      sectionCode: l.sectionCode,
      title: l.title,
      lifecycleOp: l.lifecycleOp,
      documentTable: l.documentTable,
      documentId: l.documentId,
      documentUuid: l.documentUuid,
      document: documents[i],
    })),
    {
      ...readinessOptionsForSequence(sequence, submissionApplicationType, params.asOf ?? dispatchAsOfDate()),
      originalModule3: await originalModule3Requirement(sequence, submissionApplicationType, organizationId),
    },
  );

  // Fail-visible on an unrecognized region: requiredModule1Codes returns [] for a
  // region with no registered profile, so NO required-section is checked and the
  // absence of MISSING_REQUIRED_SECTION findings does NOT mean the required
  // sections are present. Surface it as a warning rather than reporting nothing
  // missing.
  if (!getSubmissionRegionProfile(sequence.region)) {
    readiness.findings.push({
      severity: 'warning',
      code: 'UNKNOWN_REGION_PROFILE',
      sectionCode: null,
      message: `No submission region profile is registered for region "${sequence.region}"; required Module 1 section checking could not be performed.`,
    });
    readiness.warnings += 1;
  }

  // 4. Open CRITICAL Shadow Review findings for this sequence (server truth).
  const [{ value: criticalCount }] = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(shadowReviewFindings)
    .innerJoin(shadowReviewRuns, eq(shadowReviewFindings.runId, shadowReviewRuns.id))
    .where(
      and(
        eq(shadowReviewRuns.sequenceId, sequenceId),
        eq(shadowReviewFindings.organizationId, organizationId),
        eq(shadowReviewFindings.severity, 'critical'),
        eq(shadowReviewFindings.status, 'open'),
        isNull(shadowReviewFindings.deletedAt),
        isNull(shadowReviewRuns.deletedAt)
      )
    );

  const unacknowledgedShadowCriticals = criticalCount ?? 0;

  // 4b. Has this sequence ever been Shadow-Reviewed? See countCompletedShadowRuns.
  const shadowReviewRunCount = await countCompletedShadowRuns(sequenceId, organizationId);

  // 5. External agency-grade validation gate (P0-4), composed with the structural
  //    + shadow gate. Default-off: behavior is identical to before unless
  //    ECTD_REQUIRE_EVALIDATOR is set in production. The external validator runs
  //    against an unzipped package (not available in this DB-bound assessor), so a
  //    caller that already ran it passes the report in; otherwise the fail-closed
  //    "could not run" rule blocks a required production dispatch.
  const externalValidator = await resolveExternalValidator();
  const externalGate = await assessExternalValidationReport(
    externalValidator,
    params.externalValidationReport ?? null,
    evalidatorRequiredFromEnv(),
    resolveDispatchEnvironment(process.env.NODE_ENV),
  );

  // 6. Hard gate over the server-computed inputs, composed with the external
  //    gate. P-22 (2026-10-08): a leaf whose document is not yet approved is a
  //    validation WARNING, and a release blocker — the structural verdict every
  //    release step reads (freeze, dispatch, transmit) refuses it by its own
  //    blocker, never by counting it as an error.
  const structuralGate = mergeDispatchGates(
    evaluateDispatchGate({
      validationErrors: readiness.errors,
      unacknowledgedShadowCriticals,
    }),
    evaluateReleaseApprovalGate(readiness.releaseBlockers),
  );

  // 6b. Never-Shadow-Reviewed is not clean, it is UNASSESSED. A sequence with
  //     zero completed Shadow Review runs has zero open criticals for the same
  //     reason an unread document has zero findings: nothing ran to produce any.
  //     Like an undetermined count in the hard gate, that must not clear
  //     dispatch — otherwise a dossier that was never adversarially reviewed is
  //     transmitted to the agency with a `cleared: true` verdict. Block until at
  //     least one completed Shadow Review run exists.
  const shadowPresenceGate = evaluateShadowPresenceGate(shadowReviewRunCount);

  // 6c. Release-signature gate (21 CFR Part 11 §11.70). Until this landed, the
  //     entire dispatch path had no signature awareness at all: a sequence
  //     could be transmitted to the agency having never been e-signed, or
  //     having been signed over a DIFFERENT package than the one dispatching.
  //     The orchestrator's package.sign step proves a signature existed at
  //     BUILD time; dispatch is a separate, later act, so it re-checks — which
  //     is exactly the re-check the e-sig design doc reserves for transmit.
  //     Same shape as §6b: unsigned is not signature-clean, it is unsigned, and
  //     an undetermined lookup is not an absent requirement.
  const releaseSignature = await resolveReleaseSignatureStatus({
    submissionId: sequence.submissionId,
    organizationId,
    // Sequence-grained, like every other input this assessor composes. Without
    // it a release signed over sequence 0000's package cleared this gate for
    // 0001 and every later sequence under the same submission — see the header
    // of resolveReleaseSignatureStatus.
    sequenceNumber: sequence.sequenceNumber,
    // And the sequence's own id, so the resolver can also see a release signed
    // on the SUBMISSIONS spine (governed sign on 'ectd-sequence:<id>', bound to
    // this sequence's leaf manifest). Without it that spine cannot be addressed
    // at all, and a sequence authored and signed entirely through the product's
    // own governed path reads as unsigned — which made dispatch and transmit
    // unreachable for every submission type the gate applies to.
    sequenceId,
    // And its REGION. Sequence numbers restart per region, so '0000' is the FDA
    // original and the EU original both; without this a release over one clears
    // the dispatch gate for the other. Resolved through the region registry on
    // the far side, because the two spines spell one jurisdiction differently.
    region: sequence.region,
  });
  const signatureRequired = isReleaseSignatureRequired(submissionApplicationType);
  const signatureInput = {
    required: signatureRequired,
    verdict: releaseSignature.verdict,
    detail: releaseSignature.detail,
  };
  const releaseSignatureGate = evaluateReleaseSignatureGate(signatureInput);

  // One set of parts, composed for each governed step. Dispatch is the transmit
  // verdict (every gate). Freeze drops only the REQUIREMENT for a release
  // signature — a control the §11.70 design reserves for transmit — and keeps
  // every other gate, including an integrity failure on a signature that does
  // exist. See composeDispatchGatesForStep.
  const gateParts = {
    structural: structuralGate,
    external: { cleared: externalGate.cleared, blockers: externalGate.blockers },
    shadowPresence: shadowPresenceGate,
    releaseSignature: signatureInput,
  };
  // `dispatchGateOnSigning` is the dispatch verdict as it will stand once the
  // operator's dispatch signature is recorded — what the Dispatch button asks.
  // It never relaxes what the server enforces: the transition re-evaluates
  // `gate` with the new signature on record. See composeStepVerdicts.
  const { gate, freezeGate, dispatchGateOnSigning } = composeStepVerdicts(gateParts, releaseSignature);
  // The same four results `gate` merged: the dispatch-step release-signature
  // evaluation is releaseSignatureGate (required as the type requires).
  const gates = dispatchGateViews(
    {
      structural: structuralGate,
      external: gateParts.external,
      shadowPresence: shadowPresenceGate,
      releaseSignature: releaseSignatureGate,
    },
    { external: externalNotAssessed(externalGate) },
    { assessmentStatus: externalGate.assessmentStatus, assessmentNote: externalGate.assessmentNote },
  );
  readiness.findings = withRules(readiness.findings);

  return {
    sequenceId,
    region: sequence.region,
    sequenceStatus: sequence.status,
    validatedStage: validatedStageOf(sequence, readiness.errors),
    validationErrors: readiness.errors,
    unacknowledgedShadowCriticals,
    shadowReviewRunCount,
    externalValidation: externalValidationView(externalGate),
    /** True when no completed Shadow Review has run for this sequence. This now
     *  also blocks the gate (§6b), so it is informational: it reports WHY the
     *  gate is blocked when that is the only blocker. */
    shadowReviewMissing: shadowReviewRunCount === 0,
    /** Release-signature state (§6c). `required` reports whether this
     *  submission type crosses the §11.70 boundary; `verdict` is the resolved
     *  state. Informational on the response — the blocking happens in `gate`. */
    releaseSignature: {
      required: signatureRequired,
      verdict: releaseSignature.verdict,
      runId: releaseSignature.runId,
      signatureId: releaseSignature.signatureId,
      detail: releaseSignature.detail,
      cleared: releaseSignatureGate.cleared,
    },
    gate,
    freezeGate,
    dispatchGateOnSigning,
    gates,
    readiness,
    leafCount: leaves.length,
  };
}

export default { assessSequenceDispatchReadiness };
