import React, { useMemo } from 'react';
import { I } from '../icons';
import { PedigreeBadge } from '../intelligence/Intelligence';
import { EmptyState } from '../dataConnect';
import { usePublishSurfaceContext } from '../surfaceContext';
import type { SurfaceViewProps } from '../surfaceViews';
import {
  noSubmissionWords,
  otherSubmissionsLine,
  programTypeLabel,
  useProgramSequence,
  useSequenceDispatchReadiness,
  type Discovery,
  type GateState,
  type GateView,
  type ExternalValidation,
  type ReadinessFinding,
  type RuleView,
} from './programSequence';
import '../styles/project-home-v2.css';

/* The wire types, the open program's sequence discovery and the server's
   verdict are read in programSequence.ts, the one module this screen and the
   project page share (ONE_ANA_ONE_CANVAS.md slice 24). This screen renders
   them; it computes none of them. */

/* What AnA is told when there is no verdict to give — one line per not-ready
   state, each naming the program it is about. */
function notReadySummary(state: GateState, programLabel: string | null, discovery: Discovery): string {
  const p = programLabel ?? 'the open program';
  if (state === 'no-submission' && discovery.state === 'no-submission') {
    /* "No submission" is said only when none is recorded to the program: one
       of another type (an EU MAA beside the IND) is named, not denied. */
    const type = programTypeLabel(discovery.programType);
    const others = otherSubmissionsLine(discovery.otherSubmissions);
    return (
      `Dispatch readiness: the open program (${p}) has no ${type ? `${type} ` : ''}submission recorded` +
      (type ? '' : ' (it has no program type recorded)') +
      (others ? `; its submissions of other types are not gated (${others})` : '') +
      ', so there is no sequence to gate.'
    );
  }
  switch (state) {
    case 'evaluating':
      return 'Dispatch readiness, still evaluating the gate.';
    case 'error':
      return 'Dispatch readiness could not be evaluated — the gate is unanswered, which is not the same as cleared.';
    case 'no-program':
      return 'Dispatch readiness: no program is open, so no sequence is being gated.';
    case 'no-submission':
      return `Dispatch readiness: the open program (${p}) has no submission recorded, so there is no sequence to gate.`;
    default:
      return `Dispatch readiness: the open program (${p}) has no eCTD sequence yet, so there is nothing to clear.`;
  }
}

/* ── severity → tone map ── */
const SEV_TONE: Record<string, string> = { error: 'error', warning: 'warning', info: 'idle' };

/* ════ Dispatch Readiness — deterministic last gate before agency transmit ════
   Answer-first; not a dashboard. Consumes Shadow Review criticals + structural
   validation + external (eValidator) findings, composed.
   Pedigree: deterministic_registry (the gate is proven, not generated).
   full: true — owns the canvas. */

/** A finding's rule: its title and id, regions, corpus severity and where it is enforced. */
function RuleLine({ rule, code }: { rule: RuleView | null; code: string }) {
  if (!rule) {
    return (
      <span style={{ display: 'block', fontSize: 12 }}>
        <span className="mono">{code}</span> — not in the rule corpus, so no rule stands behind this finding.
      </span>
    );
  }
  return (
    <span style={{ display: 'block', fontSize: 12 }}>
      <b>{rule.title}</b> <span className="mono">{rule.id}</span> · {rule.regions.map((r) => r.toUpperCase()).join(' · ')} ·{' '}
      {rule.severity} · {rule.enforcementStatement}
    </span>
  );
}

/** One composed gate: the rule it enforces, its outcome in words, its own blockers. */
function GateOutcome({ gate }: { gate: GateView }) {
  if (gate.key === 'external' && gate.assessmentStatus) {
    const labels = {
      passed: 'External validation passed.', failed: 'External validation failed.',
      invalid: 'External validation report invalid.', not_assessed: 'Not assessed.',
    };
    return <>{labels[gate.assessmentStatus]} {gate.assessmentNote ?? gate.notAssessed} {!gate.cleared && 'Blocks dispatch:'}</>;
  }
  return <>{gate.cleared && gate.notAssessed ? <>Not assessed. {gate.notAssessed}</> : gate.cleared ? 'Satisfied.' : 'Blocks dispatch:'}</>;
}

function externalValidationSummary(ev: ExternalValidation): string {
  switch (ev.assessmentStatus) {
    case 'passed': return 'external validation passed';
    case 'failed': return 'external validation failed (advisory)';
    case 'invalid': return 'external validation report invalid (advisory)';
    case 'not_assessed': return 'external validation not assessed';
    default:
      if (ev.qualifyingRun === false || ev.errorCountKnown === false) return 'external validation not assessed';
      if (ev.ran && ev.errorCount > 0) return 'external validation failed (advisory)';
      return ev.ran ? 'external validator clean' : 'external validator not run';
  }
}

function externalValidationFacts(ev: ExternalValidation): Record<string, unknown> {
  return {
    externalValidationCleared: ev.cleared,
    externalValidationStatus: ev.assessmentStatus ?? null,
    externalValidationNote: ev.assessmentNote ?? null,
    externalValidatorKind: ev.validatorKind ?? null,
    externalSelectedValidator: ev.selectedValidatorName ?? null,
    externalReportedValidator: ev.reportedValidatorName ?? null,
    externalValidationRan: ev.ran,
    externalQualifyingRun: ev.qualifyingRun ?? null,
    externalErrorCountKnown: ev.errorCountKnown ?? null,
  };
}

function gateWithLegacyErrors(suppliedGate: GateView, externalValidation: ExternalValidation): GateView {
  // Older responses have no factual status, but their positive observed count
  // still cannot be displayed as a successful external validation.
  return suppliedGate.key === 'external' && suppliedGate.assessmentStatus == null && externalValidation.ran && externalValidation.errorCount > 0
    ? { ...suppliedGate, assessmentStatus: 'failed', assessmentNote: `The supplied report carries ${externalValidation.errorCount} error-severity finding(s). The gate's blocking policy is shown separately.` }
    : suppliedGate;
}

function GateCard({ gate: suppliedGate, externalValidation }: { gate: GateView; externalValidation: ExternalValidation }) {
  const gate = gateWithLegacyErrors(suppliedGate, externalValidation);
  /* A gate that does not block because its check never ran is not "Satisfied".
     The external validator's card read "…report for this package carries no
     errors — Satisfied." over a package no validator had seen. */
  const unassessed = gate.cleared && (Boolean(gate.notAssessed) || (gate.key === 'external' && gate.assessmentStatus != null && gate.assessmentStatus !== 'passed'));
  return (
    <div data-gate={gate.key} className={'dr2-gate ' + (unassessed ? 'warn' : gate.cleared ? 'ok' : 'block')}>
      <div className="dr2-gate-top">
        <span className="dr2-gate-dot">{unassessed ? I.alertTriangle : gate.cleared ? I.check : I.lock}</span>
        <span className="dr2-gate-label">{gate.rule?.title ?? `The ${gate.key} gate — not in the rule corpus`}</span>
      </div>
      <div className="dr2-gate-detail">
        <GateOutcome gate={gate} />
        {!gate.cleared && (
          <ul style={{ margin: '2px 0 0', paddingLeft: 16 }}>
            {gate.blockers.map((b, i) => <li key={i}>{b}</li>)}
          </ul>
        )}
      </div>
      {gate.rule && (
        <div className="dr2-gate-basis">
          <span className="mono">{gate.rule.id}</span> · {gate.rule.enforcementStatement}
        </div>
      )}
    </div>
  );
}

export function DispatchReadiness({ onAsk }: SurfaceViewProps) {
  const ask = onAsk;
  // Real deterministic gate for the OPEN PROGRAM's latest sequence, computed
  // server-side by assessSequenceDispatchReadiness. Fixture-free: real
  // assessment, honest empty (no program / no submission / no sequence), or
  // honest error — never a sample assessment, never another program's.
  const discovery = useProgramSequence();
  /* The verdict is the server's, read once in programSequence.ts for this
     screen and the project page alike: when the server states none, the gate
     is UNANSWERED, which is not cleared. */
  const { assessment: a, gate, loading, gateState, live } = useSequenceDispatchReadiness(discovery);
  const sequenceNumber = discovery.state === 'sequence' ? discovery.sequenceNumber : null;
  const programLabel = 'programLabel' in discovery ? discovery.programLabel : null;

  /* WHAT ANA SEES HERE. This surface answers one question — may this sequence
     be transmitted — and the answer is a hard gate, so the payload carries the
     BLOCKERS and not just the verdict. "Not cleared" without the reasons is the
     shape of answer that sends someone hunting; the gate already computes the
     strings, so they travel.

     `cleared` is never published as true from a missing assessment: with no
     sequence discovered, `gate` is {cleared:false, blockers:[]}, which would
     read as "blocked for no reason". The state field distinguishes that from a
     real refusal, because a gate that cannot be evaluated has not passed — and
     it says WHICH not-ready state this is (no program open, no submission for
     the program, no sequence on it, a failed read), never "no sequence in the
     organisation". `gateState` (programSequence.ts) is that field. */
  const anaContext = useMemo(
    () => ({
      summary:
        gateState === 'evaluated' && a
          ? `Dispatch readiness for sequence ${sequenceNumber ?? `id ${a.sequenceId}`} (${a.region}, ${a.sequenceStatus}) of program ${programLabel}: ` +
            (gate.cleared ? 'cleared to dispatch.' : `NOT cleared — ${gate.blockers.length} blocker(s).`)
          : notReadySummary(gateState, programLabel, discovery),
      facts: {
        gateState,
        ...('programId' in discovery ? { programId: discovery.programId, program: discovery.programLabel } : {}),
        ...('submissionId' in discovery ? { submissionId: discovery.submissionId } : {}),
        ...(sequenceNumber ? { sequenceNumber } : {}),
        ...(a
          ? {
              sequenceId: a.sequenceId,
              region: a.region,
              sequenceStatus: a.sequenceStatus,
              cleared: gate.cleared,
              blockers: gate.blockers,
              validationErrors: a.validationErrors,
              unacknowledgedShadowCriticals: a.unacknowledgedShadowCriticals,
              shadowReviewRunCount: a.shadowReviewRunCount,
              shadowReviewMissing: a.shadowReviewMissing,
              ...externalValidationFacts(a.externalValidation),
              leafCount: a.leafCount,
            }
          : {}),
      },
      availableActions: [
        'Explain why this sequence is not cleared to dispatch',
        'Explain what each blocker requires before it clears',
        'Explain what the external validator adds to this gate',
      ],
    }),
    [gateState, discovery, programLabel, sequenceNumber, a, gate],
  );
  usePublishSurfaceContext('dispatch-readiness', anaContext);

  /* the surface's identity — shown in every state */
  const head = (
    <div className="dr2-head">
      <div className="dr2-eyebrow">
        <span className="dr2-kicker">AnA · dispatch gate · proven, not generated</span>
      </div>
      <h1 className="dr2-title">Cleared to dispatch?</h1>
    </div>
  );

  /* ── honest loading / error / empty (never a fixture) ── */
  if (loading) {
    return (
      <div className="dr2">
        {head}
        <div role="status" className="scaf-note" style={{ padding: '18px 10px' }}>Assessing dispatch readiness…</div>
      </div>
    );
  }
  if (live.error || discovery.state === 'error') {
    return (
      <div className="dr2">
        {head}
        <EmptyState
          tone="error"
          icon={I.alertTriangle}
          title="Couldn't compute the dispatch gate"
          hint={
            discovery.state === 'error'
              ? `The open program's submission and sequence could not be read (${discovery.detail}). Nothing is being gated — sign in and retry, or check the service is reachable.`
              : "The deterministic readiness assessment didn't respond. It's computed server-side from your sequence's canonical leaves and open Shadow Review criticals — sign in and retry, or check the service is reachable."
          }
        />
      </div>
    );
  }
  if (discovery.state === 'no-program') {
    return (
      <div className="dr2">
        {head}
        <EmptyState
          icon={I.rocket}
          title="Open a program to gate its sequence"
          hint="The dispatch gate runs against the open program's eCTD sequence and nothing else — it never gates whichever submission happens to be newest in the organisation. Open a program first; its sequence's verdict appears here."
        />
      </div>
    );
  }
  if (discovery.state === 'no-submission') {
    /* The gate reads only the program's submission of its own type. A program
       whose submissions are all of other types has submissions, so this says
       which type is missing and names the others (programSequence.ts). */
    const words = noSubmissionWords(discovery, discovery.programLabel);
    const type = programTypeLabel(discovery.programType);
    return (
      <div className="dr2">
        {head}
        <EmptyState
          icon={I.rocket}
          title={words.title}
          hint={
            `${words.hint} ` +
            (type ? `Create its ${type} submission in the Submission Center and build a sequence; this` : 'This') +
            " screen does not stand in another program's filing for it."
          }
        />
      </div>
    );
  }
  if (discovery.state === 'no-sequence' || !a) {
    const label = discovery.state === 'no-sequence' ? discovery.programLabel : programLabel ?? 'the open program';
    const sub = discovery.state === 'no-sequence' ? discovery.submissionTitle : null;
    return (
      <div className="dr2">
        {head}
        <EmptyState
          icon={I.rocket}
          title={`No sequence to gate for ${label} yet`}
          hint={
            (sub ? `Its submission "${sub}" has no eCTD sequence yet. ` : '') +
            'Build a sequence and place documents into it, then AnA can prove whether it is cleared to transmit.'
          }
        />
      </div>
    );
  }

  /* ── real assessment (a is non-null from here) ── */
  const ev = a.externalValidation;
  const rd = a.readiness;

  /* The composed gates, as the SERVER itemized them: each is the corpus rule
     it enforces, with its own blockers. They used to be recomputed here from
     raw counts and drawn as a tick or a cross — three of the server's four
     gates, with the Shadow Review card reading "dispatch permitted" on the very
     state the server blocks. A response that carries no breakdown shows none,
     rather than a local reconstruction. */
  const gateViews: GateView[] = Array.isArray(a.gates) ? a.gates : [];

  /* AnA answer-first verdict */
  const lead = gate.cleared
    ? {
          tone: 'good',
          h: <>Your sequence is <b>cleared to dispatch</b>. Every hard gate is proven clear.</>,
          b: <>0 open validation errors, 0 unacknowledged Shadow Review criticals, {externalValidationSummary(ev)}. This verdict is computed from server state — not a model opinion. The wire transmit stays behind your Part-11 e-signature.</>,
      }
    : {
        tone: 'urgent',
        h: <>{gate.blockers.length} blocker{gate.blockers.length === 1 ? '' : 's'} stand{gate.blockers.length === 1 ? 's' : ''} between you and dispatch.</>,
        b: <>This is the deterministic floor — I cannot clear it while these are open, no matter how the draft reads. Close them, then re-check.</>,
      };

  return (
    <div className="dr2">
      <div className="dr2-head">
        <div className="dr2-eyebrow">
          <span className="dr2-kicker">AnA · dispatch gate · proven, not generated</span>
        </div>
        <h1 className="dr2-title">Cleared to dispatch?</h1>
        <div className="dr2-sub">
          {/* The sequence NUMBER is what a filing is known by (0000, 0001 …);
              the row id is kept beside it because every API path here is keyed
              by it. When the row carries no number, only the id is stated. */}
          {programLabel ? <>{programLabel} · </> : null}
          {sequenceNumber ? <>Sequence {sequenceNumber} (id {a.sequenceId})</> : <>Sequence id {a.sequenceId}</>} · region{' '}
          {String(a.region || 'fda').toUpperCase()} · {a.leafCount} leaves · status {a.sequenceStatus}{a.validatedStage?.holds === false ? <span role="status" data-validated-stage="stale"> — {a.validatedStage.reason}</span> : null}
        </div>
      </div>

      {/* the verdict */}
      <div className={'dr2-verdict ' + (gate.cleared ? 'ok' : 'blocked')}>
        <span className="dr2-verdict-ic">{gate.cleared ? I.shieldCheck : I.lock}</span>
        <span className="dr2-verdict-t">{gate.cleared ? 'Cleared to dispatch' : 'Dispatch blocked'}</span>
      </div>

      <div className={'dr2-lead tone-' + lead.tone}>
        <div className="dr2-lead-ic">{I.rocket}</div>
        <div>
          <p className="dr2-lead-h">{lead.h}</p>
          <p className="dr2-lead-b">{lead.b}</p>
        </div>
      </div>

      {/* the composed gates — each the rule it enforces, its outcome in words */}
      {gateViews.length > 0 && (
        <div className="dr2-gates">
          {gateViews.map((g) => <GateCard key={g.key} gate={g} externalValidation={ev} />)}
        </div>
      )}

      {/* blockers — shown here only when the server did not itemize its
          gates; otherwise each blocker is shown inside the gate it belongs to */}
      {!gate.cleared && gateViews.length === 0 && (
        <div className="dr2-blockers">
          <div className="dr2-blockers-hd">{I.lock} What must close before dispatch</div>
          {gate.blockers.map((b, i) => (
            <div key={i} className="dr2-blocker">
              <span className="dr2-blocker-n">{i + 1}</span>
              <span className="dr2-blocker-t">{b}</span>
            </div>
          ))}
        </div>
      )}

      {/* structural findings breakdown */}
      <div className="dr2-readiness">
        <div className="dr2-readiness-hd">
          <span className="dr2-readiness-t">Structural validation</span>
          <span className="dr2-readiness-s">
            <span className="dr2-count err">{rd.errors} error{rd.errors === 1 ? '' : 's'}</span>
            <span className="dr2-count warn">{rd.warnings} warning{rd.warnings === 1 ? '' : 's'}</span>
            <span className="dr2-count idle">{rd.infos} info</span>
          </span>
        </div>
        {(rd.findings || []).map((f: ReadinessFinding, i: number) => (
          <div key={i} data-finding={f.code} className={'dr2-find tone-' + (SEV_TONE[f.severity] || 'idle')}>
            <span className={'dr2-find-sev tone-' + (SEV_TONE[f.severity] || 'idle')}>{f.severity}</span>
            {f.sectionCode && <span className="mono dr2-find-code">{f.sectionCode}</span>}
            <span className="dr2-find-msg">
              <RuleLine rule={f.rule ?? null} code={f.code} />
              {f.message}
            </span>
            {f.severity === 'error' && (
              <button
                className="dr2-find-fix"
                onClick={() =>
                  ask(
                    f.sectionCode
                      ? 'Resolve the dispatch-blocking validation error in §' + f.sectionCode + ': ' + f.message
                      : 'Resolve the dispatch-blocking validation error: ' + f.message,
                  )
                }
              >
                {I.sparkles} Fix
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="dr2-foot">
        <PedigreeBadge level="deterministic_registry" />
        <span className="dr2-foot-note">
          Every gate input is computed from server state — a client cannot pass{' '}
          <span className="mono">validationErrors:0</span> to talk the gate down. The AI dispatch-QC task advises; this gate{' '}
          <b>enforces</b>. Bound to the governed dispatch-readiness gate;
          the wire transmit stays behind a Part-11 e-signature.
        </span>
        {gate.cleared && (
          <button
            className="dr2-transmit"
            onClick={() =>
              ask(
                'Prepare the governed transmit of sequence ' +
                  a.sequenceId +
                  ' (region ' +
                  String(a.region || 'fda').toUpperCase() +
                  ') to the agency gateway — require the Part-11 e-signature.',
              )
            }
          >
            {I.send} Prepare governed transmit
          </button>
        )}
      </div>
    </div>
  );
}
