// @vitest-environment jsdom
/**
 * ProjectHome — the project's data room.
 *
 * The data room is the set of sources this project's documentation is written
 * from. It renders real `cre_evidence_sources` client documents from
 * GET /api/c2c/projects/:id/sources and never a fixture.
 *
 * The behaviour these tests pin is mostly about honesty:
 *   - a document whose text could not be read says so, rather than appearing
 *     identical to one that can be drafted from;
 *   - an empty project says it is empty;
 *   - a failed read says so instead of rendering as "no sources".
 *
 * The data room is on the Evidence tab since FILING_SPINE.md F3 (2026-10-08);
 * it sat under Author (projectHomeDocuments.test.tsx).
 */
import React from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, fireEvent, waitFor } from '@testing-library/react';

const apiRequest = vi.hoisted(() => vi.fn());
vi.mock('@/lib/queryClient', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@/lib/queryClient')>()),
  apiRequest,
}));

import { ProjectHome } from '../surfaces/ProjectHome';
import { CHAT_UPLOAD_ACCEPT } from '../../hooks/useChatUpload';

const PID = '11111111-1111-4111-8111-111111111111';

function ok(data: unknown) {
  return { ok: true, status: 200, json: async () => data } as Response;
}

function source(over: Record<string, unknown> = {}) {
  return {
    id: 1,
    title: 'protocol-v2.pdf',
    checksum: 'sha-1',
    ingestionStatus: 'ingested',
    extractionStatus: 'extracted',
    textAvailable: (over.extractionStatus ?? 'extracted') === 'extracted',
    isCurrent: true,
    dataEligible: true,
    createdAt: '2026-07-20T10:00:00Z',
    mimeType: 'application/pdf',
    fileSize: 2_400_000,
    artifactId: null,
    origin: 'chat_upload',
    extractionMethod: 'pdf-text',
    ...over,
  };
}

const props = () => ({
  surface: { id: 'project-home', label: 'Project' } as any,
  onAsk: vi.fn(),
  onNav: vi.fn(),
  segment: 'biopharma',
});

/** The data room is on the Evidence tab (FILING_SPINE.md F3): render, then open it. */
function renderOnEvidence(ui: React.ReactElement) {
  const r = render(ui);
  const tab = Array.from(document.querySelectorAll<HTMLButtonElement>('.pj-lc-stage')).find((b) => b.textContent?.trim() === 'Evidence');
  if (!tab) throw new Error('Project home has no Evidence tab');
  fireEvent.click(tab);
  return r;
}

/** Route every ProjectHome read; only /sources carries a payload we assert on. */
function mockApi(sourcesResponse: (url: string) => Response) {
  apiRequest.mockReset();
  apiRequest.mockImplementation(async (_m: string, url: string) => {
    // The Data Room read carries its search and page as query parameters (S2).
    if (url.startsWith(`/api/c2c/projects/${PID}/sources`)) return sourcesResponse(url);
    if (url === `/api/c2c/projects/${PID}`) return ok({ id: PID, name: 'BX-301', code: 'BX301' });
    return ok({});
  });
}

afterEach(() => {
  cleanup();
  delete (window as any).C2C_PROJECT;
});
beforeEach(() => {
  (window as any).C2C_PROJECT = { id: PID, title: 'BX-301' };
});

describe('ProjectHome — recorded processing recovery', () => {
  it('rereads recovered persisted text for the same source without sending a processing mutation', async () => {
    let recovered = false;
    mockApi(() => ok({ projectId: PID, sources: [source({ id: 12, title: 'Recovered assay.txt', textAvailable: recovered,
      processing: { state: recovered ? 'completed' : 'failed', retryable: !recovered, reasonCode: recovered ? null : 'PERSISTENCE_FAILED',
        leaseExpiresAt: null, nextRetryAt: recovered ? null : '2026-10-14T04:10:00.000Z' } })], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('Processing needs retry');
    recovered = true;
    fireEvent.click(screen.getByRole('button', { name: 'Refresh sources' }));
    await screen.findByText('Read');
    expect((screen.getByLabelText('Use Recovered assay.txt as context') as HTMLInputElement).disabled).toBe(false);
    expect(screen.queryByText('Processing needs retry')).toBeNull();
    expect(apiRequest.mock.calls.every(([method]) => method === 'GET')).toBe(true);
  });
  it('shows persisted retry-needed processing instead of a premature extracted label', async () => {
    mockApi(() => ok({ projectId: PID, sources: [source({ title: 'needs-retry.pdf', isCurrent: true, dataEligible: true,
      extractionStatus: 'extracted', textAvailable: false, processing: { state: 'failed', retryable: true,
        reasonCode: 'PERSISTENCE_FAILED', leaseExpiresAt: null, nextRetryAt: '2026-10-14T04:10:00.000Z' } })], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('needs-retry.pdf');
    expect(document.body.textContent).toContain('Processing needs retry');
    expect((screen.getByLabelText('Use needs-retry.pdf as context') as HTMLInputElement).disabled).toBe(true);
    expect(screen.queryByRole('button', { name: /Write from these sources/ })).toBeNull();
  });

  it('keeps legacy unknown availability ineligible instead of inventing readable text', async () => {
    mockApi(() => ok({ projectId: PID, sources: [source({ title: 'unverified.pdf', isCurrent: true, dataEligible: true, textAvailable: undefined })], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('unverified.pdf');
    expect((screen.getByLabelText('Use unverified.pdf as context') as HTMLInputElement).disabled).toBe(true);
    expect(document.body.textContent).toContain('Text availability unconfirmed');
  });

  it('shows a superseded source as historical even when its persisted text exists', async () => {
    mockApi(() => ok({ projectId: PID, sources: [source({ title: 'previous.pdf', isCurrent: false, dataEligible: true, textAvailable: true })], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('previous.pdf');
    expect(document.body.textContent).toContain('Superseded source');
    expect((screen.getByLabelText('Use previous.pdf as context') as HTMLInputElement).disabled).toBe(true);
  });
});

describe('ProjectHome — data room', () => {
  it('offers only the shared chat candidates from its project-source picker', async () => {
    mockApi(() => ok({ projectId: PID, sources: [], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText(/No sources in this project yet/);
    const picker = screen.getByLabelText('Attach files to this project') as HTMLInputElement;
    expect(picker.accept).toBe(CHAT_UPLOAD_ACCEPT);
    expect(picker.accept.split(',')).toEqual(expect.arrayContaining(['.csv', '.xlsx', '.json', '.xml']));
  });

  it('lists the project\'s real sources', async () => {
    mockApi(() => ok({ projectId: PID, sources: [source()], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);

    expect(await screen.findByText('protocol-v2.pdf')).toBeTruthy();
    // Kind, size and date come from the source's own metadata.
    expect(document.body.textContent).toMatch(/PDF/);
    expect(document.body.textContent).toMatch(/2\.3 MB|2\.4 MB/);
  });

  it('says a document is readable only when its extraction succeeded', async () => {
    mockApi(() =>
      ok({
        projectId: PID,
        sources: [
          source({ id: 1, title: 'good.pdf', extractionStatus: 'extracted' }),
          source({ id: 2, title: 'scanned.pdf', extractionStatus: 'failed' }),
          source({ id: 3, title: 'queued.pdf', extractionStatus: 'pending' }),
        ],
        unscoped: [],
      }),
    );
    renderOnEvidence(<ProjectHome {...props()} />);

    await screen.findByText('good.pdf');
    // A document whose text could not be read must not look like one that can
    // be drafted from — a section "written from" it would be grounded in
    // nothing.
    expect(screen.getByText('Text not readable')).toBeTruthy();
    expect(screen.getByText('Not processed yet')).toBeTruthy();
    expect(screen.getByText('Read')).toBeTruthy();
  });

  it('reports how many sources are actually usable', async () => {
    mockApi(() =>
      ok({
        projectId: PID,
        sources: [
          source({ id: 1, extractionStatus: 'extracted' }),
          source({ id: 2, title: 'b.pdf', extractionStatus: 'failed' }),
        ],
        unscoped: [],
      }),
    );
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText(/2 sources · 1 readable/);
  });

  it('renders an honest empty state for a project with no sources', async () => {
    mockApi(() => ok({ projectId: PID, sources: [], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    expect(await screen.findByText(/No sources in this project yet/)).toBeTruthy();
  });

  it('distinguishes a failed read from an empty data room', async () => {
    mockApi(() => ({ ok: false, status: 500, json: async () => ({}) }) as Response);
    renderOnEvidence(<ProjectHome {...props()} />);
    expect(await screen.findByText(/Couldn't load this project's sources/)).toBeTruthy();
    expect(screen.queryByText(/No sources in this project yet/)).toBeNull();
  });

  /* Since 2026-10-08 (Data Room catalog S2) the server searches title and the
     text read from each file, over the whole room; the list is its answer. A
     client-side title filter over the loaded page could not find the 201st
     file, or a word inside a document. */
  it('searches the whole room on the server, by title and text, and lists its answer', async () => {
    mockApi((url) =>
      url.includes('q=spirometry')
        ? ok({ projectId: PID, unscoped: [], total: 1, currentTotal: 1, window: { shown: 1, truncated: false },
            sources: [source({ id: 2, title: 'csr.pdf', snippet: 'decline in <b>spirometry</b> at week 52' })] })
        : ok({ projectId: PID, unscoped: [], total: 2, currentTotal: 2,
            sources: [source({ id: 1, title: 'protocol.pdf' }), source({ id: 2, title: 'csr.pdf' })] }),
    );
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('protocol.pdf');

    fireEvent.change(screen.getByLabelText('Search sources by title or text'), { target: { value: 'spirometry' } });

    await waitFor(() => expect(screen.queryByText('protocol.pdf')).toBeNull());
    expect(screen.getByText('csr.pdf')).toBeTruthy();
    expect(document.body.textContent).toContain('decline in spirometry at week 52');
    expect(document.body.textContent).toMatch(/1 source match .spirometry. in their title or text/);
    expect(apiRequest.mock.calls.some(([, url]) => String(url).includes('/sources?q=spirometry'))).toBe(true);
  });

  it('offers a way to add sources', async () => {
    mockApi(() => ok({ projectId: PID, sources: [], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    expect(await screen.findByLabelText('Add sources to this project')).toBeTruthy();
  });
});

describe('ProjectHome — pinning sources as context', () => {
  afterEach(() => { delete (window as any).C2C_SOURCE_PINS; });

  it('cannot pin a source whose text was never read', async () => {
    // Pinning promises AnA will be grounded in the document. A source with no
    // extracted text cannot ground anything, so offering it would be a lie.
    mockApi(() =>
      ok({
        projectId: PID,
        sources: [
          source({ id: 1, title: 'good.pdf', extractionStatus: 'extracted' }),
          source({ id: 2, title: 'scanned.pdf', extractionStatus: 'failed' }),
        ],
        unscoped: [],
      }),
    );
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('good.pdf');

    expect((screen.getByLabelText('Use good.pdf as context') as HTMLInputElement).disabled).toBe(false);
    expect((screen.getByLabelText('Use scanned.pdf as context') as HTMLInputElement).disabled).toBe(true);
  });

  it('hands the pinned set to AnA', async () => {
    mockApi(() =>
      ok({
        projectId: PID,
        sources: [
          source({ id: 11, title: 'a.pdf' }),
          source({ id: 22, title: 'b.pdf' }),
        ],
        unscoped: [],
      }),
    );
    const p = props();
    renderOnEvidence(<ProjectHome {...p} />);
    await screen.findByText('a.pdf');

    fireEvent.click(screen.getByLabelText('Use a.pdf as context'));
    fireEvent.click(screen.getByLabelText('Use b.pdf as context'));

    const draft = await screen.findByText(/Draft with 2 pinned sources/);
    fireEvent.click(draft);

    expect((window as any).C2C_SOURCE_PINS).toEqual(['11', '22']);
    expect(p.onAsk).toHaveBeenCalledTimes(1);
  });

  it('offers no pin action until something is pinned', async () => {
    mockApi(() => ok({ projectId: PID, sources: [source()], unscoped: [] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('protocol-v2.pdf');
    expect(screen.queryByText(/Draft with .* pinned source/)).toBeNull();
  });
});

describe('ProjectHome — where a source is used', () => {
  /** Route /sources and /source-changes independently. */
  function mockUsageApi(sources: unknown[], changes: unknown[] = []) {
    apiRequest.mockReset();
    apiRequest.mockImplementation(async (_m: string, url: string) => {
      if (url === `/api/c2c/projects/${PID}/sources`) return ok({ projectId: PID, sources, unscoped: [] });
      if (url === `/api/c2c/projects/${PID}/source-changes`) {
        return ok({ projectId: PID, changes, count: changes.length });
      }
      if (url === `/api/c2c/projects/${PID}`) return ok({ id: PID, name: 'BX-301' });
      return ok({});
    });
  }

  it('reports the sections and documents a source is cited in', async () => {
    mockUsageApi([
      source({ id: 1, title: 'protocol.pdf', usage: { sections: 3, documents: 2, changedSections: 0 } }),
    ]);
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('protocol.pdf');
    expect(screen.getByText(/Used in 3 sections · 2 documents/)).toBeTruthy();
  });

  it('says plainly when nothing was written from a source', async () => {
    // An uploaded document nothing cites is the state a reviewer most wants to
    // notice, so it must not read the same as a cited one.
    mockUsageApi([source({ id: 1, title: 'orphan.pdf', usage: { sections: 0, documents: 0, changedSections: 0 } })]);
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('orphan.pdf');
    expect(screen.getByText('Not cited yet')).toBeTruthy();
  });

  it('flags the sections written against content the source no longer has', async () => {
    mockUsageApi([
      source({ id: 1, title: 'moved.pdf', usage: { sections: 4, documents: 1, changedSections: 2 } }),
    ]);
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('moved.pdf');
    expect(screen.getByText(/2 written against older content/)).toBeTruthy();
  });

  it('shows nothing rather than a zero when the server sends no usage field', async () => {
    // An older server is not the same fact as "cited nowhere". Guessing either
    // way would be the fabrication this surface exists to avoid.
    mockUsageApi([source({ id: 1, title: 'unknown.pdf' })]);
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('unknown.pdf');
    expect(screen.queryByText('Not cited yet')).toBeNull();
    expect(screen.queryByText(/Used in/)).toBeNull();
  });

  it('names the affected sections when a source has changed under them', async () => {
    mockUsageApi(
      [source({ id: 7, title: 'protocol-v3.pdf', usage: { sections: 1, documents: 1, changedSections: 1 } })],
      [
        {
          citationId: 'c-1',
          sectionId: 's-1',
          sectionCode: 'P.1',
          sectionTitle: 'Composition',
          documentTitle: 'CTD 3.2.P',
          sourceId: 7,
          sourceTitle: 'protocol-v3.pdf',
          citedAt: '2026-07-01T00:00:00Z',
        },
      ],
    );
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText(/1 section in this project was drafted from a source that has since changed/);
    expect(screen.getByText(/CTD 3\.2\.P · P\.1/)).toBeTruthy();
    // The platform reports; it does not silently regenerate regulated text.
    expect(screen.getByText(/Nothing has been rewritten/)).toBeTruthy();
  });

  it('shows no change banner when nothing is stale', async () => {
    mockUsageApi([source({ id: 1, usage: { sections: 1, documents: 1, changedSections: 0 } })]);
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('protocol-v2.pdf');
    expect(screen.queryByText(/drafted from a source that has since changed/)).toBeNull();
  });
});

/**
 * The count is of current sources, and a full window says so.
 * Found by the 2026-09-24 Vault-against-Veeva mapping: a re-uploaded file was
 * counted twice (its retired revision and its successor), and the list stopped
 * at 200 with nothing said.
 */
describe('ProjectHome — data room counts', () => {
  it('counts a re-uploaded file once', async () => {
    mockApi(() => ok({ projectId: PID, unscoped: [], window: { shown: 2, truncated: false }, sources: [
      source({ id: 1, title: 'protocol-v1.pdf', isCurrent: false }),
      source({ id: 2, title: 'protocol-v2.pdf', isCurrent: true }),
    ] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('protocol-v2.pdf');
    expect(document.body.textContent).toMatch(/(^|\D)1 source · 1 readable/);
    expect(document.body.textContent).not.toMatch(/(^|\D)2 sources/);
  });

  /* What the catalog found a source is (S3), as facts: only those it found. */
  it('shows what the catalog found: protocol, registry id, data cut-off, and a table\'s CDISC domain', async () => {
    mockApi(() => ok({ projectId: PID, unscoped: [], total: 2, currentTotal: 2, sources: [
      source({ id: 1, title: 'csr.pdf', catalog: { studyRef: 4, trialRegistryIdentifier: 'NCT04567890', protocolNumber: 'BX-301-02',
        documentDate: '2025-03-14', dataCutDate: '2024-12-31', dataset: null } }),
      source({ id: 2, title: 'ae.csv', catalog: { studyRef: null, trialRegistryIdentifier: null, protocolNumber: null, documentDate: null,
        dataCutDate: null, dataset: { format: 'csv', tableCount: 1, tables: [{ name: 'ae.csv', standard: 'SDTM', domain: 'AE', rowCount: 340, columnCount: 23 }] } } }),
    ] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('csr.pdf');
    const lines = screen.getAllByTestId('source-catalog').map((e) => e.textContent);
    expect(lines).toEqual(['Protocol BX-301-02 · NCT04567890 · data cut-off 2024-12-31', 'SDTM AE · 23 columns · 340 rows']);
  });

  /* The server counts the whole room (currentTotal) and pages; nothing is a floor. */
  it('a full page shows the exact total and pages to the older sources', async () => {
    mockApi((url) => url.includes('offset=200')
      ? ok({ projectId: PID, unscoped: [], total: 201, currentTotal: 201, window: { shown: 1, truncated: false },
          sources: [source({ id: 3, title: 'oldest.pdf' })] })
      : ok({ projectId: PID, unscoped: [], total: 201, currentTotal: 201, window: { shown: 2, truncated: true },
          sources: [source({ id: 1, title: 'a.pdf' }), source({ id: 2, title: 'b.pdf' })] }));
    renderOnEvidence(<ProjectHome {...props()} />);
    await screen.findByText('a.pdf');
    expect(document.body.textContent).toMatch(/201 sources/);
    expect(document.body.textContent).not.toMatch(/\+ sources/);
    expect(document.body.textContent).toMatch(/showing 1.2\)/);
    fireEvent.click(screen.getByText('Older sources'));
    await screen.findByText('oldest.pdf');
    expect(screen.getByText('Newer sources')).toBeTruthy();
  });
});
