// @vitest-environment jsdom
/** Real intake/auth/shell owners; only HTTP and saved records are synthetic. */
import React from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { AuthoringSourceImportData, AuthoringSourceImportPreviewData, BinaryImportOrigin, WorkflowImportSource } from '@shared/authoring/source-import';
import { authService } from '@/services/portal/authService';
import { clearAuthToken, setAuthToken } from '@/utils/authToken';
const apiRequest = vi.hoisted(() => vi.fn());
vi.mock('@/lib/queryClient', async original => ({ ...await original<typeof import('@/lib/queryClient')>(), apiRequest }));
import { SourceImportDialog } from '../SourceImportDialog';
import { clearShellProject, publishShellProject } from '../../shellProject';

const PROGRAM = '11111111-1111-4111-8111-111111111781';
const OTHER = '11111111-1111-4111-8111-111111111782';
const DOC = '22222222-2222-4222-8222-222222222781';
const SECTION = '33333333-3333-4333-8333-333333333781';
const SOURCE = { kind: 'data-room' as const, sourceId: 42 };
const WORKFLOW: WorkflowImportSource = { kind: 'csr', jobId: 14, sectionNumbers: ['11'] };
const HASH = 'ab'.repeat(32);
const ACTOR = { id: '7', organizationId: '12', roles: ['admin'], permissions: ['governed:write'] };
const bearer = (visit = 'initial', id = 7) => `fixture.${btoa(JSON.stringify({ userId: id, organizationId: 12, visit }))}.synthetic`;
const response = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
const success = (data: unknown) => response({ success: true, data });
function deferred<T>() { let resolve!: (value: T) => void; return { promise: new Promise<T>(done => { resolve = done; }), resolve }; }
const binaryOrigin: BinaryImportOrigin = { kind: 'data-room', id: '42', programId: PROGRAM, title: 'Saved diagnostics evidence',
  fileName: 'evidence.pdf', mimeType: 'application/pdf', sha256: HASH, documentType: 'Report', sectionCode: null, conversion: 'extracted-text' };
const preview: AuthoringSourceImportPreviewData = { preview: true, fingerprint: HASH,
  origin: { kind: 'csr', id: '14', selection: WORKFLOW, programId: PROGRAM, title: 'Saved CSR', version: 'v1',
    documentType: null, sectionCode: null, fingerprint: HASH, conversion: 'ich-e3-sections', gaps: [],
    sourceScope: { level: 'program', programId: PROGRAM, projectId: 2 }, association: { mode: 'recorded', reason: null },
    sectionOrigins: [{ code: 'CSR_11', sourceRowId: '31', contentSha256: HASH, originalAuthorship: 'unknown', model: null, modelEvidence: 'unrecorded' }] },
  sections: [{ code: 'CSR_11', title: 'Efficacy', contentSha256: HASH }], gaps: [], warnings: [], target: { programId: PROGRAM, projectId: 2 },
  association: { mode: 'recorded', required: false, reasonRequired: false, sourceProgramId: PROGRAM, sourceProjectId: 2, targetProgramId: PROGRAM } };
function saved(workflow = false): AuthoringSourceImportData {
  const origin = workflow ? preview.origin : binaryOrigin;
  return { doc: { id: DOC, title: origin.title, tenant_id: 12, client_program_id: PROGRAM, created_by: 7,
    status: 'DRAFT', module: null, product_code: null, updated_at: '2026-10-23T00:00:00Z', section_count: 1,
    c2c_document_id: null, readScope: 'document', sourceMetadataState: 'available',
    provenance: { source: 'import', importSource: { ...origin, reason: 'Review saved source evidence', warnings: [] } } },
    sections: [{ id: SECTION, doc_id: DOC, tenant_id: 12, code: workflow ? 'CSR_11' : 'source.1', title: 'Saved section',
      content: '<p>Recorded source text</p>', order_index: 0, updated_at: null }], origin, warnings: [], reused: false };
}
function dialog(props: Partial<React.ComponentProps<typeof SourceImportDialog>> = {}) {
  return <SourceImportDialog programId={PROGRAM} source={SOURCE} title="Saved evidence" onClose={() => {}} {...props} />;
}
function create() {
  fireEvent.change(screen.getByLabelText('Reason for creating a working copy'), { target: { value: 'Review saved source evidence' } });
  fireEvent.click(screen.getByRole('button', { name: 'Create working copy' }));
}
function changeOwner(kind: string) {
  if (kind === 'account') act(() => authService.setToken(bearer('other-account', 8), { ...ACTOR, id: '8' }, 'other', 3600));
  if (kind === 'session') act(() => authService.setToken(bearer('replacement'), ACTOR, 'replacement', 3600));
  if (kind === 'bearer') act(() => setAuthToken(bearer('unadopted')));
  if (kind === 'project') act(() => { publishShellProject({ id: OTHER }); publishShellProject({ id: PROGRAM }); });
}
async function refresh() {
  vi.stubGlobal('fetch', vi.fn(async () => response({ accessToken: bearer('refreshed'), refreshToken: 'rotated', expiresIn: 3600 })));
  await act(async () => { expect(await authService.refreshToken()).toBe(true); });
}
const typedUnknown = (overrides: Record<string, unknown> = {}) => ({ success: false, ok: false, code: 'AUTHORING_CREATE_COMMIT_UNCONFIRMED',
  creationOutcome: 'unconfirmed', retryAllowed: false, error: 'Check the original working document before creating another copy.',
  recovery: { documentId: DOC, organizationId: 12, programId: PROGRAM }, ...overrides });
function installReads(data = saved()) {
  apiRequest.mockImplementation(async (method: string, path: string) => {
    if (method !== 'GET') throw new Error('No additional import write was authorized');
    const url = new URL(path, 'http://localhost');
    if (url.pathname === '/api/authoring/docs') return response({ success: true, documents: [{ ...data.doc, program_id: PROGRAM }] });
    if (url.pathname === `/api/authoring/docs/${DOC}`) return response({ success: true, document: data.doc, access: { edit: { allowed: true } } });
    if (url.pathname === `/api/authoring/docs/${DOC}/sections`) return response({ success: true, sections: data.sections, readScope: 'document' });
    throw new Error(`Unexpected recovery read ${path}`);
  });
}
beforeEach(() => {
  authService.endSession(null); clearAuthToken(); localStorage.clear(); sessionStorage.clear();
  authService.setToken(bearer(), ACTOR, 'fixture-refresh', 3600); publishShellProject({ id: PROGRAM }); apiRequest.mockReset();
});
afterEach(() => { cleanup(); authService.endSession(null); clearAuthToken(); clearShellProject(); localStorage.clear(); sessionStorage.clear(); vi.unstubAllGlobals(); });

describe('source intake owns one signed-in source/project visit', () => {
  it.each(['account', 'session', 'bearer', 'project'])('discards a late workflow preview after %s replacement', async kind => {
    const pending = deferred<Response>(); apiRequest.mockReturnValue(pending.promise); render(dialog({ source: WORKFLOW }));
    changeOwner(kind); await act(async () => { pending.resolve(success(preview)); await pending.promise; });
    expect(screen.queryByTestId('workflow-import-preview')).toBeNull();
    expect(screen.queryByLabelText('Reason for creating a working copy')).toBeNull();
    expect(screen.getByRole('button', { name: 'Close' })).toBeTruthy();
  });
  it.each(['account', 'session', 'bearer', 'project'])('discards a late saved receipt after %s replacement', async kind => {
    const pending = deferred<Response>(); apiRequest.mockReturnValue(pending.promise); const onOpenDocument = vi.fn(); render(dialog({ onOpenDocument }));
    create(); changeOwner(kind); await act(async () => { pending.resolve(success(saved())); await pending.promise; });
    expect(screen.queryByTestId('source-import-result')).toBeNull(); expect(onOpenDocument).not.toHaveBeenCalled();
  });
  it('checks ownership again after a successful response body is delayed', async () => {
    const body = deferred<unknown>(); apiRequest.mockResolvedValue({ ok: true, status: 201, json: () => body.promise });
    render(dialog()); create(); await act(async () => { await Promise.resolve(); }); changeOwner('account');
    await act(async () => { body.resolve({ success: true, data: saved() }); await body.promise; });
    expect(screen.queryByTestId('source-import-result')).toBeNull();
  });
  it('keeps the original request headers and accepts a canonical refreshed response', async () => {
    const pending = deferred<Response>(); apiRequest.mockReturnValue(pending.promise); render(dialog()); create();
    const original = bearer(); await refresh(); await act(async () => { pending.resolve(success(saved())); await pending.promise; });
    expect(screen.getByTestId('source-import-result')).toBeTruthy();
    expect(apiRequest.mock.calls[0][3]).toEqual({ Authorization: `Bearer ${original}`, 'x-organization-id': '12' });
  });
  it('keeps a preview and reason through canonical refresh, then uses the adopted bearer for the next create', async () => {
    apiRequest.mockResolvedValueOnce(success(preview)).mockResolvedValueOnce(success(saved(true))); render(dialog({ source: WORKFLOW }));
    await screen.findByTestId('workflow-import-preview');
    fireEvent.change(screen.getByLabelText('Reason for creating a working copy'), { target: { value: 'Review saved source evidence' } });
    await refresh(); expect(screen.getByTestId('workflow-import-preview')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Create working copy' })); await screen.findByTestId('source-import-result');
    expect(apiRequest.mock.calls[1][3]).toEqual({ Authorization: `Bearer ${bearer('refreshed')}`, 'x-organization-id': '12' });
  });
  it.each(['account', 'session', 'bearer', 'project'])('refuses Open for an earlier saved receipt after %s replacement', async kind => {
    apiRequest.mockResolvedValue(success(saved())); const onOpenDocument = vi.fn(); render(dialog({ onOpenDocument }));
    create(); await screen.findByRole('button', { name: 'Open working copy' }); changeOwner(kind);
    const open = screen.queryByRole('button', { name: 'Open working copy' }); if (open) fireEvent.click(open);
    expect(onOpenDocument).not.toHaveBeenCalled(); expect(screen.queryByTestId('source-import-result')).toBeNull();
  });
  it('consults the latest dirty-work hold before opening and preserves the saved copy', async () => {
    apiRequest.mockResolvedValue(success(saved())); const onOpenDocument = vi.fn(); const view = render(dialog({ onOpenDocument }));
    create(); await screen.findByRole('button', { name: 'Open working copy' }); view.rerender(dialog({ onOpenDocument, openBlocked: true }));
    fireEvent.click(screen.getByRole('button', { name: 'Open working copy' })); expect(onOpenDocument).not.toHaveBeenCalled();
    view.rerender(dialog({ onOpenDocument, openBlocked: false })); fireEvent.click(screen.getByRole('button', { name: 'Open working copy' }));
    expect(onOpenDocument).toHaveBeenCalledWith(DOC);
  });
  it.each(['source', 'unmount'])('does not deliver an old pending create after %s', async kind => {
    const pending = deferred<Response>(); apiRequest.mockReturnValue(pending.promise); const onOpenDocument = vi.fn(); const view = render(dialog({ onOpenDocument }));
    create(); if (kind === 'source') view.rerender(dialog({ source: { kind: 'data-room', sourceId: 43 }, onOpenDocument })); else view.unmount();
    await act(async () => { pending.resolve(success(saved())); await pending.promise; });
    expect(screen.queryByTestId('source-import-result')).toBeNull(); expect(onOpenDocument).not.toHaveBeenCalled();
  });
});

describe('uncertain source creation stays held until an explicit scoped check', () => {
  it.each(['binary', 'workflow'])('holds another %s write and preview replacement after a lost create response', async kind => {
    if (kind === 'workflow') apiRequest.mockResolvedValueOnce(success(preview));
    apiRequest.mockRejectedValueOnce(new Error('Lost response')); render(dialog({ source: kind === 'workflow' ? WORKFLOW : SOURCE }));
    if (kind === 'workflow') await screen.findByTestId('workflow-import-preview'); create();
    const check = await screen.findByRole('button', { name: 'Check working documents' }); const before = apiRequest.mock.calls.length;
    const createButton = screen.queryByRole('button', { name: 'Create working copy' }); if (createButton) fireEvent.click(createButton);
    const reload = screen.queryByRole('button', { name: 'Reload source preview' }); if (reload) fireEvent.click(reload);
    expect(apiRequest.mock.calls).toHaveLength(before); expect(check).toBeTruthy();
    expect((screen.getByRole('button', { name: 'Close' }) as HTMLButtonElement).disabled).toBe(false);
  });
  it('reads generic inventory without inferring a saved receipt or automatically repeating creation', async () => {
    apiRequest.mockRejectedValueOnce(new Error('Lost response')); render(dialog()); create();
    const check = await screen.findByRole('button', { name: 'Check working documents' }); installReads(); fireEvent.click(check);
    await waitFor(() => expect(screen.getByText(/does not identify which request/i)).toBeTruthy());
    expect(screen.queryByRole('button', { name: 'Open working copy' })).toBeNull();
    expect(apiRequest.mock.calls.filter(([method]) => method === 'POST')).toHaveLength(1);
    expect(apiRequest.mock.calls.filter(([method]) => method === 'GET')).toHaveLength(1);
    expect((screen.getByRole('button', { name: 'Create working copy' }) as HTMLButtonElement).disabled).toBe(false);
  });
  it('recovers an identified import through exact current records and offers a separate Open', async () => {
    apiRequest.mockResolvedValueOnce(response(typedUnknown(), 503)); const onOpenDocument = vi.fn(); render(dialog({ onOpenDocument })); create();
    const check = await screen.findByRole('button', { name: 'Check working documents' }); installReads(); fireEvent.click(check);
    const open = await screen.findByRole('button', { name: 'Open working copy' }); expect(onOpenDocument).not.toHaveBeenCalled();
    const reads = apiRequest.mock.calls.filter(([method]) => method === 'GET'); expect(reads).toHaveLength(3);
    for (const [, path, , headers] of reads) { expect(new URL(path, 'http://localhost').searchParams.get('programId')).toBe(PROGRAM);
      expect(headers).toEqual({ Authorization: `Bearer ${bearer()}`, 'x-organization-id': '12' }); }
    fireEvent.click(open); expect(onOpenDocument).toHaveBeenCalledWith(DOC);
    expect(apiRequest.mock.calls.filter(([method]) => method === 'POST')).toHaveLength(1);
  });
  it.each([
    { recovery: { documentId: DOC, organizationId: 99, programId: PROGRAM } },
    { recovery: { documentId: 'not-a-uuid', organizationId: 12, programId: PROGRAM } },
    { recovery: { documentId: DOC, organizationId: 12, programId: OTHER } },
  ])('keeps a recognized but foreign/malformed recovery identity held: %j', async invalid => {
    apiRequest.mockResolvedValueOnce(response(typedUnknown(invalid), 503)); render(dialog()); create();
    const check = await screen.findByRole('button', { name: 'Check working documents' }); installReads(); fireEvent.click(check);
    await waitFor(() => expect((check as HTMLButtonElement).disabled).toBe(false));
    expect(screen.queryByRole('button', { name: 'Open working copy' })).toBeNull();
    const createButton = screen.queryByRole('button', { name: 'Create working copy' }); if (createButton) fireEvent.click(createButton);
    expect(apiRequest.mock.calls.filter(([method]) => method === 'POST')).toHaveLength(1);
  });
  it('leaves a failed preview retryable without creating a document', async () => {
    apiRequest.mockRejectedValueOnce(new Error('Preview unavailable')).mockResolvedValueOnce(success(preview)); render(dialog({ source: WORKFLOW }));
    fireEvent.click(await screen.findByRole('button', { name: 'Reload source preview' })); await screen.findByTestId('workflow-import-preview');
    expect(apiRequest.mock.calls.every(([, , payload]) => payload.previewOnly === true)).toBe(true);
    expect(screen.queryByRole('button', { name: 'Check working documents' })).toBeNull();
  });
});
