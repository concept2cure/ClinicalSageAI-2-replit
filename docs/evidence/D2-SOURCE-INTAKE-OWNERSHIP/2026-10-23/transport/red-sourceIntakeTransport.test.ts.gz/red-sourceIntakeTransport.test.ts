// @vitest-environment jsdom
/** Canonical receipt and intake transports; all HTTP remains synthetic. */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { AuthoringSourceImportData, AuthoringSourceImportPreviewData, WorkflowImportOrigin, WorkflowImportSource } from '@shared/authoring/source-import';
const apiRequest = vi.hoisted(() => vi.fn());
vi.mock('@/lib/queryClient', async original => ({ ...await original<typeof import('@/lib/queryClient')>(), apiRequest }));
import { readWorkflowImportResult } from '../../authoringHandoff';

const PROGRAM = '11111111-1111-4111-8111-111111111791';
const DOC = '22222222-2222-4222-8222-222222222791';
const SECTION = '33333333-3333-4333-8333-333333333791';
const HASH = 'a'.repeat(64);
const source: WorkflowImportSource = { kind: 'csr', jobId: 44, sectionNumbers: ['11'] };
const origin: WorkflowImportOrigin = { kind: 'csr', id: '44', programId: PROGRAM, title: 'Saved CSR',
  documentType: null, sectionCode: null, fingerprint: HASH, selection: source, gaps: [], version: '1',
  conversion: 'ich-e3-sections', sourceScope: { level: 'project', programId: null, projectId: 42 },
  association: { mode: 'recorded', reason: null }, sectionOrigins: [{ code: '11.1', sourceRowId: 'csr_section_outputs:17',
    contentSha256: HASH, originalAuthorship: 'unknown', model: null, modelEvidence: 'unrecorded' }] };
const preview: AuthoringSourceImportPreviewData = { preview: true, origin, fingerprint: HASH,
  sections: [{ code: '11.1', title: 'Efficacy', contentSha256: HASH }], gaps: [], warnings: [],
  target: { programId: PROGRAM, projectId: 42 }, association: { mode: 'recorded', required: false,
    reasonRequired: false, sourceProgramId: null, sourceProjectId: 42, targetProgramId: PROGRAM } };
function copy(): AuthoringSourceImportData {
  return { doc: { id: DOC, title: 'Saved CSR working copy', tenant_id: 7, client_program_id: PROGRAM,
    provenance: { source: 'import', importSource: origin } }, sections: [{ id: SECTION, doc_id: DOC,
    tenant_id: 7, code: '11.1', title: 'Efficacy', content: '<p>Saved observations.</p>', order_index: 0 }],
    origin, warnings: [], reused: false };
}
const read = (data: AuthoringSourceImportData) => readWorkflowImportResult({ success: true, data }, PROGRAM, source, preview);
beforeEach(() => apiRequest.mockReset());

describe('fresh source intake receipts require actual saved row identity', () => {
  it('retains a valid exact saved document and section receipt', () => {
    const data = copy(); expect(read(data)).toBe(data);
  });
  it.each(['document-id', 'section-id', 'missing-program', 'missing-tenant', 'section-parent', 'section-tenant', 'content', 'order', 'provenance'] as const)
    ('refuses malformed fresh %s instead of offering an unrelated or incomplete working copy', field => {
      const data = copy();
      if (field === 'document-id') data.doc.id = 'not-a-document-uuid';
      if (field === 'section-id') data.sections[0].id = 'not-a-section-uuid';
      if (field === 'missing-program') delete data.doc.client_program_id;
      if (field === 'missing-tenant') delete data.doc.tenant_id;
      if (field === 'section-parent') data.sections[0].doc_id = '44444444-4444-4444-8444-444444444791';
      if (field === 'section-tenant') data.sections[0].tenant_id = 8;
      if (field === 'content') data.sections[0].content = { unavailable: true };
      if (field === 'order') data.sections[0].order_index = 0.5;
      if (field === 'provenance') delete data.doc.provenance;
      expect(read(data)).toBeNull();
    });
});
