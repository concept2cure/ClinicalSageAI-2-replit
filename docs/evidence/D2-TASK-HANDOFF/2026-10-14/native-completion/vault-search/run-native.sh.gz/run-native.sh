#!/usr/bin/env bash
set -euo pipefail
cd /workspace/concept2cure
source /workspace/scratch/task-handoff-native/env.sh
export PATH=/workspace/scratch/node22/node-v22.23.3-linux-x64/bin:$PATH
export NODE_OPTIONS=--max-old-space-size=4096
# Optional embeddings refuse before transport except the suite's explicit localhost stub.
export EMBEDDING_PROVIDER=local EMBEDDING_LOCAL_BASE_URL= LOCAL_AI_BASE_URL=
export OPENAI_API_KEY= OPENAI_BASE_URL= OPENAI_API_BASE= ANTHROPIC_API_KEY= ANTHROPIC_BASE_URL=
export AZURE_OPENAI_API_KEY= AZURE_OPENAI_ENDPOINT= GEMINI_API_KEY= GOOGLE_API_KEY=
export DEEPSEEK_API_KEY= XAI_API_KEY= GROQ_API_KEY= MISTRAL_API_KEY= COHERE_API_KEY=
npx vitest run --config vitest.db.config.ts \
  tests/db/ana-vault-search-no-key.dbtest.ts \
  tests/db/vault-chunking-off.dbtest.ts \
  tests/db/vault-document-relationships.dbtest.ts \
  tests/db/vault-fixity.dbtest.ts \
  tests/db/vault-library-search.dbtest.ts \
  tests/db/vault-passage-search-keyless.dbtest.ts \
  tests/db/vault-passage-search.dbtest.ts \
  tests/db/vault-reupload.dbtest.ts \
  --reporter=verbose --reporter=json \
  --outputFile=/workspace/scratch/task-handoff-vault-native/first-native.json \
  > /workspace/scratch/task-handoff-vault-native/first-native.log 2>&1
