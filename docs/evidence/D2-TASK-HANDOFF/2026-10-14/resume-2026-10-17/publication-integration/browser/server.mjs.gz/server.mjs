import { createServer } from '/workspace/concept2cure/node_modules/vite/dist/node/index.js';
import { resolve } from 'node:path';

const root = '/workspace/concept2cure';
const probe = resolve(root, 'docs/evidence/D2-EDITOR-INTEGRATION/2026-10-17/assembly-build/canonical-integration/browser/probe.tsx');
const server = await createServer({ root, configFile: false,
  plugins: [{ name: 'scratch-assembly-leave-host', enforce: 'pre', transform(code, id) {
    if (id.split('?')[0] !== probe) return null;
    const original = 'onBack: () => {}, hostShowsBack: true';
    const originalSession = "await authService.adoptSession('synthetic-assembly-browser-session');";
    const originalFixtureImport = "import { DOC, PROGRAM, documentRow, program } from './mock-api.mjs';";
    if (![original, originalSession, originalFixtureImport].every(part => code.includes(part))) {
      throw new Error('The retained probe host changed; inspect before adapting it.');
    }
    const syntheticSession = `const syntheticIssuedAt = Math.floor(Date.now() / 1000);
const syntheticClaims = { sub: String(actor.id), userId: Number(actor.id), organizationId: Number(actor.organizationId),
  iat: syntheticIssuedAt, exp: syntheticIssuedAt + 3600, jti: 'synthetic-assembly-leave-browser' };
const syntheticToken = [btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' })), btoa(JSON.stringify(syntheticClaims)),
  'synthetic-fixture-signature'].map(part => part.replace(/\\+/g, '-').replace(/\\//g, '_').replace(/=+$/g, '')).join('.');
if (!await authService.adoptSession(syntheticToken, false, { userId: String(actor.id), organizationId: String(actor.organizationId) })) {
  throw new Error('The synthetic browser session did not confirm its exact fixture actor.');
}`;
    return code.replace(originalFixtureImport, "import { DOC, PROGRAM, documentRow, program, actor } from './mock-api.mjs';")
      .replace(originalSession, syntheticSession).replace(original,
      "onBack: () => window.assemblyNavigation.push({ route: 'host-back', target: peekEditorTarget() }), hostShowsBack: false")
      + "\nimport { surfaceLeaveRefusal } from '/client/src/concept2cure/v2/navParams';\nObject.assign(window, { assemblyLeaveRefusal: surfaceLeaveRefusal });\n";
  } }],
  resolve: { alias: { '@': root + '/client/src', '@shared': root + '/shared', react: root + '/node_modules/react',
    'react-dom': root + '/node_modules/react-dom', '@tanstack/react-query': root + '/node_modules/@tanstack/react-query' } },
  server: { host: '127.0.0.1', port: 5201, strictPort: true, watch: null },
  optimizeDeps: { include: ['react', 'react-dom/client', '@tanstack/react-query'] } });
await server.listen();
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await server.close(); process.exit(0); });
process.stdout.write(`Scratch assembly leave fixture pid ${process.pid} http://127.0.0.1:5201\n`);
