/**
 * AnA RI — Intelligence Orchestrator
 *
 * Dynamically orchestrates AnA's internal reasoning modes based on
 * user intent, document context, and risk level. This is the brain
 * that makes AnA feel like a single intelligent operator rather than
 * a toolbox of modes.
 *
 * @module server/services/ana-ri/orchestrator
 */

import {
  buildAnaRISystemPrompt,
  getIntelligencePriorities,
  type AnaRIPromptOptions,
  type IntentLens,
  type RoleIntelligencePriorities,
  type UserRole,
  type WorkstreamContext,
  type WorkstreamHandoff,
  type WorkstreamPhase,
  type WorkstreamType,
} from './persona.js';
import { buildDeficiencyContext, type SubmissionType } from './deficiency-taxonomy.js';
import { resolveToDeficiencyType, resolveToRegistryEntry, getSubmissionTypeContext } from '../../../shared/regulatory/submission-type-bridge.js';
import { buildDocumentActionContext, type DocumentActionType } from './document-actions.js';
import {
  detectDocumentTemplate,
  buildDocumentTemplateBlock,
  type DetectedDocumentTemplate,
} from './document-templates.js';
import { buildRoleAdaptiveContext } from './role-adapter.js';
import { buildCommandContextForPrompt } from './command-executor.js';
import {
  getProjectIntelligence,
  computeReadinessScore,
  getProjectSignals,
  enrichProjectIntelligence,
  type ProjectIntelligenceSummary,
  type RiskFactor,
  type OpenQuestion,
  type KeyDecision,
  type LearnedInsight,
  type ReadinessContext,
  type IntelligenceUpdatePayload,
  type SignalSummary,
} from '../intelligence/index.js';
import { describeReadiness } from '../intelligence/readiness-scoring-engine.js';
import { getGateway } from '../ai-gateway/index.js';
import { sectionIdentityLine } from '../ind/ctd/index.js';
import { statedTypeLine } from './open-document.js';
import { sanitizeLine } from './surface-context-block.js';

// ─────────────────────────────────────────────────────────────────────────────
// The open CTD section, named from the canonical overlay
// ─────────────────────────────────────────────────────────────────────────────

/**
 * The line naming the open section in the "ACTIVE SECTION" block.
 *
 * This was a hand-kept table here, and it told AnA that 2.7.3 is "Summary of
 * Clinical Pharmacodynamics", 2.7.4 efficacy, 2.7.5 safety and 1.14 the
 * environmental assessment — none of which ICH M4E or FDA's Module 1 says. It
 * now reads CTD_AUTHORING_GUIDANCE through the same renderer as the stream's
 * section playbook (ind/ctd/section-brief.ts). The full brief rides on that
 * playbook; this line only says which section is open, so the two blocks do
 * not repeat each other. Null for a code nothing registers.
 */
export function getSectionGuidance(sectionCode: string): string | null {
  return sectionIdentityLine(sectionCode);
}

// ─────────────────────────────────────────────────────────────────────────────
// Intent Detection
// ─────────────────────────────────────────────────────────────────────────────

interface DetectedIntent {
  lens: IntentLens;
  confidence: number;
  signals: string[];
}

/** Keyword patterns for intent detection */
const INTENT_PATTERNS: Record<IntentLens, RegExp[]> = {
  audit: [
    /\b(audit|review|check|assess|evaluate|examine|inspect|validate|verify)\b/i,
    /\b(gap[s]?|miss(?:ing|ed)|incomplete|deficien|weakness|issue[s]?)\b/i,
    /\b(compli(?:ance|ant)|conform|non-?conform)\b/i,
    /\blike a reviewer\b/i,
    /\bwhat (?:would|will|might) (?:a |the )?(?:reviewer|fda|ema)\b/i,
  ],
  improve: [
    /\b(improve|enhance|strengthen|rewrite|revise|refine|polish|edit)\b/i,
    /\b(better|stronger|clearer|more (?:persuasive|compelling|defensible))\b/i,
    /\b(fix|correct|update|optimize)\b/i,
    /\bmedical writ(?:ing|er)\b/i,
    /\bmake (?:it|this) (?:better|stronger|clearer)\b/i,
  ],
  risk: [
    /\b(risk[s]?|reject(?:ion|ed)?|deficien(?:cy|cies)|rtf|refuse to file)\b/i,
    /\b(complete response|crl|information request|clinical hold)\b/i,
    /\b(what (?:could|might|will) go wrong)\b/i,
    /\b(vulnerabilit|threat|danger|concern|worry)\b/i,
    /\b(predict|anticipate|foresee|preempt)\b/i,
  ],
  strategy: [
    /\b(strateg(?:y|ic|ize)|pathway|approach|plan|roadmap)\b/i,
    /\b(pre-?(?:ind|sub|submission)|meeting|interaction)\b/i,
    /\b(accelerat(?:ed|ion)|breakthrough|fast track|priority review|orphan)\b/i,
    /\b(regulatory pathway|submission (?:plan|strategy|timeline))\b/i,
    /\b(fda vs|ema vs|region|global)\b/i,
    /\b(cms|medicare|medicaid|payer|coverage|reimbursement|coding strategy)\b/i,
  ],
  compare: [
    /\b(compare|comparison|versus|vs\.?|differ(?:ence|ent)|side.by.side)\b/i,
    /\b(predicate|equivalent|similar (?:product|device|drug))\b/i,
    /\b(benchmark|competitive|landscape)\b/i,
    /\b(version|revision|change[s]? (?:between|from|since))\b/i,
  ],
  auto: [], // Never matched — fallback
};

/**
 * Detect the user's intent from their message.
 * Returns the best-matching lens with confidence score.
 */
export type { IntentLens, UserRole };

export function detectIntent(message: string): DetectedIntent {
  const scores: Array<{ lens: IntentLens; score: number; signals: string[] }> = [];

  for (const [lens, patterns] of Object.entries(INTENT_PATTERNS)) {
    if (lens === 'auto') continue;
    const signals: string[] = [];
    let score = 0;
    for (const pattern of patterns) {
      const match = message.match(pattern);
      if (match) {
        score += 1;
        signals.push(match[0]);
      }
    }
    if (score > 0) {
      scores.push({ lens: lens as IntentLens, score, signals });
    }
  }

  if (scores.length === 0) {
    return { lens: 'auto', confidence: 0, signals: [] };
  }

  // Sort by score descending
  scores.sort((a, b) => b.score - a.score);
  const best = scores[0];
  const maxPossible = INTENT_PATTERNS[best.lens].length;
  const confidence = Math.min(best.score / Math.max(maxPossible, 1), 1);

  return { lens: best.lens, confidence, signals: best.signals };
}

// ─────────────────────────────────────────────────────────────────────────────
// Submission Type Detection
// ─────────────────────────────────────────────────────────────────────────────

const SUBMISSION_PATTERNS: Record<SubmissionType, RegExp[]> = {
  ind: [/\bIND\b/, /\binvestigational new drug\b/i, /\bpre-?IND\b/i, /\b21 CFR 312\b/, /\bCTA\b/, /\bclinical trial a(?:pplication|uthoris?ation)\b/i, /\bCTN\b/, /\bclinical trial notification\b/i],
  nda: [/\bNDA\b/, /\bnew drug application\b/i, /\b21 CFR 314\b/, /\bMAA\b/, /\bmarketing authori[sz]ation\b/i, /\bNDS\b/, /\bnew drug submission\b/i, /\bJNDA\b/, /\bmarket(?:ing)? approval\b/i],
  bla: [/\bBLA\b/, /\bbiologics? license\b/i, /\b21 CFR 601\b/, /\bbiosimilar\b/i],
  '510k': [/\b510\(?k\)?\b/, /\bsubstantial equivalence\b/i, /\bpredicate\b/i],
  pma: [/\bPMA\b/, /\bpremarket approval\b/i],
  de_novo: [/\bde novo\b/i, /\bnovel device\b/i],
  cer: [/\bCER\b/, /\bclinical evaluation report\b/i, /\bMEDDEV\b/i, /\bEU MDR\b/i, /\bIVDR\b/i, /\btechnical documentation\b/i],
  ectd: [/\beCTD\b/, /\bcommon technical document\b/i, /\bModule [1-5]\b/],
  general: [], // Never matched
};

/**
 * Detect submission type from message content.
 * Uses both pattern matching AND registry resolution so that international
 * types (EU_MAA, CA_NDS, JP_MKT_APPROVAL, etc.) map to the nearest
 * deficiency-taxonomy-compatible type for intelligence activation.
 */
export function detectSubmissionType(message: string): SubmissionType | null {
  // 1. Pattern match first (fast path for common types)
  for (const [type, patterns] of Object.entries(SUBMISSION_PATTERNS)) {
    if (type === 'general') continue;
    for (const pattern of patterns) {
      if (pattern.test(message)) {
        return type as SubmissionType;
      }
    }
  }

  // 2. Try resolving registry IDs mentioned in the message (e.g. "US_IND", "EU_MAA")
  const registryIdPattern = /\b([A-Z]{2,6}_[A-Z0-9_]{2,30})\b/g;
  let match;
  while ((match = registryIdPattern.exec(message)) !== null) {
    const entry = resolveToRegistryEntry(match[1]);
    if (entry) {
      return resolveToDeficiencyType(entry.id);
    }
  }

  return null;
}

/**
 * Resolve a registry ID or project submission type to a deficiency-compatible
 * type. This is the bridge that ensures ALL 158+ filing types get intelligence.
 * Called when the project's submissionType or registryId is known (from DB).
 */
export function resolveProjectSubmissionType(submissionTypeOrRegistryId: string): SubmissionType {
  return resolveToDeficiencyType(submissionTypeOrRegistryId);
}

// ─────────────────────────────────────────────────────────────────────────────
// Orchestrator
// ─────────────────────────────────────────────────────────────────────────────

export interface OrchestratorInput {
  message: string;
  /** Explicit intent lens from UI (overrides auto-detection) */
  intentLens?: IntentLens;
  /** User role (from profile or context) */
  userRole?: UserRole;
  /** Response language (from the client's UI language). Defaults to English. */
  language?: AnaRIPromptOptions['language'];
  /** Project context */
  projectContext?: AnaRIPromptOptions['projectContext'];
  /**
   * Document context. Extends the persona prompt's document context with the
   * optional `title` and `status` fields the orchestrator reads when building
   * grounding-context metadata (the system prompt itself only uses the base
   * documentType/section/module fields).
   */
  documentContext?: AnaRIPromptOptions['documentContext'] & {
    title?: string;
    status?: string;
  };
  /** Submission type override */
  submissionType?: SubmissionType;
  /** Conversation history for context */
  conversationHistory?: Array<{ role: 'user' | 'assistant'; content: string }>;
  /** Authoring context with optional pre-fetched decision context (_decisionContext) */
  authoringContext?: {
    projectId?: string;
    organizationId?: number;
    sectionCode?: string;
    moduleCode?: string;
    artifactStatus?: string;
    _decisionContext?: Array<{ decision: unknown; receipt?: unknown }>;
    /** Pre-fetched RIM context block (loaded by route layer via preloadRIMContext) */
    _rimContext?: string;
    [key: string]: unknown;
  };
  /** Pre-fetched project intelligence profile (loaded by route layer, injected into system prompt) */
  _projectIntelligenceProfile?: ProjectIntelligenceSummary | null;
  /**
   * Pre-rendered RELATIONAL CONTEXT block — AnA's self-developed notes about
   * this user + project (loaded async by the route layer via
   * relational-profile-service). Drives the per-user personality adaptation.
   */
  _relationalOverlay?: string | null;
  /**
   * Pre-rendered EXTERNAL INTELLIGENCE block — fresh regulatory-agency and
   * study-methodology findings from the nightly sweep (loaded async by the
   * route layer via external-intelligence-service).
   */
  _externalIntelBlock?: string | null;
  /**
   * Pre-rendered REGULATORY DEADLINES block — OVERDUE / DUE-SOON tracked
   * obligations for the org (loaded async by the route layer via the deadline
   * radar). Lets AnA proactively lead with time-critical risk.
   */
  _deadlineRadarBlock?: string | null;
  /**
   * Pre-rendered SESSION BRIEFING block — first-turn situational reconciliation
   * (deadlines + recent decisions) so AnA can open with where the program stands.
   */
  _sessionBriefingBlock?: string | null;
  /**
   * Pre-rendered OPEN CONTRADICTIONS block — unresolved contradiction-engine
   * findings, severity-first (loaded async by the route layer). Present on
   * every turn while findings are open, because a finding that blocks
   * promotion stays live until someone resolves it — it does not alternate
   * with the briefing/deadline pair.
   */
  _contradictionWatchBlock?: string | null;
  /**
   * Pre-rendered OPEN DOCUMENT block (open-document.ts, via the route prefetch):
   * the type of the document open in front of the person and its outline, from
   * the saved record or a registry-validated surface type.
   */
  _openDocumentBlock?: string | null;
  /** Pre-fetched user feedback patterns from the learning loop (async, injected by chat-context-builder) */
  _feedbackContext?: {
    totalFeedback: number;
    acceptanceRate: number;
    topDismissedTypes: Array<{ type: string; count: number }>;
  } | null;
}

export interface OrchestratorOutput {
  systemPrompt: string;
  detectedIntent: DetectedIntent;
  detectedSubmissionType: SubmissionType | null;
  /** Specific regulatory document type detected from the message (e.g. "CTD Clinical Overview") */
  detectedDocumentTemplate: DetectedDocumentTemplate | null;
  appliedRole: UserRole;
  activeWorkstream: WorkstreamContext;
  workstreamHandoff: WorkstreamHandoff | null;
  /** Suggested document actions based on the interaction */
  suggestedActions: DocumentActionType[];
  /** Grounding context available to AnA for this request */
  groundingContext: {
    hasProjectContext: boolean;
    hasArtifactContext: boolean;
    hasSectionContext: boolean;
    hasWorkflowContext: boolean;
    hasEvidenceContext: boolean;
    hasMemoryContext: boolean;
    documentStatus: string | null;
    enrichmentSources: string[];
    enrichmentFailures: string[];
  };
  /** Metadata about what was orchestrated */
  orchestrationMeta: {
    intentSource: 'explicit' | 'detected' | 'default';
    submissionTypeSource: 'explicit' | 'project_context' | 'detected' | 'none';
    roleSource: 'explicit' | 'default';
    deficiencyContextInjected: boolean;
    documentActionContextInjected: boolean;
    documentTemplateInjected: boolean;
    workstreamContextInjected: boolean;
    workstreamHandoffInjected: boolean;
    projectIntelligenceInjected: boolean;
    rimContextInjected: boolean;
  };
}

/**
 * The core orchestrator — assembles the complete AnA RI system prompt
 * by analyzing the user's message, context, and role.
 */
/**
 * The document context the persona prompt may print. It is client-supplied and
 * lands in the cached system prefix: the type is printed only as a registry id
 * and name (or as "not a registry type"), and section and module as one
 * sanitized line each — never the client's multi-line text.
 */
function promptDocumentContext(doc: OrchestratorInput['documentContext']): AnaRIPromptOptions['documentContext'] {
  if (!doc) return undefined;
  const line = (v: unknown) => (typeof v === 'string' ? sanitizeLine(v, 80) || undefined : undefined);
  const documentType = statedTypeLine(doc.documentType);
  const section = line(doc.section);
  const module = line(doc.module);
  return documentType || section || module ? { documentType, section, module } : undefined;
}

export function orchestrate(input: OrchestratorInput): OrchestratorOutput {
  // 1. Detect intent
  const detectedIntent =
    input.intentLens && input.intentLens !== 'auto'
      ? { lens: input.intentLens, confidence: 1, signals: ['explicit'] }
      : detectIntent(input.message);

  const intentSource =
    input.intentLens && input.intentLens !== 'auto'
      ? ('explicit' as const)
      : detectedIntent.lens !== 'auto'
        ? ('detected' as const)
        : ('default' as const);

  // 2. Detect submission type — cascade: explicit → project context → message detection
  const projectSubmissionType = input.projectContext?.submissionType
    ? resolveToDeficiencyType(input.projectContext.submissionType) as SubmissionType
    : null;
  const detectedSubmissionType = input.submissionType || projectSubmissionType || detectSubmissionType(input.message);
  const submissionTypeSource = input.submissionType
    ? ('explicit' as const)
    : projectSubmissionType
      ? ('project_context' as const)
      : detectedSubmissionType
        ? ('detected' as const)
      : ('none' as const);

  // 3. Determine role
  const appliedRole = input.userRole || 'general';
  const roleSource = input.userRole ? ('explicit' as const) : ('default' as const);

  // 4. Build base system prompt
  const promptOptions: AnaRIPromptOptions = {
    userRole: appliedRole,
    intentLens: detectedIntent.lens,
    language: input.language,
    projectContext: input.projectContext,
    documentContext: promptDocumentContext(input.documentContext),
  };

  const activeWorkstream = detectWorkstream(input, detectedIntent.lens, detectedSubmissionType);
  const workstreamHandoff = detectWorkstreamHandoff(input, activeWorkstream);
  promptOptions.workstreamContext = activeWorkstream;
  if (workstreamHandoff) {
    promptOptions.workstreamHandoff = workstreamHandoff;
  }
  if (input._relationalOverlay && input._relationalOverlay.trim()) {
    promptOptions.relationalContext = input._relationalOverlay;
  }

  let systemPrompt = buildAnaRISystemPrompt(promptOptions);

  // 4a. Inject nightly external intelligence (pre-fetched by route layer):
  //     fresh agency updates + study-methodology findings AnA may surface
  //     when relevant to the user's program.
  if (input._externalIntelBlock && input._externalIntelBlock.trim()) {
    systemPrompt += '\n\n' + input._externalIntelBlock.trim();
  }

  // 4a-bis. Inject proactive regulatory deadlines (pre-fetched by route layer):
  //     OVERDUE / DUE-SOON tracked obligations AnA should surface up front.
  if (input._deadlineRadarBlock && input._deadlineRadarBlock.trim()) {
    systemPrompt += '\n\n' + input._deadlineRadarBlock.trim();
  }

  // 4a-ter. Inject the session-start briefing (pre-fetched by route layer):
  //     a first-turn reconciliation of deadlines + recent decisions. Supersedes
  //     the standalone deadline block on that turn (the prefetch emits only one).
  if (input._sessionBriefingBlock && input._sessionBriefingBlock.trim()) {
    systemPrompt += '\n\n' + input._sessionBriefingBlock.trim();
  }

  // 4a-quater. Inject open contradiction findings (pre-fetched by route layer):
  //     persisted, unresolved contradiction-engine findings — including ones
  //     that BLOCK PROMOTION. Every turn, not just session start: an open
  //     contradiction stays live until it is resolved, not until it is
  //     mentioned once.
  if (input._contradictionWatchBlock && input._contradictionWatchBlock.trim()) {
    systemPrompt += '\n\n' + input._contradictionWatchBlock.trim();
  }

  // 4b. Inject project intelligence profile (pre-fetched by route layer)
  //     Role-based priorities filter WHAT intelligence surfaces, not just tone.
  let projectIntelligenceInjected = false;
  if (input._projectIntelligenceProfile) {
    const rolePriorities = getIntelligencePriorities(appliedRole);
    const profileBlock = formatProjectIntelligenceBlock(input._projectIntelligenceProfile, rolePriorities);
    if (profileBlock) {
      systemPrompt += '\n\n' + profileBlock;
      projectIntelligenceInjected = true;
    }
  }

  // 4b'. The document open in front of the person, resolved by the route from
  //      the saved record — ahead of anything guessed from the message.
  if (input._openDocumentBlock && input._openDocumentBlock.trim()) {
    systemPrompt += '\n\n' + input._openDocumentBlock.trim();
  }

  // 4c. Detect specific regulatory document type and inject its template structure.
  //     This fires ABOVE the intent-lens system — "draft a Clinical Overview" maps
  //     directly to the 2.5 template, bypassing the generic "improve" lens.
  const detectedDocumentTemplate = detectDocumentTemplate(input.message);
  let documentTemplateInjected = false;
  if (detectedDocumentTemplate) {
    const templateBlock = buildDocumentTemplateBlock(detectedDocumentTemplate);
    if (templateBlock) {
      systemPrompt += '\n\n' + templateBlock;
      documentTemplateInjected = true;
    }
  }

  // 5. Inject deficiency context if submission type is known
  let deficiencyContextInjected = false;
  if (detectedSubmissionType) {
    const deficiencyContext = buildDeficiencyContext(detectedSubmissionType);
    if (deficiencyContext) {
      systemPrompt += '\n\n' + deficiencyContext;
      deficiencyContextInjected = true;
    }
  }

  // 5b. Inject full registry context when the project has a registry ID or
  //     international submission type, so AnA knows the exact regulatory framework.
  const registrySource = input.projectContext?.submissionType || input.submissionType;
  if (registrySource) {
    const regCtx = getSubmissionTypeContext(registrySource);
    if (regCtx && regCtx.registryId !== detectedSubmissionType) {
      const lines = [
        `## REGULATORY CONTEXT (${regCtx.registryId})`,
        `**Filing Type:** ${regCtx.displayName}`,
        `**Agency:** ${regCtx.agency} (${regCtx.region})`,
        `**Dossier Standard:** ${regCtx.dossierStandard}`,
        `**Application Family:** ${regCtx.applicationFamily}`,
      ];
      if (regCtx.segment) lines.push(`**Segment:** ${regCtx.segment}`);
      if (regCtx.category) lines.push(`**Category:** ${regCtx.category}`);
      if (regCtx.description) lines.push(`**Description:** ${regCtx.description}`);
      if (regCtx.submissionFormat) lines.push(`**Submission Format:** ${regCtx.submissionFormat}`);
      if (regCtx.ctdModule) lines.push(`**CTD Module:** ${regCtx.ctdModule}`);
      systemPrompt += '\n\n' + lines.join('\n');
    }
  }

  // 6. Inject document action context
  const documentActionContext = buildDocumentActionContext(detectedIntent.lens);
  let documentActionContextInjected = false;
  if (documentActionContext) {
    systemPrompt += '\n\n' + documentActionContext;
    documentActionContextInjected = true;
  }

  // 7. Inject role-adaptive context
  if (appliedRole !== 'general') {
    const roleContext = buildRoleAdaptiveContext(appliedRole, detectedSubmissionType);
    systemPrompt += '\n\n' + roleContext;
  }

  // 8. (Command capabilities injected via buildCommandContextForPrompt() in step 10)

  // 8b. Inject decision architecture context for grounded explanations.
  // The chat route layer (async) pre-fetches decision context and attaches it
  // as _decisionContext on the authoringContext object. This keeps orchestrate() sync.
  if (input.authoringContext?.projectId) {
    try {
      const decisionCtx = input.authoringContext._decisionContext;
      if (decisionCtx && decisionCtx.length > 0) {
        const decisionBlock = decisionCtx.map(({ decision, receipt }: { decision: unknown; receipt?: unknown }) => {
          const d = decision as Record<string, unknown>;
          const r = receipt as Record<string, unknown> | undefined;
          let line = `- [${(d.status as string)?.toUpperCase?.() || '?'}] ${d.kind}: ${d.summary}`;
          const authority = d.authority as Record<string, unknown> | undefined;
          if (authority?.level) line += ` (authority: ${authority.level})`;
          const sourceSignals = d.sourceSignals as unknown[] | undefined;
          if (sourceSignals && sourceSignals.length > 0) line += ` — ${sourceSignals.length} signal(s)`;
          if (r) {
            const execution = r.execution as Record<string, unknown> | undefined;
            if (execution?.executed) line += ' → executed';
            const pendingApprovals = r.pendingApprovals as unknown[] | undefined;
            if (pendingApprovals && pendingApprovals.length > 0) line += ` → ${pendingApprovals.length} pending approval(s)`;
            const provisionalItems = r.provisionalItems as unknown[] | undefined;
            if (provisionalItems && provisionalItems.length > 0) line += ` → ${provisionalItems.length} provisional`;
          }
          return line;
        }).join('\n');
        systemPrompt += `\n\n## DECISION CONTEXT\nRecent decisions for this project/section:\n${decisionBlock}\n\nWhen explaining results, reference these decisions. Answer "why" from source signals and rationale. Answer "what happened" from receipts. Answer "what needs approval" from pending approvals. Never invent explanations — if no decision record exists, say so.`;
      }
    } catch { /* non-blocking */ }
  }

  // 8b2. Inject RIM (Regulatory Intelligence Model) context for document-scoped conversations.
  // Pre-fetched by the route layer via preloadRIMContext() and attached as _rimContext.
  // Only injected when the user is working on a specific section or artifact — not for general chat.
  let rimContextInjected = false;
  if (
    input.authoringContext?._rimContext &&
    (input.authoringContext?.sectionCode || input.authoringContext?.artifactId)
  ) {
    try {
      const rimBlock = input.authoringContext._rimContext;
      if (rimBlock.trim().length > 0) {
        systemPrompt += '\n\n' + rimBlock;
        rimContextInjected = true;
      }
    } catch { /* non-blocking */ }
  }

  // 8c. Inject document-state intelligence when authoring context includes artifact status
  if (input.authoringContext) {
    const artifactStatus = input.authoringContext?.artifactStatus;
    const sectionCode = input.authoringContext?.sectionCode;
    const moduleCode = input.authoringContext?.moduleCode;

    if (artifactStatus) {
      const statusLower = (artifactStatus || '').toLowerCase();
      let stateDirective = '';
      if (statusLower === 'draft') {
        stateDirective = `\n\n## DOCUMENT STATE: DRAFT\nThis artifact is in DRAFT status. Your behavior should be:\n- Constructive and building-forward\n- Offer to write, expand, fill gaps, restructure\n- Flag missing subsections and weak claims\n- Suggest running /audit or /scan before moving to review\n- Recommend evidence that needs gathering`;
      } else if (statusLower === 'review' || statusLower === 'in_review') {
        stateDirective = `\n\n## DOCUMENT STATE: IN REVIEW\nThis artifact is in REVIEW status. Your behavior should be:\n- Evaluative and precise — act as a reviewer\n- Identify issues that would block approval\n- Focus on completeness, consistency, defensibility\n- Do NOT suggest major rewrites — suggest targeted fixes\n- Recommend specific review actions and reviewers`;
      } else if (statusLower === 'approved') {
        stateDirective = `\n\n## DOCUMENT STATE: APPROVED\nThis artifact is APPROVED. Your behavior should be:\n- Cautious — warn before suggesting changes ("This is approved; changes require re-review")\n- Focus on pre-submission checks: cross-references, formatting, eCTD placement\n- Suggest /preflight or /checklist rather than edits\n- Verification-focused, not editing-focused`;
      } else if (statusLower === 'locked' || statusLower === 'frozen') {
        stateDirective = `\n\n## DOCUMENT STATE: LOCKED\nThis artifact is LOCKED/FROZEN and IMMUTABLE. Your behavior should be:\n- Do NOT suggest edits — this document cannot be changed\n- If user asks to edit: "This document is locked. Create a new version to make changes."\n- Focus on interpretation, comparison, or export actions\n- Read-only and informational`;
      }
      if (stateDirective) {
        systemPrompt += stateDirective;
      }
    }

    if (sectionCode) {
      const sectionGuidance = getSectionGuidance(sectionCode);
      systemPrompt += `\n\n## ACTIVE SECTION: ${sectionCode}${moduleCode ? ` (Module ${moduleCode})` : ''}\nThe user is working in a specific CTD section. Tailor all guidance to this section. When the user says "this section" or "here", they mean ${sectionCode}. Be section-specific, not generic.${sectionGuidance ? `\n\n### This section\n${sectionGuidance}` : ''}`;
    }
  }

  // 8d. Inject context-freshness signal when conversation is long
  if (input.conversationHistory && input.conversationHistory.length > 12) {
    systemPrompt += `\n\n## CONTEXT FRESHNESS WARNING\nThis conversation has ${input.conversationHistory.length} messages. Project context was injected at the start and may not reflect recent changes. If the user asks about current state, suggest running /status or /readiness for a live check rather than relying on stale context. If you're unsure whether data is current, say so.`;
  }

  // 8e. Inject user feedback patterns from learning loop (pre-fetched by chat-context-builder)
  if (input._feedbackContext && input._feedbackContext.totalFeedback > 0 && input._feedbackContext.acceptanceRate < 100) {
    const fb = input._feedbackContext;
    const dismissedWithCounts = fb.topDismissedTypes
      .filter(d => d.count > 1)
      .slice(0, 3);
    if (dismissedWithCounts.length > 0) {
      // 2026-10-15: printed "(acceptance rate: N%)", N being the share of all
      // feedback actions that were not this type's dismissals. It is a count.
      const lines = dismissedWithCounts
        .map(d => `- ${d.type}: dismissed ${d.count} of the last ${fb.totalFeedback} recommendation feedback actions recorded for this project`)
        .join('\n');
      systemPrompt += `\n\n## USER FEEDBACK PATTERNS\nThe user has previously dismissed or rejected the following types of recommendations for this project:\n${lines}\n\nAvoid repeating these exact patterns. If you must recommend something similar, acknowledge the prior dismissal and explain why the recommendation is still relevant, or offer an alternative approach.`;
    }
  }

  // 8e2. Intelligence Questioning Engine — instruct AnA to use the flow tools
  systemPrompt += `

## INTELLIGENCE QUESTIONING FLOWS
Apply Intelligent Awareness when choosing how to collect missing inputs for a regulatory document (protocol, CSR, IND, SOP, 510(k), CER, etc.). When the user requests a guided interview, or essential inputs need structured collection, invoke the \`start_intelligence_flow\` tool with the document type. For a small clarification, ask focused questions in chat. For a sufficiently specified drafting task, use the confirmed context and draft the supported content. Do not automatically start or restart an interview merely because the user requests a document; use the existing answers and active flow when relevant.

Available document types: protocol, csr, ind, nda, bla, sop, 510k, pma, cer, cmc, risk management, safety narrative, labeling, briefing book, stability study, project setup — plus natural language aliases (e.g., "new drug application", "biologics license", "premarket approval", "prescribing information", "advisory committee briefing").

Within an active structured flow, ask its questions through the tool: the client renders those steps as form widgets with validation. This does not prohibit ordinary clarifying questions in chat. Resume a persisted interview using the session_id returned by the tool and answer_intelligence_question rather than starting over. Do not claim a flow started or resumed unless its tool result confirms it.

## WAR GAME SIMULATION
When a user asks you to "run a war game", "pressure test", "audit simulation", "FDA review simulation", "stress test", or similar, use the start_war_game tool with the collected intelligence data from the most recent completed flow. If no flow has been completed yet, start an intelligence flow for the relevant document type first, since the war game audits what the flow collected. When a flow completes on a document that is heading to an agency, a war game is often the consequential next move; offer it in your own words when it is.

War Game auditors are available for 15 document categories: protocol, ind, csr, 510k, cer, sop, nda, bla, pma, cmc, risk_management, safety_narrative, labeling, briefing_book, stability. Each auditor contains 25-32 adversarial rules across 7 audit dimensions (completeness, consistency, regulatory alignment, scientific rigor, practical feasibility, documentation, risk identification). The simulation scores each dimension starting from 100 and deducting points per finding severity, producing an overall regulatory risk assessment.`;

  // 8f. Inject proactive intelligence surfacing protocol + intelligence usage directives + citation protocol
  systemPrompt += `

## USING INJECTED INTELLIGENCE
The PROJECT INTELLIGENCE PROFILE, REGULATORY INTELLIGENCE CONTEXT, PERSISTENT MEMORY CONTEXT and USER FEEDBACK PATTERNS sections above are what this project already knows. Use the items that bear on the question and cite them as below. A documented decision is never overturned silently: if your answer departs from one, say so and why. Let the evidence sufficiency scores set how firmly you recommend. Low readiness is context, not an instruction to guess or to run an interview. Apply Intelligent Awareness to decide whether the gap blocks a defensible recommendation: ask the decisive question first when it does; otherwise give bounded help, naming what is missing and how it could change the answer.

## EVIDENCE CITATION PROTOCOL
When your response draws on specific knowledge from the injected context above, cite the source inline using this format:

- For memory atoms: [Source: {category} — {title}]
- For readiness scores: [Readiness: {section} at {score}%]
- For regulatory signals: [Signal: {type} — {description}]
- For precedent data: [Precedent: {case/decision reference}]
- For project decisions: [Decision: {decision summary}]
- For risk factors: [Risk: {severity} — {risk description}]
- For learned insights: [Insight: {insight summary}]

For LIVE external evidence returned by tools (each result includes a \`url\` — render it as a clickable markdown link so the user can verify):
- For ClinicalTrials.gov (search_clinical_evidence): [[{nctId}]({url}) — {title}]
- For PubMed (search_literature): [[PMID {pmid}]({url}) — {title}{, DOI if present}]
- For Medicare coverage (search_medicare_coverage): [[{NCD/LCD number}]({url}) — {title}]

Citation rules:
1. Cite when making specific factual claims derived from injected context or a tool result, not for general regulatory knowledge
2. Maximum 3 citations per response for injected context — but when you draw on live tool results (trials, literature, coverage), cite EVERY trial/article/coverage document you reference, with its url, so claims are independently verifiable
3. Place citations at the end of the relevant sentence or paragraph, not mid-sentence
4. If no specific source exists for a claim, say "Based on general regulatory practice" — never fabricate a citation, NCT/PMID/MCD number, or url (only use identifiers and urls returned by a tool)
5. When a recommendation rests on inference rather than evidence, label it [INFERRED] and say in a few words what would settle it. The label carries the uncertainty; do not attach a confidence percentage of your own, because a figure you estimate is not one an engine produced
6. Memory atoms injected above use the format [category | "title"] — use those values in your citations

## PROACTIVE INTELLIGENCE PROTOCOL
The injected blocks above are where your foresight comes from: a risk in the intelligence profile, a decision the request would contradict, a milestone the deadline radar shows, a memory atom that answers part of the question, a question the person keeps returning to that a template would save them. When one of them bears on what the person is doing now, raise it without being asked, once per thread, in one plain sentence where it belongs (Proactive Foresight and the chat register govern the form). When none does, add nothing.`;

  // 9. Inject conversation continuity context
  if (input.conversationHistory && input.conversationHistory.length > 0) {
    const continuityContext = buildContinuityContext(
      input.conversationHistory,
      detectedSubmissionType
    );
    if (continuityContext) {
      systemPrompt += '\n\n' + continuityContext;
    }
  }

  // 10. Inject command context — tells AnA what operational commands are available
  systemPrompt += '\n\n' + buildCommandContextForPrompt();

  // 11. Determine suggested document actions
  const suggestedActions = getSuggestedActions(
    detectedIntent.lens,
    detectedSubmissionType,
    activeWorkstream
  );

  // 12. Build grounding context metadata
  const groundingContext = {
    hasProjectContext: !!(input.projectContext?.productName || input.projectContext?.submissionType || input.authoringContext?.projectId),
    hasArtifactContext: !!(input.documentContext?.documentType || (input.documentContext as any)?.title),
    hasSectionContext: !!(input.documentContext?.section || input.authoringContext?.sectionCode),
    hasWorkflowContext: !!(activeWorkstream.stream !== 'general'),
    hasEvidenceContext: deficiencyContextInjected,
    hasMemoryContext: !!(input.conversationHistory && input.conversationHistory.length > 0),
    documentStatus: (input.documentContext as any)?.status ?? null,
    enrichmentSources: [] as string[], // populated by caller after enrichment
    enrichmentFailures: [] as string[], // populated by caller if enrichment fails
  };

  return {
    systemPrompt,
    detectedIntent,
    detectedSubmissionType,
    detectedDocumentTemplate,
    appliedRole,
    activeWorkstream,
    workstreamHandoff,
    suggestedActions,
    groundingContext,
    orchestrationMeta: {
      intentSource,
      submissionTypeSource,
      roleSource,
      deficiencyContextInjected,
      documentActionContextInjected,
      documentTemplateInjected,
      workstreamContextInjected: true,
      workstreamHandoffInjected: !!workstreamHandoff,
      projectIntelligenceInjected,
      rimContextInjected,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// RIM Context Pre-loader
// ─────────────────────────────────────────────────────────────────────────────

/**
 * The signal block of the RIM preload. 2026-10-15: it printed "Trend: stable"
 * with too little data to tell, and an "Average score" that averaged the
 * invented scores of every artifact edit and feedback click.
 */
function formatSignalSummaryBlock(summary: SignalSummary): string {
  const riskLines = Object.entries(summary.byRiskLevel)
    .filter(([, count]) => Number(count) > 0)
    .map(([risk, count]) => `- ${risk}: ${count}`)
    .join('\n');
  const patternLine =
    summary.topPatternIds.length > 0
      ? `Top patterns: ${summary.topPatternIds.slice(0, 5).join(', ')}`
      : 'Top patterns: none captured yet';
  const trendLine =
    summary.overallTrend === null
      ? `Trend: not determined (${summary.trendConfidence} data, n=${summary.trendSampleSize})`
      : `Trend: ${summary.overallTrend} (${summary.trendConfidence}, n=${summary.trendSampleSize})`;
  const meanLine =
    summary.averageScore === null
      ? 'Mean signal score: none recorded'
      : `Mean signal score: ${summary.averageScore} (model scores and severity-mapped pattern scores; not a readiness figure)`;
  return (
    `**${summary.totalSignals} intelligence signals**\n` +
    `${trendLine}\n` +
    `${meanLine}\n` +
    `${patternLine}\n` +
    `Risk distribution:\n${riskLines || '- none'}`
  );
}

/**
 * Pre-fetch RIM intelligence context for injection into the orchestrator.
 *
 * Call this in the async route layer BEFORE calling `orchestrate()`, then
 * attach the result as `authoringContext._rimContext`. This follows the
 * same pattern used for `_decisionContext`.
 *
 * Only call when the user is working on a specific document section or
 * artifact — skip for general chat to avoid unnecessary overhead.
 *
 * The returned block is capped at ~400 tokens to avoid prompt bloat.
 *
 * @param projectId - The project ID
 * @param organizationId - The organization ID (for live readiness scoring)
 * @returns A formatted markdown block or empty string if no data
 */
export async function preloadRIMContext(
  projectId: string,
  organizationId?: number,
): Promise<string> {
  try {
    const parts: string[] = [];

    // 1. Readiness score (live computation if org available, else skip)
    if (organizationId) {
      try {
        const ctx: ReadinessContext = {
          organizationId,
          projectId: Number(projectId),
        };
        const score = await computeReadinessScore(ctx);
        const gapLines = score.gaps
          .slice(0, 5)
          .map(
            (g) =>
              `- [${g.severity.toUpperCase()}] ${g.module}: ${g.description}`,
          )
          .join('\n');
        // 2026-10-15: printed "Readiness: {overallScore}/100", which without a
        // recorded assessment is document completeness alone.
        parts.push(
          `**${describeReadiness(score)}** | Trend: ${score.trend?.direction || 'unknown'}` +
            (gapLines ? `\nTop gaps:\n${gapLines}` : ''),
        );
      } catch (e: unknown) {
        console.warn(
          '[rim-preload] Readiness scoring failed:',
          e instanceof Error ? e.message : String(e),
        );
      }
    }

    // 2. Accumulated RIM signals (in-memory, synchronous)
    if (organizationId) {
      try {
      const summary = getProjectSignals(organizationId, Number(projectId));
      if (summary && summary.totalSignals > 0) {
        parts.push(formatSignalSummaryBlock(summary));
      }
      } catch (e: unknown) {
        console.warn(
          '[rim-preload] Signal retrieval failed:',
          e instanceof Error ? e.message : String(e),
        );
      }
    }

    if (parts.length === 0) return '';

    return (
      `## REGULATORY INTELLIGENCE CONTEXT (cite a readiness score as [Readiness: section at score%] only where one is given below; cite a signal as [Signal: type — description])\n` +
      parts.join('\n\n') +
      `\n\nUse this intelligence to inform your response. Flag sections with low readiness. When citing readiness scores or signals, use the Evidence Citation Protocol format.`
    );
  } catch (e: unknown) {
    console.warn(
      '[rim-preload] Failed to build RIM context:',
      e instanceof Error ? e.message : String(e),
    );
    return '';
  }
}

/**
 * Determine which document actions to suggest based on intent and submission type.
 */
function getSuggestedActions(
  lens: IntentLens,
  submissionType: SubmissionType | null,
  workstream: WorkstreamContext
): DocumentActionType[] {
  const actions: DocumentActionType[] = [];

  switch (lens) {
    case 'audit':
      actions.push('deficiency_preemption_memo', 'risk_memo', 'reviewer_question_brief');
      break;
    case 'improve':
      actions.push('rewritten_section', 'evidence_memo');
      break;
    case 'risk':
      actions.push('risk_memo', 'deficiency_preemption_memo', 'strategy_note');
      break;
    case 'strategy':
      actions.push('strategy_note', 'risk_memo');
      break;
    case 'compare':
      actions.push('evidence_memo', 'strategy_note');
      break;
    default:
      // Auto — suggest the most universally useful actions
      actions.push('risk_memo', 'rewritten_section', 'strategy_note');
  }

  switch (workstream.stream) {
    case 'document_authoring':
      actions.unshift('rewritten_section', 'revised_artifact');
      break;
    case 'deficiency_response':
      actions.unshift('deficiency_preemption_memo', 'reviewer_question_brief');
      break;
    case 'evidence_development':
      actions.unshift('evidence_memo');
      break;
    case 'submission_strategy':
      actions.unshift('strategy_note');
      break;
    case 'review_preparation':
      actions.unshift('reviewer_question_brief', 'risk_memo');
      break;
    case 'program_risk':
      actions.unshift('risk_memo');
      break;
    default:
      break;
  }

  if (submissionType === 'ectd' || submissionType === 'nda' || submissionType === 'bla') {
    actions.push('attach_to_dossier');
  }

  return [...new Set(actions)];
}

function detectWorkstream(
  input: OrchestratorInput,
  lens: IntentLens,
  submissionType: SubmissionType | null
): WorkstreamContext {
  const recentHistory = (input.conversationHistory || []).slice(-6);
  const historyText = recentHistory.map(message => message.content).join(' ');
  const contextText = [
    input.message,
    historyText,
    input.projectContext?.submissionType,
    input.projectContext?.phase,
    input.documentContext?.documentType,
    input.documentContext?.section,
    input.documentContext?.module,
  ]
    .filter(Boolean)
    .join(' ');

  const stream = detectWorkstreamType(contextText, lens);
  const phase = detectWorkstreamPhase(input, stream);
  const currentFocus = detectCurrentFocus(input, historyText, stream);
  const blockers = detectBlockers(contextText, recentHistory);

  return {
    stream,
    phase,
    objective: summarizeObjective(input.message, stream, submissionType),
    currentFocus,
    blockers,
    nextStep: inferNextStep(stream, phase, lens, submissionType),
    collaborationMode: inferCollaborationMode(stream, phase, lens),
  };
}

function detectWorkstreamHandoff(
  input: OrchestratorInput,
  activeWorkstream: WorkstreamContext
): WorkstreamHandoff | null {
  const history = input.conversationHistory || [];
  if (history.length < 3) {
    return null;
  }

  const previousHistory = history.slice(0, -1);
  const previousText = previousHistory.map(message => message.content).join(' ');
  if (!previousText.trim()) {
    return null;
  }

  const previousLens = detectIntent(previousText).lens;
  const previousSubmissionType = detectSubmissionType(previousText);
  const previousStream = detectWorkstreamType(previousText, previousLens);

  if (previousStream === 'general' || previousStream === activeWorkstream.stream) {
    return null;
  }

  const carryForward = extractCarryForwardItems(previousHistory);
  const openLoops = detectBlockers(previousText, previousHistory);
  const transitionReason = inferTransitionReason(
    previousStream,
    activeWorkstream.stream,
    input.message
  );

  return {
    from: previousStream,
    to: activeWorkstream.stream,
    carryForward,
    openLoops:
      openLoops.length > 0
        ? openLoops
        : inferOpenLoopsFromStream(previousStream, previousSubmissionType),
    transitionReason,
  };
}

function detectWorkstreamType(text: string, lens: IntentLens): WorkstreamType {
  const lower = text.toLowerCase();

  if (
    /deficien|information request|complete response|crl|rtf|reviewer question|response matrix/i.test(
      lower
    )
  ) {
    return 'deficiency_response';
  }
  if (
    /rewrite|revise|redraft|draft|author|edit.*section|clinical overview|module [1-5]/i.test(lower)
  ) {
    return 'document_authoring';
  }
  if (/pathway|strategy|pre-ind|pre-sub|meeting|submission plan|sequence/i.test(lower)) {
    return 'submission_strategy';
  }
  if (
    /cms|medicare|medicaid|payer|reimbursement|coverage determination|coding strategy|hcpcs|cpt|drg|apc/i.test(
      lower
    )
  ) {
    return 'submission_strategy';
  }

  const scores: Array<{ stream: WorkstreamType; score: number }> = [
    {
      stream: 'submission_strategy',
      score: scorePatterns(lower, [
        /pathway|strategy|timeline|meeting|pre-ind|pre-sub|submission plan|sequence|agency/i,
        /fda|ema|pmda|global|regional/i,
        /cms|medicare|medicaid|payer|reimbursement|coverage|coding strategy|hcpcs|cpt|drg|apc/i,
      ]),
    },
    {
      stream: 'document_authoring',
      score: scorePatterns(lower, [
        /rewrite|revise|redraft|edit|author|draft|section|module|narrative/i,
        /clinical overview|summary|module 2|module 3|cer|briefing book/i,
      ]),
    },
    {
      stream: 'deficiency_response',
      score: scorePatterns(lower, [
        /deficien|information request|complete response|crl|rtf|reviewer question|response/i,
        /objection|agency feedback|inspection finding|483/i,
      ]),
    },
    {
      stream: 'evidence_development',
      score: scorePatterns(lower, [
        /evidence|support|justify|validation|dataset|study|citation|source/i,
        /endpoint|safety|exposure|comparability|stability|specification/i,
        /diagnostic|ivd|companion diagnostic|analytical validation|clinical performance|sensitivity|specificity/i,
      ]),
    },
    {
      stream: 'review_preparation',
      score: scorePatterns(lower, [
        /audit|review|readiness|mock review|gap assessment|checklist/i,
        /reviewer|inspection readiness|due diligence/i,
      ]),
    },
    {
      stream: 'program_risk',
      score: scorePatterns(lower, [
        /risk|threat|vulnerab|what could go wrong|mitigation|exposure/i,
        /delay|timeline impact|probability|approval odds/i,
      ]),
    },
    {
      stream: 'cross_function_alignment',
      score: scorePatterns(lower, [
        /team|owner|stakeholder|handoff|alignment|decision maker|cross-functional/i,
        /clinical|cmc|regulatory|quality.*together|dependencies/i,
      ]),
    },
  ];

  scores.sort((left, right) => right.score - left.score);
  if (scores[0].score > 0) {
    return scores[0].stream;
  }

  switch (lens) {
    case 'improve':
      return 'document_authoring';
    case 'audit':
      return 'review_preparation';
    case 'risk':
      return 'program_risk';
    case 'strategy':
      return 'submission_strategy';
    case 'compare':
      return 'evidence_development';
    default:
      return 'general';
  }
}

function scorePatterns(text: string, patterns: RegExp[]): number {
  return patterns.reduce((count, pattern) => count + (pattern.test(text) ? 1 : 0), 0);
}

function detectWorkstreamPhase(input: OrchestratorInput, stream: WorkstreamType): WorkstreamPhase {
  const lower = input.message.toLowerCase();
  const phaseFromThread = input.conversationHistory?.length
    ? detectConversationPhase(input.conversationHistory)
    : 'initial';

  if (/approve|decide|go\/no-go|recommend final|which option/i.test(lower)) {
    return 'decision';
  }
  if (/implement|execute|run|create|generate|send|file|submit/i.test(lower)) {
    return 'execution';
  }
  if (/rewrite|redraft|draft|author|compose/i.test(lower)) {
    return 'drafting';
  }
  if (/refine|tighten|improve|adjust|revise|make it/i.test(lower)) {
    return 'refinement';
  }
  if (
    stream === 'review_preparation' ||
    stream === 'program_risk' ||
    /audit|assess|analyze|evaluate/i.test(lower)
  ) {
    return 'analysis';
  }
  if (phaseFromThread === 'iterative_refinement') {
    return 'refinement';
  }
  if (phaseFromThread === 'deep_dive' || phaseFromThread === 'follow_up') {
    return 'analysis';
  }
  return 'triage';
}

function detectCurrentFocus(
  input: OrchestratorInput,
  historyText: string,
  stream: WorkstreamType
): string | undefined {
  const text = `${input.message} ${historyText}`;
  const sectionMatch = text.match(
    /(?:Section|Module|Chapter)\s+[\d.]+[A-Za-z]?(?:\s*[-–:]\s*[^\n.]{3,60})?/i
  );
  if (sectionMatch) {
    return sectionMatch[0].trim();
  }
  // Printed as "Current Focus" in the cached prefix: one sanitized line, and a
  // type only as the registry states it (promptDocumentContext).
  if (input.documentContext?.section) {
    return sanitizeLine(input.documentContext.section, 80) || undefined;
  }
  if (input.documentContext?.documentType) {
    return statedTypeLine(input.documentContext.documentType);
  }

  switch (stream) {
    case 'submission_strategy':
      return 'Regulatory pathway and sequencing';
    case 'document_authoring':
      return 'Draft quality and claim architecture';
    case 'deficiency_response':
      return 'Response package and reviewer objections';
    case 'evidence_development':
      return 'Evidence chain and support gaps';
    case 'review_preparation':
      return 'Submission readiness';
    case 'program_risk':
      return 'Risk ranking and mitigation';
    case 'cross_function_alignment':
      return 'Owners, dependencies, and unresolved decisions';
    default:
      return undefined;
  }
}

function detectBlockers(
  text: string,
  history: Array<{ role: 'user' | 'assistant'; content: string }>
): string[] {
  const lower = `${text} ${history.map(message => message.content).join(' ')}`.toLowerCase();
  const blockers: string[] = [];
  const blockerPatterns: Array<{ pattern: RegExp; blocker: string }> = [
    {
      pattern: /missing|insufficient|inadequate|gap|not.*enough|lack of evidence/i,
      blocker: 'Critical evidence is missing or insufficient',
    },
    {
      pattern: /unresolved|safety signal|toxicit|adverse event concern|clinical hold/i,
      blocker: 'Safety concerns remain unresolved',
    },
    {
      pattern: /unclear pathway|which pathway|regulatory strategy|agency expectation/i,
      blocker: 'Pathway or agency strategy is not settled',
    },
    {
      pattern: /weak prose|rewrite|narrative|unclear section|structure/i,
      blocker: 'Narrative quality is not yet submission-defensible',
    },
    {
      pattern: /owner|alignment|handoff|dependency|waiting on/i,
      blocker: 'Cross-functional dependencies are still open',
    },
  ];

  for (const { pattern, blocker } of blockerPatterns) {
    if (pattern.test(lower)) {
      blockers.push(blocker);
    }
  }

  return [...new Set(blockers)].slice(0, 3);
}

function extractCarryForwardItems(
  history: Array<{ role: 'user' | 'assistant'; content: string }>
): string[] {
  const text = history.map(message => message.content).join(' ');
  const carryForward = new Set<string>();

  const sectionMatches = text.match(
    /(?:Section|Module|Chapter)\s+[\d.]+[A-Za-z]?(?:\s*[-–:]\s*[^\n.]{3,60})?/gi
  );
  if (sectionMatches) {
    sectionMatches.slice(0, 2).forEach(match => carryForward.add(match.trim()));
  }

  const termMatches = extractKeyRegTerms(text);
  termMatches.slice(0, 3).forEach(term => carryForward.add(term));

  return [...carryForward].slice(0, 4);
}

function inferTransitionReason(
  previousStream: WorkstreamType,
  currentStream: WorkstreamType,
  message: string
): string {
  const lower = message.toLowerCase();

  if (/now|next|switch|instead|move to|shift/i.test(lower)) {
    return 'The user explicitly pivoted to the next regulatory workstream.';
  }
  if (currentStream === 'document_authoring') {
    return `The thread moved from ${previousStream} into drafting so analysis can become governed text.`;
  }
  if (currentStream === 'deficiency_response') {
    return `The thread moved from ${previousStream} into reviewer-response planning.`;
  }
  if (currentStream === 'submission_strategy') {
    return `The thread moved from ${previousStream} into a program-level regulatory decision.`;
  }

  return `The thread shifted from ${previousStream} to ${currentStream} while preserving unresolved regulatory context.`;
}

function inferOpenLoopsFromStream(
  stream: WorkstreamType,
  submissionType: SubmissionType | null
): string[] {
  switch (stream) {
    case 'submission_strategy':
      return [
        `Pathway decision remains open${submissionType ? ` for ${submissionType.toUpperCase()}` : ''}`,
      ];
    case 'document_authoring':
      return ['Draft still needs a stronger claim-to-evidence chain'];
    case 'deficiency_response':
      return ['Reviewer objections still need mapped responses and evidence'];
    case 'evidence_development':
      return ['Evidence gaps still need to be closed or explicitly risk-accepted'];
    case 'review_preparation':
      return ['Readiness issues still need to be ranked and assigned'];
    case 'program_risk':
      return ['Top risks still need mitigation owners and timeline impact'];
    case 'cross_function_alignment':
      return ['Cross-functional dependencies still need owners and deadlines'];
    default:
      return [];
  }
}

function summarizeObjective(
  message: string,
  stream: WorkstreamType,
  submissionType: SubmissionType | null
): string {
  const normalized = message.replace(/\s+/g, ' ').trim();
  if (normalized.length > 0 && normalized.length <= 180) {
    return normalized;
  }

  const submissionLabel = submissionType ? `${submissionType.toUpperCase()} ` : '';
  switch (stream) {
    case 'submission_strategy':
      return `Resolve the ${submissionLabel}regulatory pathway and execution sequence.`;
    case 'document_authoring':
      return 'Turn the current draft into submission-defensible language.';
    case 'deficiency_response':
      return 'Preempt or answer reviewer objections with evidence-backed responses.';
    case 'evidence_development':
      return 'Map what evidence exists, what is missing, and what must be strengthened.';
    case 'review_preparation':
      return 'Pressure-test the package the way an agency reviewer would.';
    case 'program_risk':
      return 'Rank approval risk and define concrete mitigations.';
    case 'cross_function_alignment':
      return 'Convert unresolved cross-functional issues into an executable plan.';
    default:
      return 'Advance the user toward a clearer regulatory decision or artifact.';
  }
}

function inferNextStep(
  stream: WorkstreamType,
  phase: WorkstreamPhase,
  lens: IntentLens,
  submissionType: SubmissionType | null
): string {
  const submissionLabel = submissionType ? `${submissionType.toUpperCase()} ` : '';

  switch (stream) {
    case 'submission_strategy':
      return `Decide the ${submissionLabel}pathway, key agency interaction, and the evidence required before the next milestone.`;
    case 'document_authoring':
      return phase === 'drafting'
        ? 'Produce revised text with a tighter claim-to-evidence chain and explicit regulatory support.'
        : 'Tighten the current draft, remove overstatement, and prepare the next review-ready version.';
    case 'deficiency_response':
      return 'Draft a deficiency response matrix that maps each likely question to evidence, owner, and mitigation.';
    case 'evidence_development':
      return 'Build an evidence inventory, mark critical gaps, and decide what can be defended now versus what needs new support.';
    case 'review_preparation':
      return 'Run a reviewer-style audit, rank the issues by severity, and convert the highest-risk items into assigned fixes.';
    case 'program_risk':
      return 'Rank the top risks by severity and likelihood, then define mitigations with timeline consequences.';
    case 'cross_function_alignment':
      return 'Translate the open issues into owners, dependencies, and a single decision path for the team.';
    default:
      return lens === 'improve'
        ? 'Rewrite the weak material into a defensible version and identify the evidence still needed.'
        : 'Clarify the blocking issue and convert it into the next concrete regulatory action.';
  }
}

function inferCollaborationMode(
  stream: WorkstreamType,
  phase: WorkstreamPhase,
  lens: IntentLens
): 'drive' | 'coauthor' | 'advise' {
  if (
    stream === 'document_authoring' ||
    phase === 'drafting' ||
    phase === 'refinement' ||
    lens === 'improve'
  ) {
    return 'coauthor';
  }
  if (
    stream === 'submission_strategy' ||
    stream === 'deficiency_response' ||
    stream === 'program_risk' ||
    phase === 'decision' ||
    phase === 'execution'
  ) {
    return 'drive';
  }
  return 'advise';
}

// ─────────────────────────────────────────────────────────────────────────────
// Conversation Continuity
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Extract working context from conversation history to maintain short-horizon continuity.
 * Prevents AnA from acting memoryless inside an active thread.
 *
 * @param currentSubmissionType - The submission type already detected from the current message,
 *   so we don't inject a conflicting one from history.
 */
function buildContinuityContext(
  history: Array<{ role: 'user' | 'assistant'; content: string }>,
  currentSubmissionType: SubmissionType | null
): string | null {
  if (history.length < 2) return null;

  const lines: string[] = ['## CONVERSATION CONTINUITY'];

  // Only look at recent messages (last 6) to avoid noise from old context
  const recentHistory = history.slice(-6);

  // Extract the active document/section under discussion from recent messages only
  const recentText = recentHistory.map(m => m.content).join(' ');
  const sectionMatches = recentText.match(
    /(?:Section|Module|Chapter)\s+[\d.]+[A-Za-z]?(?:\s*[-–:]\s*[^\n.]{3,60})?/gi
  );
  if (sectionMatches) {
    const uniqueSections = [...new Set(sectionMatches.map(s => s.trim()))].slice(0, 3);
    lines.push('');
    lines.push('**Document/Section Under Discussion:**');
    uniqueSections.forEach(s => lines.push(`- ${s}`));
  }

  // Detect active concern themes from recent assistant messages
  // Use narrower patterns that require problem-context, not just mention
  const recentAssistant = recentHistory
    .filter(m => m.role === 'assistant')
    .slice(-2)
    .map(m => m.content);

  const concerns: string[] = [];
  const concernPatterns: Array<{ pattern: RegExp; label: string }> = [
    // Require problem-indicating context words alongside domain terms
    {
      pattern:
        /(?:inadequate|insufficient|incomplete|missing|weak|deficient)\s+\w*\s*(?:evidence|data|support|justification)/i,
      label: 'Evidence adequacy',
    },
    {
      pattern:
        /safety signal|adverse event.*(?:concern|risk|unresolved)|toxicity.*(?:finding|signal)/i,
      label: 'Safety concerns',
    },
    {
      pattern:
        /endpoint.*(?:weak|inadequate|not.*justified|concern)|efficacy.*(?:insufficient|marginal)/i,
      label: 'Efficacy/endpoint defensibility',
    },
    {
      pattern:
        /(?:process validation|manufacturing).*(?:insufficient|inadequate|gap)|specification.*(?:not.*justified|weak)/i,
      label: 'CMC/manufacturing quality',
    },
    {
      pattern: /(?:predicate|equivalence).*(?:inadequate|not.*demonstrated|weak)/i,
      label: 'Device equivalence',
    },
    {
      pattern: /(?:labeling|claim).*(?:unsupported|overstate|not.*reflect)/i,
      label: 'Labeling/claims',
    },
    {
      pattern: /(?:statistical|multiplicity|sample size).*(?:inadequate|concern|not.*controlled)/i,
      label: 'Statistical rigor',
    },
  ];

  for (const { pattern, label } of concernPatterns) {
    if (recentAssistant.some(text => pattern.test(text))) {
      concerns.push(label);
    }
  }

  if (concerns.length > 0) {
    lines.push('');
    lines.push('**Active Concern Themes:**');
    concerns.slice(0, 4).forEach(c => lines.push(`- ${c}`));
  }

  // Detect any previously recommended actions from the last assistant message only
  const lastAssistant = recentAssistant[recentAssistant.length - 1] || '';
  const actionMentions: string[] = [];
  if (/(?:create|generate).*risk memo|risk assessment.*(?:recommend|suggest)/i.test(lastAssistant))
    actionMentions.push('Risk assessment in progress');
  if (/(?:create|generate).*deficiency|preemption.*memo/i.test(lastAssistant))
    actionMentions.push('Deficiency preemption analysis');
  if (/(?:rewrite|revise).*(?:section|document|text)/i.test(lastAssistant))
    actionMentions.push('Document improvement');
  if (/(?:strategy|pathway).*(?:recommend|note|assessment)/i.test(lastAssistant))
    actionMentions.push('Strategy development');

  if (actionMentions.length > 0) {
    lines.push('');
    lines.push('**Active Work Stream:**');
    actionMentions.slice(0, 3).forEach(a => lines.push(`- ${a}`));
  }

  // Only inject historical submission type if no current detection exists
  // This prevents conflicts between deficiency context (built from current) and continuity
  if (!currentSubmissionType) {
    const histSubmission = detectSubmissionType(recentText);
    if (histSubmission) {
      lines.push('');
      lines.push(`**Submission Context (from conversation):** ${histSubmission.toUpperCase()}`);
    }
  }

  // Detect conversation phase (depth of engagement)
  const phase = detectConversationPhase(history);
  if (phase !== 'initial') {
    lines.push('');
    lines.push(`**Conversation Phase:** ${phase}`);
    switch (phase) {
      case 'deep_dive':
        lines.push(
          'The user is drilling into detail. Give comprehensive, specific answers. Avoid high-level summaries they have already seen.'
        );
        break;
      case 'iterative_refinement':
        lines.push(
          'The user is refining previous output. Focus only on what changed or what they asked to modify. Do NOT regenerate unchanged content.'
        );
        break;
      case 'topic_shift':
        lines.push(
          'The user has shifted topics. Acknowledge the pivot naturally and bring relevant context from earlier discussion if applicable.'
        );
        break;
      case 'follow_up':
        lines.push(
          'The user is following up on your last response. Reference your previous analysis directly. Do not repeat context they already have.'
        );
        break;
      case 'summarization':
        lines.push(
          'The user wants a summary or synthesis. Consolidate the discussion into actionable intelligence.'
        );
        break;
    }
  }

  // Extract key entities/terms mentioned across the conversation to maintain vocabulary consistency
  const keyTerms = extractKeyRegTerms(recentHistory.map(m => m.content).join(' '));
  if (keyTerms.length > 0) {
    lines.push('');
    lines.push('**Key Regulatory Terms in Thread:**');
    lines.push(keyTerms.slice(0, 8).join(', '));
  }

  lines.push('');
  lines.push(
    '**Continuity instruction:** Build on the above context. Do not re-introduce yourself or ask the user to re-state what they already told you. Continue the working thread.'
  );

  return lines.length > 2 ? lines.join('\n') : null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Conversation Phase Detection
// ─────────────────────────────────────────────────────────────────────────────

type ConversationPhase =
  | 'initial'
  | 'deep_dive'
  | 'iterative_refinement'
  | 'topic_shift'
  | 'follow_up'
  | 'summarization';

/**
 * Detect what phase the conversation is in based on message patterns.
 * This helps AnA calibrate the depth and style of the response.
 */
function detectConversationPhase(
  history: Array<{ role: 'user' | 'assistant'; content: string }>
): ConversationPhase {
  if (history.length < 2) return 'initial';

  const userMessages = history.filter(m => m.role === 'user');
  const lastUser = userMessages[userMessages.length - 1]?.content || '';
  const prevUser = userMessages[userMessages.length - 2]?.content || '';
  const lower = lastUser.toLowerCase();

  // Summarization phase
  if (
    /\b(summarize|summary|synthesize|wrap up|consolidate|key takeaways|action items|recap)\b/i.test(
      lower
    )
  ) {
    return 'summarization';
  }

  // Iterative refinement — user is asking to modify/adjust previous output
  if (
    /\b(change|modify|adjust|tweak|make it|instead|rather|also add|remove the|less|more)\b/i.test(
      lower
    ) &&
    lower.length < 200
  ) {
    return 'iterative_refinement';
  }

  // Follow-up — short message that references "it", "that", "this" or "the above"
  if (
    lower.length < 100 &&
    /\b(what about|how about|and |also |can you|tell me more|explain|elaborate|expand|the above|that|this)\b/i.test(
      lower
    )
  ) {
    return 'follow_up';
  }

  // Topic shift — new message introduces very different keywords from previous
  if (prevUser) {
    const prevTerms = new Set(prevUser.toLowerCase().match(/\b[a-z]{4,}\b/g) || []);
    const currTerms = new Set(lower.match(/\b[a-z]{4,}\b/g) || []);
    const overlap = [...currTerms].filter(t => prevTerms.has(t)).length;
    const unionSize = new Set([...prevTerms, ...currTerms]).size;
    if (unionSize > 5 && overlap / unionSize < 0.15) {
      return 'topic_shift';
    }
  }

  // Deep dive — long detailed message in a multi-turn conversation
  if (userMessages.length >= 3 && lastUser.length > 200) {
    return 'deep_dive';
  }

  return 'follow_up';
}

// ─────────────────────────────────────────────────────────────────────────────
// Regulatory Term Extraction
// ─────────────────────────────────────────────────────────────────────────────

/** Extract key regulatory terms used in the conversation for vocabulary consistency */
function extractKeyRegTerms(text: string): string[] {
  const patterns: RegExp[] = [
    /\b(?:IND|NDA|BLA|510\(?k\)?|PMA|De Novo|CER|IVDR|EU MDR|eCTD)\b/gi,
    /\bICH [A-Z]\d+(?:\([A-Z]\d+\))?/gi,
    /\b21 CFR (?:Part )?\d+(?:\.\d+)?/gi,
    /\b(?:Module [1-5]|Section \d+\.\d+(?:\.\d+)?)\b/gi,
    /\b(?:RTF|CRL|REMS|ETASU|PDUFA|GDUFA|MDUFA|BsUFA)\b/g,
    /\b(?:pre-?IND|pre-?NDA|pre-?BLA|pre-?submission|Type [A-D] meeting)\b/gi,
    /\b(?:substantial equivalence|bioequivalence|clinical hold|refuse to file|complete response)\b/gi,
    /\b(?:breakthrough therapy|fast track|priority review|accelerated approval|orphan drug)\b/gi,
  ];

  const terms = new Set<string>();
  for (const pattern of patterns) {
    const matches = text.match(pattern);
    if (matches) matches.forEach(m => terms.add(m.trim()));
  }
  return [...terms];
}

// ─────────────────────────────────────────────────────────────────────────────
// Thread Intelligence Extraction
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Extracted intelligence structure from conversation analysis.
 */
interface ExtractedIntelligence {
  decisions: string[];
  risks: string[];
  openQuestions: string[];
  insights: string[];
}

const EXTRACTION_PROMPT = `Analyze this conversation and extract regulatory intelligence. Return JSON:
{
  "decisions": ["decision text..."],
  "risks": ["risk description..."],
  "openQuestions": ["question..."],
  "insights": ["insight..."]
}
Only include items that are NEW and SPECIFIC to this project. Skip generic advice. Be concise — one sentence per item. Return empty arrays if nothing qualifies.`;

/**
 * Extract intelligence from a conversation thread and persist to the project
 * intelligence profile. Should be called non-blocking (fire-and-forget).
 *
 * Only processes the last 6 messages to keep extraction focused and cost-effective.
 * Requires at least 6 messages (3+ exchanges) to have enough substance.
 */
export async function extractThreadIntelligence(
  messages: Array<{ role: string; content: string }>,
  projectId: number | string,
  organizationId: number | string,
): Promise<void> {
  // Guard: need at least 6 messages (3 exchanges) for meaningful extraction
  if (messages.length < 6) return;

  const numericProjectId = typeof projectId === 'string' ? parseInt(projectId, 10) : projectId;
  const numericOrgId = typeof organizationId === 'string' ? parseInt(organizationId, 10) : organizationId;

  if (isNaN(numericProjectId) || isNaN(numericOrgId)) return;

  const gw = getGateway();
  if (!gw) return;

  // Only use the last 6 messages to keep the extraction prompt short
  const recentMessages = messages
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .slice(-6);

  if (recentMessages.length < 4) return; // Need at least 2 exchanges in the window

  const conversationText = recentMessages
    .map(m => `[${m.role}]: ${m.content.slice(0, 2000)}`)
    .join('\n\n');

  const extractionPrompt = `${EXTRACTION_PROMPT}\n\nConversation:\n${conversationText}`;

  // Call AI gateway with short max_tokens for cost efficiency.
  // tenant-binding: runs in the caller's request tenant scope, which the gateway binds; left unmetered by design
  const response = await gw.route({
    taskType: 'structured_output',
    messages: [{ role: 'user', content: extractionPrompt }],
    maxTokens: 500,
    temperature: 0.1,
    jsonMode: true,
  });

  if (!response.content) return;

  // Parse the structured response
  let extracted: ExtractedIntelligence;
  try {
    const parsed = JSON.parse(response.content);
    extracted = {
      decisions: Array.isArray(parsed.decisions) ? parsed.decisions.filter((d: unknown) => typeof d === 'string' && d.length > 0) : [],
      risks: Array.isArray(parsed.risks) ? parsed.risks.filter((r: unknown) => typeof r === 'string' && r.length > 0) : [],
      openQuestions: Array.isArray(parsed.openQuestions) ? parsed.openQuestions.filter((q: unknown) => typeof q === 'string' && q.length > 0) : [],
      insights: Array.isArray(parsed.insights) ? parsed.insights.filter((i: unknown) => typeof i === 'string' && i.length > 0) : [],
    };
  } catch (e: unknown) {
    console.warn('[AnA RI] Intelligence extraction JSON parse failed:', e instanceof Error ? e.message : String(e));
    return;
  }

  // Skip if nothing was extracted
  const totalItems = extracted.decisions.length + extracted.risks.length +
    extracted.openQuestions.length + extracted.insights.length;
  if (totalItems === 0) return;

  // Build the update payload for the project intelligence profile
  const now = new Date().toISOString();
  const payload: IntelligenceUpdatePayload = {};

  if (extracted.decisions.length > 0) {
    payload.keyDecisions = extracted.decisions.map(d => ({
      decision: d,
      rationale: 'Extracted from AnA conversation',
      date: now,
      source: 'ana-thread-extraction',
    }));
  }

  if (extracted.risks.length > 0) {
    payload.risks = extracted.risks.map(r => ({
      risk: r,
      likelihood: 'medium',
      impact: 'medium',
      mitigation: undefined,
    }));
  }

  if (extracted.openQuestions.length > 0) {
    payload.openQuestions = extracted.openQuestions.map(q => ({
      question: q,
      context: 'Raised during AnA conversation',
      priority: 'medium',
    }));
  }

  if (extracted.insights.length > 0) {
    payload.learnedInsights = extracted.insights.map(i => ({
      insight: i,
      source: 'ana-thread-extraction',
      confidence: null, // was 0.7, a constant shown to AnA as "confidence: 70%"
      extractedAt: now,
    }));
  }

  // Persist to the project intelligence profile (additive merge)
  await enrichProjectIntelligence(numericProjectId, numericOrgId, payload);

  console.log(
    `[AnA RI] Intelligence extracted: ${extracted.decisions.length} decisions, ` +
    `${extracted.risks.length} risks, ${extracted.openQuestions.length} questions, ` +
    `${extracted.insights.length} insights (project ${numericProjectId})`
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Project Intelligence Profile — context injection for conversation continuity
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Format a project intelligence profile into a concise system prompt block.
 * When priorities are provided, filters and limits content based on the user's role.
 * Returns null if the profile has no meaningful content to inject.
 */
function formatProjectIntelligenceBlock(
  profile: ProjectIntelligenceSummary,
  priorities?: RoleIntelligencePriorities,
): string | null {
  const parts: string[] = [];

  // Limits — use priorities if provided, otherwise defaults that match prior behavior
  const maxRisks = priorities?.maxRisks ?? 5;
  const maxDecisions = priorities?.maxDecisions ?? 5;
  const maxInsights = priorities?.maxInsights ?? 5;
  const maxQuestions = priorities?.maxQuestions ?? 5;
  const header = priorities?.intelligenceHeader ?? 'PROJECT INTELLIGENCE PROFILE';

  // Header
  parts.push(`## ${header}`);
  parts.push(`**Project ID:** ${profile.projectId} | **Status:** ${profile.profileStatus}`);
  if (profile.targetIndication || profile.targetPopulation) {
    const meta: string[] = [];
    if (profile.targetIndication) meta.push(`**Indication:** ${profile.targetIndication}`);
    if (profile.targetPopulation) meta.push(`**Population:** ${profile.targetPopulation}`);
    parts.push(meta.join(' | '));
  }

  // Readiness directive (role-gated — prompts AnA to surface readiness proactively)
  if (priorities?.includeReadiness) {
    parts.push('');
    parts.push('### Readiness');
    parts.push('This user role prioritizes readiness visibility. Proactively surface readiness scores and gap analysis. Use /readiness data when available.');
  }

  // Regulatory Strategy
  parts.push('');
  parts.push('### Regulatory Strategy');
  parts.push(profile.regulatoryStrategy || 'Not yet defined');

  // Known Risks — filtered by riskFocus and limited by maxRisks
  const risks = profile.riskFactors as readonly RiskFactor[];
  if (risks.length > 0) {
    const severityOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    const riskFocusSet = priorities?.riskFocus
      ? new Set(priorities.riskFocus as string[])
      : null;
    const filteredRisks = riskFocusSet
      ? risks.filter((r) => riskFocusSet.has((r.impact ?? '').toLowerCase()))
      : [...risks];
    const sortedRisks = [...filteredRisks].sort((a, b) => {
      const aScore = severityOrder[a.impact?.toLowerCase() ?? ''] ?? 4;
      const bScore = severityOrder[b.impact?.toLowerCase() ?? ''] ?? 4;
      return aScore - bScore;
    });
    const topRisks = sortedRisks.slice(0, maxRisks);
    if (topRisks.length > 0) {
      parts.push('');
      parts.push(`### Known Risks (${filteredRisks.length})`);
      for (const r of topRisks) {
        parts.push(`- [${(r.impact || 'unknown').toUpperCase()}] ${r.risk} (likelihood: ${r.likelihood || 'unknown'})`);
      }
      if (filteredRisks.length > maxRisks) {
        parts.push(`- ... and ${filteredRisks.length - maxRisks} more`);
      }
    }
  }

  // Open Questions — limited by maxQuestions
  const questions = profile.openQuestions as readonly OpenQuestion[];
  if (questions.length > 0 && maxQuestions > 0) {
    const priorityOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    const sortedQuestions = [...questions].sort((a, b) => {
      const aScore = priorityOrder[a.priority?.toLowerCase() ?? ''] ?? 4;
      const bScore = priorityOrder[b.priority?.toLowerCase() ?? ''] ?? 4;
      return aScore - bScore;
    });
    const topQuestions = sortedQuestions.slice(0, maxQuestions);
    parts.push('');
    parts.push(`### Open Questions (${questions.length})`);
    for (const q of topQuestions) {
      const priorityTag = q.priority ? `[${q.priority.toUpperCase()}] ` : '';
      parts.push(`- ${priorityTag}${q.question}`);
    }
    if (questions.length > maxQuestions) {
      parts.push(`- ... and ${questions.length - maxQuestions} more`);
    }
  }

  // Key Decisions — limited by maxDecisions
  const decisions = profile.keyDecisions as readonly KeyDecision[];
  if (decisions.length > 0 && maxDecisions > 0) {
    const sortedDecisions = [...decisions].sort((a, b) => {
      return (b.date || '').localeCompare(a.date || '');
    });
    const topDecisions = sortedDecisions.slice(0, maxDecisions);
    parts.push('');
    parts.push(`### Key Decisions (${decisions.length})`);
    for (const d of topDecisions) {
      const dateTag = d.date ? ` (${d.date})` : '';
      parts.push(`- ${d.decision}${dateTag} — ${d.rationale}`);
    }
    if (decisions.length > maxDecisions) {
      parts.push(`- ... and ${decisions.length - maxDecisions} more`);
    }
  }

  // Learned Insights — limited by maxInsights
  const insights = profile.learnedInsights as readonly LearnedInsight[];
  if (insights.length > 0 && maxInsights > 0) {
    const sortedInsights = [...insights].sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0));
    const topInsights = sortedInsights.slice(0, maxInsights);
    parts.push('');
    parts.push('### Learned Insights');
    for (const i of topInsights) {
      // 2026-10-15: a missing confidence printed as "confidence: 0%".
      const conf = i.confidence == null ? '' : `, confidence: ${Math.round(i.confidence * 100)}%`;
      parts.push(`- ${i.insight} (source: ${i.source}${conf})`);
    }
    if (insights.length > maxInsights) {
      parts.push(`- ... and ${insights.length - maxInsights} more`);
    }
  }

  // Signal trends (role-gated)
  if (priorities?.includeSignalTrends) {
    parts.push('');
    parts.push('### Signal Trends');
    parts.push('Signal trend analysis is active for this role. Use /signals to inspect recent patterns.');
  }

  // Check if there's any meaningful content beyond the header
  const hasContent = risks.length > 0 || questions.length > 0 || decisions.length > 0 ||
    insights.length > 0 || profile.regulatoryStrategy;
  if (!hasContent) return null;

  // Closing directive
  parts.push('');
  parts.push('Use this profile to maintain continuity. Reference known risks and open questions proactively. Reconsider prior recommendations when new evidence or an explicit user correction changes their basis. Explain the departure; do not silently amend a recorded decision. If the current request and profile conflict without a clear correction, ask which applies to this task. When citing items from this profile, use the Evidence Citation Protocol format: [Risk: severity — description], [Decision: summary], [Insight: summary].');

  return parts.join('\n');
}

/**
 * Pre-fetch the project intelligence profile for injection into the orchestrator.
 * Call this in route handlers before calling orchestrate(), then pass the result
 * as `_projectIntelligenceProfile` on the OrchestratorInput.
 *
 * Non-blocking: returns null on any failure.
 */
export async function prefetchProjectIntelligence(
  projectId: number | undefined | null,
  organizationId: number | undefined | null,
): Promise<ProjectIntelligenceSummary | null> {
  if (!projectId || !organizationId) return null;
  try {
    return await getProjectIntelligence(projectId, organizationId);
  } catch (e: unknown) {
    console.warn(
      '[orchestrator] Failed to prefetch project intelligence profile:',
      e instanceof Error ? e.message : String(e),
    );
    return null;
  }
}
