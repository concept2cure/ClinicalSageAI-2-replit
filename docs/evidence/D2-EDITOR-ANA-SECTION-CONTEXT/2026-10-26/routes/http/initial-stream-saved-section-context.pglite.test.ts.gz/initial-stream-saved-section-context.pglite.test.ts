import { PGlite } from '@electric-sql/pglite';
import httpRequest from 'supertest';
import { describe, it, expect, vi, beforeEach, beforeAll, afterAll } from 'vitest';

const io = vi.hoisted(() => ({
  resolve: vi.fn(),
  query: vi.fn(),
  lumen: vi.fn(),
  memory: vi.fn(),
  enrich: vi.fn(),
  prefetch: vi.fn(),
  bootstrap: vi.fn(),
  reflect: vi.fn(),
  logToolRun: vi.fn(),
}));
const harnessModule = vi.hoisted(() => () => import('./support/stream-route-harness.js'));
vi.mock('../../../db.js', () => ({ getPool: () => ({ query: io.query }), pool: { query: io.query }, db: {} }));
vi.mock('../shared.js', async importOriginal =>
  (await harnessModule()).mocks.shared(await importOriginal<Record<string, unknown>>()),
);
vi.mock('../post-processing.js', async () => (await harnessModule()).mocks.postProcessing());
vi.mock('../../../services/ana/AnaToolExecutor.js', async () => (await harnessModule()).mocks.toolExecutor());
vi.mock('../../../services/ana/governed-toolset.js', async () => (await harnessModule()).mocks.governedToolset());
vi.mock('../../../services/ana/run-control.js', async importOriginal =>
  (await harnessModule()).mocks.runControl(await importOriginal<typeof import('../../../services/ana/run-control.js')>()),
);
vi.mock('../../../services/ana-ri/orchestrator.js', async original => ({
  ...await original<typeof import('../../../services/ana-ri/orchestrator.js')>(),
  prefetchProjectIntelligence: async () => null, preloadRIMContext: async () => '',
}));
vi.mock('../../../services/c2c/project-ref.js', () => ({ integerProjectForRef: io.resolve }));
vi.mock('../../../services/c2c/program-project-anchor.js', async importOriginal => ({
  ...(await importOriginal<Record<string, unknown>>()),
  strictProjectRowForRef: io.resolve,
}));
vi.mock('../../../services/lumen-context-builder.js', async () => ({ ...(await harnessModule()).mocks.lumen(), getIntelligencePrefix: io.lumen }));
vi.mock('../../../services/memory-context-assembler.js', () => ({ buildMemoryContextForChat: io.memory }));
vi.mock('../../../services/ana-ri/context-enrichment.js', () => ({ enrichContextForChat: io.enrich }));
vi.mock('../../../services/chat-thread-helpers.js', async () => (await harnessModule()).mocks.chatThreads());
vi.mock('../../../services/ana-session-bootstrap.js', () => ({ sessionBootstrapBlockFor: io.bootstrap }));
vi.mock('../../../services/kernel-adaptive-policy.js', async () => (await harnessModule()).mocks.kernelPolicy());
vi.mock('../../../services/ana/ana-input-guard.js', async () => (await harnessModule()).mocks.inputGuard());
vi.mock('../../../services/auditService.js', async () => (await harnessModule()).mocks.audit());
vi.mock('../../../services/toolRegistry.js', () => ({ logToolRun: io.logToolRun }));
vi.mock('../../../services/ana-ri/relational-profile-service.js', () => ({ loadRelationalOverlay: async () => '', reflectAfterTurn: io.reflect }));
vi.mock('../../../services/ana/tool-telemetry.js', async () => (await harnessModule()).mocks.toolTelemetry());
vi.mock('../../../services/ana-ri-metrics.js', async () => (await harnessModule()).mocks.metrics());
vi.mock('../../../services/anthropic-files.js', async () => (await harnessModule()).mocks.anthropicFiles());

import { mountStreamRoute } from '../stream.js';
import { harness as h, resetHarness, streamApp } from './support/stream-route-harness.js';


vi.mock('../../../services/intelligence/learning-loop-service.js', () => ({ getFeedbackSummary: async () => ({ totalFeedback: 0 }) }));
vi.mock('../../../services/external-intelligence/index.js', () => ({ buildExternalIntelBlock: async () => '' }));
vi.mock('../../../services/ana/session-briefing.js', () => ({ getSessionBriefing: async () => ({ block: '' }) }));
vi.mock('../../../services/ana/deadline-radar.js', () => ({ getDeadlineRadar: async () => ({}), buildDeadlineRadarBlock: () => '' }));
vi.mock('../../../services/ana/contradiction-watch.js', () => ({ getOpenContradictionsForOrg: async () => [], buildContradictionWatchBlock: () => '' }));
vi.mock('../../../services/decision-lifecycle-service.js', () => ({ decisionLifecycleService: { getDecisionContext: () => [] } }));

const app = streamApp(router => {
  router.use((req, _res, next) => { Object.assign(req, { dbClient: { query: io.query } }); next(); });
  mountStreamRoute(router);
});
const PROGRAM = '11111111-2222-4333-8444-555555555555';
const PRIVATE_PROGRAM = '22222222-2222-4333-8444-555555555555';
const DOC = '11111111-2222-4333-8444-000000000041';
const PRIVATE_DOC = '11111111-2222-4333-8444-000000000042';
const SEC = '22222222-2222-4333-8444-000000000001';
const PARENT_TEMPLATE = '11111111-2222-4333-8444-000000000061';
const CHILD_TEMPLATE = '11111111-2222-4333-8444-000000000062';
const PRIVATE_TEMPLATE = '11111111-2222-4333-8444-000000000063';
const CHILD_GUIDE = 'EXACT_RETAINED_CHILD_CSR_GUIDANCE: retain actual completed patient CRFs; never invent them.';
const source = (id: string, entryId: string, registryId: string | null, region = 'GLOBAL') => ({
  id, entryId, version: 1, sha256: (id === CHILD_TEMPLATE ? 'b' : 'a').repeat(64), kind: 'narrative',
  aiDraftable: true, authoringMode: 'ai_draft', originalFormat: 'narrative', limitations: [id === PARENT_TEMPLATE ? 'PARENT_ONLY_US_IND_LIMIT' : 'Retain original records.'],
  filingContext: { registryId, region, agency: region === 'US' ? 'FDA' : 'ICH' },
});
let database: PGlite;
const statements: string[] = [];
beforeAll(async () => {
  database = new PGlite();
  await database.exec(`
    CREATE TABLE regulatory_programs(id uuid PRIMARY KEY,organization_id int,deleted_at timestamptz);
    CREATE TABLE projects(id int PRIMARY KEY,organization_id int,client_workspace_id int,regulatory_program_id uuid,owner_id int,created_by_id int,settings jsonb,status text DEFAULT 'active');
    CREATE TABLE organization_users(organization_id int,user_id int,role text);
    CREATE TABLE users(id int PRIMARY KEY,status text,email text);
    CREATE TABLE organizations(id int PRIMARY KEY,status text,client_type text);
    CREATE TABLE project_visibility_settings(project_id int,organization_id int,visibility text);
    CREATE TABLE project_members(project_id int,organization_id int,user_id int,role text,status text);
    CREATE TABLE concept2cure_review_assignments(reviewer_id int,organization_id int,artifact_id uuid,status text);
    CREATE TABLE concept2cure_artifacts(id uuid PRIMARY KEY,project_id int,organization_id int,metadata jsonb);
    CREATE TABLE authoring_documents(id uuid PRIMARY KEY,tenant_id int,client_program_id uuid,title text,module text,product_code text,status text,created_by text,updated_at timestamptz,template_id uuid,provenance jsonb);
    CREATE TABLE authoring_sections(id uuid PRIMARY KEY,doc_id uuid,tenant_id int,code text,title text,order_index int,created_at timestamptz,updated_at timestamptz,content text);
    CREATE TABLE doc_permissions(id uuid DEFAULT gen_random_uuid(),doc_id uuid,section_id uuid,tenant_id int,principal_id text,email text,role text,valid_from timestamptz DEFAULT now(),valid_until timestamptz,revoked_at timestamptz);
    CREATE TABLE authoring_audit_trail(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),doc_id uuid,section_id uuid,tenant_id int,operation_type text,actor_email text,metadata jsonb,created_at timestamptz DEFAULT now());
    CREATE TABLE template_guidance(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),template_id uuid,tenant_id int,section_name text,section_code text,guidance_text text,examples jsonb,regulatory_references jsonb,ai_prompts jsonb,compliance_checklist jsonb);
    CREATE SCHEMA intelligence;
    CREATE TABLE intelligence.document_templates(id uuid PRIMARY KEY,status text);
    CREATE TABLE intelligence.template_sections(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),template_id uuid,section_code text,section_title text,ordering int,content_guidance text,required_elements jsonb,source_reference text);
    INSERT INTO organizations VALUES(7,'active','biotech');
    INSERT INTO users VALUES(3,'active','reviewer@example.test'),(5,'active','other@example.test');
    INSERT INTO organization_users VALUES(7,3,'member'),(7,5,'member');
    INSERT INTO regulatory_programs VALUES('${PROGRAM}',7,NULL),('${PRIVATE_PROGRAM}',7,NULL);
    INSERT INTO projects VALUES(42,7,NULL,'${PROGRAM}',3,3,'{}','active'),(84,7,NULL,'${PRIVATE_PROGRAM}',5,5,'{}','active');
    INSERT INTO project_visibility_settings VALUES(42,7,'org_public'),(84,7,'private');
  `);
}, 90_000);
afterAll(async () => { await database.close(); });
beforeEach(async () => {
  resetHarness();
  io.query.mockReset().mockImplementation(async (sql: string, params?: unknown[]) => { statements.push(sql); return database.query<Record<string, unknown>>(sql, params); });
  io.resolve.mockReset().mockResolvedValue(42);
  io.memory.mockReset().mockResolvedValue({ memoryBlock: '', atoms: [], diagnostics: null });
  io.enrich.mockReset().mockResolvedValue({ block: '', sources: [], enrichmentMeta: {} });
  io.bootstrap.mockReset().mockResolvedValue(''); io.reflect.mockReset().mockResolvedValue(undefined); io.logToolRun.mockReset().mockResolvedValue(undefined); io.lumen.mockReset().mockResolvedValue('');
  await database.exec('TRUNCATE authoring_documents,authoring_sections,authoring_audit_trail,doc_permissions,template_guidance');
  await database.query(`INSERT INTO authoring_documents VALUES($1,7,$2,'Parent IND','M5','DRUG','DRAFT','3','2026-10-02',$3,$4),($5,7,$6,'Private IB','M5','DRUG','DRAFT','5','2026-10-02',$7,$8)`,
    [DOC,PROGRAM,PARENT_TEMPLATE,{templateSource:source(PARENT_TEMPLATE,'registry:US_IND','US_IND','US')},PRIVATE_DOC,PRIVATE_PROGRAM,PRIVATE_TEMPLATE,{templateSource:source(PRIVATE_TEMPLATE,'registry:ICH_IB','ICH_IB')}]);
  await database.query(`INSERT INTO authoring_sections VALUES($1,$2,7,'16.3.1','Actual saved appendix',0,'2026-10-01','2026-10-02','')`,[SEC,DOC]);
  const child = source(CHILD_TEMPLATE,'component:clinical_study_report',null);
  await database.query(`INSERT INTO authoring_audit_trail(doc_id,section_id,tenant_id,operation_type,metadata) VALUES($1,$2,7,'CREATE',$3)`,
    [DOC,SEC,{templateSource:child,templateGuidance:{guidance_text:CHILD_GUIDE,drafting_mode:'manual',regulatory_references:['ICH E3'],compliance_checklist:[],common_pitfalls:[],source_reference:'server/services/ind/ctd/csr-e3-guidance.ts#16.3.1'},
      assembly:{version:1,docId:DOC,programId:PROGRAM,templateId:CHILD_TEMPLATE,templateSnapshot:child.sha256,fingerprint:'c'.repeat(64)}}]);
  statements.length=0;
});
async function turn(artifactId = DOC, sectionId: string | undefined = SEC) {
  h.state.script = ['A source review is needed.'];
  const response=await httpRequest(app).post('/api/ana-ri/stream').send({message:'Review the exact open section.',project_id:PROGRAM,
    authoring_context:{projectId:PROGRAM,artifactId,sectionId,sectionCode:'3',sectionTitle:'Client label',documentType:'US_IND'}});
  expect(response.status,response.text).toBe(200);
  expect(h.state.requests.length).toBeGreaterThan(0);
  return h.state.requests[0].messages.map(message=>String(message.content)).join('\n');
}

describe('the live stream uses the exact admitted saved section reference', () => {
  it('retains assembled CSR guidance instead of the different parent IND outline', async () => {
    const prompt=await turn();
    expect(prompt).toContain(CHILD_GUIDE);
    expect(prompt).not.toContain('registry US_IND');
    expect(prompt).not.toContain('PARENT_ONLY_US_IND_LIMIT');
  });
  it('does not leak another recorded project’s saved template through the admitted public project', async () => {
    const prompt=await turn(PRIVATE_DOC,undefined);
    expect(prompt).not.toContain('registry ICH_IB');
    expect(prompt).not.toContain('ICH E6(R3) Appendix A');
    expect(statements.some(sql=>/authoring_audit_trail/.test(sql))).toBe(false);
  });
});
