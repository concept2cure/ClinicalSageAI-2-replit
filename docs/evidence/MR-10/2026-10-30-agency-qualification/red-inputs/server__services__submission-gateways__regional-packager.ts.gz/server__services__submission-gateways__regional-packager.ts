/**
 * Regional eCTD packager — wraps a package of CTD leaves into the
 * folder structure + backbone XML that each region requires.
 *
 * What's the same across FDA / EMA / PMDA:
 *   - Module 2–5 folder layout (ICH M4)
 *   - Standard MD5 hash file (util/index-md5.txt)
 *   - util/dtd/ for shared eCTD DTDs
 *
 * What differs:
 *   - Module 1 layout (m1/us/, m1/eu/, m1/jp/)
 *   - Regional backbone XML (us-regional.xml / eu-regional.xml / jp-regional.xml)
 *     each with different element names + required attributes
 *   - Module 1 envelope leaf (FDA: 1-1, EMA: 1.0.x, PMDA: 1.13)
 *   - Character encoding rules (FDA + EMA: UTF-8; PMDA: UTF-8 but allows
 *     Shift-JIS in legacy paths)
 *
 * This file produces the correct backbone + folder skeleton; it does NOT
 * generate Module 2–5 content (that comes from the platform's authoring
 * pipeline). Callers pass a `LeafIndex` mapping CTD section codes to file
 * paths and the packager assembles the zip with one m1 backbone per
 * region.
 *
 * Validator integration: pre-transmit validation is run by the per-gateway
 * service (FDA eValidator, EMA-validator, PMDA pre-check). The packager
 * surfaces the backbone path so the validator can target it directly.
 */

import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';
import { createHash } from 'crypto';
import JSZip from 'jszip';
import type { Region, SubmissionFormat, SubmissionBundle } from './types';
import { ValidationError, resolveToRegistryEntry, getSubmissionTypeLabel } from './types';

// Re-export the region taxonomy from this packager's public surface: callers
// that import `packageEctdSubmission` (e.g. the eCTD qualification subsystem)
// also need its `Region` type, and the packager is their entry point.
export type { Region } from './types';
import { finalizePdfA } from '../ectd/pdfa-pipeline';
import { isPdfLeaf } from '../ectd/pdfa-detect';
import { assessLeafPdfSecurity } from '../ectd/leaf-pdf-security';
import { assertLeafSourceIntegrity, prepareOriginalPdf, requireOriginalPdfA, verifyPreservedOriginalsArchive } from '../ectd/original-pdf-preservation';
import type { LeafSourceIntegrity, OriginalPdfProof } from '../ectd/original-pdf-contract';
import {
  evaluateSubmissionGrade,
  pdfaRequiredFromEnv,
  type LeafGradeRecord,
} from '../ectd/pdfa-readiness';
import {
  listVendoredDtds,
  listVendoredStylesheets,
  assessDtdReadiness,
  dtdRequiredFromEnv,
  resolveDtdDir,
  STF_DTD,
  hasPassedPackageDtdValidation,
  type DtdReadinessResult,
  type DtdRegion,
} from '../ectd/dtd-bundler';
import { validateBackboneFile } from '../ectd/backbone-validation';
import { verifyChecksumBuffers } from '../ectd/checksum-manifest';
import type { DtdValidationEvidence } from '../../../shared/regulatory/ectd-dtd-validation';
import { classifyRegionalBackbone } from '../ectd/regional-backbone-readiness';
import {
  resolveApplicationTypeCode,
  resolveSubmissionTypeCode,
  resolveSubmissionSubTypeCode,
  resolveFormTypeCode,
  resolveContactTypeCode,
  submissionTypeTerms,
  usRegionalHeadingPlacement,
} from '../ectd/controlled-vocab';
import { generateStfFiles, type StfLeaf, type StfStudyMeta } from '../ectd/stf-generator';
import { auditStfCoverage } from '../ectd/ectd4-validator';
import {
  resolveCrossReferences,
  xrefRequiredFromEnv,
  type CrossReference,
} from '../ectd/cross-reference-resolver';

// Packager primitives, split into ./ectd-packager/* so the reusable pieces
// (types, leaf-id, md5-index, path helpers) live apart from this ~600-line
// orchestrator. This file stays the packager barrel: it imports them for its
// own use AND re-exports the public ones below, so every caller keeps its
// stable `../regional-packager` import path.
import type {
  EctdLeaf,
  FdaApplicantContact,
  FdaFormLeaf,
  FdaRegionalAdmin,
  LeafRef,
  ChecksumEntry,
} from './ectd-packager/types';
import { leafIdSlug, baseLeafId, createLeafIdAssigner } from './ectd-packager/leaf-id';
import { buildMd5Index } from './ectd-packager/md5-index';
import { escapeXml, studyFolderSlug, commonDir } from './ectd-packager/paths';
import { isPathWithin } from '../../utils/document-file-roots';
import { buildIchModuleTree, findDroppedLeaves, ECTD_XLINK_NS, type RenderedLeaf } from './ectd-packager/ich-headings';
import { normalizeCtdCode } from '../ectd/section-to-ctd';
import { ctdFolderSlug, compareSectionCode } from '../../../shared/regulatory/section-code';

// Re-export the public packager surface (barrel).
export type { EctdLeaf, FdaApplicantContact, FdaFormLeaf, FdaRegionalAdmin };
export { leafIdSlug, baseLeafId, createLeafIdAssigner, buildMd5Index, studyFolderSlug, commonDir };

/** Region → the Module 1 folder its regional backbone and leaves live under. */
export const M1_FOLDER_BY_REGION: Record<Region, string> = {
  fda:  'm1/us',
  ema:  'm1/eu',
  pmda: 'm1/jp',
  ca:   'm1/ca',
  uk:   'm1/uk',
  ch:   'm1/ch',
  au:   'm1/au',
  cn:   'm1/cn',
  br:   'm1/br',
  in:   'm1/in',
  kr:   'm1/kr',
  sg:   'm1/sg',
};

/**
 * Where a leaf's bytes go in the package, and which backbone its href resolves
 * against.
 *
 * ── Why this is a function, and why it canonicalises first ───────────────────
 * Both were derived inline from the RAW `ctdSection` string, in two places (the
 * lifecycle-delete branch and the normal branch), by `startsWith('1')` and
 * `charAt(0)`. `submission_leaves.section_code` carries two spellings: Module
 * 2-5 callers write `3.2.S.4.2`, and every Module 1 filing path writes the
 * `m`-prefixed form — `withTransmittalPair` emits `m1.1` and `m1.2` on EVERY
 * lifecycle sequence, the IND filing routes write `m1.12.4` and `m1.13`, and
 * the Module 1 forms panel places a sponsor's signed form at `m1.1`.
 *
 * `'m1.1'.startsWith('1')` is false, so all of those took the Module 2-5 branch
 * and landed at `mm/m1-1/…` — a top-level folder no eCTD layout defines, with
 * the backbone href pointing there. The most-filed documents in the product
 * were the ones going to the wrong place.
 *
 * The section is therefore canonicalised ONCE, here, through the same
 * `normalizeCtdCode` whose own docstring calls itself "the one normalisation
 * point on the transmit path" — a claim nothing on this path had made true.
 * That also collapses `3.2.s.4.2` and `3.2.S.4.2` onto one folder instead of
 * two siblings for one CTD section, and it keeps the full depth: `3.2.S.4.2`
 * files at `m3/3-2-s-4-2/`, never at its heading.
 *
 * Folder slugs are lowercase — the eCTD convention, and what `leafIdSlug`
 * already does for leaf ids.
 *
 * Fails closed on a section that is not a CTD code at all, because the value
 * used to become a folder name: `m1/us/1.2` — which this product's own
 * placement dialog suggested in its placeholder — produced `mm/m1-us-1-2/`. A
 * package whose layout is derived from an unparseable string is not one to ship
 * quietly.
 */
/**
 * Is this leaf a Module 1 (regional) leaf?
 *
 * The same canonicalisation `leafPackagePath` applies, and for the same reason:
 * this predicate decides WHICH BACKBONE a leaf is written into, and it was
 * `ctdSection.startsWith('1')` in six places. An `m1.1` leaf — what every
 * Module 1 filing path in this product writes — answered false to all of them,
 * so it was left out of the regional backbone AND swept into the ICH index.xml
 * as though it were a Module 2-5 document.
 *
 * An unparseable section is not Module 1; it has no module at all, and
 * `leafPackagePath` refuses it by name when its bytes are placed.
 */
export function isModule1Section(ctdSection: string): boolean {
  return normalizeCtdCode(ctdSection)?.charAt(0) === '1';
}

/**
 * A single file-name segment: no separator, no NUL, not `.` or `..`.
 *
 * Leaf file names and the application id reach this packager from AnA's tool
 * arguments (package_ectd_for_region), i.e. from the model. A `fileName` of
 * `../../x.pdf` became a zip entry outside its CTD folder — shipped to an agency
 * as such, and written outside the extraction directory when a caller asked for
 * the unzipped tree — and an `applicationId` of `../../x` put the zip itself
 * anywhere the process could write (INJ-PATH-002).
 */
function isPlainName(value: string): boolean {
  return value.length > 0 && value !== '.' && value !== '..' && !/[\\/\0]/.test(value);
}

export function leafPackagePath(
  leaf: Pick<EctdLeaf, 'ctdSection' | 'fileName'> & { studyId?: string },
  region: Region,
): { relPath: string; href: string; backboneDir: string } {
  if (!isPlainName(leaf.fileName)) {
    throw new ValidationError(
      `A leaf's file name must be a single name with no path in it; '${leaf.fileName}' is not. ` +
        `The CTD section decides the folder.`,
      [{ ruleId: 'LEAF-FILE-NAME-NOT-PLAIN', severity: 'error', filePath: leaf.fileName }],
    );
  }
  const section = normalizeCtdCode(leaf.ctdSection);
  if (!section) {
    throw new ValidationError(
      `Leaf '${leaf.fileName}' has section code '${leaf.ctdSection}', which is not a CTD section code ` +
        `(expected e.g. 1.2, 2.7.3 or 3.2.S.4.2). It has no place in the backbone.`,
      [{ ruleId: 'LEAF-SECTION-UNPARSEABLE', severity: 'error', filePath: leaf.fileName }],
    );
  }
  const slug = ctdFolderSlug(section)!;
  if (section.charAt(0) === '1') {
    // Module 1 → under the regional folder; href relative to the regional backbone.
    const backboneDir = M1_FOLDER_BY_REGION[region];
    return { relPath: `${backboneDir}/${slug}/${leaf.fileName}`, href: `${slug}/${leaf.fileName}`, backboneDir };
  }
  // Module 2-5 → shared folders; href relative to index.xml at the root.
  // Study-report leaves (studyId set) go under a per-study subfolder so each
  // study owns its folder + its own stf-<study-id>.xml (ICH STF convention).
  const studySub = leaf.studyId ? `/${studyFolderSlug(leaf.studyId)}` : '';
  const relPath = `m${section.charAt(0)}/${slug}${studySub}/${leaf.fileName}`;
  return { relPath, href: relPath, backboneDir: '' };
}

/**
 * Finalize a leaf's bytes to submission grade before they are written + hashed.
 * PDFs are run through the PDF/A-1b pipeline (a no-op when Ghostscript/veraPDF
 * are absent, so behaviour is unchanged in environments without the binaries).
 * When the bytes are actually converted the MD5 MUST be recomputed from the
 * converted bytes — the eCTD checksum contract requires index-md5 to match the
 * file that ships in the package — so any pre-computed leaf.md5 is dropped.
 *
 * Returns the conversion outcome alongside the bytes so the packager can build
 * the submission-grade roll-up and enforce the PDF/A gate (audit gap P0-2).
 */
async function finalizeLeafBytes(
  buf: Buffer,
  fileName: string,
  region: Region,
  options: { skipPdfaConversion?: boolean; sourceIntegrity?: LeafSourceIntegrity; originalPdfARequired?: boolean } = {},
): Promise<{
  bytes: Buffer;
  md5Override?: string;
  isPdf: boolean;
  converted: boolean;
  encrypted: boolean;
  securityReason?: string;
  agencyFormAsIssued?: boolean;
  originalPdfProof?: OriginalPdfProof;
}> {
  const { sourceIntegrity } = options;
  assertLeafSourceIntegrity(buf, fileName, sourceIntegrity);
  const namedPdf = fileName.toLowerCase().endsWith('.pdf');
  /* 2026-09-22 (W5/D7): the security gate keys on the BYTES, not the name.
     It ran only for a name ending .pdf, so secured PDF bytes under any other
     name shipped unexamined. Conversion still keys on the declared type: a
     PDF under a non-.pdf name is judged for security and shipped unchanged,
     never rewritten by the PDF/A pipeline.
     2026-09-23 (W5/D7, round-2 review): name .pdf OR %PDF- header is the one
     shared predicate, pdfa-detect isPdfLeaf, not an inline copy. */
  const pdfBytes = isPdfLeaf(fileName, buf);
  if (!pdfBytes) return { bytes: buf, isPdf: false, converted: false, encrypted: false };
  // Security is judged here on every path, including the deterministic one that
  // skips PDF/A. finalizePdfA used to note it only as a warning string the
  // packager then discarded, so a secured leaf shipped indistinguishable from
  // any other unconverted PDF. One rule, shared with transmit: leaf-pdf-security.
  const security = await assessLeafPdfSecurity(buf, region);
  if (security.verdict === 'secured') {
    return { bytes: buf, isPdf: namedPdf, converted: false, encrypted: true, securityReason: security.reason };
  }
  // An FDA form ships exactly as FDA issued it — never through Ghostscript,
  // which would strip the XFA form and FDA's security settings.
  if (security.verdict === 'fda-form-as-issued' && !sourceIntegrity?.registeredLegalOriginals.length) {
    return { bytes: buf, isPdf: true, converted: false, encrypted: false, agencyFormAsIssued: true };
  }
  const originalPdfProof = await prepareOriginalPdf(buf, fileName, sourceIntegrity);
  if (originalPdfProof) {
    if (options.originalPdfARequired) requireOriginalPdfA(originalPdfProof, fileName);
    return { bytes: buf, isPdf: true, converted: false, encrypted: false, originalPdfProof };
  }
  if (!namedPdf) return { bytes: buf, isPdf: false, converted: false, encrypted: false };
  // Deterministic path: skip PDF/A normalization so the shipped bytes equal the
  // input bytes exactly. Used for validation-only assembly (e.g. the submission
  // orchestrator) where byte-determinism across re-renders matters more than
  // PDF/A-1b normalization — Ghostscript conversion embeds timestamps and is
  // non-deterministic, which would break a re-derive-and-compare drift check.
  if (options.skipPdfaConversion) return { bytes: buf, isPdf: true, converted: false, encrypted: false };
  const result = await finalizePdfA(buf);
  if (!result.converted) return { bytes: buf, isPdf: true, converted: false, encrypted: false };
  const bytes = Buffer.from(result.pdfBytes);
  return { bytes, md5Override: createHash('md5').update(bytes).digest('hex'), isPdf: true, converted: true, encrypted: false };
}

export interface PackagerInput {
  region: Region;
  /** Application id — e.g. IND/NDA number for FDA, EU Procedure number for
   *  EMA, JP Application number for PMDA. */
  applicationId: string;
  /** Submission sequence number, four-digit zero-padded. */
  sequence: string;          // e.g. '0001'
  /** Submission type: 'original' | 'amendment' | 'response' | etc. */
  submissionType: string;
  /** Sponsor identifier — DUNS for FDA, EMA org id, PMDA applicant id. Written
   *  exactly as given: for FDA it is the text of us-regional `<applicant-info><id>`
   *  (since 2026-10-01; it reached no FDA file before). A caller that has none
   *  passes its UNASSIGNED marker (scripts/ci/check-fabricated-identity.mjs);
   *  the packager never substitutes a value. */
  sponsorId: string;
  /** Sponsor (company) name, written exactly as given: for FDA it is
   *  us-regional `<applicant-info><company-name>`. Same UNASSIGNED rule. */
  sponsorName: string;
  /** Product / device name. */
  productName: string;
  /** All leaves to include. */
  leaves: EctdLeaf[];
  /** Output directory; the package zip is written here. */
  outputDir: string;
  /** Whether to also write the unzipped tree alongside the zip (useful
   *  for validator runs that need to walk the folder structure). */
  emitUnzipped?: boolean;
  /** Submission environment for the PDF/A gate. 'production' (the default)
   *  enforces PDF/A when ECTD_REQUIRE_PDFA=true; 'staging' never blocks. */
  environment?: 'staging' | 'production';
  /**
   * Skip PDF/A-1b normalization so each leaf ships byte-identical to its source.
   * For validation-only assembly (e.g. the submission orchestrator) where
   * re-render byte-determinism matters more than PDF/A normalization: Ghostscript
   * conversion embeds timestamps and is non-deterministic, which would make a
   * re-derive-and-compare drift check false-positive. Default false (the real
   * deliverable path always normalizes to PDF/A).
   */
  skipPdfaConversion?: boolean;
  /** FDA us-regional admin metadata (only used when region === 'fda'). */
  fda?: FdaRegionalAdmin;
  /** Per-study metadata for the Study Tagging Files generated from study leaves. */
  studyMeta?: StfStudyMeta[];
  /**
   * Declared intra-package cross-references (hyperlinks between leaves/sections,
   * e.g. a 2.7.3 summary citing a 5.3.5.1 study report). Resolved at package
   * time; a broken (dangling / withdrawn-target) reference is surfaced on the
   * bundle and blocks a production build when ECTD_REQUIRE_XREF=true.
   */
  crossReferences?: CrossReference[];
}

/* ─── Region-specific backbone builders ───────────────────────────── */

/**
 * Rebase a cross-sequence pointer authored relative to the SEQUENCE ROOT onto
 * the backbone that will carry it.
 *
 * `computeLifecycleOperations` builds `modified-file` as '../<prior>/<the prior
 * leaf's package-relative path>' — correct from index.xml, which is at the
 * root. The FDA regional backbone is at m1/<region>/us-regional.xml, so the
 * same string written there resolves two directories too deep. Every step down
 * to the backbone is one more step back out.
 *
 * An absolute or already-anchored pointer is left alone: only a relative one is
 * being re-expressed, not rewritten.
 */
function rebaseToBackbone(pointer: string, backboneDir: string): string {
  if (!backboneDir || pointer.startsWith('/')) return pointer;
  const depth = backboneDir.split('/').filter(Boolean).length;
  return depth ? `${'../'.repeat(depth)}${pointer}` : pointer;
}

/**
 * Build one `<leaf>` element with the full ICH attribute set: operation,
 * inline `checksum`/`checksum-type="md5"` (matching the shipped bytes), the
 * backbone-relative `xlink:href`, and — for a lifecycle operation — the
 * `modified-file` pointer at the superseded leaf (its backbone + '#' + ID).
 *
 * A delete ships no file, so it carries no `xlink:href` and no checksum: only
 * its operation, its `modified-file` and its title. FDA's eCTD validation
 * criteria say a checksum is not specified for a delete. 2026-09-29 (W5/D7):
 * it carried the withdrawn file's path as its href and that file's checksum.
 *
 * The ID is the one assigned once for this leaf's backbone (`ref.id`), which is
 * also what the leaf manifest records — see `assignBackboneIds`.
 */
function leafElement(leaf: EctdLeaf, ref: LeafRef): string {
  if (!ref.id) {
    throw new Error(`regional-packager: leaf "${leaf.fileName}" (section ${leaf.ctdSection}) has no backbone ID assigned.`);
  }
  const modified = leaf.modifiedFile
    ? ` modified-file="${escapeXml(rebaseToBackbone(leaf.modifiedFile, ref.backboneDir))}"`
    : '';
  const content = leaf.operation === 'delete'
    ? ''
    : ` checksum="${ref.md5}" checksum-type="md5" xlink:href="${escapeXml(ref.href)}"`;
  return `<leaf operation="${leaf.operation}"${modified}${content} xlink:type="simple" ID="${escapeXml(ref.id)}">
  <title>${escapeXml(leaf.title)}</title>
</leaf>`;
}

/**
 * Render `<applicant-info>`: the applicant's `<id>` (the DUNS, as text) and
 * `<company-name>`, then `<applicant-contacts>` only when contacts were supplied.
 *
 * 2026-10-01 (package-spine sweep F07): this wrote `<applicant-info/>` whenever
 * no contacts were passed, which is every package-spine bundle, and never read
 * sponsorId or sponsorName, so no file in an FDA bundle named the applicant.
 * The identity is written exactly as the caller recorded it. An absent one
 * arrives as the caller's UNASSIGNED marker (scripts/ci/check-fabricated-identity.mjs);
 * nothing is invented here. With no contacts the element is left out rather
 * than filled with a placeholder contact, and `fdaBackboneGaps` reports it.
 */
function fdaApplicantInfoBlock(input: PackagerInput, contacts: readonly FdaApplicantContact[]): string {
  const contactsBlock = contacts.length
    ? `\n      <applicant-contacts>\n${contacts.map(fdaApplicantContact).join('\n')}\n      </applicant-contacts>`
    : '';
  return `    <applicant-info>
      <id>${escapeXml(input.sponsorId)}</id>
      <company-name>${escapeXml(input.sponsorName)}</company-name>${contactsBlock}
    </applicant-info>`;
}

/**
 * One `<applicant-contact>`: its name, then `<telephones>`, then `<emails>`, each
 * wrapper written only when the contact has that value. It used to write
 * `<email>` and `<telephone>` straight under `<applicant-contact>`, email first.
 *
 * 2026-10-01: `<telephone>` carries no telephone-number-type. FDA's code list
 * for it is not vendored in this repository (cv-v3-data.ts has none), so no
 * code is guessed; `fdaBackboneGaps` reports the omission instead.
 */
function fdaApplicantContact(c: FdaApplicantContact): string {
  const code = resolveContactTypeCode(c.type) ?? 'fdaact1';
  const lines = [
    '        <applicant-contact>',
    `          <applicant-contact-name applicant-contact-type="${code}">${escapeXml(c.name)}</applicant-contact-name>`,
  ];
  if (c.phone) lines.push('          <telephones>', `            <telephone>${escapeXml(c.phone)}</telephone>`, '          </telephones>');
  if (c.email) lines.push('          <emails>', `            <email>${escapeXml(c.email)}</email>`, '          </emails>');
  lines.push('        </applicant-contact>');
  return lines.join('\n');
}

/** Render the `<form>` elements nested under submission-information. */
function fdaFormsBlock(forms: FdaFormLeaf[], resolve: (l: EctdLeaf) => LeafRef): string {
  return forms
    .map((f) => {
      const code = resolveFormTypeCode(f.formType) ?? 'fdaft2';
      return `          <form form-type="${code}">
${leafElement(f.leaf, resolve(f.leaf)).split('\n').map((l) => '            ' + l).join('\n')}
          </form>`;
    })
    .join('\n');
}

/**
 * The content of `<m1-regional>`: one heading element per FDA heading, holding
 * that heading's leaves, in section order (1.1 < 1.2 < 1.3.3 < 1.12.1 <
 * 1.14.4.1) whatever order the package lists its leaves in.
 *
 * 2026-10-01 (package-spine sweep F06): headings were written in the order the
 * package listed them, so a package that listed its cover letter first wrote
 * `<m1-2-cover-letters>` before `<m1-1-forms>`. Every heading is still written
 * directly under `<m1-regional>`; `usRegionalHeadingPlacement` says why a deeper
 * one is not nested, and `fdaBackboneGaps` reports each one that should be.
 *
 * A leaf declared under `fda.forms` is written once, by `fdaFormsBlock`, and not
 * here (package-spine sweep F20, 2026-10-08): it was written in both places with
 * one ID, which `fdaFormGaps` could only report.
 */
function fdaModule1Block(input: PackagerInput, resolve: (l: EctdLeaf) => LeafRef): string {
  const byHeading = new Map<string, { element: string; leaves: string[] }>();
  for (const l of fdaModule1HeadingLeaves(input)) {
    const { heading, element } = usRegionalHeadingPlacement(l.ctdSection);
    const group = byHeading.get(heading) ?? { element, leaves: [] };
    group.leaves.push(leafElement(l, resolve(l)));
    byHeading.set(heading, group);
  }
  const indent = (xml: string) => xml.split('\n').map((y) => '      ' + y).join('\n');
  return [...byHeading.keys()]
    .sort(compareSectionCode)
    .map((heading) => {
      const { element, leaves } = byHeading.get(heading)!;
      return `    <${element}>\n${leaves.map(indent).join('\n')}\n    </${element}>`;
    })
    .join('\n');
}

/**
 * What `buildFdaBackbone` cannot stand behind in the backbone it writes for this
 * input. `classifyRegionalBackbone` turns the list into `regionConformant`: true
 * only when it is empty, never for the region alone (sweep F06, 2026-10-01).
 * Each entry is a fact about the bytes the builder writes.
 */
function fdaBackboneGaps(input: PackagerInput): string[] {
  const fda = input.fda ?? {};
  const m1 = fdaModule1HeadingLeaves(input);
  const headingGaps = new Map<string, string>();
  for (const l of m1) {
    const { heading, gap } = usRegionalHeadingPlacement(l.ctdSection);
    if (gap) headingGaps.set(heading, gap);
  }
  return [...fdaContactGaps(fda.contacts ?? []), ...fdaFormGaps(m1, fda.forms ?? []), ...headingGaps.values()];
}

/** What `fdaApplicantInfoBlock` had to leave out of, or default in, the applicant contacts. */
function fdaContactGaps(contacts: readonly FdaApplicantContact[]): string[] {
  if (!contacts.length) return ['<applicant-info> has no <applicant-contacts>: no applicant contact was supplied'];
  return contacts.flatMap((c) => {
    const who = `applicant contact ${JSON.stringify(c.name)}`;
    return [
      resolveContactTypeCode(c.type) ? '' : `${who} has role ${JSON.stringify(c.type)}, which is not an applicant-contact-type code; it is written as fdaact1`,
      c.phone
        ? `${who}: <telephone> carries no telephone-number-type, whose FDA code list is not vendored here`
        : `${who} has no telephone, so no <telephones>`,
      c.email ? '' : `${who} has no email, so no <emails>`,
    ].filter(Boolean);
  });
}

/**
 * The Module 1 leaves written under their heading in `<m1-regional>`: every
 * Module 1 leaf except one declared under `fda.forms` (the same leaf object),
 * which the admin block carries instead.
 */
function fdaModule1HeadingLeaves(input: PackagerInput): EctdLeaf[] {
  const declared = new Set((input.fda?.forms ?? []).map((f) => f.leaf));
  return input.leaves.filter((l) => isModule1Section(l.ctdSection) && !declared.has(l));
}

/**
 * The forms' gaps, over the Module 1 leaves written under a heading
 * (`fdaModule1HeadingLeaves`). A forms leaf (1.1, or a 1.1.x filed under it)
 * there has no declared form type.
 *
 * Where a form belongs: FDA's Module 1 backbone specification (v2.6, the
 * DTD 3.3 line) places the 356h and the 1571 in their application's admin
 * section and other forms under `m1-1-forms` using the form element; the
 * repository's docs/ectd/SPEC_DIGEST.md records the admin `<form form-type>`
 * under `<submission-information>`, which `fdaFormsBlock` writes (sweep F20,
 * 2026-10-08, where the sentence and its sources are recorded). This replaces
 * a note that called the placement an open question. Wrapping the other forms
 * in `<form>` under `m1-1-forms` waits on the vendored us-regional DTD, so a
 * bare forms leaf there stays reported here.
 */
function fdaFormGaps(m1: readonly EctdLeaf[], forms: readonly FdaFormLeaf[]): string[] {
  const unresolved = forms
    .filter((f) => !resolveFormTypeCode(f.formType))
    .map((f) => `form ${f.leaf.fileName} has form type ${JSON.stringify(f.formType)}, which is not a form-type code; it is written as fdaft2`);
  const leafGaps = m1.flatMap((l) =>
    usRegionalHeadingPlacement(l.ctdSection).heading === '1.1'
      ? [`Module 1 forms leaf ${l.fileName} (${l.ctdSection}) has no declared form type`]
      : [],
  );
  return [...unresolved, ...leafGaps];
}

/**
 * FDA us-regional.xml backbone — written to the FDA eCTD Backbone Files
 * Specification for Module 1 (DTD version 3.3) as far as this repository records
 * it; what it cannot stand behind is listed by `fdaBackboneGaps` and decides the
 * bundle's regionConformant. Module 1 sits under m1/us/;
 * the backbone declares `xmlns:fda-regional="http://www.ich.org/fda"`, carries
 * the coded admin block (application-type / submission-type / submission-sub-
 * type / form-type as `fdaXX` attributes), and nests content leaves under
 * FDA-published section heading elements (e.g. `<m1-2-cover-letters>`).
 *
 * DTD path: the regional backbone is written two levels deep (m1/<cc>/<cc>-regional.xml)
 * while the vendored DTDs are bundled at the sequence root (util/dtd/), so the
 * DOCTYPE must climb two levels (`../../util/dtd/…`) — the form FDA's own example
 * us-regional.xml uses. A single `../` resolved to m1/util/dtd/, which no package
 * contains, so every regional backbone was un-validatable the moment a DTD was
 * dropped in. Pinned by __tests__/regional-backbone-dtd-path.test.ts.
 *
 * The <?xml-stylesheet?> PI on the line after the DOCTYPE had the same one-level
 * bug (`../util/style/`). It climbs two levels now, and the same test pins it.
 */
function buildFdaBackbone(input: PackagerInput, resolve: (l: EctdLeaf) => LeafRef): string {
  const fda = input.fda ?? {};
  /* Filing identity fails closed, and neither attribute is resolved through the
     other's vocabulary.

     Two callers disagree about what `input.submissionType` holds. The interface
     documents a SUBMISSION type ('original' | 'amendment' | ...), which is what
     most callers pass; orchestrator-real-package.ts passes an APPLICATION type
     ('IND' | 'NDA' | '510k' | ...). The old code fed that one field into BOTH
     vocabularies, so each caller hit the other's failure:

       - `resolveApplicationTypeCode('original')` -> null -> `?? 'fdaat1'`, and
         fdaat1 is NDA. Every package built without an explicit fda block
         declared itself a New Drug Application. The same default caught the
         real device pathways: `510k`, `de_novo`, `pma` — all enumerated in
         shared/schema/submissions.ts and offered in the UI — resolve to null
         because a 510(k) is not filed on this backbone at all, so a device
         dossier shipped as an NDA in the field the ESG routes on.
         applicationTypeToFdaCode's own contract says it "returns null for
         unknown values so callers can fail closed rather than mislabel an
         application" — stated at the definition, broken at its only call site.

       - `resolveSubmissionTypeCode('IND')` -> `fdast9`, because the only fdast
         entry containing "IND" is `IND Safety Reports`. Every orchestrator IND
         sequence — original, amendment, annual report — declared itself an IND
         safety report. core-to-packager.ts fixed this for the path that
         supplies an explicit fda block; the orchestrator supplies none, so the
         cross-vocabulary guess was still reachable here.

     So the field is classified once, and each vocabulary is asked only about a
     value that belongs to it. */
  const explicitApp = resolveApplicationTypeCode(fda.applicationType ?? '');
  const inferredApp = resolveApplicationTypeCode(input.submissionType);
  const appTypeCode = explicitApp ?? inferredApp;
  if (!appTypeCode) {
    /* A REFUSAL, so it is thrown as one. These two were the only plain Errors
       left in this module: every other refusal here is a ValidationError, and
       callers branch on that type to render the reason. A plain Error slipped
       past those branches and reached the operator as a bare 500 — 'amendment'
       is an ordinary word for a follow-up filing and no fdast term, so the
       obvious value produced an unexplained failure. */
    throw new ValidationError(
      `Cannot build the FDA regional backbone: no application type was supplied, and ` +
        `${JSON.stringify(input.submissionType)} is not one. The eCTD Module 1 ` +
        `application-type vocabulary covers NDA, sNDA, ANDA, BLA, IND and master ` +
        `files; device pathways (510(k), De Novo, PMA) and non-US pathways (MAA, ` +
        `CTA) have no code in it and must not be filed on this backbone. Pass ` +
        `fda.applicationType. Defaulting to fdaat1 would declare this package a ` +
        `New Drug Application, which is a statement about the filing, not a ` +
        `formatting detail.`,
      [],
    );
  }

  /* Only a value that is NOT an application type may be read as a submission
     type — that is what keeps 'IND' out of the fdast vocabulary. Sequence 0000
     is an original by definition, so deriving fdast1 for it is a fact; any
     later sequence could be an efficacy supplement, a CMC supplement or an
     annual report, and "Original Application" is not a safe guess for one. */
  const subTypeSource = fda.submissionType ?? (inferredApp ? undefined : input.submissionType);
  const subTypeCode = subTypeSource
    ? resolveSubmissionTypeCode(subTypeSource)
    : input.sequence === '0000'
      ? 'fdast1'
      : null;
  if (!subTypeCode) {
    throw new ValidationError(
      `Cannot build the FDA regional backbone: submission-type is unresolved for ` +
        `sequence ${input.sequence} (${JSON.stringify(subTypeSource ?? null)}). Only ` +
        `sequence 0000 can be derived as an Original Application; a follow-up must ` +
        `supply fda.submissionType from the eCTD Module 1 vocabulary — ` +
        `${(submissionTypeTerms('fda') ?? []).join(', ')} — because ` +
        `an efficacy supplement, a CMC supplement and an annual report are different ` +
        `filings and the backbone has to say which this is.`,
      [],
    );
  }

  const subSubTypeCode =
    resolveSubmissionSubTypeCode(fda.submissionSubType ?? 'original') ?? 'fdasst1';
  const submissionId = fda.submissionId ?? input.sequence;

  const applicantInfo = fdaApplicantInfoBlock(input, fda.contacts ?? []);
  const forms = fda.forms?.length ? '\n' + fdaFormsBlock(fda.forms, resolve) : '';
  const m1Regional = fdaModule1Block(input, resolve);

  /* application-containing-files="true" (2026-10-01, sweep F07; the attribute was
     absent): this backbone declares exactly one <application>, and it is the one
     whose files this package carries. Every leaf it references with an href is
     written into the same zip, and `resolve` refuses a referenced leaf (a form
     leaf, say) that the package does not carry. */
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fda-regional:fda-regional SYSTEM "../../util/dtd/us-regional-v3-3.dtd">
<?xml-stylesheet type="text/xsl" href="../../util/style/us-regional.xsl"?>
<fda-regional:fda-regional dtd-version="3.3" xml:lang="en"
    xmlns:fda-regional="http://www.ich.org/fda"
    xmlns:xlink="${ECTD_XLINK_NS}">
  <admin>
${applicantInfo}
    <application-set>
      <application application-containing-files="true">
        <application-information>
          <application-number application-type="${appTypeCode}">${escapeXml(input.applicationId)}</application-number>
        </application-information>
        <submission-information>
          <submission-id submission-type="${subTypeCode}">${escapeXml(submissionId)}</submission-id>
          <sequence-number submission-sub-type="${subSubTypeCode}">${escapeXml(input.sequence)}</sequence-number>${forms}
        </submission-information>
      </application>
    </application-set>
  </admin>
  <m1-regional>
${m1Regional}
  </m1-regional>
</fda-regional:fda-regional>`;
}

/**
 * EMA eu-regional.xml backbone. Per EMA EU eCTD Specification v3.0.
 * Module 1 sits under m1/eu/ with eu-regional.xml at the m1/eu/ root.
 */
function buildEmaBackbone(input: PackagerInput, resolve: (l: EctdLeaf) => LeafRef): string {
  const m1Leaves = input.leaves
    .filter((l) => isModule1Section(l.ctdSection))
    .map((l) => leafElement(l, resolve(l)))
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE eu-regional SYSTEM "../../util/dtd/eu-regional.dtd">
<eu-regional xmlns:xlink="http://www.w3.org/1999/xlink"
             dtd-version="3.0">
  <admin>
    <procedure>
      <procedure-number>${escapeXml(input.applicationId)}</procedure-number>
      <procedure-type>${escapeXml(input.submissionType)}</procedure-type>
    </procedure>
    <applicant>
      <id>${escapeXml(input.sponsorId)}</id>
      <name>${escapeXml(input.sponsorName)}</name>
    </applicant>
    <submission>
      <sequence>${escapeXml(input.sequence)}</sequence>
      <submission-unit>${escapeXml(input.submissionType)}</submission-unit>
      <related-sequence/>
    </submission>
  </admin>
  <m1-eu>
${m1Leaves}
  </m1-eu>
</eu-regional>`;
}

/**
 * PMDA jp-regional.xml backbone. Per PMDA "Notification on Electronic
 * Common Technical Document" (initial 2016, updated 2021). Module 1
 * sits under m1/jp/ with multi-byte titles permitted.
 */
function buildPmdaBackbone(input: PackagerInput, resolve: (l: EctdLeaf) => LeafRef): string {
  const m1Leaves = input.leaves
    .filter((l) => isModule1Section(l.ctdSection))
    .map((l) => leafElement(l, resolve(l)))
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE jp-regional SYSTEM "../../util/dtd/jp-regional.dtd">
<jp-regional xmlns:xlink="http://www.w3.org/1999/xlink"
             dtd-version="1.0">
  <admin>
    <application>
      <application-number>${escapeXml(input.applicationId)}</application-number>
      <application-type>${escapeXml(input.submissionType)}</application-type>
    </application>
    <applicant>
      <pmda-applicant-id>${escapeXml(input.sponsorId)}</pmda-applicant-id>
      <name>${escapeXml(input.sponsorName)}</name>
    </applicant>
    <submission>
      <sequence-number>${escapeXml(input.sequence)}</sequence-number>
      <submission-type>${escapeXml(input.submissionType)}</submission-type>
      <product-name>${escapeXml(input.productName)}</product-name>
    </submission>
  </admin>
  <m1-jp>
${m1Leaves}
  </m1-jp>
</jp-regional>`;
}

/**
 * Health Canada ca-regional.xml backbone. Per the Health Canada "Guidance
 * Document: Preparation of Regulatory Activities in the eCTD Format" and the
 * CA Module 1 specification. Module 1 sits under m1/ca/ with the regional
 * backbone at m1/ca/ca-regional.xml. Transmission is via the Common
 * Electronic Submissions Gateway (CESG).
 */
function buildHcBackbone(input: PackagerInput, resolve: (l: EctdLeaf) => LeafRef): string {
  const m1Leaves = input.leaves
    .filter((l) => isModule1Section(l.ctdSection))
    .map((l) => leafElement(l, resolve(l)))
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE ca-regional SYSTEM "../../util/dtd/ca-regional.dtd">
<ca-regional xmlns:xlink="http://www.w3.org/1999/xlink"
             dtd-version="3.0">
  <admin>
    <application>
      <dossier-id>${escapeXml(input.applicationId)}</dossier-id>
      <regulatory-activity-type>${escapeXml(input.submissionType)}</regulatory-activity-type>
    </application>
    <applicant>
      <company-name>${escapeXml(input.sponsorName)}</company-name>
      <company-id>${escapeXml(input.sponsorId)}</company-id>
    </applicant>
    <submission>
      <sequence-number>${escapeXml(input.sequence)}</sequence-number>
      <submission-type>${escapeXml(input.submissionType)}</submission-type>
      <product-name>${escapeXml(input.productName)}</product-name>
    </submission>
  </admin>
  <m1-ca>
${m1Leaves}
  </m1-ca>
</ca-regional>`;
}

/* ─── M2-M5 common backbone (ICH M8) ──────────────────────────────── */

/** The regional Module 1 backbone, as index.xml references it. */
interface RegionalBackboneRef {
  /** Package-relative path, e.g. m1/us/us-regional.xml. */
  href: string;
  /** MD5 of the regional XML bytes written into the package. */
  md5: string;
}

/**
 * index.xml's pointer to Module 1. Module 1 content lives in the regional
 * backbone, and the ICH backbone reaches it through a leaf under
 * m1-administrative-information-and-prescribing-information that names the
 * regional XML with its MD5. Without it the regional file (an IND's Form FDA
 * 1571 among its leaves) was in the package, in util/index-md5.txt, and
 * referenced by nothing in index.xml — a reader of the ICH backbone saw a
 * sequence with no Module 1 at all. Every sequence carries its own regional
 * backbone, so the pointer is always operation="new".
 */
function regionalBackboneReference(ref: RegionalBackboneRef): string {
  const file = ref.href.split('/').pop() ?? ref.href;
  return `  <m1-administrative-information-and-prescribing-information>
    <leaf operation="new" checksum="${ref.md5}" checksum-type="md5" xlink:href="${escapeXml(ref.href)}" xlink:type="simple" ID="leaf-m1-regional-backbone">
      <title>Module 1 regional backbone (${escapeXml(file)})</title>
    </leaf>
  </m1-administrative-information-and-prescribing-information>
`;
}

function buildIndexXml(
  input: PackagerInput,
  m2to5: EctdLeaf[],
  resolve: (l: EctdLeaf) => LeafRef,
  regional: RegionalBackboneRef | null,
): string {
  // Fail loudly on any leaf that maps to no ICH module — otherwise it would be
  // silently dropped from the backbone (a submission document vanishing without
  // a trace). Module-1 leaves are already filtered out upstream, so anything
  // unmappable here is a genuinely out-of-range or malformed CTD section.
  const dropped = findDroppedLeaves(m2to5);
  if (dropped.length) {
    const detail = dropped.map((l) => `${l.ctdSection} (${l.fileName})`).join(', ');
    throw new ValidationError(
      `eCTD backbone cannot place ${dropped.length} leaf(s) — no ICH Module 2–5 ` +
        `heading matches: ${detail}. Assign each a valid CTD section.`,
      dropped.map((l) => `unplaceable-section:${l.ctdSection}`),
    );
  }
  // Render each leaf, then nest it under its authoritative ICH v3.2.2 heading.
  // Flat <m2>..<m5> is NOT a valid ectd:ectd child — the DTD requires the named
  // heading tree (m3-quality > m3-2-body-of-data > m3-2-s-drug-substance > leaf).
  // See ectd-packager/ich-headings.
  const rendered: RenderedLeaf[] = m2to5.map((l) => ({
    leaf: l,
    xml: leafElement(l, resolve(l)),
  }));
  const moduleBlocks = buildIchModuleTree(rendered, 2);
  return `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="util/style/ectd-2-0.xsl"?>
<!DOCTYPE ectd:ectd SYSTEM "util/dtd/ich-ectd-3-2.dtd">
<ectd:ectd xmlns:ectd="http://www.ich.org/ectd"
           xmlns:xlink="${ECTD_XLINK_NS}"
           dtd-version="3.2">
${regional ? regionalBackboneReference(regional) : ''}${moduleBlocks}
</ectd:ectd>`;
}

/**
 * Give every leaf its backbone ID, once per carrying backbone. The builders
 * render the ID from the ref and the leaf manifest records the same value, so a
 * later sequence's modified-file names exactly the ID this backbone carries.
 *
 * 2026-09-29 (W5/D7): each builder ran its own assigner and nothing recorded
 * the result, so no later sequence could name a leaf, and modified-file carried
 * the file's path instead of the ID. A Module 1 leaf is carried by the regional
 * backbone; every other leaf by index.xml.
 *
 * `assigners` carries the per-backbone ID sets across calls. The packager
 * assigns the input leaves' IDs before it writes the Study Tagging Files (each
 * STF points at index.xml leaf IDs) and the STF leaves' IDs after, with the
 * same sets, so the IDs are the ones a single pass would give and an STF leaf
 * can never take an ID already used.
 */
function assignBackboneIds(
  leaves: EctdLeaf[],
  refByLeaf: Map<EctdLeaf, LeafRef>,
  regionalBackbone: string,
  assigners: Map<string, ReturnType<typeof createLeafIdAssigner>> = new Map(),
): void {
  for (const leaf of leaves) {
    const ref = refByLeaf.get(leaf);
    if (!ref || ref.id) continue;
    const backbone = ref.backboneDir ? regionalBackbone : 'index.xml';
    let assign = assigners.get(backbone);
    if (!assign) {
      assign = createLeafIdAssigner();
      assigners.set(backbone, assign);
    }
    ref.id = assign(leaf);
    ref.backbone = backbone;
  }
}

/**
 * A modified-file, from the sequence root: one or more '../', a relative path
 * to a prior sequence's backbone (.xml), '#', and an XML ID — e.g.
 * `../0000/index.xml#leaf-3-2-S-1-general`, or the grouped form
 * `../../nda456789/0001/m1/us/us-regional.xml#id2`. No '..' past the prefix.
 */
const MODIFIED_FILE_NAMES_A_LEAF =
  /^(?:\.\.\/)+(?:[A-Za-z0-9_-][A-Za-z0-9._-]*\/)+[A-Za-z0-9_-][A-Za-z0-9._-]*\.xml#[A-Za-z_][A-Za-z0-9._-]*$/;

/** Each region's Module 1 backbone, from the sequence root. */
const REGIONAL_BACKBONE_BY_REGION: Record<Region, string> = {
  fda:  `${M1_FOLDER_BY_REGION.fda}/us-regional.xml`,
  ema:  `${M1_FOLDER_BY_REGION.ema}/eu-regional.xml`,
  pmda: `${M1_FOLDER_BY_REGION.pmda}/jp-regional.xml`,
  ca:   `${M1_FOLDER_BY_REGION.ca}/ca-regional.xml`,
  uk:   `${M1_FOLDER_BY_REGION.uk}/uk-regional.xml`,
  ch:   `${M1_FOLDER_BY_REGION.ch}/ch-regional.xml`,
  au:   `${M1_FOLDER_BY_REGION.au}/au-regional.xml`,
  cn:   `${M1_FOLDER_BY_REGION.cn}/cn-regional.xml`,
  br:   `${M1_FOLDER_BY_REGION.br}/br-regional.xml`,
  in:   `${M1_FOLDER_BY_REGION.in}/in-regional.xml`,
  kr:   `${M1_FOLDER_BY_REGION.kr}/kr-regional.xml`,
  sg:   `${M1_FOLDER_BY_REGION.sg}/sg-regional.xml`,
};

/** The region's Module 1 backbone path from the sequence root, e.g. `m1/us/us-regional.xml`. */
export function regionalBackbonePath(region: Region): string {
  return REGIONAL_BACKBONE_BY_REGION[region];
}

/* ─── Top-level packager ──────────────────────────────────────────── */

interface CapturedPackageEntry { relPath: string; bytes: Buffer }

async function capturedChecksumManifest(dir: string): Promise<string> {
  // nosemgrep: javascript.lang.security.audit.path-traversal.path-join-resolve-traversal.path-join-resolve-traversal -- a constant file name in the packager's own working directory
  const file = path.join(dir, 'checksums.txt');
  try {
    const stat = await fs.lstat(file);
    return stat.isFile() && !stat.isSymbolicLink() ? await fs.readFile(file, 'utf8') : '';
  } catch { return ''; }
}

async function capturePackageEntries(zip: JSZip): Promise<CapturedPackageEntry[]> {
  const entries: CapturedPackageEntry[] = [];
  for (const [relPath, file] of Object.entries(zip.files)) {
    if (file.dir) continue;
    const bytes = Buffer.from(await file.async('nodebuffer'));
    entries.push({ relPath, bytes });
    // Freeze input by replacing original references with the private captured
    // buffers subsequently materialized for validation and written to the ZIP.
    zip.file(relPath, bytes, { date: file.date });
  }
  return entries;
}

/** Shared materialization for private validation and optional unzipped output. */
async function materializePackageEntries(dir: string, entries: CapturedPackageEntry[]): Promise<void> {
  await fs.mkdir(dir, { recursive: true });
  for (const { relPath, bytes } of entries) {
    // nosemgrep: javascript.lang.security.audit.path-traversal.path-join-resolve-traversal.path-join-resolve-traversal -- checked on the next line: isPathWithin(dir, dest) refuses an escaping entry (PACKAGE-ENTRY-ESCAPES)
    const dest = path.join(dir, relPath);
    if (!isPathWithin(dir, dest) || relPath.includes('\\')) {
      throw new ValidationError(`Package entry '${relPath}' would extract outside its directory.`, [
        { ruleId: 'PACKAGE-ENTRY-ESCAPES', severity: 'error', filePath: relPath },
      ]);
    }
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.writeFile(dest, bytes);
  }
}

async function validateCapturedPackage(entries: CapturedPackageEntry[], expectedFiles: string[], gate: DtdReadinessResult, manifestText: string): Promise<DtdValidationEvidence> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ectd-package-validation-'));
  try {
    await materializePackageEntries(dir, entries);
    const results = await Promise.all(expectedFiles.map(relPath => validateBackboneFile(dir, relPath)));
    const files = results.map(({ relPath, wellFormed, doctype, dtd }) => ({ relPath, wellFormed, doctype, dtd }));
    const supportive = entries.filter(entry => /^util\/(?:dtd|style)\/[^/]+\.(?:dtd|xsl)$/.test(entry.relPath))
      .map(entry => ({ fileName: path.posix.basename(entry.relPath), content: entry.bytes }));
    const integrity = verifyChecksumBuffers(supportive, manifestText, ['.dtd', '.xsl']);
    const evidence: DtdValidationEvidence = { version: 1, expectedFiles, files, integrity, passed: true };
    evidence.passed = hasPassedPackageDtdValidation({ ...gate, validation: evidence });
    return evidence;
  } finally { await fs.rm(dir, { recursive: true, force: true }); }
}

/** Bounded package-relative diagnostics reach the existing compile refusal. */
function dtdRefusalDetails(validation: DtdValidationEvidence): string[] {
  const failures = validation.files.flatMap(file => {
    const diagnostic = !file.wellFormed.ran || !file.wellFormed.valid || file.wellFormed.errors.length
      ? file.wellFormed.errors[0] ?? 'XML well-formedness did not run or failed'
      : !file.doctype.valid ? file.doctype.errors[0] ?? 'DOCTYPE dependency verification failed'
      : !file.dtd.ran || !file.dtd.valid || file.dtd.errors.length ? file.dtd.errors[0] ?? 'DTD validation did not run or failed' : null;
    return diagnostic ? [`${file.relPath}: ${diagnostic.slice(0, 300)}`] : [];
  });
  if (!validation.integrity.ok) {
    const names = [...validation.integrity.mismatched.map(item => item.fileName), ...validation.integrity.missingFiles, ...validation.integrity.unlistedFiles];
    failures.push(`Supportive-file checksum verification failed: ${names.slice(0, 8).join(', ') || 'required supportive bytes are unverified'}.`);
  }
  return failures.length ? failures.slice(0, 6) : ['Required supportive-file verification or complete XML execution coverage is absent.'];
}

export async function packageEctdSubmission(input: PackagerInput): Promise<SubmissionBundle> {
  /* Resolve the caller-supplied submission type through the canonical bridge.
     This normalizes any alias/legacy string (e.g. '510k', 'SNDA', 'ind') to
     the registry entry so that backbone XML, display names, and audit rows
     all use the same canonical identifier. The bridge returns null for
     unrecognized strings — in that case we fall through to the raw value,
     preserving backward compatibility for ad-hoc or org-specific types. */
  const registryEntry = resolveToRegistryEntry(input.submissionType);
  const canonicalSubmissionType = registryEntry?.applicationType ?? input.submissionType;
  const submissionTypeLabel = getSubmissionTypeLabel(input.submissionType);

  /* Build a normalized copy of the input for the backbone builders so they
     emit the canonical type into XML elements. The original PackagerInput
     is not mutated. */
  const normalizedInput: PackagerInput = {
    ...input,
    submissionType: canonicalSubmissionType,
  };

  const region = input.region;
  const backboneFileByRegion = REGIONAL_BACKBONE_BY_REGION;

  /* FDA eCTD validation 1789 — every file in a Module 4/5 study section (all
     but 4.3, 5.2, 5.3.6 and 5.4) must be referenced by a Study Tagging File,
     so it needs a study id and an STF file-tag. Checked before any byte is
     read, by the one coverage check (auditStfCoverage, ectd4-validator.ts).
     A US sequence that breaks it is refused, naming every such file; another
     region packages and the count is carried on bundle.stf.untagged.
     2026-10-05 (g-stf-1789-fail-closed): the STF pass below kept only leaves
     that already had both, so an untagged study report shipped with no STF,
     `untagged` was always 0 and nothing reported the rejection FDA would
     issue. */
  const stfUncovered = input.leaves.flatMap((leaf) =>
    auditStfCoverage(
      [{
        section: leaf.ctdSection, title: `${leaf.title} [${leaf.fileName}]`, operation: leaf.operation,
        studyId: leaf.studyId, stfFileTag: leaf.stfFileTag,
      }],
      { region, fileTagModelled: true },
    ).map((finding) => ({ leaf, finding })),
  );
  const stfRefusals = stfUncovered.filter((u) => u.finding.severity === 'error');
  if (stfRefusals.length > 0) {
    throw new ValidationError(
      `FDA validation 1789 (technical rejection): ${stfRefusals.length} file(s) in Module 4/5 study sections ` +
        `would be referenced by no Study Tagging File — ` +
        stfRefusals.map((u) => `${u.leaf.fileName} (section ${u.leaf.ctdSection}, no ${u.finding.code === 'STF_MISSING_FILE_TAG' ? 'file-tag' : 'study id'})`).join('; ') +
        `. Give each its study id and STF file-tag, or file it under 4.3, 5.2, 5.3.6 or 5.4 if that is where it belongs.`,
      stfRefusals.map((u) => ({
        ruleId: 'FDA-TRC-1789', severity: 'error', filePath: u.leaf.fileName, message: u.finding.message,
      })),
    );
  }

  const zip = new JSZip();
  const checksums: ChecksumEntry[] = [];
  const grades: LeafGradeRecord[] = [];

  /* PASS 1 — finalize every leaf's bytes FIRST, so the backbone can carry each
     leaf's real (post-PDF/A) MD5 as an inline `checksum` and a backbone-relative
     `xlink:href`. eCTD requires the checksum in the backbone to match the bytes
     shipped; finalization can change the bytes, so it must happen before the
     backbone is built. */
  interface PreparedLeaf {
    leaf: EctdLeaf; relPath: string; ref: LeafRef; bytes: Buffer;
    /** md5 of the bytes this packager was HANDED, when finalization changed them. */
    sourceMd5?: string;
    originalPdfProof?: OriginalPdfProof;
  }
  const prepared: PreparedLeaf[] = [];
  /** Backbone-only withdrawals: no bytes, but a filing act the manifest records. */
  const withdrawn: EctdLeaf[] = [];
  const refByLeaf = new Map<EctdLeaf, LeafRef>();
  for (const leaf of input.leaves) {
    // A modified-file names a filed LEAF — the backbone of the sequence that
    // filed it, '#', and its ID — never a file (ICH eCTD v3.2.2). Refused here,
    // the one sink every path reaches, so no caller can ship a pointer that
    // resolves to no leaf. 2026-09-29 (W5/D7).
    if (leaf.modifiedFile && !MODIFIED_FILE_NAMES_A_LEAF.test(leaf.modifiedFile)) {
      throw new ValidationError(
        `Leaf '${leaf.fileName}' (section ${leaf.ctdSection}) has modified-file "${leaf.modifiedFile}", which names no filed leaf. ` +
          `It must name the prior sequence's backbone and that leaf's ID, e.g. ../0000/index.xml#leaf-…`,
        [{ ruleId: 'LEAF-MODIFIED-FILE-NOT-A-LEAF', severity: 'error', filePath: leaf.fileName }],
      );
    }

    // A lifecycle delete is ALWAYS backbone-only: the withdrawn document lives
    // in a PRIOR sequence, so the delete leaf carries no bytes of its own —
    // exactly what computeLifecycleOperations emits. Render it as
    // operation="delete" pointing at the prior file (modified-file, also used as
    // the xlink:href), and never read a file, write it into this package, or
    // add a checksum line.
    //
    // 2026-09-23 (W5/D7, round-2 skeptic): this is the one sink every path
    // reaches, so the invariant is enforced HERE. A delete that carried a
    // sourcePath used to fall through and be packaged as an ordinary file: the
    // withdrawn document's bytes shipped in the withdrawing sequence, checksummed,
    // under an href into THIS sequence and with no modified-file — the AnA tool
    // package_ectd_for_region built exactly that for every withdrawal. Both
    // shapes are now refused, naming the leaf: a delete with a sourcePath, and
    // a delete with no modified-file pointer at the leaf it withdraws.
    //
    // 2026-09-23 (W5/D7, round-2 skeptic, second pass): sequence 0000 was exempt
    // from the modified-file rule, so a delete in a first sequence — where
    // nothing is on file to withdraw — packaged with checksum="" and an
    // xlink:href at a file absent from the zip (reachable through the AnA tool,
    // whose schema no longer requires source_path). Every delete in 0000 is now
    // refused, and every other delete must name its modified-file.
    // package-from-core already reports a 0000 delete in `skipped`, so the
    // canonical spine never reaches this.
    if (leaf.operation === 'delete') {
      if (leaf.sourcePath) {
        throw new ValidationError(
          `Leaf '${leaf.fileName}' (section ${leaf.ctdSection}) is a delete that carries a source file ` +
            `(${leaf.sourcePath}). A withdrawal ships no content: it names the filed leaf it withdraws ` +
            `through modified-file and carries no bytes, so the package will not read, ship or checksum them. ` +
            `Remove the source path from the delete.`,
          [{ ruleId: 'LEAF-DELETE-CARRIES-BYTES', severity: 'error', filePath: leaf.fileName }],
        );
      }
      if (input.sequence.trim() === '0000') {
        throw new ValidationError(
          `Leaf '${leaf.fileName}' (section ${leaf.ctdSection}) is a delete in sequence 0000. A first sequence ` +
            `has nothing on file to withdraw, so there is no filed leaf this delete could name.`,
          [{ ruleId: 'LEAF-DELETE-IN-FIRST-SEQUENCE', severity: 'error', filePath: leaf.fileName }],
        );
      }
      if (!leaf.modifiedFile) {
        throw new ValidationError(
          `Leaf '${leaf.fileName}' (section ${leaf.ctdSection}) is a delete in sequence ${input.sequence} with no ` +
            `modified-file. A withdrawal must name the filed leaf it withdraws (the prior sequence's backbone and ` +
            `that leaf's ID, e.g. ../0000/index.xml#leaf-…); without it the agency cannot tell which document is withdrawn.`,
          [{ ruleId: 'LEAF-DELETE-NO-MODIFIED-FILE', severity: 'error', filePath: leaf.fileName }],
        );
      }
      const { backboneDir } = leafPackagePath(leaf, region);
      // A withdrawal has no bytes of its own: no href and no checksum reach the
      // backbone (leafElement), only its modified-file, rebased onto the
      // backbone that carries it. 2026-09-29 (W5/D7): its href used to be the
      // pointer and its checksum the withdrawn file's.
      refByLeaf.set(leaf, { href: '', md5: '', backboneDir });
      withdrawn.push(leaf);
      continue; // no bytes → no prepared entry, no ZIP file, no checksum line
    }

    // A replace or append in a follow-up acts on a filed leaf and must say
    // which, exactly as a delete must. Without modified-file the backbone files
    // a second current version beside the one it meant to supersede. This is
    // the one sink every path reaches (the canonical spine reports such an act
    // before it gets here). 2026-09-29 (W5/D7).
    if ((leaf.operation === 'replace' || leaf.operation === 'append') && input.sequence.trim() !== '0000' && !leaf.modifiedFile) {
      throw new ValidationError(
        `Leaf '${leaf.fileName}' (section ${leaf.ctdSection}) is a ${leaf.operation} in sequence ${input.sequence} with no ` +
          `modified-file. It must name the filed leaf it acts on (the prior sequence's backbone and that leaf's ID, ` +
          `e.g. ../0000/index.xml#leaf-…); without it the version it supersedes stays current at the agency.`,
        [{ ruleId: 'LEAF-ACT-NO-MODIFIED-FILE', severity: 'error', filePath: leaf.fileName }],
      );
    }

    const raw = await fs.readFile(leaf.sourcePath);
    const { bytes, md5Override, isPdf, converted, encrypted, securityReason, agencyFormAsIssued, originalPdfProof } =
      await finalizeLeafBytes(raw, leaf.fileName, region, { skipPdfaConversion: input.skipPdfaConversion, sourceIntegrity: leaf.sourceIntegrity,
        originalPdfARequired: pdfaRequiredFromEnv() && (input.environment ?? 'production') === 'production' });
    grades.push({ fileName: leaf.fileName, isPdf, converted, encrypted, ...(agencyFormAsIssued ? { agencyFormAsIssued } : {}),
      ...(originalPdfProof ? { originalPdfAValidation: originalPdfProof.pdfAValidation } : {}) });
    if (encrypted) {
      throw new ValidationError(
        `Leaf '${leaf.fileName}' is an encrypted/secured PDF (${securityReason ?? 'it carries an /Encrypt entry'}); the package cannot ship it.`,
        [{ ruleId: 'LEAF-ENCRYPTED', severity: 'error', filePath: leaf.fileName, message: securityReason }],
      );
    }
    // Hash the EXACT bytes about to be written into the zip — never a caller-
    // supplied leaf.md5. The eCTD checksum contract requires index-md5 to match
    // the shipped file; a pre-computed leaf.md5 can be stale/wrong (computed
    // against different bytes, before a re-render), which md5Override only
    // guards on the PDF/A-conversion branch. The bytes are already in memory, so
    // recomputing is free and makes the manifest correct by construction.
    const md5 = md5Override ?? createHash('md5').update(bytes).digest('hex');
    /* The digest of what the caller HANDED us, recorded whenever finalization
       changed the bytes (PDF/A conversion). The next sequence decides "did this
       document change" by comparing the md5 its caller computed — over what it
       rendered or staged, before this function runs — and that is only a
       like-for-like comparison against THIS digest. Against `md5` it compares
       two stages of one document, which Ghostscript makes differ on every run
       (it stamps dates and a random document ID): with the toolchain in the
       production image, every follow-up re-filed every unchanged document as
       `replace`. `md5` stays what the backbone and index-md5 carry. */
    const sourceMd5 = md5Override !== undefined ? createHash('md5').update(raw).digest('hex') : undefined;

    // Module, folder and carrying backbone — one canonicalising rule, shared
    // with the lifecycle-delete branch above (leafPackagePath).
    const { relPath, href, backboneDir } = leafPackagePath(leaf, region);
    const ref: LeafRef = { href, md5, backboneDir };
    refByLeaf.set(leaf, ref);
    prepared.push({ leaf, relPath, ref, bytes, ...(sourceMd5 && sourceMd5 !== md5 ? { sourceMd5 } : {}),
      ...(originalPdfProof ? { originalPdfProof } : {}) });
  }
  const resolve = (l: EctdLeaf): LeafRef => {
    const ref = refByLeaf.get(l);
    if (!ref) {
      // A leaf referenced by the backbone (e.g. an FDA transmittal form passed
      // in fda.forms) that was never in input.leaves is never read, hashed, or
      // written into the zip. Emitting a fabricated ref (empty/unverified md5 +
      // an href to a file that is absent from the package) would declare a
      // legally-required document present while it is missing. Fail closed: the
      // referenced leaf must be in input.leaves so it is actually packaged.
      throw new ValidationError(
        `regional-packager: leaf "${l.fileName}" (section ${l.ctdSection}) is referenced by the backbone but was not packaged — include it in input.leaves so it is read, hashed, and written into the submission.`,
        // ValidationError carries structured findings alongside the sentence —
        // this call was written with the message alone. Same shape as the
        // unplaceable-leaf refusal above, so a caller inspecting `findings`
        // sees this refusal too instead of only its text.
        [`unpackaged-referenced-leaf:${l.ctdSection}:${l.fileName}`],
      );
    }
    return ref;
  };

  /* Backbone IDs for the input leaves first: each Study Tagging File points at
     its study's leaves by their index.xml ID. The STF leaves get theirs from
     the same per-backbone sets once they exist (assignBackboneIds). */
  const backboneIdAssigners = new Map<string, ReturnType<typeof createLeafIdAssigner>>();
  assignBackboneIds(input.leaves, refByLeaf, backboneFileByRegion[region], backboneIdAssigners);

  /* PASS 1.5 — Study Tagging Files (ICH STF v2.6.1, audit gap G5). For each
     M4/M5 study (leaves carrying studyId + stfFileTag) generate a per-study
     stf-<study-id>.xml that tags the study's leaves by their index.xml leaf ID,
     place it in the study's folder, reference it in index.xml, and checksum it.
     Graceful no-op when there are no study leaves.
     2026-10-05 (g-stf-name-tags-and-shape): every STF was written as 'stf.xml'
     and pointed at the PDFs relative to the study folder; the name and the
     doc-content -> index.xml#ID shape now come from stf-generator.ts. */
  const stfSyntheticLeaves: EctdLeaf[] = [];
  const stfPaths: string[] = [];
  /* `untagged` is the 1789 coverage gap found above (stfUncovered): zero for a
     US sequence, which is refused otherwise; for another region the files that
     package with no STF. Absent when the sequence has no study files at all. */
  let stfSummary: { studies: number; leaves: number; untagged: number } | undefined =
    stfUncovered.length > 0 ? { studies: 0, leaves: 0, untagged: stfUncovered.length } : undefined;
  {
    const studyPrepared = prepared.filter(
      (p) => p.leaf.studyId && p.leaf.stfFileTag && !isModule1Section(p.leaf.ctdSection),
    );
    if (studyPrepared.length > 0) {
      const byStudy = new Map<string, typeof studyPrepared>();
      for (const p of studyPrepared) {
        const list = byStudy.get(p.leaf.studyId!) ?? [];
        list.push(p);
        byStudy.set(p.leaf.studyId!, list);
      }
      const studyFolder = new Map<string, string>();
      const stfLeaves: StfLeaf[] = [];
      for (const [studyId, entries] of byStudy) {
        const folder = commonDir(entries.map((e) => e.relPath));
        studyFolder.set(studyId, folder);
        // index.xml is at the sequence root: one '../' per folder level.
        const indexRelPath = `${'../'.repeat(folder.split('/').filter(Boolean).length)}index.xml`;
        for (const e of entries) {
          if (!e.ref.id || e.ref.backbone !== 'index.xml') {
            throw new Error(
              `regional-packager: study leaf "${e.leaf.fileName}" (section ${e.leaf.ctdSection}) has no index.xml leaf ID for its Study Tagging File to point at.`,
            );
          }
          stfLeaves.push({
            studyId,
            fileTag: e.leaf.stfFileTag!,
            ctdSection: e.leaf.ctdSection,
            href: e.relPath,
            title: e.leaf.title,
            operation: e.leaf.operation,
            indexLeafId: e.ref.id,
            indexRelPath,
          });
        }
      }
      const stfResult = generateStfFiles(stfLeaves, input.studyMeta ?? [], {
        dtdSystemPath: studyId => path.posix.relative(studyFolder.get(studyId)!, `util/dtd/${STF_DTD}`),
      });
      stfSummary = { studies: stfResult.summary.studies, leaves: stfResult.summary.leaves, untagged: stfUncovered.length };
      for (const file of stfResult.files) {
        const folder = studyFolder.get(file.studyId)!;
        const relPath = `${folder}/${file.fileName}`;
        stfPaths.push(relPath);
        const bytes = Buffer.from(file.xml, 'utf8');
        const md5 = createHash('md5').update(bytes).digest('hex');
        const section = byStudy.get(file.studyId)![0].leaf.ctdSection;
        const synthetic: EctdLeaf = {
          ctdSection: section, operation: 'new', sourcePath: '',
          fileName: file.fileName, title: `Study Tagging File — ${file.studyId}`,
        };
        // A study tagging file lives under m4/m5 and is referenced from index.xml
        // at the root, so its href is already root-relative.
        const ref: LeafRef = { href: relPath, md5, backboneDir: '' };
        refByLeaf.set(synthetic, ref);
        prepared.push({ leaf: synthetic, relPath, ref, bytes });
        stfSyntheticLeaves.push(synthetic);
      }
    }
  }

  assignBackboneIds(stfSyntheticLeaves, refByLeaf, backboneFileByRegion[region], backboneIdAssigners);

  const backboneByRegion: Record<Region, () => string> = {
    fda:  () => buildFdaBackbone(normalizedInput, resolve),
    ema:  () => buildEmaBackbone(normalizedInput, resolve),
    pmda: () => buildPmdaBackbone(normalizedInput, resolve),
    ca:   () => buildHcBackbone(normalizedInput, resolve),
    // ICH-aligned / EU-structure regions use EMA backbone as the closest standard
    uk:   () => buildEmaBackbone(normalizedInput, resolve),
    ch:   () => buildEmaBackbone(normalizedInput, resolve),
    au:   () => buildEmaBackbone(normalizedInput, resolve),
    // CTD/eCTD regions without a distinct backbone builder — EMA ICH M4 fallback
    cn:   () => buildEmaBackbone(normalizedInput, resolve),
    br:   () => buildEmaBackbone(normalizedInput, resolve),
    in:   () => buildEmaBackbone(normalizedInput, resolve),
    kr:   () => buildEmaBackbone(normalizedInput, resolve),
    sg:   () => buildEmaBackbone(normalizedInput, resolve),
  };

  /* PASS 2 — write the regional Module 1 backbone (now that hrefs+md5s exist). */
  const regionalXml = backboneByRegion[region]();
  const regionalPath = backboneFileByRegion[region];
  const regionalMd5 = createHash('md5').update(regionalXml).digest('hex');
  zip.file(regionalPath, regionalXml);
  checksums.push({ relPath: regionalPath, md5: regionalMd5 });

  /* Write all finalized leaf bytes. */
  for (const p of prepared) {
    zip.file(p.relPath, p.bytes);
    checksums.push({ relPath: p.relPath, md5: p.ref.md5 });
  }
  // Module 2–5 leaves for index.xml, including the generated STF files so each
  // Each stf-<study-id>.xml is a referenced leaf in the backbone (not an orphan file).
  const m2to5 = [
    ...input.leaves.filter((l) => !isModule1Section(l.ctdSection)),
    ...stfSyntheticLeaves,
  ];

  /* PDF/A submission-grade gate (audit gap P0-2): when ECTD_REQUIRE_PDFA=true
     and this is a production package, refuse to ship any PDF leaf that the
     PDF/A pipeline could not convert (e.g. Ghostscript missing). Default
     (flag unset) is report-only, preserving graceful degradation. */
  const gradeGate = evaluateSubmissionGrade({
    leaves: grades,
    environment: input.environment ?? 'production',
    requirePdfA: pdfaRequiredFromEnv(),
  });
  if (!gradeGate.cleared) {
    throw new ValidationError(
      `eCTD package is not submission-grade: ${gradeGate.blockers.join(' ')}`,
      gradeGate.blockers,
    );
  }
  const submissionGrade = gradeGate.summary;

  /* Bundle vendored DTDs into util/dtd/ so the package is DTD self-contained
     (the backbones' DOCTYPEs reference util/dtd/*.dtd). The licensed DTD files
     are vendored per assets/ectd-dtd/README.md (or come from $ECTD_DTD_DIR), so
     this is a no-op when absent. DTDs are package files, so they are checksummed
     into index-md5.txt alongside the leaves. */
  const dtdDir = resolveDtdDir();
  const vendoredDtds = await listVendoredDtds(dtdDir);
  const manifestText = await capturedChecksumManifest(dtdDir);
  for (const dtd of vendoredDtds) {
    const relPath = `util/dtd/${dtd.fileName}`;
    zip.file(relPath, dtd.bytes);
    checksums.push({ relPath, md5: createHash('md5').update(dtd.bytes).digest('hex') });
  }

  /* Bundle vendored stylesheets into util/style/ for the same reason: index.xml
     references util/style/ectd-2-0.xsl and the FDA backbone references
     ../../util/style/us-regional.xsl. Same drop-point, same MD5 treatment. */
  const vendoredStylesheets = await listVendoredStylesheets(dtdDir);
  for (const xsl of vendoredStylesheets) {
    const relPath = `util/style/${xsl.fileName}`;
    zip.file(relPath, xsl.bytes);
    checksums.push({ relPath, md5: createHash('md5').update(xsl.bytes).digest('hex') });
  }

  /* DTD self-containment gate (audit gap P0-1): when ECTD_REQUIRE_DTD=true and
     this is a production package, refuse to ship a package that references DTDs
     it does not contain. Default (flag unset) is report-only. */
  const dtdGate = assessDtdReadiness({
    region: region as DtdRegion,
    present: vendoredDtds.map((d) => d.fileName),
    presentStylesheets: vendoredStylesheets.map((s) => s.fileName),
    environment: input.environment ?? 'production',
    requireDtd: dtdRequiredFromEnv(),
    hasStudyTaggingFiles: stfPaths.length > 0,
  });
  if (!dtdGate.cleared) {
    throw new ValidationError(
      `eCTD package is not DTD self-contained (DTDs and stylesheets): ${dtdGate.blockers.join(' ')}`,
      dtdGate.blockers,
    );
  }

  /* Cross-reference resolution (intra-package hyperlinks). Resolve declared
     references against the leaf set; a broken (dangling / withdrawn-target)
     reference is an eCTD technical-validation defect. Surfaced on the bundle;
     blocks a production build when ECTD_REQUIRE_XREF=true (report-only default,
     mirroring the PDF/A + DTD gates). */
  const xref = resolveCrossReferences(input.leaves, input.crossReferences ?? []);
  if (!xref.ok && xrefRequiredFromEnv() && (input.environment ?? 'production') === 'production') {
    const detail = xref.broken.map((b) => `${b.source}→${b.target} (${b.reason})`).join(', ');
    throw new ValidationError(
      `eCTD package has ${xref.broken.length} broken cross-reference(s): ${detail}. ` +
        `Resolve them, or clear ECTD_REQUIRE_XREF for non-submission builds.`,
      xref.broken.map((b) => `${b.source}→${b.target}: ${b.reason}`),
    );
  }

  /* Write the ICH M2-M5 index.xml + index-md5.txt. */
  const indexXml = buildIndexXml(input, m2to5, resolve, { href: regionalPath, md5: regionalMd5 });
  const indexXmlMd5 = createHash('md5').update(indexXml).digest('hex');
  zip.file('index.xml', indexXml);
  checksums.push({ relPath: 'index.xml', md5: indexXmlMd5 });

  // ICH eCTD v3.2.2 REQUIRES `index-md5.txt` at the SEQUENCE ROOT holding the
  // bare MD5 of index.xml — regional validators (FDA eValidator / EMA / PMDA)
  // reject a sequence whose backbone checksum file is missing. (The additional
  // `util/index-md5.txt` full-file manifest below is a platform convenience, not
  // the spec artifact, and is not a substitute for the root file.)
  zip.file('index-md5.txt', indexXmlMd5);
  zip.file('util/index-md5.txt', buildMd5Index(checksums));

  // Validate privately captured package entries before publishing its ZIP.
  // Reuse these same buffers for ZIP output and optional validator extraction.
  const captured = await capturePackageEntries(zip);
  const validation = await validateCapturedPackage(captured, ['index.xml', regionalPath, ...stfPaths], dtdGate, manifestText);
  if (dtdRequiredFromEnv() && (input.environment ?? 'production') === 'production' && !validation.passed) {
    const reasons = dtdRefusalDetails(validation);
    throw new ValidationError(`eCTD package DTD validation is incomplete or failed. ${reasons.join(' ')}`,
      reasons.map(message => ({ ruleId: 'PACKAGE-DTD-VALIDATION', severity: 'error', message })));
  }

  /* Generate the zip + write to disk. */
  if (!isPlainName(input.applicationId) || !isPlainName(input.sequence)) {
    throw new ValidationError(
      'The application id and the sequence number name the package file, so each must be a single name ' +
        'with no path in it.',
      [{ ruleId: 'PACKAGE-NAME-NOT-PLAIN', severity: 'error', filePath: `${input.applicationId}-${input.sequence}` }],
    );
  }
  await fs.mkdir(input.outputDir, { recursive: true });
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  const filename = `${input.applicationId}-${input.sequence}-${region}.zip`;
  const outPath = path.join(input.outputDir, filename);
  await verifyPreservedOriginalsArchive(buffer, prepared.flatMap(p => p.originalPdfProof ? [{ href: p.relPath, proof: p.originalPdfProof }] : []));
  await fs.writeFile(outPath, buffer);

  const format: SubmissionFormat = region === 'pmda' ? 'pmda_ectd' : 'ectd';

  /* Optionally extract for validator runs. */
  if (input.emitUnzipped) {
    const extractDir = path.join(input.outputDir, `${input.applicationId}-${input.sequence}-${region}`);
    await materializePackageEntries(extractDir, captured);
  }

  // Per-sequence leaf manifest for cross-sequence lifecycle diffing: each shipped
  // leaf's CTD section + final href + md5 (+ op/modified-file/title), and the
  // backbone ID it carries there (leafId + backbone) — what the next sequence's
  // modified-file names. The NEXT sequence loads
  // this (loadPriorSequenceManifest) and diffs against it to derive
  // replace/append/delete. Raw shape (not built via sequence-manifest) to keep
  // the packager free of an ectd/ import; the ectd-side caller runs
  // buildLeafManifest over it before persisting.
  const leafManifest = [
    ...prepared.map((p) => ({
      ctdSection: p.leaf.ctdSection,
      fileName: p.leaf.fileName,
      href: p.relPath,
      md5: p.ref.md5,
      // What the next sequence's diff compares against; see PreparedLeaf.
      ...(p.sourceMd5 ? { sourceMd5: p.sourceMd5 } : {}),
      ...(p.originalPdfProof ? { originalPdfProof: p.originalPdfProof } : {}),
      ...(p.leaf.operation ? { operation: p.leaf.operation } : {}),
      ...(p.leaf.modifiedFile ? { modifiedFile: p.leaf.modifiedFile } : {}),
      ...(p.leaf.title ? { title: p.leaf.title } : {}),
      ...(p.leaf.leafKey ? { leafKey: p.leaf.leafKey } : {}),
      ...(p.ref.id && p.ref.backbone ? { leafId: p.ref.id, backbone: p.ref.backbone } : {}),
    })),
    // A withdrawal ships no file, but it is a filing act: the prior-state fold
    // drops a leaf whose last operation is a delete, and it can only do that if
    // the delete is recorded. Left out, the withdrawn leaf stayed on file for
    // every later sequence. Its href is the pointer the backbone carries, from
    // this sequence's root. 2026-09-23 (W5/D7).
    ...withdrawn.map((leaf) => {
      const ref = refByLeaf.get(leaf);
      return {
        ctdSection: leaf.ctdSection,
        fileName: leaf.fileName,
        href: leaf.modifiedFile ?? '',
        md5: leaf.md5 ?? '',
        operation: 'delete' as const,
        ...(leaf.modifiedFile ? { modifiedFile: leaf.modifiedFile } : {}),
        ...(leaf.title ? { title: leaf.title } : {}),
        ...(leaf.leafKey ? { leafKey: leaf.leafKey } : {}),
        ...(ref?.id && ref.backbone ? { leafId: ref.id, backbone: ref.backbone } : {}),
      };
    }),
  ];

  return {
    path:      outPath,
    sha256:    createHash('sha256').update(buffer).digest('hex'),
    sizeBytes: buffer.length,
    leafManifest,
    format,
    displayName: `${input.productName} · ${region.toUpperCase()} ${submissionTypeLabel} #${input.sequence}`,
    submissionGrade,
    // `required`/`missing` list DTDs; `selfContained` also accounts for the
    // stylesheets the backbones reference, so it can be false while `missing`
    // is empty — that is the stylesheet gap. That gap is now CARRIED rather
    // than only counted: without missingStylesheets the pre-transmit gate could
    // refuse a transmit for a stylesheet-only gap while naming no file at all.
    dtdStatus: {
      required: dtdGate.required,
      present: dtdGate.present,
      missing: dtdGate.missing,
      missingStylesheets: dtdGate.missingStylesheets,
      requiredStylesheets: dtdGate.requiredStylesheets,
      presentStylesheets: dtdGate.presentStylesheets,
      selfContained: dtdGate.selfContained,
      validation,
    },
    // Honest regional-M1 status: only fda/ema/pmda/ca have their own backbone
    // builder; the eight widened regions reuse the EMA structure, so their
    // `<cc>-regional.xml` is a PLACEHOLDER and must never read as conformant.
    // FDA's is judged on what its builder reports it could not stand behind.
    regionalBackbone: classifyRegionalBackbone(
      region,
      regionalPath,
      region === 'fda' ? fdaBackboneGaps(normalizedInput) : undefined,
      validation,
    ),
    ...(stfSummary ? { stf: stfSummary } : {}),
    ...(input.crossReferences?.length
      ? {
          crossReferenceStatus: {
            resolved: xref.resolved.length,
            broken: xref.broken.map((b) => ({ source: b.source, target: b.target, reason: b.reason })),
            ok: xref.ok,
          },
        }
      : {}),
  };
}
