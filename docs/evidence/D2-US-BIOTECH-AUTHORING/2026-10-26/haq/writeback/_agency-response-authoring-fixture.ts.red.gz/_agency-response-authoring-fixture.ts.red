/** Minimal source-only agency tables for isolated Authoring bridge tests.
 * Each test retains its own explicit migration list; no migration is hidden here. */
export const AGENCY_EVENT = 'agency-source-event';
export const AGENCY_QUESTION = 701;
export const AGENCY_ANSWER = 'Recorded answer based on the retained source evidence.';
export const AGENCY_RESPONSE_SOURCE_DDL = `CREATE TABLE concept2cure_agency_communications (
  event_id text PRIMARY KEY, organization_id integer, project_id integer, communication_type text,
  source_type text, received_date timestamptz, due_date timestamptz, closure_status text,
  human_review_status text, response_required boolean, audit_metadata jsonb);
CREATE TABLE agency_communication_questions (
  id integer PRIMARY KEY, organization_id integer, project_id integer, communication_event_id text,
  question_ref text, question_text text, discipline text, ctd_section text, response_text text,
  response_revision integer, response_updated_by integer, response_updated_at timestamptz,
  withdrawn_at timestamptz, withdrawal_reason text);`;

/** Additional columns read by the existing answer writer/readback and approval rules. */
export const AGENCY_RESPONSE_WRITEBACK_DDL = `
ALTER TABLE agency_communication_questions ADD COLUMN severity text DEFAULT 'major';
ALTER TABLE agency_communication_questions ADD COLUMN owner_user_id integer;
ALTER TABLE agency_communication_questions ADD COLUMN created_at timestamptz DEFAULT NOW();
ALTER TABLE agency_communication_questions ADD COLUMN updated_at timestamptz DEFAULT NOW();
ALTER TABLE agency_communication_questions ADD COLUMN withdrawn_by integer;
CREATE TABLE agency_question_response_revisions (
  id serial PRIMARY KEY, organization_id integer, question_id integer, revision integer,
  response_text text, response_digest text, written_by integer, written_at timestamptz DEFAULT NOW(), reason text,
  UNIQUE(question_id,revision));
CREATE TABLE electronic_signatures (
  id serial PRIMARY KEY, organization_id integer, signed_target text, bound_payload_digest text,
  signer_id integer, signer_name text, signed_at timestamptz DEFAULT NOW(), signature_meaning text,
  superseded_by integer, is_valid boolean DEFAULT true);
CREATE TABLE regulatory_commitments (
  id serial PRIMARY KEY, organization_id integer, source_question_id integer, commitment_type text,
  description text, due_date date, fulfilled_date date, regulatory_basis text, status text, deleted_at timestamptz);
`;
