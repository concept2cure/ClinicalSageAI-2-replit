/**
 * Regulatory document coverage report.
 *
 * Prints the portfolio-wide readiness of every document type in the global
 * registry: which types have a real, region-specific authoring structure
 * (production-ready / buildable) vs. which are still catalog-only metadata.
 * Also prints the biotech lifecycle spine (Pre-IND → IND → NDA/BLA across the
 * primary regions) so a product owner can confirm end-to-end coverage at a
 * glance.
 *
 * Usage:
 *   tsx scripts/regulatory-coverage-report.ts            # human-readable report
 *   tsx scripts/regulatory-coverage-report.ts --json     # machine-readable JSON
 *   tsx scripts/regulatory-coverage-report.ts --gaps     # only catalog-only gaps
 *
 * @module scripts/regulatory-coverage-report
 */

import {
  buildCoverageReport,
  getLifecycleSpineStatus,
  getCatalogOnlyGaps,
} from '../server/services/regulatory/registry/registryCoverage.js';
import {
  buildSubmittabilityReport,
  getUnsubmittableFilings,
} from '../server/services/regulatory/registry/submittabilityCoverage.js';

const asJson = process.argv.includes('--json');
const gapsOnly = process.argv.includes('--gaps');

const report = buildCoverageReport();
const spine = getLifecycleSpineStatus();
const gaps = getCatalogOnlyGaps();
// The back half. `report` above answers "can this be AUTHORED"; this answers
// "can it be SUBMITTED" — the other end of project initiation → submission.
const submittability = buildSubmittabilityReport();
const unsubmittable = getUnsubmittableFilings();

if (asJson) {
  process.stdout.write(
    JSON.stringify(
      { summary: report.summary, byRegion: report.byRegion, spine, gaps, submittability, unsubmittable },
      null,
      2
    ) + '\n'
  );
  process.exit(0);
}

function pct(n: number, total: number): string {
  return total === 0 ? '0%' : `${Math.round((n / total) * 100)}%`;
}

const line = (s = '') => process.stdout.write(s + '\n');

line('══════════════════════════════════════════════════════════════════');
line('  REGULATORY DOCUMENT COVERAGE REPORT');
line('══════════════════════════════════════════════════════════════════');
line();
line(`Total active document types: ${report.summary.total}`);
line(`  production_ready : ${report.summary.byReadiness.production_ready}  (${pct(report.summary.byReadiness.production_ready, report.summary.total)})  — dedicated section + task blueprints`);
line(`  buildable        : ${report.summary.byReadiness.buildable}  (${pct(report.summary.byReadiness.buildable, report.summary.total)})  — real section structure, generic tasks`);
line(`  catalog_only     : ${report.summary.byReadiness.catalog_only}  (${pct(report.summary.byReadiness.catalog_only, report.summary.total)})  — generic CTD fallback (backlog)`);
line();

if (!gapsOnly) {
  line('── Biotech lifecycle spine (Pre-IND → IND → NDA/BLA) ──────────────');
  line();
  for (const node of spine) {
    const mark = node.readiness === 'production_ready' ? '●' : node.readiness === 'buildable' ? '◐' : node.present ? '○' : '✗';
    line(`  ${mark}  ${node.region.padEnd(3)} ${node.id.padEnd(18)} ${node.readiness}`);
  }
  line();
  line('  ● production_ready   ◐ buildable   ○ catalog_only   ✗ missing');
  line();

  line('── Coverage by region ────────────────────────────────────────────');
  line();
  line('  region  agency          total  prod  build  catalog');
  for (const r of report.byRegion) {
    line(`  ${r.region.padEnd(7)} ${r.agency.padEnd(15)} ${String(r.total).padStart(4)}  ${String(r.productionReady).padStart(4)}  ${String(r.buildable).padStart(5)}  ${String(r.catalogOnly).padStart(6)}`);
  }
  line();
}

line(`── Catalog-only backlog (${gaps.length}) ─────────────────────────────────────`);
line();
const byRegion = new Map<string, string[]>();
for (const g of gaps) {
  const arr = byRegion.get(g.region) ?? [];
  arr.push(g.id);
  byRegion.set(g.region, arr);
}
for (const [region, ids] of [...byRegion.entries()].sort()) {
  line(`  ${region}: ${ids.join(', ')}`);
}
line();
line('These types are selectable in the catalog but resolve to a generic CTD');
line('outline. They are the prioritised backlog for dedicated section/task');
line('blueprints. Run with --json for machine-readable output.');

// ── Submittability: the back half of the workflow ────────────────────────────
line();
line('══════════════════════════════════════════════════════════════════');
line('  SUBMITTABILITY — can an authored filing actually reach an agency?');
line('══════════════════════════════════════════════════════════════════');
/* EVERY tier, or the numbers do not account for the filings. This line printed
   four of the five — `portal_only` was omitted — so it summed to one less than
   the total it sits under, and the filing in that tier appeared nowhere in the
   report at all. */
line(
  `  submittable ${submittability.byTier.submittable}   ` +
    `components (not filed on their own) ${submittability.byTier.not_a_filing}   ` +
    `portal-only ${submittability.byTier.portal_only}   ` +
    `no-identity ${submittability.byTier.no_identity}   ` +
    `no-gateway ${submittability.byTier.no_gateway}`
);
line();
for (const r of submittability.byRegion.filter((r) => r.filings > 0)) {
  line(
    `  ${String(r.region).padEnd(8)} ${String(r.submittable).padStart(3)}/${String(r.filings).padEnd(3)} filings via ` +
      `${String(r.gatewaySlug ?? '-')}:${String(r.defaultGateway ?? '-')}`
  );
}
if (unsubmittable.length) {
  line();
  line(`  ⚠ ${unsubmittable.length} filing type(s) selectable at initiation but NOT submittable:`);
  for (const u of unsubmittable) line(`      ${u.id} (${u.region}) — ${u.tier}`);
}

/* PORTAL-ONLY IS NOT A GAP, AND IT IS NOT FINISHABLE HERE EITHER.
   `getUnsubmittableFilings()` returns the INTEGRATION backlog by contract —
   no_identity and no_gateway — and deliberately excludes portal_only, because
   no integration will ever make a portal filing transmittable.
   `buildSubmittabilityReport().portalOnly` exists for exactly this, and this
   script never read it: the closing line was driven by `unsubmittable` alone
   and printed "Every startable filing type is finishable" over an EU CTA whose
   own channel is CTIS. It is worse than a silent omission, because the
   platform's gateway selection routes any EU non-device sequence to the
   medicines gateway (CESP) instead — so the one filing the report called
   finishable is the one that would go out the wrong door. */
if (submittability.portalOnly.length) {
  line();
  line(`  ◆ ${submittability.portalOnly.length} filing type(s) whose channel is a PORTAL, not a gateway.`);
  line('    Authored here, submitted by hand there. No integration changes this.');
  for (const p of submittability.portalOnly) {
    line(`      ${p.id} (${p.region}) — ${p.portalChannel ?? 'portal channel not named'}`);
  }
}

if (!unsubmittable.length && !submittability.portalOnly.length) {
  line();
  line('  ✅ Every startable filing type is finishable.');
} else if (!unsubmittable.length) {
  line();
  line('  ✅ Every startable filing type reaches a gateway, except the portal-only');
  line('     type(s) named above, which leave the platform by hand.');
}
