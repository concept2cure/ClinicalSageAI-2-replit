# PREPARATION ONLY; root must approve execution after the normal push closes.
import pathlib,os,json,hashlib,subprocess,sys,signal,time,urllib.parse,urllib.request,datetime,secrets,stat
if sys.argv[1:]!=['--execute-reviewed-runtime-refresh']:raise SystemExit('Prepared only; root runtime-refresh grant required.')
root=pathlib.Path('/workspace/ClinicalSageAI-2-replit');base=pathlib.Path('/tmp/platform-test-published-runtime-refresh-prep')
pins=json.loads((base/'source-pins.json').read_text())
for path,digest in pins['sources'].items():
 if hashlib.sha256((root/path).read_bytes()).hexdigest()!=digest:raise SystemExit('Reviewed source changed: '+path)
pidfile=pathlib.Path('/tmp/platform-workflow-server-pid.txt');leader=int(pidfile.read_text().strip())
if os.getpgid(leader)!=leader or os.getsid(leader)!=leader:raise SystemExit('Owned runtime is not its reviewed isolated group/session leader.')
def members(group):
 found=[]
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  pid=int(proc.name)
  try:
   if os.getpgid(pid)!=group:continue
   status=(proc/'status').read_text();uids=next(line.split()[1:] for line in status.splitlines() if line.startswith('Uid:'))
   if any(line.startswith('State:') and 'Z' in line for line in status.splitlines()):continue
   if not all(int(uid)==os.getuid() for uid in uids) or (proc/'cwd').resolve()!=root.resolve():raise RuntimeError('Owned group UID/cwd changed.')
   argv=[part.decode() for part in (proc/'cmdline').read_bytes().split(b'\0') if part]
   env=dict(part.decode().split('=',1) for part in (proc/'environ').read_bytes().split(b'\0') if b'=' in part)
   found.append((pid,argv,env))
  except (FileNotFoundError,ProcessLookupError):continue
 return found
owned=members(leader);servers=[row for row in owned if row[2].get('PORT')=='5000' and any(arg=='server/index.ts' or arg.endswith('/server/index.ts') for arg in row[1])]
if not servers:raise SystemExit('No current owned port5000 server; no fallback.')
runtime,argv,env=max(servers,key=lambda row:row[0]);env=dict(env)
for key in ['DATABASE_URL','APP_DATABASE_URL','DATABASE_OWNER_URL','DATABASE_URL_ADMIN','DATABASE_NEON_NEW_SECRET','NEON_DATABASE_URL','NEON_DATABASE_URL_ADMIN']:
 value=env.get(key)
 if not value:continue
 u=urllib.parse.urlsplit(value)
 if u.hostname!='127.0.0.1' or u.port!=55432 or u.path!='/platform_test' or urllib.parse.parse_qs(u.query,keep_blank_values=True)!={'sslmode':['disable']}:raise SystemExit('Database alias is outside the reviewed loopback platform_test target: '+key)
if not env.get('DATABASE_URL') or not env.get('APP_DATABASE_URL'):raise SystemExit('Both reviewed owner/runtime configurations are required.')
if urllib.parse.urlsplit(env['APP_DATABASE_URL']).username!='app_service' or urllib.parse.urlsplit(env['DATABASE_URL']).username=='app_service':raise SystemExit('Owner/runtime role split is missing.')
# Preserve all database/auth/provider settings in memory; the one explicit
# non-minting exception prevents dotenv from restoring a global password flag.
config_keys=[key for key in env if key!='APP_SERVICE_DB_PASSWORD' and any(word in key.upper() for word in ['DATABASE','AUTH','JWT','SESSION','SECRET','TOKEN','API_KEY','PROVIDER','BASE_URL','ENDPOINT','STORAGE'])]
config_hash=hashlib.sha256(json.dumps({key:env[key] for key in sorted(config_keys)},sort_keys=True).encode()).hexdigest()
env['APP_SERVICE_DB_PASSWORD']='';env['RUNTIME_REFRESH_ARTIFACT_DIR']=str(base)
oldlog=pathlib.Path(os.readlink(pathlib.Path(f'/proc/{runtime}/fd/1')))
if oldlog!=pathlib.Path('/tmp/platform-workflow-dev-server.txt') or os.readlink(pathlib.Path(f'/proc/{runtime}/fd/2'))!=str(oldlog):raise SystemExit('Unexpected current private server log.')
info=oldlog.lstat()
if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid():raise SystemExit('Current log is not an owned regular file.')
exe=str(pathlib.Path(f'/proc/{runtime}/exe').resolve())
path_for_tools='/tmp/platform-tools:/home/agent/.npm/_npx/6d82ddbdd7da268b/node_modules/node/bin:'+env.get('PATH','')
deploy_env=dict(env);deploy_env['PATH']=path_for_tools
fd=os.open(base/'deploy.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);results=[]
with os.fdopen(fd,'wb') as out:
 for command in [['node',str(base/'observe.mjs'),'before'],['node','scripts/db/deploy-migrate.mjs'],['node',str(base/'observe.mjs'),'after']]:
  process=subprocess.Popen(command,cwd=root,env=deploy_env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=900);result={'stage':command[1:],'exitCode':code,'timeout':False}
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
   result={'stage':command[1:],'exitCode':None,'timeout':True,'processGroupTerminated':True}
  results.append(result);(base/'deploy-result.json').write_text(json.dumps({'target':'platform_test','stages':results},indent=2)+'\n');os.chmod(base/'deploy-result.json',0o600)
  if result['exitCode']!=0:raise SystemExit('Canonical deployment/inspection stopped; old runtime left intact. See protected phase artifacts.')
# Recheck the exact controlled group before any stop; never kill by port alone.
if int(pidfile.read_text().strip())!=leader or not members(leader):raise SystemExit('Owned runtime identity changed; no restart.')
os.killpg(leader,signal.SIGTERM)
for _ in range(100):
 if not members(leader):break
 time.sleep(0.2)
else:raise SystemExit('Owned group did not stop gracefully; no forced kill or replacement server.')
archive=base/('previous-server-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+secrets.token_hex(4)+'.log')
if archive.exists():raise SystemExit('Exclusive log archive unexpectedly exists.')
os.rename(oldlog,archive);os.chmod(archive,0o600)
fd=os.open(oldlog,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as out:new=subprocess.Popen(argv,executable=exe,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
pidtemp=base/'new-pid.txt';pidtemp.write_text(str(new.pid)+'\n');pidtemp.chmod(0o600);os.replace(pidtemp,pidfile)
receipt={'oldLeaderPid':leader,'oldRuntimePid':runtime,'newLeaderPid':new.pid,'newGroup':os.getpgid(new.pid),'newSession':os.getsid(new.pid),'archivedLog':str(archive),'archivedLogSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'newLog':str(oldlog),'configKeys':len(config_keys),'preservedConfigurationSha256':config_hash,'mintPasswordFlagEmpty':True,'healthIsLivenessOnly':True,'healthzStatus':None,'readyzStatus':None}
for _ in range(120):
 if new.poll() is not None:receipt['startupExitCode']=new.returncode;break
 try:
  with urllib.request.urlopen('http://127.0.0.1:5000/healthz',timeout=2) as response:receipt['healthzStatus']=response.status
  break
 except Exception:time.sleep(0.5)
try:
 with urllib.request.urlopen('http://127.0.0.1:5000/readyz',timeout=5) as response:receipt['readyzStatus']=response.status
except urllib.error.HTTPError as error:receipt['readyzStatus']=error.code
except Exception:receipt['readyzStatus']=None
current=members(new.pid);current_servers=[row for row in current if row[2].get('PORT')=='5000' and any(arg=='server/index.ts' or arg.endswith('/server/index.ts') for arg in row[1])]
if current_servers:
 observed=max(current_servers,key=lambda row:row[0])[2]
 receipt['preservedConfigurationMatches']=all(observed.get(key)==env[key] for key in config_keys)
 receipt['ownedRuntimeVerified']=True
else:receipt['ownedRuntimeVerified']=False;receipt['preservedConfigurationMatches']=False
(base/'restart-result.json').write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(base/'restart-result.json',0o600)
print('Owned platform_test canonical deployment and restart complete; PID',new.pid,'healthz',receipt['healthzStatus'],'readyz',receipt['readyzStatus'],'; protected receipts:',base)
raise SystemExit(0 if receipt['healthzStatus']==200 and receipt['ownedRuntimeVerified'] and receipt['preservedConfigurationMatches'] else 1)
