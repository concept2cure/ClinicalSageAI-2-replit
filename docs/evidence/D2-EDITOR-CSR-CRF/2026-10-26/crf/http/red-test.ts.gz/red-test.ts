/** Real HTTP/JWT and canonical authoring writes over isolated PGlite. The
 * saved-design table is a minimal explicit source fixture; no source parser,
 * projection, current-access decision, importer or writer is mocked. */
import express from 'express';
import { SignJWT } from 'jose';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { createJourneyDb, type JourneyDb } from '../../../tests/golden-journeys/harness';
import { AUTHOR, AUTHORING_ACCESS_DDL, ORG, OTHER_ORG, PROGRAM, PROGRAM_B, PREREQ, JWT_SECRET, asToken, makeApp } from './_authoring-canvas-fixture';
import { newTrace, tappedPool } from './_authoring-record-fixture';
import { projectCrfShell } from '../../services/study-design/crf-shell';
import type { StudyDesign } from '../../services/study-design/study-design-types';

const h = vi.hoisted(() => ({ db: null as unknown, pool: null as unknown }));
vi.mock('../../db', () => ({ get db() { return h.db; }, get pool() { return h.pool; }, getPool: () => h.pool,
  query: (sql: string, params?: unknown[]) => (h.pool as { query: (text: string, args?: unknown[]) => Promise<unknown> }).query(sql, params) }));

const STUDY = 'saved-crf-study';
const REASON = 'Prepare the saved blank CRF design for controlled review';
const trace = newTrace();
let db: JourneyDb;
let app: express.Express;
let author: (req: request.Test) => request.Test;
const design: StudyDesign = {
  id: STUDY, programId: PROGRAM, organizationId: ORG, title: 'Recorded CRF study', version: 2, status: 'draft',
  phase: '2', indication: 'Recorded indication', productType: 'drug', objectives: [], estimands: [],
  endpoints: [{ name: 'Recorded response', role: 'primary', type: 'continuous', measurementMethod: 'central laboratory', timepoint: 'Week 4' }],
  framework: { inferentialFrame: 'superiority', structuralDesign: 'parallel_group', controlType: 'placebo' },
  population: { targetDescription: 'Adults', analysisPopulations: [], eligibility: [{ type: 'inclusion', text: 'Recorded eligibility criterion' }] },
  arms: [{ name: 'Treatment', interventions: [{ name: 'Recorded treatment', role: 'investigational' }] }],
  statisticalPlan: { alpha: 0.05, power: 0.8, plannedAnalyses: [] },
  scheduleOfActivities: { epochs: [{ id: 'screen', name: 'Screening', kind: 'screening', order: 0 },
    { id: 'treat', name: 'Treatment', kind: 'treatment', order: 1 }],
  visits: [{ id: 'V1', name: 'Screening', epochId: 'screen', order: 0 }, { id: 'V2', name: 'Week 4', epochId: 'treat', order: 1 }],
  activities: [{ id: 'A1', name: 'Recorded response assessment', category: 'efficacy', order: 0, endpointNames: ['Recorded response'] },
    { id: 'A2', name: 'Unlinked assessment', category: 'biomarker', order: 1 }],
  cells: [{ activityId: 'A1', visitId: 'V2', state: 'performed' }, { activityId: 'A2', visitId: 'V1', state: 'performed' }] },
};

beforeAll(async () => {
  db = await createJourneyDb({ prereqSql: PREREQ + AUTHORING_ACCESS_DDL, migrations: [
    'db/migrations/20260725_authoring_document_loop_tables.sql',
    'db/migrations/20260817_doc_revisions_immutable_ledger.sql',
    'db/migrations/20260725_authoring_audit_trail.sql',
    'db/migrations/20260813_audit_tamper_proof_log.sql',
    'db/migrations/20260725_authoring_signatures_and_workflow.sql',
    'db/migrations/20260725_authoring_signature_freeze_binding.sql',
    'db/migrations/20260730_authoring_runtime_ddl.sql',
    'db/migrations/20260730_authoring_comments_router_columns.sql',
    'db/migrations/20260727_authoring_object_permissions.sql',
    'db/migrations/20260803_document_span_lineage.sql',
    'migrations/20260907_span_lineage_accepted_machine_draft.sql',
    'migrations/20260908_span_lineage_machine_draft.sql',
    'migrations/20260728_authoring_comments_threading.sql',
    'migrations/20260727_authoring_document_program_scope.sql',
    'migrations/20260728_authoring_document_governed_binding.sql',
    'migrations/20260814d_document_alias_map.sql',
    'migrations/20260921_audit_logs_chain_seq.sql',
    'migrations/20260921_authoring_document_provenance.sql',
  ], testOnlySql: `CREATE TABLE cdisc_prm_studies(study_id text,tenant_id integer,program_id uuid,
    protocol_version text,metadata jsonb,updated_at timestamptz);` });
  h.db = db.db;
  h.pool = tappedPool(db, trace);
  author = asToken(await new SignJWT({ userId: AUTHOR.id, email: AUTHOR.email, organizationId: ORG, role: 'member' })
    .setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('1h').sign(new TextEncoder().encode(JWT_SECRET)));
  const requestRouter = express.Router();
  // Match production's existing request-client binding; router verifies real JWT.
  requestRouter.use((req, _res, next) => {
    Object.assign(req, { dbClient: { query: (sql: string, params?: unknown[]) =>
      (h.pool as { query: (text: string, args?: unknown[]) => Promise<unknown> }).query(sql, params) } });
    next();
  });
  requestRouter.use((await import('../authoring.router')).default);
  app = makeApp(requestRouter);
  await db.pool.query(`INSERT INTO cdisc_prm_studies VALUES($1,$2,$3,'2',$4,'2026-10-01')`,
    [STUDY, ORG, PROGRAM, { kind: 'c2c.studyDesign.v1', design }]);
}, 180_000);
afterAll(async () => { await db?.close(); });

const body = (studyId = STUDY, extra: Record<string, unknown> = {}) => ({ programId: PROGRAM, reason: REASON,
  source: { kind: 'study-design-crf', studyId }, ...extra });
const preview = (studyId = STUDY) => author(request(app).post('/api/authoring/import/source')).send(body(studyId, { previewOnly: true }));

describe('exact saved-study CRF working copy through the existing authoring route', () => {
  it('previews every projected blank form and preserves exact saved source identity', async () => {
    const response = await preview();
    expect(response.status, JSON.stringify(response.body)).toBe(200);
    const result = response.body.data;
    expect(result).toMatchObject({ preview: true, origin: { kind: 'study-design-crf', id: STUDY,
      selection: { kind: 'study-design-crf', studyId: STUDY }, conversion: 'study-design-crf-projection',
      sourceScope: { level: 'program', programId: PROGRAM, projectId: 42 } } });
    expect(result.sections.map((section: { code: string }) => section.code)).toEqual([
      'crf.identification', 'crf.gaps', ...projectCrfShell(design).forms.map((_form, index) => `crf.form.${String(index + 1).padStart(3, '0')}`),
    ]);
    expect((await db.pool.query('SELECT COUNT(*)::int AS n FROM authoring_documents')).rows[0].n).toBe(0);
  });
});
