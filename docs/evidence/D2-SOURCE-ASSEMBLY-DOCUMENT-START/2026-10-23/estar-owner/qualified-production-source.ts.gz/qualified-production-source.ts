/**
 * useEstarExport — the 510(k) surface's two real export actions, consuming
 * server/routes/510k-estar-routes.ts:
 *
 *   exportDraftPackage()  POST /api/510k/estar/build     (draft content ZIP —
 *                         rendered section PDFs; NOT the official eSTAR)
 *   exportOfficialEstar() POST /api/510k/estar/official  (the submittable FDA
 *                         eSTAR PDF; 422 with blockers until the official
 *                         template + verified field map are vendored). With
 *                         useProgramData the administrative fields are filled
 *                         from the org's governed records — governed wins,
 *                         typed values fill only the gaps — and the response's
 *                         fieldReport says what was and was not written.
 *
 * Both send meta.ident (program UUID / code / numeric project id — resolved
 * org-scoped server-side) and useProjectContent so the package is assembled
 * from the org's real authored sections, never a client-fabricated payload.
 * The response's downloadable_output_ref (base64) is turned into a real
 * browser download. Mirrors the raw-fetch mutator pattern of useEstarFiling,
 * with the same auth headers as useFetchJson (Bearer + x-organization-id).
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { errorCodeOf, serverMessage } from '@/lib/queryClient';
import { authService } from '@/services/portal/authService';
import { capturedActorHeaders } from '@/utils/authToken';
import { buildAuthHeaders, useFetchJson } from './useFetchJson';
import type { OfficialEstarType, OfficialEstarVariant } from './useEstarOfficialFields';
import { downloadBase64 } from '../../v2/download';
import { mutationUnconfirmed } from '../../v2/mutationOutcome';
import { taskActorScope } from '../../v2/taskTarget';
import {
  attachmentRefusals, confirmedAttachmentReceipts, copyAttachmentSelections,
  type OfficialEstarAttachment, type EstarAttachmentReceipt, type EstarAttachmentRefusal,
} from './estarAttachmentReceipt';
export type { OfficialEstarAttachment, EstarAttachmentReceipt, EstarAttachmentRefusal } from './estarAttachmentReceipt';

interface DownloadRef {
  encoding: 'base64';
  mime_type: string;
  filename: string;
  data: string;
}

export interface EstarExportOutcome {
  ok: boolean;
  /**
   * The browser actually took the file. `downloadBase64` reports this and it was
   * being discarded, so a blocked download still read as "Downloaded …" — for
   * the official FDA eSTAR, the one artifact a user must actually receive.
   */
  delivered: boolean;
  /** Registered in the artifact registry (governed consequence) vs audited-only delivery. */
  governed: boolean;
  filename: string | null;
  /**
   * Advisory us-estar formatting counts from the build. null = no report (the
   * check did not run, or this path runs none) — never read as 0 errors.
   */
  formattingErrors: number | null;
  formattingWarnings: number | null;
  /**
   * What the formatting check established (2026-09-22, W5/D7). 'not_assessed'
   * = it ran but some applicable rules could not be judged; 'not_run' = the
   * server sent no report; null = no export produced. Same fail-closed
   * contract as erasedFields.
   */
  formattingVerdict?: 'conformant' | 'conformant_with_warnings' | 'nonconformant' | 'not_assessed' | 'not_run' | null;
  /** Honest blockers when the official eSTAR is not producible (422). */
  blockers: string[];
  /**
   * The server refused with 403 { error:'NOT_ENTITLED' } — the capability is
   * above the org's plan (services/entitlements/require-entitlement). Distinct
   * from a role 403: only the entitlement shape sets this, so the surface can
   * render the Locked state (never a dead button) instead of a generic failure.
   */
  blockedByEntitlement: boolean;
  /** Minimum plan tier the server named alongside NOT_ENTITLED (never invented). */
  requiredTier: string | null;
  /** What the official fill wrote and left blank — null on the draft path,
   *  on failure, or when the server sent no report. */
  fieldReport: EstarFieldReport | null;
  /**
   * The keys the template's own scripts CLEAR once the applicant works the
   * form — named by the server on every POST /official 200, on both paths.
   *
   * It has its own slot because `fieldReport` does not exist on the verbatim
   * path: `describeOfficialFill` returns `fieldReport: null` whenever no
   * governed resolution ran, which is every export that does not set
   * `useProgramData`. The fill had named these keys since 2026-09-07 and this
   * hook read only the report, so the whole verbatim path said nothing about
   * values the form is about to take back.
   *
   * `[]` is "assessed, nothing erased". `null` is "not reported". The status
   * line only complains about `null` on the OFFICIAL path — the draft package
   * is a content ZIP, not the FDA form, so no template script clears anything
   * and there is nothing for the server to have reported. Collapsing assessed
   * and unreported on the official path would rebuild the fail-open at the last
   * hop; complaining about it on the draft path would be noise on every export.
   */
  erasedFields: string[] | null;
  /**
   * This outcome came from POST /official — the submittable FDA eSTAR — rather
   * than from the draft content ZIP. It exists so the line can tell "the
   * official server did not report the erasure" (a real gap the filer should
   * know about) from "this was never an official fill" (nothing to report).
   */
  official: boolean;
  /** A produced PreSTAR prefill is not a completed request. */
  applicantCompletionRequired?: boolean;
  /** Only a one-to-one server receipt confirms the selected UUIDs and bytes. */
  attachments?: EstarAttachmentReceipt[];
  attachmentRefusals?: EstarAttachmentRefusal[];
  /** The server may have produced/retained bytes, but delivery was not proved. */
  unconfirmed?: boolean;
  error: string | null;
}

/** The server's account of the administrative fill (POST /official 200). */
export interface EstarFieldReport {
  mappedCount: number;
  filledCount: number;
  blankCount: number;
  /** Canonical keys the fill left blank — the platform held no value. */
  blankKeys: string[];
  /** Typed keys the server dropped: a governed value took precedence, or the
   *  key is not on the template. */
  ignoredRequestKeys: string[];
  /** Governed facts the fill could not express — e.g. a second predicate the
   *  template has no box for. The user finishes these on the form. */
  advisories: string[];
  /** Keys we DID write that the template's own scripts clear once the applicant
   *  works the form. Counted in filledCount, gone by the time FDA sees it. */
  clearedByTemplateKeys: string[];
  /** Keys the template rebuilds from a DIFFERENT governed fact, so the cell
   *  ends up holding another value rather than nothing. */
  substitutedByTemplateKeys: string[];
}

export interface OfficialEstarOptions {
  /** The marketing pathway the eSTAR is produced for — selects the field map
   *  server-side. Defaults to '510k' so callers that predate the pathway
   *  option keep their behaviour. */
  type?: OfficialEstarType;
  /** Fill the administrative fields from the program's governed records. */
  useProgramData?: boolean;
  /** Values typed for this export only; empty/whitespace entries are dropped
   *  before sending (see cleanRequestData). */
  data?: Record<string, string>;
  /** Exact Vault version and FDA slot choices; expectedSha256 never leaves the browser. */
  attachments?: OfficialEstarAttachment[];
}

/**
 * Keep only the entries a user actually typed: non-empty after trimming,
 * trimmed. Pure + exported so the "only typed keys travel" rule is
 * unit-testable without a DOM.
 */
export function cleanRequestData(
  data: Record<string, string> | undefined,
): Record<string, string> {
  const out: Record<string, string> = {};
  if (!data) return out;
  for (const [key, raw] of Object.entries(data)) {
    if (typeof raw !== 'string') continue;
    const value = raw.trim();
    if (value) out[key] = value;
  }
  return out;
}

/**
 * The administrative-fill clause of the success line — filled of mapped, and
 * the blank count when anything was left blank. Pure so the wording is pinned
 * by a test rather than by however the JSX reads.
 */
export function fieldReportClause(report: EstarFieldReport | null): string {
  if (!report) return '';
  const blank = report.blankCount > 0 ? ` · ${report.blankCount} left blank` : '';
  // An advisory is a governed fact the form has no box for; the line carries
  // it whole, because "filled" alone would read as "finished".
  const advisories = report.advisories.map((a) => ` · ${a}`).join('');
  /*
   * "N of M filled" is true of the bytes we hand over and STOPS BEING TRUE the
   * moment the applicant works the form: the template's own scripts clear some
   * of those cells and rebuild one of them from a different governed fact. The
   * count is not restated smaller — we did write them — but it is no longer
   * stated alone, because a filer reading it decides whether the form is done.
   */
  const willNotSurvive = report.clearedByTemplateKeys.length + report.substitutedByTemplateKeys.length;
  const caveat = willNotSurvive > 0 ? ` · ${willNotSurvive} the form changes when you complete it` : '';
  return ` · ${report.filledCount} of ${report.mappedCount} administrative fields filled${blank}${caveat}${advisories}`;
}

/**
 * The erasure clause for a success with no field report — the verbatim path.
 *
 * Names the keys rather than only counting them: "2 values will be cleared" is
 * not actionable, and the whole point of the field is that the filer has to
 * re-enter these on the form. Pure, so the wording is pinned by a test.
 */
export function erasedFieldsClause(keys: string[] | null | undefined): string {
  // Anything that is not an array is "not reported" — null from a non-official
  // or older response, undefined from an outcome literal that predates the
  // field. Never `[]`, which would assert an assessment nobody made.
  if (!Array.isArray(keys)) return ' · this server did not report which values the form clears';
  if (keys.length === 0) return '';
  return ` · ${keys.length} value(s) the form clears when you complete it: ${keys.join(', ')}`;
}

/** The server's `erasedFields`, or null when it did not send the field. */
function parseErasedFields(raw: unknown): string[] | null {
  if (!Array.isArray(raw)) return null;
  return raw.filter((x): x is string => typeof x === 'string');
}

function parseFieldReport(raw: unknown): EstarFieldReport | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (
    typeof r.mappedCount !== 'number' ||
    typeof r.filledCount !== 'number' ||
    typeof r.blankCount !== 'number'
  ) {
    return null;
  }
  const strings = (v: unknown): string[] =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];
  return {
    mappedCount: r.mappedCount,
    filledCount: r.filledCount,
    blankCount: r.blankCount,
    blankKeys: strings(r.blankKeys),
    ignoredRequestKeys: strings(r.ignoredRequestKeys),
    advisories: strings(r.advisories),
    clearedByTemplateKeys: strings(r.clearedByTemplateKeys),
    substitutedByTemplateKeys: strings(r.substitutedByTemplateKeys),
  };
}

/**
 * The one-line export status the 510(k) surface renders (pure — extracted so
 * the Locked/blocked/success wording is unit-testable without a DOM).
 *
 * The NOT_ENTITLED line follows the entitlements UX contract (§4, locked-never-
 * dead): name the real minimum tier and the capability, nothing more.
 */
export function exportStatusLine(busy: boolean, outcome: EstarExportOutcome | null): string | null {
  if (busy) return 'Exporting…';
  if (!outcome) return null;
  if (outcome.ok) {
    const fErrors = outcome.formattingErrors ?? 0;
    const fWarnings = outcome.formattingWarnings ?? 0;
    const counts =
      fErrors + fWarnings > 0 ? ` · ${fErrors} formatting errors, ${fWarnings} warnings to fix before submitting` : '';
    // A clean count is only a clean result when the check ran on every rule.
    const coverage =
      outcome.formattingVerdict === 'not_assessed'
        ? ' · some formatting rules could not be checked'
        : outcome.formattingVerdict === 'not_run'
          ? ' · formatting was not checked'
          : '';
    const formatting = counts + coverage;
    const registry = outcome.governed ? '' : ' · audit-logged; artifact registry placement pending';
    // The server produced it either way; whether the file reached the user is a
    // separate fact, and saying "Downloaded" when it did not is the difference
    // between a user who looks in their downloads folder and one who does not.
    // Two ways it can fail to arrive, and they are not the same problem: the
    // browser refused the file, or the server never sent one.
    const verb = outcome.delivered
      ? `Downloaded ${outcome.filename ?? 'package'}`
      : outcome.filename
        ? `${outcome.filename} was produced but the browser blocked the download`
        : 'Export accepted, but the server returned no file to download';
    /* Only on the official path, and only when there is no report to carry it.
       On the governed path `clearedByTemplateKeys` is the same finding under
       another name and `fieldReportClause` already states it, so saying it
       twice in one line reads as two separate problems; on the draft path
       there is no FDA form and nothing to clear. */
    const erasure = outcome.official && !outcome.fieldReport
      ? erasedFieldsClause(outcome.erasedFields)
      : '';
    const completion = outcome.applicantCompletionRequired ? ' · PreSTAR administrative prefill; applicant completion and review required before filing' : '';
    return `${verb}${fieldReportClause(outcome.fieldReport)}${erasure}${formatting}${registry}${completion}`;
  }
  if (outcome.blockedByEntitlement) return entitlementRequiredLine(outcome.requiredTier);
  if (outcome.unconfirmed) return `Export unconfirmed — ${outcome.error ?? 'the result could not be confirmed'}`;
  return `Export failed — ${
    outcome.blockers.length ? outcome.blockers.join(' · ') : outcome.error ?? 'unknown error'
  }`;
}

/**
 * The one sentence for "this plan does not unlock the export" — used after a
 * 403 NOT_ENTITLED and, through useEstarEntitlement, BEFORE the first click.
 * Names the real minimum tier when the server named one; never invents a tier.
 */
export function entitlementRequiredLine(requiredTier: string | null | undefined): string {
  return requiredTier
    ? `Requires the ${requiredTier} plan — device assembly readiness`
    : 'Requires a higher plan — device assembly readiness';
}

/**
 * GET /api/510k/estar/entitlement — the export gate's verdict for this org,
 * read before anyone clicks. `enforced` is true only when the operator has
 * turned enforcement on (ENTITLEMENTS_ENFORCE=on); in 'warn' or 'off' mode the
 * POST would go through, so a surface must NOT lock on `allowed:false` unless
 * `enforced` is also true. `allowed` is null when nothing was evaluated.
 */
export interface EstarEntitlementView {
  capability: string;
  mode: 'off' | 'warn' | 'on';
  enforced: boolean;
  allowed: boolean | null;
  requiredTier: string | null;
  tier: string | null;
  reason: string | null;
}

export const ESTAR_ENTITLEMENT_URL = '/api/510k/estar/entitlement';

/** Pure: would the producing routes refuse this org today? */
export function entitlementBlocksExport(view: EstarEntitlementView | null | undefined): boolean {
  return view?.enforced === true && view.allowed === false;
}

function isEntitlementView(data: unknown): data is EstarEntitlementView {
  if (!data || typeof data !== 'object') return false;
  const d = data as Partial<EstarEntitlementView>;
  return typeof d.enforced === 'boolean' && (d.mode === 'off' || d.mode === 'warn' || d.mode === 'on');
}

export interface UseEstarEntitlementResult {
  entitlement: EstarEntitlementView | null;
  loading: boolean;
  error: string | null;
}

export function useEstarEntitlement(): UseEstarEntitlementResult {
  const { data, loading, error } = useFetchJson<unknown>(ESTAR_ENTITLEMENT_URL);
  /* A body that is not the documented verdict is no verdict: the control
     stays live (the 403 path still guards the write) rather than locking on
     a shape nobody read. */
  return { entitlement: isEntitlementView(data) ? data : null, loading, error };
}

const IDLE: EstarExportOutcome | null = null;

/* Was a local copy of the save-a-blob dance, byte-identical to the one in the
   sibling export hook — and both revoked the object URL synchronously right
   after click(), which races the download and can produce a zero-byte file.
   `downloadBase64` owns the decode and the timing. */
function triggerDownload(ref: DownloadRef): boolean {
  // atob throws on a malformed payload; that is a failure to deliver, not an
  // export failure, so it is reported as one rather than thrown into the
  // request's own catch where it would read as a network error.
  try {
    return downloadBase64(ref.filename, ref.data, ref.mime_type);
  } catch {
    return false;
  }
}

export interface ProgramRef {
  /** Program identifier the server resolves org-scoped (UUID / code / numeric id). */
  id: string;
  code?: string | null;
  title?: string | null;
}

export interface UseEstarExportResult {
  /** True while either export request is in flight. */
  busy: boolean;
  /** Outcome of the most recent export attempt (null until one runs). */
  outcome: EstarExportOutcome | null;
  exportDraftPackage: (program: ProgramRef) => Promise<EstarExportOutcome>;
  exportOfficialEstar: (
    program: ProgramRef,
    variant?: OfficialEstarVariant,
    opts?: OfficialEstarOptions,
  ) => Promise<EstarExportOutcome>;
  /** Forget the last outcome. A surface calls this when the program it shows
   *  changes, so a previous program's "Downloaded … filled/blank" line and its
   *  blank-caption list never sit under the next program's header. Stable. */
  reset: () => void;
}

function failedExport(official: boolean, error: string, unconfirmed = false): EstarExportOutcome {
  return {
    ok: false, delivered: false, governed: false, filename: null, formattingErrors: null, formattingWarnings: null,
    formattingVerdict: null, blockers: [], blockedByEntitlement: false, requiredTier: null, fieldReport: null,
    erasedFields: null, official, error, ...(unconfirmed ? { unconfirmed: true } : {}),
  };
}

function inlinePdfData(value: unknown): value is string {
  if (typeof value !== 'string' || value.length === 0 || value.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value)) return false;
  // Check the signature without decoding another whole copy of a large export.
  // The existing download primitive remains the single full decoder/deliverer.
  try { return atob(value.slice(0, 12)).startsWith('%PDF-'); } catch { return false; }
}

function isOfficialDownload(value: unknown): value is DownloadRef {
  if (!value || typeof value !== 'object') return false;
  const ref = value as Partial<DownloadRef>;
  return ref.encoding === 'base64' && ref.mime_type === 'application/pdf' &&
    typeof ref.filename === 'string' && ref.filename.trim().length > 0 && inlinePdfData(ref.data);
}

function refusedExport(json: Record<string, unknown> | null, official: boolean, status: number, hasAttachments: boolean): EstarExportOutcome {
  const code = errorCodeOf(json);
  const unconfirmed = hasAttachments && mutationUnconfirmed(status, code);
  const sentence = serverMessage(json);
  const recovery = 'The export result was not confirmed. No file was downloaded. Review the program’s Vault and retained exports before trying again.';
  const error = unconfirmed
    ? code === 'OUTCOME_UNKNOWN' && sentence ? sentence : [sentence, recovery].filter(Boolean).join(' ')
    : sentence ?? `the server gave no reason (HTTP ${status})`;
  // Only the exact entitlement refusal names a plan limitation; a role403 does not.
  const blockedByEntitlement = status === 403 && json?.error === 'NOT_ENTITLED';
  return {
    ...failedExport(official, error, unconfirmed),
    blockers: Array.isArray(json?.blockers) ? json.blockers as string[] : [],
    blockedByEntitlement,
    requiredTier: blockedByEntitlement && typeof json?.requiredTier === 'string' ? json.requiredTier : null,
    attachmentRefusals: attachmentRefusals(json?.attachmentReport),
  };
}

async function postExport(url: string, body: unknown, official: boolean, current: () => boolean,
  request: { expected: readonly OfficialEstarAttachment[]; headers: Record<string, string> }): Promise<EstarExportOutcome> {
  const { expected, headers } = request;
  try {
    const res = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(body),
    });
    const json = (await res.json().catch(() => null)) as Record<string, unknown> | null;

    if (!res.ok) return refusedExport(json, official, res.status, expected.length > 0);

    if (!current()) return failedExport(official, 'The export context changed before delivery. Check the original program’s retained exports.', true);
    const attachments = expected.length ? confirmedAttachmentReceipts(json?.attachmentReport, expected) : undefined;
    if (expected.length && (!attachments || json?.officialEstarPdf !== true || !isOfficialDownload(json?.downloadable_output_ref))) {
      return { ...failedExport(official, 'The attachment result was not confirmed. No file was downloaded; check the program’s retained exports before trying again.', true),
        attachmentRefusals: attachmentRefusals(json?.attachmentReport) };
    }
    const ref = json?.downloadable_output_ref as DownloadRef | undefined;
    const delivered = ref?.data ? triggerDownload(ref) : false;

    const formatting = (json?.formattingReport ?? null) as
      | { errors?: unknown; warnings?: unknown; verdict?: unknown }
      | null;
    const count = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);
    const VERDICTS = ['conformant', 'conformant_with_warnings', 'nonconformant', 'not_assessed'] as const;
    type KnownVerdict = (typeof VERDICTS)[number];
    return {
      ok: true,
      delivered,
      governed: json?.governed === true,
      filename: ref?.filename ?? null,
      formattingErrors: formatting ? count(formatting.errors) : null,
      formattingWarnings: formatting ? count(formatting.warnings) : null,
      // A report without a known verdict (an older server) cannot claim it assessed everything.
      formattingVerdict: formatting
        ? VERDICTS.includes(formatting.verdict as KnownVerdict)
          ? (formatting.verdict as KnownVerdict)
          : 'not_assessed'
        : 'not_run',
      blockers: [],
      blockedByEntitlement: false,
      requiredTier: null,
      fieldReport: parseFieldReport(json?.fieldReport),
      erasedFields: parseErasedFields(json?.erasedFields),
      official,
      error: null,
      applicantCompletionRequired: json?.applicantCompletionRequired === true,
      ...(attachments ? { attachments, attachmentRefusals: [] } : {}),
    };
  } catch {
    // A throw here is the fetch itself failing (offline, DNS, abort). Its
    // native message is "Failed to fetch" / "Load failed", so the hook's own
    // wording is the only thing worth showing.
    return expected.length
      ? failedExport(official, 'The attachment export result was not confirmed. Check the program’s retained exports before trying again.', true)
      : failedExport(official, 'Export request failed');
  }
}

/** Accept a bearer rotation only when the canonical session adopted it for the same actor. */
function exportCredentialsCurrent(headers: Record<string, string>, account: ReturnType<typeof authService.getUser>): boolean {
  const live = buildAuthHeaders();
  if (headers['x-organization-id'] !== live['x-organization-id']) return false;
  if (headers.Authorization === live.Authorization) return true;
  const actor = taskActorScope(account);
  if (!actor) return false;
  try {
    const verified = capturedActorHeaders({ userId: Number(actor.userId), organizationId: Number(actor.organizationId) });
    return verified.Authorization === live.Authorization && verified['x-organization-id'] === live['x-organization-id'] &&
      authService.captureSessionReadGuard(verified.Authorization.slice('Bearer '.length)).current();
  } catch { return false; }
}

export function useEstarExport(isContextCurrent?: () => boolean): UseEstarExportResult {
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState<EstarExportOutcome | null>(IDLE);
  const generation = useRef(0);
  const active = useRef<number | null>(null);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; generation.current += 1; active.current = null; };
  }, []);

  const run = useCallback(async (url: string, body: unknown, official: boolean, expected: readonly OfficialEstarAttachment[] = []) => {
    if (active.current !== null) return failedExport(official, 'An export is already in progress.');
    const request = ++generation.current;
    const headers = buildAuthHeaders();
    const session = authService.captureSessionReadGuard();
    const account = authService.getUser();
    const current = () => mounted.current && generation.current === request && session.sameRevision() &&
      authService.getUser() === account && exportCredentialsCurrent(headers, account) && isContextCurrent?.() !== false;
    active.current = request;
    setBusy(true);
    try {
      const result = await postExport(url, body, official, current, { expected, headers });
      if (current()) setOutcome(result);
      return result;
    } finally {
      if (active.current === request) {
        active.current = null;
        if (mounted.current) setBusy(false);
      }
    }
  }, [isContextCurrent]);

  const exportDraftPackage = useCallback(
    (program: ProgramRef) =>
      run('/api/510k/estar/build', {
        meta: {
          id: program.code || program.id,
          ident: program.id,
          title: program.title || undefined,
        },
        useProjectContent: true,
      }, false),
    [run],
  );

  const exportOfficialEstar = useCallback(
    (program: ProgramRef, variant: OfficialEstarVariant = 'device', opts: OfficialEstarOptions = {}) => {
      const selected = copyAttachmentSelections(opts.attachments ?? []);
      if (!selected) {
        const failure = failedExport(true, 'Choose distinct Vault versions with a recorded SHA-256 and an FDA attachment destination.');
        if (mounted.current && active.current === null && isContextCurrent?.() !== false) setOutcome(failure);
        return Promise.resolve(failure);
      }
      return run('/api/510k/estar/official', {
        meta: {
          id: program.code || program.id,
          ident: program.id,
          title: program.title || undefined,
        },
        type: opts.type ?? '510k',
        variant,
        /* Governed records win server-side; typed values fill only the gaps.
           Without useProgramData the route fills `data` verbatim, as before. */
        useProgramData: opts.useProgramData === true,
        data: cleanRequestData(opts.data),
        ...(selected.length ? { attachments: selected.map(({ slot, source }) => ({ slot, source })) } : {}),
      }, true, selected);
    },
    [run, isContextCurrent],
  );

  const reset = useCallback(() => {
    generation.current += 1;
    active.current = null;
    setBusy(false);
    setOutcome(IDLE);
  }, []);

  return { busy, outcome, exportDraftPackage, exportOfficialEstar, reset };
}
