import { createServer } from '/workspace/concept2cure/node_modules/vite/dist/node/index.js';
import react from '/workspace/concept2cure/node_modules/@vitejs/plugin-react/dist/index.js';
import fs from 'node:fs';
const repo='/workspace/concept2cure';
const viewer={id:'7',organizationId:7,email:'viewer@fixture.invalid',name:'Fixture viewer',roles:['viewer'],permissions:[]};
const catalog={modules:[{moduleId:'vault',name:'Recovered source library',description:'Saved source records',category:'documents',icon:null,path:'/vault',isEnabled:true,subscriptionState:'enabled',isAvailable:true,requiredTier:'standard',sortOrder:10}]};
const license={organizationId:7,tier:'professional',industryMode:'biotech',usage:{projects:{currentCount:3,maxAllowed:25},users:{currentCount:9,maxAllowed:50}}};
const task=(taskId,title,project,moduleType)=>({taskId,title,project,moduleType,taskType:'document',status:'pending',priority:'high',assignee:'7',assignedBy:'7',progress:0,impactScore:null,criticalPath:false,regulatoryImpact:false,approvalRequired:false,approvalStatus:'not_started',approvalHistory:[],dependsOn:[],blocks:[],comments:0,attachments:0,source:'unified',due:'',dueDateIso:null,phase:null,blocked:false});
const tasks=[task('TASK-31','Draft stability summary','31','cmc'),task('TASK-32','Review predicate table','32','mdx')];
const projects={data:[{id:31,name:'BX-204 Oncology IND'},{id:32,name:'MD-11 Device Program'}]};
const initialModes=()=>({catalog:'failure',license:'failure',projects:'failure',board:'partial'});
let modes=initialModes();
let reads=[];
const held={catalog:[],license:[],projects:[],board:[]};
function json(res,status,payload){res.statusCode=status;res.setHeader('Content-Type','application/json');res.end(JSON.stringify(payload));}
function answer(res,key){if(modes[key]==='held'){held[key].push(res);return;}json(res,modes[key]==='failure'?503:200,modes[key]==='failure'?{error:'Synthetic temporarily unavailable'}:key==='catalog'?catalog:key==='license'?license:key==='projects'?projects:{data:modes.board==='partial'?[tasks[0]]:tasks,meta:{partial:modes.board==='partial',unreadSources:modes.board==='partial'?['project_tasks']:[]}});}
const entry=`import React from 'react';
import {createRoot} from 'react-dom/client';
import '${repo}/design-system/colors_and_type.css';
import '${repo}/client/src/styles/projects-prototype.css';
import '${repo}/client/src/index.css';
import '${repo}/client/src/concept2cure/v2/styles/surfaces-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/app-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/journey-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/coverage-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/authoring-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/research-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/misc-surfaces-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/device-v2.css';
import '${repo}/client/src/concept2cure/v2/styles/surface-text-ramp.css';
import {Apps} from '${repo}/client/src/concept2cure/v2/surfaces/WorkflowCatalog.tsx';
const surface={id:'apps',label:'Subscription & features',navTier:'workspace',layoutMode:'apps'};
createRoot(document.getElementById('root')).render(React.createElement('main',{className:'c2c-v2'},React.createElement('div',{className:'page'},React.createElement(Apps,{surface,onAsk:()=>{},onNav:()=>{},segment:'biotech'}))));`;
const taskEntry=entry.replace(`import {Apps} from '${repo}/client/src/concept2cure/v2/surfaces/WorkflowCatalog.tsx';`,`import {TaskBoard} from '${repo}/client/src/concept2cure/v2/surfaces/TaskBoard.tsx';import {AuthProvider,useAuth} from '${repo}/client/src/services/portal/authService.tsx';import {QueryClientProvider} from '@tanstack/react-query';import {queryClient} from '${repo}/client/src/lib/queryClient.ts';`).replace("const surface=","function TaskFixture(){const auth=useAuth();return auth.isBootstrapping?null:React.createElement(TaskBoard,{surface:{...surface,id:'tasks'},onAsk:()=>{},onNav:()=>{},segment:'biotech'});};const surface=").replace("React.createElement(Apps,{surface,onAsk:()=>{},onNav:()=>{},segment:'biotech'})","React.createElement(AuthProvider,null,React.createElement(QueryClientProvider,{client:queryClient},React.createElement(TaskFixture)))");
const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Component browser qualification — synthetic catalog replies</title><style>html,body,#root{min-height:100%;margin:0}</style></head><body><div id="root"></div><script type="module" src="/@catalog-entry"></script></body></html>`;
const server=await createServer({configFile:false,root:repo,plugins:[react(),{name:'private-component-harness',resolveId(id){if(id==='/@catalog-entry')return '\0catalog-entry';if(id==='/@task-entry')return '\0task-entry';},load(id){if(id==='\0catalog-entry')return entry;if(id==='\0task-entry')return taskEntry;},configureServer(s){s.middlewares.use(async(req,res,next)=>{
 const path=req.url?.split('?')[0];
 if(path==='/__catalog_fixture__'){
  if(req.method==='GET'){json(res,200,{modes,reads,held:Object.fromEntries(Object.entries(held).map(([k,v])=>[k,v.length]))});return;}
  let body='';for await(const c of req)body+=c;const command=JSON.parse(body||'{}');
  if(command.reset){if(Object.values(held).some(v=>v.length))throw new Error('Cannot reset while replies held');reads=[];modes=initialModes();}
  if(command.modes)Object.assign(modes,command.modes);
  if(command.release){const key=command.release;for(const waiting of held[key].splice(0))answer(waiting,key);}
  json(res,200,{modes,reads});return;
 }
 if(path==='/api/v1/auth/session'){reads.push({path,method:req.method,bearerPresent:Boolean(req.headers.authorization)});json(res,200,{authenticated:true,user:viewer,session:{}});return;}
 if(path==='/api/task-management/assignees'){reads.push({path,method:req.method});json(res,200,{data:[]});return;}
 const key=path==='/api/module-subscriptions/catalog'?'catalog':path==='/api/module-subscriptions/license'?'license':path==='/api/projects'?'projects':path==='/api/task-management/board'?'board':null;
 if(key){reads.push({path,method:req.method,organization:req.headers['x-organization-id']??null,bearerPresent:Boolean(req.headers.authorization)});if(req.method!=='GET'){json(res,405,{error:'No fixture mutation supported'});return;}answer(res,key);return;}
 if(path==='/favicon.ico'){res.statusCode=204;res.end();return;}
 if(path==='/component-catalog'||path==='/component-taskboard'){const transformed=await s.transformIndexHtml(path,path==='/component-taskboard'?html.replace('/@catalog-entry','/@task-entry'):html);res.setHeader('Content-Type','text/html');res.end(transformed);return;}
 next();
});}}],resolve:{dedupe:['react','react-dom'],alias:{'@':repo+'/client/src','@shared':repo+'/shared','@assets':repo+'/attached_assets'}},define:{__BUILD_COMMIT__:JSON.stringify('component-browser-synthetic-fixture')},server:{hmr:false,host:'127.0.0.1',port:5197,strictPort:true,fs:{allow:[repo,'/workspace/scratch/catalog-browser-20261030']}},optimizeDeps:{include:['react','react-dom/client','react/jsx-dev-runtime','react/jsx-runtime','lucide-react','wouter']}});
await server.listen();
fs.writeFileSync('/workspace/scratch/catalog-browser-20261030/server.pid',String(process.pid));
console.log(JSON.stringify({ready:true,pid:process.pid,url:'http://127.0.0.1:5197/component-catalog',kind:'Actual Apps component and canonical client transport; synthetic unverified API replies only'}));
async function close(){for(const list of Object.values(held))for(const res of list.splice(0))json(res,503,{error:'Harness stopped'});await server.close();process.exit(0);}
process.on('SIGTERM',close);process.on('SIGINT',close);
