import fs from 'node:fs';
import assert from 'node:assert/strict';
import { chromium } from '/opt/codex/cua_node/lib/node_modules/playwright-core/index.mjs';
const base='http://127.0.0.1:5197';
const outDir='/workspace/concept2cure/docs/evidence/W2/2026-10-30-catalog-tasking-recovery/browser';
const control=async command=>{const r=await fetch(base+'/__catalog_fixture__',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(command)});assert.equal(r.status,200);return r.json();};
const read=async()=>{const r=await fetch(base+'/__catalog_fixture__');return r.json();};
const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const results=[];
try{
 for(const viewport of [{width:1440,height:1000},{width:390,height:844}]){
  await control({reset:true});
  const ctx=await b.newContext({viewport,isMobile:viewport.width===390,hasTouch:viewport.width===390});const p=await ctx.newPage();const errors=[];const consoleErrors=[];
  p.on('pageerror',e=>{errors.push(e.message);console.log('page-error',e.message);});p.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
  await p.addInitScript(()=>{const viewer={id:'7',organizationId:7,email:'viewer@fixture.invalid',name:'Fixture viewer',roles:['viewer'],permissions:[]};const token='fixture.'+btoa(JSON.stringify({userId:7,organizationId:7,sessionId:'component-only'}))+'.fixture';sessionStorage.setItem('trialsage_access_token',token);sessionStorage.setItem('trialsage_user',JSON.stringify(viewer));sessionStorage.setItem('trialsage_token_expiry',new Date(Date.now()+86400000).toISOString());});
  const screenshots=[];const layouts=[];
  const capture=async stage=>{
   const name=`taskboard-${viewport.width}-${stage}.png`;await p.screenshot({path:outDir+'/'+name,fullPage:true});screenshots.push(name);
   layouts.push(await p.evaluate(stage=>({stage,viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,contentWidth:document.querySelector('.tb').getBoundingClientRect().width,alerts:[...document.querySelectorAll('.c2c-error-state')].map(e=>{const body=e.querySelector('.c2c-error-body').getBoundingClientRect();const actions=e.querySelector('.c2c-error-actions')?.getBoundingClientRect();return {body:{width:body.width,bottom:body.bottom},actions:actions?{y:actions.y,width:actions.width}:null};}),partial:document.querySelector('[data-testid="tb-partial"]')?.textContent.trim()??null}),stage));
  };
  try{
   await p.goto(base+'/component-taskboard',{waitUntil:'domcontentloaded'});
   await p.getByRole('heading',{level:1}).waitFor({timeout:60000});
   await p.getByTestId('tb-view-only').waitFor();
   await p.getByRole('button',{name:'Open Draft stability summary',exact:true}).waitFor();
   await p.getByTestId('tb-project-read-error').waitFor();await p.getByTestId('tb-partial').waitFor();
   await capture('partial-and-project-failure');
   const initial=await read();assert.equal(initial.reads.filter(x=>x.path==='/api/task-management/board').length,1);assert.equal(initial.reads.filter(x=>x.path==='/api/projects').length,1);
   await control({modes:{projects:'held'}});await p.getByRole('button',{name:'Retry project list',exact:true}).dblclick();
   await p.getByTestId('tb-project-read-error').getByRole('button',{name:'Retrying…',exact:true}).waitFor();
   assert.equal(await p.getByTestId('tb-project-read-error').getByRole('button').isDisabled(),true);
   assert.equal(await p.getByRole('button',{name:'Open Draft stability summary',exact:true}).isVisible(),true);await capture('projects-loading');
   const loadingProjects=await read();assert.equal(loadingProjects.reads.filter(x=>x.path==='/api/projects').length,2);assert.equal(loadingProjects.reads.filter(x=>x.path==='/api/task-management/board').length,1);
   await control({modes:{projects:'success'},release:'projects'});
   await p.getByTestId('tb-project-read-error').waitFor({state:'detached'});assert.equal(await p.getByRole('button',{name:'Open Draft stability summary',exact:true}).isVisible(),true);
   assert.ok(await p.getByRole('option',{name:'BX-204 Oncology IND',exact:true}).count());
   await control({modes:{board:'held'}});await p.getByRole('button',{name:'Retry task board',exact:true}).dblclick();
   await p.getByText('Loading the task board…',{exact:true}).waitFor();await capture('board-loading');
   const loadingBoard=await read();assert.equal(loadingBoard.reads.filter(x=>x.path==='/api/task-management/board').length,2);assert.equal(loadingBoard.reads.filter(x=>x.path==='/api/projects').length,2);
   await control({modes:{board:'success'},release:'board'});
   await p.getByRole('button',{name:'Open Review predicate table',exact:true}).waitFor();assert.equal(await p.getByRole('button',{name:'Open Draft stability summary',exact:true}).isVisible(),true);
   await p.getByTestId('tb-partial').waitFor({state:'detached'});await capture('recovered');
   const final=await read();assert.equal(final.reads.every(x=>x.method==='GET'),true);assert.equal(final.reads.filter(x=>x.path==='/api/task-management/assignees').length,1);assert.equal(errors.length,0);
   for(const l of layouts){assert.ok(l.documentWidth<=viewport.width,JSON.stringify(l));if(viewport.width===390)for(const alert of l.alerts){assert.ok(alert.body.width>=180,JSON.stringify({failure:'phone task error text too narrow',stage:l.stage,...alert}));if(alert.actions)assert.ok(alert.actions.y>=alert.body.bottom,JSON.stringify({failure:'phone task recovery actions must follow message',stage:l.stage,...alert}));}}
   results.push({viewport,status:'passed',heading:await p.getByRole('heading',{level:1}).innerText(),syntheticViewerContext:true,initial,loadingProjects,loadingBoard,final,retainedCardDuringProjectRetry:true,recoveredMissingTask:true,layouts,screenshots,uncaughtErrors:errors,consoleErrors,note:'Actual TaskBoard/AuthProvider/QueryClientProvider with explicitly synthetic viewer session context and synthetic unverified HTTP responses; no production auth/DB/AnA claim.'});
  }catch(e){console.log(JSON.stringify({viewport,url:p.url(),errors,consoleErrors,body:(await p.locator('body').innerText()).slice(0,3000)}));throw e;}
  finally{await ctx.close();}
 }
 const out={kind:'Chromium actual task-board component with real auth provider/query provider/hooks/transport/styles and synthetic loopback HTTP responses',date:new Date().toISOString(),results};
 fs.writeFileSync(outDir+'/taskboard-results.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({status:'passed',viewports:results.map(x=>x.viewport),screenshots:results.flatMap(x=>x.screenshots)}));
}finally{await b.close();}
