import fs from 'node:fs';
import assert from 'node:assert/strict';
import { chromium } from '/opt/codex/cua_node/lib/node_modules/playwright-core/index.mjs';
const base='http://127.0.0.1:5197';
const outDir='/workspace/concept2cure/docs/evidence/W2/2026-10-30-catalog-tasking-recovery/browser';
const control=async command=>{const r=await fetch(base+'/__catalog_fixture__',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(command)});assert.equal(r.status,200);return r.json();};
const read=async()=>{const r=await fetch(base+'/__catalog_fixture__');return r.json();};
const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const results=[];
try{
 for(const viewport of [{width:1440,height:1000},{width:390,height:844}]){
  await control({reset:true});
  const ctx=await b.newContext({viewport,isMobile:viewport.width===390,hasTouch:viewport.width===390});const p=await ctx.newPage();const errors=[];const consoleErrors=[];
  p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
  const screenshots=[];const layouts=[];
  const capture=async stage=>{
   const name=`catalog-${viewport.width}-${stage}.png`;await p.screenshot({path:outDir+'/'+name,fullPage:true});screenshots.push(name);
   layouts.push(await p.evaluate(stage=>({stage,viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,contentWidth:document.querySelector('.workflow-page').getBoundingClientRect().width,buttons:[...document.querySelectorAll('button')].filter(e=>e.textContent.includes('Retry')).map(e=>{const r=e.getBoundingClientRect();return{text:e.textContent.trim(),x:r.x,width:r.width,right:r.right,visible:r.width>0&&r.height>0,disabled:e.disabled};}),alerts:[...document.querySelectorAll('.c2c-error-state')].map(e=>{const body=e.querySelector('.c2c-error-body').getBoundingClientRect();const actions=e.querySelector('.c2c-error-actions')?.getBoundingClientRect();return {body:{width:body.width,bottom:body.bottom},actions:actions?{y:actions.y,width:actions.width}:null};}),font:getComputedStyle(document.querySelector('.ph-title')).fontFamily}),stage));
  };
  try{
   await p.goto(base+'/component-catalog',{waitUntil:'domcontentloaded'});
   await p.getByRole('heading',{name:'Subscription & features',exact:true}).waitFor({timeout:60000});
   await p.getByRole('button',{name:'Retry features',exact:true}).waitFor();await p.getByRole('button',{name:'Retry subscription details',exact:true}).waitFor();
   await p.getByRole('searchbox',{name:'Find a feature'}).fill('Recovered');await capture('failure');
   const initial=await read();assert.deepEqual(initial.reads.map(x=>[x.method,x.path]).sort(),[['GET','/api/module-subscriptions/catalog'],['GET','/api/module-subscriptions/license']].sort());
   await control({modes:{catalog:'held'}});await p.getByRole('button',{name:'Retry features',exact:true}).dblclick();
   await p.getByText('Loading features…',{exact:true}).waitFor();await capture('catalog-loading');
   const loadingCatalog=await read();assert.equal(loadingCatalog.reads.filter(x=>x.path.endsWith('/catalog')).length,2);assert.equal(loadingCatalog.reads.filter(x=>x.path.endsWith('/license')).length,1);
   await control({modes:{catalog:'success'},release:'catalog'});
   const feature=p.getByText('Recovered source library',{exact:true});await feature.waitFor({state:'attached'});
   for(const details of await feature.locator('xpath=ancestor::details').all()){if(!await details.evaluate(e=>e.open))await details.locator(':scope > summary').click();}
   await feature.waitFor();assert.equal(await p.getByRole('searchbox',{name:'Find a feature'}).inputValue(),'Recovered');
   await control({modes:{license:'held'}});await p.getByRole('button',{name:'Retry subscription details',exact:true}).dblclick();
   await p.getByText('Loading license…',{exact:true}).waitFor();assert.equal(await feature.isVisible(),true);await capture('subscription-loading');
   const loadingLicense=await read();assert.equal(loadingLicense.reads.filter(x=>x.path.endsWith('/catalog')).length,2);assert.equal(loadingLicense.reads.filter(x=>x.path.endsWith('/license')).length,2);
   await control({modes:{license:'success'},release:'license'});
   await p.getByText('Current subscription',{exact:true}).waitFor();await feature.waitFor();await capture('recovered');
   const final=await read();assert.equal(final.reads.length,4);assert.equal(final.reads.every(x=>x.method==='GET'),true);assert.equal(errors.length,0);
   for(const l of layouts){assert.ok(l.documentWidth<=viewport.width,JSON.stringify(l));if(viewport.width===390)for(const alert of l.alerts){assert.ok(alert.body.width>=180,JSON.stringify({failure:'phone error text is too narrow',stage:l.stage,...alert}));if(alert.actions)assert.ok(alert.actions.y>=alert.body.bottom,JSON.stringify({failure:'phone recovery actions must follow message',stage:l.stage,...alert}));}for(const button of l.buttons){assert.ok(button.visible);assert.ok(button.x>=0&&button.right<=viewport.width,JSON.stringify(button));}}
   results.push({viewport,status:'passed',initial,loadingCatalog,loadingLicense,final,searchPreserved:true,layouts,screenshots,uncaughtErrors:errors,consoleErrors,note:'503 console errors are deliberately controlled synthetic failure responses. No verified sign-in/session/database/deployed-app claim.'});
  }catch(e){console.log(JSON.stringify({viewport,url:p.url(),errors,consoleErrors,body:(await p.locator('body').innerText()).slice(0,3000)}));throw e;}
  finally{await ctx.close();}
 }
 const out={kind:'Chromium actual catalog component with real hooks/canonical transport/styles and synthetic loopback HTTP responses',date:new Date().toISOString(),results};
 fs.writeFileSync(outDir+'/results.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({status:'passed',viewports:results.map(x=>x.viewport),screenshots:results.flatMap(x=>x.screenshots)}));
}finally{await b.close();}
