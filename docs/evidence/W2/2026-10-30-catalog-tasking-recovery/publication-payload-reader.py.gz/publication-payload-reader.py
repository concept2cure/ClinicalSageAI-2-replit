#!/usr/bin/env python3
"""Prepare/read committed Git data for an exact-tree canonical publication.

Read-only Git operations. No API, credential reads, ref updates, commits or gates.
All output files stay below this script's private scratch directory. Reader JSON
is bounded to 8192 UTF-8 bytes, including newline. Never print chunk data to the
model: orchestrators should parse it internally and send assembled base64 only
to create_blob, then compare the returned Git blob SHA with the manifest.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LIMIT = 8192
BASE64_PART = 7168  # ASCII characters, split AFTER encoding the complete blob.
BRANCH = 'concept2cure-v2'
MODES = {'100644': 'blob', '100755': 'blob', '120000': 'blob', '160000': 'commit'}


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')


def bounded(value):
    data = encoded(value)
    if len(data) > LIMIT:
        raise ValueError('JSON record exceeds the 8192-byte output limit')
    return data


def emit(value):
    sys.stdout.buffer.write(bounded(value))


def git(repo, *args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')
    result = subprocess.run(['git', '--no-optional-locks', '-c', 'core.fsmonitor=false',
                             '-C', str(repo), *args], capture_output=True, env=env)
    if result.returncode:
        # Metadata-only errors: do not dump subprocess output or blob content.
        raise ValueError('Read-only Git command failed: ' + args[0])
    return result.stdout


def ref(repo, value):
    return git(repo, 'rev-parse', '--verify', value).decode('ascii').strip()


def parse_diff(data):
    parts = data.split(b'\0')
    if parts[-1] != b'':
        raise ValueError('Raw Git diff did not end with NUL')
    parts.pop()
    if len(parts) % 2:
        raise ValueError('Unexpected raw Git diff field count')
    entries = []
    for n in range(0, len(parts), 2):
        header, raw_path = parts[n:n + 2]
        fields = header.decode('ascii').split()
        if len(fields) != 5 or not fields[0].startswith(':'):
            raise ValueError('Unexpected raw Git diff header')
        old_mode, mode, old_sha, sha, status = fields
        old_mode = old_mode[1:]
        if status not in ('A', 'D', 'M', 'T'):
            raise ValueError('Unsupported committed-tree diff status')
        path = raw_path.decode('utf-8', errors='strict')
        if not path or path.startswith('/') or any(p in ('', '.', '..') for p in path.split('/')):
            raise ValueError('Unsafe Git tree path')
        deletion = status == 'D'
        tree_mode = old_mode if deletion else mode
        if tree_mode not in MODES:
            raise ValueError('Unsupported Git tree mode')
        if len(old_sha) != 40 or len(sha) != 40:
            raise ValueError('Expected full SHA-1 Git object IDs')
        entries.append({'kind': 'entry', 'index': len(entries), 'path': path,
                        'status': status, 'oldMode': old_mode, 'mode': mode,
                        'oldSha': old_sha, 'sha': None if deletion else sha,
                        'deletion': deletion, 'blobIndex': None,
                        'treeEntry': {'path': path, 'mode': tree_mode,
                                      'type': MODES[tree_mode], 'sha': None if deletion else sha}})
    return entries


def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def chunks(data, blob_index, sha, start, pins):
    complete_base64 = base64.b64encode(data).decode('ascii')
    count = max(1, (len(complete_base64) + BASE64_PART - 1) // BASE64_PART)
    for part in range(count):
        fragment = complete_base64[part * BASE64_PART:(part + 1) * BASE64_PART]
        yield {'formatVersion': 1, 'kind': 'blob_chunk', 'head': pins['head'],
               'base': pins['base'], 'index': start + part, 'blobIndex': blob_index,
               'gitBlobSha': sha, 'partIndex': part, 'partCount': count,
               'encoding': 'base64', 'data': fragment}


def pages(records, pins):
    current = []
    page_index = 0
    for record in records:
        candidate = {'formatVersion': 1, 'kind': 'manifest_page', 'head': pins['head'],
                     'base': pins['base'], 'index': page_index, 'records': current + [record]}
        if len(encoded(candidate)) > LIMIT:
            if not current:
                raise ValueError('One manifest record exceeds the bounded page size')
            yield {'formatVersion': 1, 'kind': 'manifest_page', 'head': pins['head'],
                   'base': pins['base'], 'index': page_index, 'records': current}
            page_index += 1
            current = [record]
        else:
            current.append(record)
    if current or not records:
        yield {'formatVersion': 1, 'kind': 'manifest_page', 'head': pins['head'],
               'base': pins['base'], 'index': page_index, 'records': current}


def private_output(value):
    output = Path(value).resolve()
    if output == ROOT or not output.is_relative_to(ROOT):
        raise ValueError('Output must be a new directory beneath the private scratch helper directory')
    return output


def read_json(path):
    return json.loads(path.read_bytes())


def write_file(output, name, data, integrity):
    if len(data) > LIMIT:
        raise ValueError('Attempted to write an oversized bounded record')
    path = output / name
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)
    path.chmod(0o600)
    integrity[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def pins_now(repo, head_ref, base_ref):
    if git(repo, 'branch', '--show-current').decode().strip() != BRANCH:
        raise ValueError('Only the canonical branch may prepare publication payloads')
    if git(repo, 'rev-parse', '--show-object-format').decode().strip() != 'sha1':
        raise ValueError('This GitHub publisher requires SHA-1 repository objects')
    head = ref(repo, head_ref + '^{commit}')
    base = ref(repo, base_ref + '^{commit}')
    if head != ref(repo, 'HEAD'):
        raise ValueError('The selected qualified head must equal current committed HEAD')
    if git(repo, 'status', '--porcelain=v1', '-z', '--untracked-files=normal'):
        raise ValueError('Commit all intended work before preparing an immutable publication bundle')
    if git(repo, 'merge-base', base, head).decode().strip() != base:
        raise ValueError('Canonical base must be an ancestor of the qualified head')
    return {'branch': BRANCH, 'head': head, 'headTree': ref(repo, head + '^{tree}'),
            'base': base, 'baseTree': ref(repo, base + '^{tree}'),
            'headRef': head_ref, 'baseRef': base_ref}


def prepare(args):
    repo = Path(args.repo).resolve()
    pins = pins_now(repo, args.head, args.base)
    output = private_output(args.output or str(ROOT / ('bundle-' + pins['head'][:12] + '-' + pins['base'][:12])))
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    raw = git(repo, 'diff', '--raw', '--no-abbrev', '--no-renames', '--no-ext-diff',
              '--no-textconv', '--no-color', '-z', pins['base'], pins['head'], '--')
    entries = parse_diff(raw)
    integrity = {}
    blobs = []
    seen = {}
    chunk_count = 0
    for entry in entries:
        if entry['deletion'] or entry['treeEntry']['type'] != 'blob':
            continue
        sha = entry['sha']
        if sha in seen:
            entry['blobIndex'] = seen[sha]
            continue
        data = git(repo, 'cat-file', 'blob', sha)
        if blob_sha(data) != sha:
            raise ValueError('Committed blob hash did not match its immutable Git object ID')
        blob_index = len(blobs)
        seen[sha] = blob_index
        entry['blobIndex'] = blob_index
        start = chunk_count
        for chunk in chunks(data, blob_index, sha, start, pins):
            write_file(output, f'chunks/{chunk_count:08d}.json', bounded(chunk), integrity)
            chunk_count += 1
        blobs.append({'kind': 'blob', 'index': blob_index, 'sha': sha, 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest(),
                      'base64Chars': len(base64.b64encode(data)), 'chunkStart': start,
                      'chunkCount': chunk_count - start})
    page_count = 0
    for page in pages(entries + blobs, pins):
        write_file(output, f'manifest/{page_count:08d}.json', bounded(page), integrity)
        page_count += 1
    if pins_now(repo, args.head, args.base) != pins:
        raise ValueError('Git inputs changed during preparation; do not use this incomplete bundle')
    index = {'formatVersion': 1, 'kind': 'publication_index', **pins,
             'entries': len(entries), 'blobs': len(blobs), 'manifestPages': page_count,
             'chunks': chunk_count, 'maxJsonBytes': LIMIT, 'base64PartChars': BASE64_PART,
             'completeBase64BeforeSplit': True, 'repo': str(repo),
             'note': 'No API writes, Git mutation, gate execution or remote-current authorization is performed here.'}
    write_file(output, 'index.json', bounded(index), integrity)
    # Internal integrity metadata may be larger than a page; it is never emitted.
    with (output / 'integrity.json').open('x', encoding='utf-8') as f:
        json.dump(integrity, f, sort_keys=True, separators=(',', ':'))
    (output / 'integrity.json').chmod(0o600)
    (output / 'COMPLETE').write_text(hashlib.sha256(encoded(index)).hexdigest() + '\n')
    (output / 'COMPLETE').chmod(0o600)
    emit({'prepared': True, 'output': str(output), **{k: index[k] for k in
         ('head', 'headTree', 'base', 'baseTree', 'entries', 'blobs', 'manifestPages', 'chunks')}})


def bundle(args):
    output = private_output(args.bundle)
    index_bytes = (output / 'index.json').read_bytes()
    if (output / 'COMPLETE').read_text().strip() != hashlib.sha256(index_bytes).hexdigest():
        raise ValueError('Bundle completion/index integrity check failed')
    index = json.loads(index_bytes)
    if index.get('formatVersion') != 1 or index.get('completeBase64BeforeSplit') is not True:
        raise ValueError('Unsupported publication bundle format')
    return output, index, read_json(output / 'integrity.json')


def checked(output, name, integrity):
    data = (output / name).read_bytes()
    expected = integrity.get(name)
    if not expected or len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
        raise ValueError('Bundle file integrity check failed')
    if len(data) > LIMIT:
        raise ValueError('Bundle record exceeds bounded output size')
    return json.loads(data)


def reader(args):
    output, index, integrity = bundle(args)
    if args.command == 'index':
        emit(checked(output, 'index.json', integrity))
    elif args.command in ('manifest', 'chunk'):
        count = index['manifestPages' if args.command == 'manifest' else 'chunks']
        if args.index < 0 or args.index >= count:
            raise ValueError('Numeric record index is outside the manifest')
        name = ('manifest' if args.command == 'manifest' else 'chunks') + f'/{args.index:08d}.json'
        value = checked(output, name, integrity)
        if value['head'] != index['head'] or value['base'] != index['base'] or value['index'] != args.index:
            raise ValueError('Record pins/index do not match the publication bundle')
        emit(value)
    else:
        records = []
        for n in range(index['manifestPages']):
            page = checked(output, f'manifest/{n:08d}.json', integrity)
            if (page['head'], page['base'], page['index']) != (index['head'], index['base'], n):
                raise ValueError('Manifest page publication pins mismatch')
            records += page['records']
        entries = [r for r in records if r['kind'] == 'entry']
        blobs = [r for r in records if r['kind'] == 'blob']
        if len(entries) != index['entries'] or len(blobs) != index['blobs']:
            raise ValueError('Manifest record counts mismatch')
        if any(r['index'] != n for n, r in enumerate(entries)) or any(r['index'] != n for n, r in enumerate(blobs)):
            raise ValueError('Manifest record indices mismatch')
        if sum(r['chunkCount'] for r in blobs) != index['chunks']:
            raise ValueError('Manifest chunk counts mismatch')
        verified = 0
        for blob in (r for r in records if r['kind'] == 'blob'):
            fragments = []
            for part in range(blob['chunkCount']):
                n = blob['chunkStart'] + part
                chunk = checked(output, f'chunks/{n:08d}.json', integrity)
                if (chunk['blobIndex'], chunk['gitBlobSha'], chunk['partIndex'], chunk['partCount'], chunk['head'], chunk['base']) != (blob['index'], blob['sha'], part, blob['chunkCount'], index['head'], index['base']):
                    raise ValueError('Blob chunk ordering or publication pins mismatch')
                fragments.append(chunk['data'])
            complete = ''.join(fragments)
            data = base64.b64decode(complete, validate=True)
            if len(complete) != blob['base64Chars'] or len(data) != blob['bytes'] or blob_sha(data) != blob['sha'] or hashlib.sha256(data).hexdigest() != blob['sha256']:
                raise ValueError('Reassembled blob does not equal the committed Git blob')
            verified += 1
        emit({'verified': True, 'head': index['head'], 'headTree': index['headTree'],
              'base': index['base'], 'manifestPages': index['manifestPages'],
              'blobs': verified, 'chunks': index['chunks'], 'maxJsonBytes': LIMIT})


def self_test():
    pins = {'head': 'a' * 40, 'base': 'b' * 40}
    checked_cases = 0
    for length in (0, 1, 2, 3, 5376, 5377, 10000, 50001):
        data = bytes(n % 256 for n in range(length))
        values = list(chunks(data, 0, blob_sha(data), 0, pins))
        assert all(len(bounded(c)) <= LIMIT for c in values)
        combined = ''.join(c['data'] for c in values)
        assert combined == base64.b64encode(data).decode('ascii')
        assert base64.b64decode(combined, validate=True) == data
        assert all('=' not in c['data'] for c in values[:-1])
        checked_cases += 1
    raw = b':100644 100755 ' + b'a' * 40 + b' ' + b'b' * 40 + b' M\0line\nname\t.txt\0'
    entry = parse_diff(raw)[0]
    assert entry['path'] == 'line\nname\t.txt' and entry['treeEntry']['mode'] == '100755'
    raw = b':120000 000000 ' + b'a' * 40 + b' ' + b'0' * 40 + b' D\0deleted-link\0'
    assert parse_diff(raw)[0]['treeEntry'] == {'path': 'deleted-link', 'mode': '120000', 'type': 'blob', 'sha': None}
    manifest = list(pages([{'kind': 'entry', 'path': 'synthetic/' + str(n), 'value': 'x' * 120} for n in range(1000)], pins))
    assert all(len(bounded(p)) <= LIMIT for p in manifest)
    assert sum(len(p['records']) for p in manifest) == 1000
    emit({'selfTestPassed': True, 'chunkingCases': checked_cases, 'nulSafeDiffCases': 2,
          'manifestRecords': 1000, 'manifestPages': len(manifest), 'maxJsonBytes': LIMIT,
          'gitMutations': 0, 'apiCalls': 0, 'preparedPublicationBundle': False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('prepare')
    p.add_argument('--repo', default='/workspace/concept2cure')
    p.add_argument('--head', default='HEAD')
    p.add_argument('--base', default='origin/concept2cure-v2')
    p.add_argument('--output')
    commands.add_parser('self-test')
    for command in ('index', 'manifest', 'chunk', 'verify'):
        p = commands.add_parser(command)
        p.add_argument('--bundle', required=True)
        if command in ('manifest', 'chunk'):
            p.add_argument('--index', type=int, required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        prepare(args)
    elif args.command == 'self-test':
        self_test()
    else:
        reader(args)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, AssertionError) as exc:
        # Do not expose blob contents, subprocess stderr, credentials or env.
        emit({'error': type(exc).__name__, 'message': str(exc)[:400]})
        raise SystemExit(1)
