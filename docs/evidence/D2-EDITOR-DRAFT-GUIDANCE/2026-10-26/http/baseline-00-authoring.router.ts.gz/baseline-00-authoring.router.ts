import { Router, Request, Response, type NextFunction } from 'express';
import { citationRefreshRefusalMessage } from '@shared/authoring/citations';
import { readAssemblySourceManifest, type AssemblySourceManifest } from '@shared/authoring/assembly-sources';
import multer from 'multer';
import { parseDraftEnvelope } from './authoring-draft-envelope.js';
import { registerAuthoringAssemblyRoutes } from './authoring-assembly';
import fs from 'fs';
import path from 'path';
// spawn — reserved for future PDF generation pipeline
import crypto from 'crypto';
// Lazy load docx to prevent startup failures
import { verifyJwtWithRotation } from '../utils/jwtVerify';
import { nonAccessTokenReason } from '../middleware/tokenType';
import { isUuid } from '../middleware/uuidParam';
import { enforceOrgMembership, requireEditorAccess } from '../middleware/orgMembership';
import { getPool } from '../db';
import { requestConnectable, requestPgClient } from '../db/requestDb';
import { AuthoringReadScopeError } from '../services/authoring/authoring-read-scope';
import { readAuthoringDocuments, readAuthoringDocument, readAuthoringDocumentSections, AuthoringReadInputError } from '../services/authoring/authoring-document-read';
import { authoringReviewInputSchema } from '../../shared/authoring/peer-review';
import {
  readAuthoringPeerReviews, submitAuthoringPeerReview, requestAuthoringPeerReviews,
  AuthoringPeerReviewRefused, AuthoringPeerReviewCommitUnconfirmed,
} from '../services/authoring/peer-review';
import type { PoolClient } from 'pg';
import { SourceReadAccessError } from '../services/clinical-regulatory-evidence/source-read-access';
import { ProgramReadAccessError } from '../services/c2c/current-program-access';
import { currentTenantOrgUuid, TenantKeyRequiredError } from '../db/currentTenant';
import { writeChainedAuditRow } from '../services/auditService';
import { resolveSignerOrgRole } from '../services/part11/resolve-signer-role.js';
import { checkSigningAuthority } from '../services/part11/signing-authority-gate.js';
import { reverifySigner, type SignerReverified } from '../services/part11/reverify-signer.js';
import { signerReverificationDeps } from '../services/part11/reverify-signer-deps.js';
import { authedOrgId } from '../utils/authedOrgId';
import { createScopedLogger } from '../utils/logger';
import { makeUploadFileFilter } from '../middleware/uploadAllowlist';
import { assertUploadSafe, UploadSafetyError } from '../middleware/uploadSafety';
// c2c_documents is the system of record for a filing; this router is the
// editing layer over it. This resolves which governed document an authored
// document belongs to. See server/services/c2c/governed-document-binding.ts.
import { DocumentAliasConflictError } from '../services/c2c/document-alias-map.js';
import {
  commitSectionToFiling,
  type CommitSectionResult,
} from '../services/c2c/commit-section-to-filing.js';
import { readFilingLock } from '../services/c2c/filing-lock.js';
import { filingAgreesWithEditing, filingResponse, signedFilingSectionTexts, type FilingDivergence } from '../services/c2c/filing-section-target.js';
// Spine F1: the approval signature records the filing sections it approves
// through the one governed-action writer (audit_logs + c2c_ana_actions).
import { recordGovernedAction } from './c2c/actions';
// Span lineage: every span of an authored document must trace to where it came
// from. The gate is factored into one helper so every authored-content write
// (interactive save AND section create) applies the identical rule.
// See server/services/clinical-regulatory-evidence/lineage-gate.ts.
import { enforceAuthorLineage, UnverifiedMachineFormattingError } from '../services/clinical-regulatory-evidence/lineage-gate';
// Types only: the service itself is imported where it is called.
import type {
  CitationChange,
  CitationImage,
} from '../services/clinical-regulatory-evidence/source-usage.service';
import {
  authoringPrincipalFromRequest,
  decideAuthoringPermission,
  grantAuthoringPermission,
  resolveAuthoringDocumentScope,
  resolveAuthoringSectionScope,
} from '../services/authoring/authoring-permissions';
import { resolveRequirements } from '../services/ind/ctd/requirements-resolver.js';
import { resolveSectionBriefSource } from '../services/ind/ctd/section-brief.js';
import { basisLabel, type RegulatoryBasis } from '../../shared/regulatory/regulatory-basis';
import { claimDocRoleOf } from '../../shared/ana/clinical-claims-vocabulary';
import { sectionReadableText } from '../services/authoring/authoring-read-render';
import {
  checkDocumentFigureConsistency,
  type ConsistencySection,
  type DocumentConsistencyCheck,
} from '../services/authoring/document-figure-consistency';
import { respondIfConverterBusy, serverError } from '../lib/api-response';
import {
  verifyLedger,
  type RevisionOrigin,
  machineContributors,
  acceptedMachineText,
  ANA_MACHINE_AUTHOR_ID,
  MACHINE_AUTHOR_IDS,
} from '../services/authoring/revision-ledger';
import {
  checkSectionWritable,
  checkDocumentWritable,
  reserveWritableSection, reserveWritableDocument, DocumentWriteReservationError,
  LOCKED_DOCUMENT_STATUSES as LOCKED_STATUSES,
} from '../services/authoring/document-lock';
// The document/section creators, the Part 11 evidence writers and the export
// renderer were the bodies of POST /docs, POST /sections and POST
// /docs/:docId/export in this file (WM, 2026-09-21, docs/design/
// ANA_DOCUMENT_CANVAS.md). They moved into services so the from-draft route,
// the vault filing and the AnA `draft_authoring_document` tool write the SAME
// rows through the SAME code. The handlers here are the HTTP mapping they
// always were.
import { createDocument, createSection } from '../services/authoring/authoring-documents';
import { importSourceDocument } from '../services/authoring/authoring-source-import';
import { AuthoringCreateOutcomeError, authoringCreationRecoveryPayload, rollbackAuthoringTransaction, settleAuthoringTransactionFailure, type AuthoringTransactionState } from '../services/authoring/authoring-create-outcome';
import { AuthoringSectionWriteOutcomeError, authoringSectionRecoveryPayload } from '../services/authoring/authoring-section-outcome';
import { buildIndDocumentCatalog } from '../services/authoring/ind-document-catalog';
import { getBuiltinAuthoringTemplates, builtinTemplateReference, type BuiltinAuthoringTemplate } from '../services/authoring/builtin-authoring-templates';
import { savedTemplateGuidance, TemplateGuidanceError } from '../services/authoring/authoring-template-guidance';
import { AuthoringProgramAccessError } from '../services/authoring/authoring-program-access';
import { refileSavedAuthoringSection } from '../services/authoring/authoring-refile-saved-section';
import { requireGovernedReason, optionalGovernedReason } from './governed-reason';
import {
  createDocumentFromDraft,
  parseDraftInput,
} from '../services/authoring/authoring-from-draft';
import {
  writeAuthoringAuditTrail,
  createRevision as createRevisionOn,
  bindingColumnState as bindingColumnStateOn,
  type AuthoringAuditContext,
  type CreateAuditTrailOptions,
} from '../services/authoring/authoring-evidence';
import { loadAuthoringRecord, resolveTurnRecordSources, textSha256, type TurnRecordSource } from '../services/authoring/authoring-record';
import {
  creditMachineClaims,
  contributorsOf,
  governedSaveRefusal,
  machineClaimDisclosure,
  machineClaimReport,
  refusedForModel,
  type GovernedClaimVerdict,
} from '../services/authoring/governed-machine-claims';
import { evidenceShown, fileFailedDraftTurn, openDraftTurn, type DraftTurn } from '../services/ana/turn-record-draft';
import { assertEditorDraftNotTruncated, DraftTruncatedError } from '../services/authoring/authoring-draft-termination';
import { isTruncated } from '../services/ai-gateway/finish-reason';
import { sendAuditedExport, walkTenantChain } from '../services/audit/audited-export';
import { canReadAuditTrail } from '../services/audit/audit-api-authority';
import {
  AuthoringPdfRenderingError,
  renderAuthoringExport,
  logExport,
  computeDocHash as computeDocHashOn,
  computeAuthoringSignatureDigest as computeSignatureDigest,
  sectionsDigest,
  readSignaturesForExport,
  anySignatureCovers,
  EXPORT_FORMATS,
  type ExportFormat,
} from '../services/authoring/authoring-export';
import { SavedDraftSourceError, withSavedDraftSourceReservation } from '../services/authoring/draft-source-references';
import { assertWorkflowImportRelease, prepareWorkflowImportAdoption, WorkflowImportGovernanceError } from '../services/authoring/workflow-import-governance';
import { admitAnaProjectScope, AnaProjectScopeError } from '../services/ana/project-scope-admission';
import { withExtendingRoles } from '../../shared/constants/org-roles';
import {
  fileAuthoringDocumentToVault,
  isPlausibleFolderId,
  VAULT_FILE_FORMATS,
  type VaultFileFormat,
} from '../services/authoring/authoring-file-to-vault';

const logger = createScopedLogger('authoring-router');

const router = Router();


// REQUIRED JWT verification middleware for 21 CFR Part 11 compliance.
//
// This composes the CANONICAL auth primitives so the authoring surface enforces
// IDENTICAL semantics to server/middleware/auth.ts authenticateToken in EVERY
// environment — not only where the /api boundary happens to run in enforce mode
// (C2C-SEC-001). It replaces a bespoke jose verifier that omitted two canonical
// controls: non-access token-class rejection (AUTH_008) and the live
// organization_users membership re-check (AUTH_009).
//
// Twin-safety (see server/middleware/orgMembership.ts): every import here
// resolves to the same file under vitest, tsx, and the production build —
// verifyJwtWithRotation via ../utils/jwtVerify (whose .js is a shim that
// re-exports the .ts), nonAccessTokenReason via ../middleware/tokenType (no .js
// twin), enforceOrgMembership via ../middleware/orgMembership (no .js twin). An
// extensionless import of '../middleware/auth' would instead bind to the stale
// auth.js twin under vitest and silently drop AUTH_008/AUTH_009.
router.use((req: Request, res: Response, next: any) => {
  // SECURITY (ledger C-18): drop every caller-supplied identity header BEFORE
  // anything downstream reads them. requireAny() reads x-roles, createAuditTrail
  // reads x-user-email; a client value must never survive to a route. This runs
  // first so it applies on every path, including rejection.
  delete (req.headers as any)['x-roles'];
  delete (req.headers as any)['x-user-email'];
  delete (req.headers as any)['x-tenant-id'];
  // The trail's session id comes from the verified token's `sid` (below);
  // a caller-sent x-session-id is not the session (DP-43).
  delete (req.headers as any)['x-session-id'];

  const auth = req.headers.authorization || (req.headers as any).Authorization;
  if (!auth || !/^Bearer\s+\S+$/i.test(auth)) {
    return res
      .status(401)
      .json({ error: 'Authentication required for 21 CFR Part 11 compliance' });
  }

  let decoded: any;
  try {
    // Canonical rotation-aware HS256 verification (JWT_SECRET_{ENV} ?? JWT_SECRET),
    // identical to authenticateToken — replaces the router-only AUTH_JWT_SECRET
    // path (dead config nothing signs with).
    decoded = verifyJwtWithRotation(auth.replace(/^Bearer\s+/i, ''));
  } catch {
    return res.status(401).json({ error: 'Invalid authentication token' });
  }

  // AUTH_008 (fail-closed): a non-access token (refresh / MFA challenge / MFA
  // partial) is signed with the same secret and must never authenticate here.
  if (nonAccessTokenReason(decoded)) {
    return res.status(401).json({ error: 'Invalid authentication token' });
  }

  // AUTH_007: a signed token with no usable subject must not authenticate.
  const subject = decoded.userId ?? decoded.id ?? decoded.sub;
  if (subject === undefined || subject === null || subject === '' || subject === 0) {
    return res
      .status(401)
      .json({ error: 'Authentication required for 21 CFR Part 11 compliance' });
  }

  // Expose the verified principal on req.user so actor-identity helpers
  // (getActorId / getActorEmail / getTenantId → authedOrgId) derive attribution
  // from the token only. Populated by this router's own first middleware — via
  // the canonical primitives — so the token-class and membership invariants are
  // enforced by the router itself in all environments.
  req.user = {
    id: subject,
    userId: subject,
    email: decoded.email ? String(decoded.email).toLowerCase() : undefined,
    role: decoded.role,
    roles: Array.isArray(decoded.roles)
      ? decoded.roles
      : decoded.roles
        ? String(decoded.roles).split(',')
        : undefined,
    organizationId: decoded.organizationId ?? decoded.orgId ?? decoded.tenant_id,
  };

  // Re-derive the sanitized identity headers legacy readers consume, from the
  // VERIFIED principal only (absence of a claim ⇒ absence of the header).
  const setOrClear = (header: string, value: string | number | undefined) => {
    if (value === undefined) delete (req.headers as any)[header];
    else (req.headers as any)[header] = value;
  };
  setOrClear('x-user-email', req.user.email);
  setOrClear('x-session-id', typeof decoded.sid === 'string' && decoded.sid ? decoded.sid : undefined);
  const roleList = Array.isArray(req.user.roles) && req.user.roles.length ? req.user.roles : undefined;
  setOrClear('x-roles', roleList ? roleList.map((r) => String(r).toUpperCase()).join(',') : undefined);
  const tenantId = authedOrgId(req);
  setOrClear('x-tenant-id', tenantId == null ? undefined : tenantId);

  // AUTH_009 (terminal): live organization_users re-check — fail-closed 403 on a
  // revoked membership, fail-open only on infra-indeterminate. Same control and
  // ~60s cache as authenticateToken.
  return enforceOrgMembership(req, res, next);
});
/* A disk-backed multer instance and its MIME allowlist stood here, attached
   to no route. The two upload routes this file does serve build their own
   memory-storage instances further down (imageUpload, docxImport); an unused
   /tmp writer with a 25MB limit was a configuration nobody could reach and
   nobody was maintaining. */

// Use centralized database pool
const pool = getPool();

// A minimal "thing that runs a query" — satisfied by both the shared Pool and a
// pooled client obtained via pool.connect(). Lifecycle mutations (section save,
// freeze, e-sign, sign) run all their writes on ONE such client inside a
// BEGIN/COMMIT so a mid-way failure ROLLs BACK rather than leaving partial
// state; the query helpers below accept the executor so those writes route
// through the same transaction. Non-transactional callers omit it and get the
// pool, preserving prior behavior.
type Queryable = { query: (text: string, params?: any[]) => Promise<any> };

/**
 * Document states in which the record is LOCKED and its sections are immutable.
 *
 * Matches the freeze handler's own check (`doc.status === 'FROZEN' ||
 * doc.status === 'APPROVED'`). Compared case-insensitively because the router
 * writes both cases — `POST /docs` inserts `'draft'` and the analytics query
 * counts `'approved'` in lower case, while freeze/approve write `'FROZEN'` /
 * `'APPROVED'` in upper case. A case-sensitive comparison would silently miss a
 * locked record.
 */
/* Re-exported from the canonical lock service rather than redeclared: the set
   is also read by the write gate below and by the client's frozen affordance,
   and three copies of "which statuses seal a record" is three chances for them
   to disagree about a Part 11 guarantee. */
const LOCKED_DOCUMENT_STATUSES = LOCKED_STATUSES;

/**
 * Is the fine-grained per-user section-permission matrix enforced?
 *
 * 21 CFR Part 11 §11.10(d) — "limiting system access to authorized individuals".
 * The matrix used to be strictly opt-in behind `AUTH_ENFORCE_SECTION_PERMS === '1'`,
 * and that flag is set NOWHERE in this repository outside tests. The effective
 * production rule was therefore "any authenticated member of the owning tenant may
 * edit any unlocked section of that tenant" — no per-user grant, and PATCH
 * /sections/:sectionId carries no coarse role gate either. A viewer-tier member, or
 * any member with no grant on the document, could edit a regulated IND/CTD section
 * they were never authorized to author.
 *
 * Enforced by DEFAULT in production and staging; the flag remains as a non-production
 * kill-switch (`'0'` disables, `'1'` forces on) so local development and fixtures that
 * predate the grant store keep working. Production cannot be opted out.
 *
 * Paired with the creator auto-grant on POST /docs — without that grant this control
 * is a lockout rather than a permission model.
 */
function sectionPermsEnforced(): boolean {
  if (process.env.NODE_ENV === 'production') return true;
  const flag = process.env.AUTH_ENFORCE_SECTION_PERMS;
  if (flag === '1') return true;
  if (flag === '0') return false;
  return process.env.NODE_ENV === 'staging';
}

/**
 * Section-level write authorization (C2C-AUTHOR-001 / C2C-AUTHOR-002).
 *
 * WHAT WAS WRONG
 * --------------
 * 1. DEFAULT ALLOW-ALL. The whole function opened with
 *      `if (process.env.AUTH_ENFORCE_SECTION_PERMS !== '1') return true;`
 *    and that flag is set NOWHERE in this repository. So the deployed default
 *    returned true before establishing anything at all — not the caller's
 *    tenant, not that the section existed, not the document's state.
 * 2. IMMUTABILITY WAS FLAG-GATED. The APPROVED check lived INSIDE that
 *    short-circuit, so with the flag off (i.e. always) a signed, frozen IND
 *    document's sections stayed editable. Record immutability is not a feature
 *    flag — it is 21 CFR Part 11 §11.10(c)/(e). It is now unconditional.
 *    FROZEN was never checked at all, at any flag setting.
 * 3. NO TENANT SCOPE. Neither query carried a tenant predicate, so with the
 *    flag ON a grant in tenant B could authorise a write in tenant A. Both
 *    queries are now anchored to the VERIFIED tenant.
 * 4. HEADER-DERIVED IDENTITY. Identity came from `x-user-email` and roles from
 *    `x-roles`. This router's own first middleware strips caller-supplied
 *    copies and re-derives them from verified claims, so these were not
 *    directly forgeable HERE — but authorization must not depend on a mutable
 *    header at all (one mis-ordered middleware and the class is back). Both now
 *    read the verified principal, matching requireAny() and ledger C-18.
 * 5. AND/OR PRECEDENCE. `WHERE s.id = $1 AND … OR (p.section_id IS NULL AND …)`
 *    binds AND tighter than OR, so the right-hand branch was NOT anchored to
 *    the requested section: ANY doc-level grant the caller held on ANY document
 *    satisfied a write to ANY other section. Every predicate is now anchored to
 *    the requested section AND the caller's tenant.
 * 6. PHANTOM TABLE. `doc_permissions` had no CREATE statement anywhere in the
 *    repo, so the flag-on path could only ever deny (relation does not exist →
 *    catch → false). A control that cannot be switched on is not a control,
 *    which is precisely why the insecure default was never turned off. The
 *    table is now provisioned by the canonical loop-tables migration and
 *    carried by the authoring provisioning unit.
 *
 * WHAT THE FLAG NOW GATES
 * -----------------------
 * ONLY the optional per-user object matrix — and that matrix is decided by the
 * canonical service (decideAuthoringPermission), never by a second query here.
 * The non-negotiable
 * guarantees — verified principal, tenant isolation, object existence within
 * that tenant, and the Part 11 immutability lock — run on every call regardless
 * of configuration. Flag-off is therefore no longer allow-all: it is
 * "a verified member of the owning tenant may edit an unlocked section of that
 * tenant", which is what keeps collaborative authoring working. It deliberately
 * does NOT prove a per-user grant; that is what the flag buys.
 *
 * FAILS CLOSED. Any throw, any missing tenant claim, any unknown section
 * denies. Never returns true on an error path.
 */
async function canEditSection(
  req: Request,
  sectionId: string | string[] | undefined
): Promise<boolean> {
  try {
    // A repeated ?sectionId or a missing param is not an identifiable object.
    if (typeof sectionId !== 'string' || sectionId.length === 0) return false;

    // Identity and tenant come from the VERIFIED principal only — never a
    // header, body or query value.
    if (!getActorId(req)) return false;
    const tenantId = authedOrgId(req);
    if (tenantId == null) return false;

    // ── UNCONDITIONAL: object existence + tenant + record immutability ───────
    // Resolving the section THROUGH its tenant proves three things at once: the
    // section exists, it belongs to the caller's tenant, and its parent
    // document is tenant-consistent (the join matches on tenant as well as id).
    const parent = (
      await pool.query(
        `SELECT d.status
           FROM authoring_sections s
           JOIN authoring_documents d
             ON d.id = s.doc_id AND d.tenant_id = s.tenant_id
          WHERE s.id = $1 AND s.tenant_id = $2
          LIMIT 1`,
        [sectionId, tenantId]
      )
    ).rows[0] as { status?: string | null } | undefined;

    // Unknown section, or a section belonging to another tenant.
    if (!parent) return false;

    // 21 CFR Part 11 record integrity: a frozen or approved record is closed to
    // edits for EVERY caller, including QA/RA_CMC, at every flag setting.
    if (LOCKED_DOCUMENT_STATUSES.has(String(parent.status ?? '').toUpperCase())) {
      return false;
    }

    // ── Fine-grained per-user matrix: ON by default in prod/staging ──────────
    if (!sectionPermsEnforced()) return true;

    // ONE implementation of the object-level decision.
    //
    // This used to be a second copy: an email-only join over doc_permissions
    // that accepted AUTHOR and REVIEWER, ignored revoked_at and valid_until, and
    // let a bare QA / RA_CMC role edit any section of the tenant. In production
    // that copy never decided anything — the canonical middleware
    // (server/middleware/authoringObjectAuthorization.ts, mounted on /api ahead
    // of this router) had already refused every caller it would have admitted,
    // and a revoked grant it would still have honoured was already dead at the
    // gateway. Two gates with two rule sets is exactly the divergence the
    // working agreement forbids, and the proof-tier tests were proving the
    // copy production never ran. The decision now comes from
    // decideAuthoringPermission, so a revocation, an expiry, an OWNER grant or
    // a global-admin role means the same thing here as it does at the gateway.
    // This gate stays as the fail-closed backstop the middleware is documented
    // to have: one mis-ordered mount and it is still the last word.
    const principal = authoringPrincipalFromRequest(req);
    if (!principal) return false;
    const scope = await resolveAuthoringSectionScope(pool, tenantId, sectionId);
    if (!scope) return false;
    const decision = await decideAuthoringPermission({
      pool,
      principal,
      scope,
      action: 'edit',
    });
    return decision.allowed;
  } catch (error) {
    // Fail CLOSED: a permission store that cannot be consulted authorises
    // nothing. Logged so an operator sees a broken store rather than a silent
    // deny storm.
    logger.error('canEditSection failed; denying the section edit', {
      sectionId: typeof sectionId === 'string' ? sectionId : null,
      err: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}

// Role-based access control helper
/**
 * Role gate.
 *
 * Reads the VERIFIED claim (req.user.roles) rather than the x-roles header.
 * The middleware above now derives and sanitises that header, so the two agree —
 * but authorization must not depend on a mutable header at all. One middleware
 * ordering mistake, one route mounted without this router's own JWT middleware,
 * and a header-reading gate is bypassable again. Reading the claim removes the
 * whole class. See ledger C-18.
 */
const requireAny = (roles: string[]) => {
  return (req: Request, res: Response, next: any) => {
    const claimed = ((req.user as { roles?: unknown } | undefined)?.roles ?? []) as unknown[];
    const userRoles = (Array.isArray(claimed) ? claimed : [claimed]).map(r =>
      String(r).toUpperCase()
    );
    const hasRole = roles.some(role => userRoles.includes(role.toUpperCase()));
    if (!hasRole) {
      return res.status(403).json({ error: `Requires one of: ${roles.join(', ')}` });
    }
    next();
  };
};

// Guard for section changes & token refresh.
//
// Belt-and-braces: canEditSection already fails closed internally, but this
// middleware must never be able to fall through to next() — or to reject into
// Express's error handler — on a throw. Either outcome is a fail-OPEN or a
// request that gets no answer at all. next() is deliberately OUTSIDE the try so
// an error raised by a downstream handler cannot be mistaken for a gate failure
// and trigger a second response.
router.use('/sections/:sectionId', async (req: Request, res: Response, next: any) => {
  try {
    if (['PATCH', 'POST', 'DELETE'].includes(req.method)) {
      /* ── Say WHICH refusal this is (MDX UAT item A4) ──────────────────────
         `canEditSection` already refuses a FROZEN or APPROVED document — that
         part of Part 11 §11.10(c)/(e) has been enforced here all along, on the
         editor save, the history revert and the AnA draft accept alike (this
         middleware is a prefix match, so all three are covered).

         What it could not do is say WHY, because it returns a boolean: a
         sealed record and a missing grant both came back as
         403 "No edit permission for this section". Those are different facts
         with different remedies — one is "ask an administrator", the other is
         "this content is signed; create a new version" — and the author who
         typed a paragraph into a frozen section was told the wrong one.

         Reading the lock first names the seal in the payload. It is the same
         query `canEditSection` runs, through the canonical helper, so the two
         cannot drift; `canEditSection` keeps its own lock check as the
         fail-closed backstop this middleware is documented to be.

         The STATUS stays 403. A sealed record is arguably a 409, and the
         contract test that pins this says in its own words that "the record
         itself is what matters, not the status code" — but 403 is the answer
         this endpoint has always given, and changing a status is a change to
         every client that branches on it, which is not this fix's to make. The
         distinction the UI needs travels in `error` and `message`, which
         nothing was reading before because nothing was sent. */
      const tenantId = authedOrgId(req);
      if (tenantId != null && typeof req.params.sectionId === 'string') {
        const lock = await checkSectionWritable(pool, req.params.sectionId, tenantId);
        if (!lock.writable && lock.code === 'DOCUMENT_FROZEN') {
          return res.status(403).json({
            error: 'DOCUMENT_FROZEN',
            message: lock.reason,
          });
        }
      }

      const ok = await canEditSection(req, req.params.sectionId);
      if (!ok) return res.status(403).json({ error: 'No edit permission for this section' });
    }
  } catch (error) {
    logger.error('section edit guard failed; denying the request', {
      method: req.method,
      err: error instanceof Error ? error.message : String(error),
    });
    return res.status(403).json({ error: 'No edit permission for this section' });
  }
  return next();
});

// Source tenant id from the verified JWT. The previous header / query /
// body fallback was attacker-controlled and is the IDOR shape PRs
// #496-#499 closed.
const getTenantId = (req: Request): number => {
  const tenantId = authedOrgId(req);
  if (tenantId == null) {
    throw new Error('Tenant context required');
  }
  return tenantId;
};

// Source the actor identity used for attribution / audit (created_by,
// updated_by, resolved_by, etc.) from the verified JWT only. Client-supplied
// `req.body.created_by` / `x-user-id` headers were attacker-controlled and let
// a user attribute authored content to another user or "system" (21 CFR Part
// 11 audit-trail integrity gap). Returns null when unauthenticated so the
// caller can respond 401.
const getActorId = (req: Request): string | null => {
  const subject = req.user?.id ?? req.user?.userId;
  if (subject === undefined || subject === null || subject === '') {
    return null;
  }
  return String(subject);
};

// Email-based actor attribution (created_by/submitted_by columns that store an
// email string). Sourced from the verified JWT only — never from
// `x-user-email` / `req.body.*` which were attacker-controlled. Returns null
// when the JWT carries no email/subject so the caller can respond 401.
const getActorEmail = (req: Request): string | null => {
  if (req.user?.email) {
    return String(req.user.email);
  }
  // Fall back to the JWT subject id so attribution is still tied to the
  // authenticated principal when the token omits an email claim.
  const subject = req.user?.id ?? req.user?.userId;
  if (subject === undefined || subject === null || subject === '') {
    return null;
  }
  return String(subject);
};

/**
 * The frozen snapshot a signature taken right now would cover — the most recent
 * frozen_documents row for this document, or null if it has never been frozen.
 *
 * Part 11 §11.70 requires a signature to be linked to the record version it
 * attests to. Signing an unfrozen document is allowed (an author may sign before
 * QA freezes), and that case is recorded as null rather than guessed at.
 */
const currentFrozenSnapshot = async (
  docId: string | string[] | undefined,
  tenantId: number,
  executor: Queryable = pool,
): Promise<{ version: string; contentHash: string } | null> => {
  const r = await executor.query(
    `SELECT version, content_hash FROM frozen_documents
      WHERE document_id = $1 AND tenant_id = $2
      ORDER BY frozen_at DESC LIMIT 1`,
    [docId, tenantId]
  );
  if ((r.rowCount ?? 0) === 0) return null;
  const row = r.rows[0] as { version: string; content_hash: string };
  return { version: row.version, contentHash: row.content_hash };
};

/**
 * A signature digest that an auditor can RECOMPUTE from the stored row.
 *
 * Every input is a durable column; nothing here is a timestamp. The previous
 * digest on /sign hashed `new Date().toISOString()`, which made it impossible to
 * verify — a hash nobody can reproduce proves nothing. Binding
 * coveredContentHash into the digest is what ties the signature to a specific
 * frozen snapshot cryptographically rather than by mere reference
 * (ledger C-11 residual 2).
 *
 * The `authoring-sig-v1` prefix keeps a future scheme change distinguishable
 * instead of silently incompatible.
 */
// Helper function to compute document hash for signatures. The digest itself
// is services/authoring/authoring-export.ts computeDocHash, so the vault filing
// records the same doc_sha256 the export route does.
const computeDocHash = (docId: string | string[] | undefined, tenantId: number): Promise<string> =>
  computeDocHashOn(pool, docId, tenantId);

/*
 * 21 CFR Part 11 §11.10(g) — may this signer apply a signature at all?
 *
 * "Use of ... controls to ensure that persons who ... electronically sign
 * records ... have the authority to do so." Identity is NOT authority: this
 * router once verified a PIN and a token and then let any authenticated member
 * sign, including `meaning: 'APPROVER'`, which approves and freezes a document.
 *
 * Each signing route here (freeze, e-sign, sign) asks the platform's one
 * policy, checkSigningAuthority (part11/signing-authority-gate.ts), inline in
 * its handler and before the credentials: the role from the membership row,
 * never `req.user.role`, 403 ESIGNATURE_NO_AUTHORITY, or 503
 * SIGNING_AUTHORITY_UNVERIFIED when the role cannot be read. This router held
 * its own copy of that check (assertSigningAuthority) until 2026-10-08 (P-27);
 * a failed lookup there was an unhandled 500.
 *
 * @compliance 21 CFR Part 11 §11.10(d), §11.10(g)
 */

/**
 * Does this document exist for this tenant?
 *
 * computeDocHash hashes the section rows and returns sha256("") when there are
 * none — which is indistinguishable from an unknown or cross-tenant docId. So a
 * signature could be written, an approval flip attempted against zero rows, and
 * a frozen_documents row inserted, all bound to the hash of the empty string,
 * and the caller told the document was signed and approved. §11.70 requires a
 * signature to be linked to its record; a signature bound to no record is not.
 */
// Does `authoring_documents` carry `c2c_document_id` in THIS deployment?
// Three-valued ('unknown' when the probe could not run) — the probe itself is
// services/authoring/authoring-evidence.ts bindingColumnState; this keeps the
// pool default every call site here relies on.
const bindingColumnState = (executor: Queryable = pool) => bindingColumnStateOn(executor);

async function documentExistsForTenant(
  docId: string | string[] | undefined,
  tenantId: number,
  executor: Queryable = pool,
): Promise<boolean> {
  const r = await executor.query(
    'SELECT 1 FROM authoring_documents WHERE id = $1 AND tenant_id = $2 LIMIT 1',
    [docId, tenantId],
  );
  return (r.rowCount ?? 0) > 0;
}

// Comprehensive audit logging for 21 CFR Part 11 compliance.
//
// The writer itself — the authoring_audit_trail row, the audit_logs index entry
// on the standalone path, the hash-chained entry when enlisted in a caller's
// transaction, and the fail-closed policy — is
// services/authoring/authoring-evidence.ts writeAuthoringAuditTrail, so the
// creators in services/authoring/authoring-documents.ts write the same rows
// from this router and from the AnA tool. This adapter derives the actor from
// the VERIFIED principal exactly as before and keeps every call site unchanged.
const auditContextFromRequest = (req: Request): AuthoringAuditContext => ({
  tenantId: getTenantId(req),
  actorId: getActorId(req) ?? undefined,
  actorEmail: (req.headers as any)['x-user-email'] || 'unknown',
  actorRole: (req.headers as any)['x-roles'] || 'unknown',
  ipAddress: req.ip || req.connection?.remoteAddress || 'unknown',
  userAgent: (req.headers['user-agent'] as string | undefined) || 'unknown',
  sessionId: (req.headers as any)['x-session-id'] || undefined,
  pool,
});

const createAuditTrail = async (
  req: Request,
  docId: string | string[] | undefined,
  sectionId: string | string[] | undefined | null,
  operationType: string,
  beforeContent: string | null,
  afterContent: string | null,
  changeReason: string | null,
  metadata: any = {},
  // When part of a lifecycle transaction, the caller passes its BEGIN'd client
  // so the audit row commits (or rolls back) atomically with the mutation it
  // records. Defaults to the pool for standalone callers.
  executor: Queryable = pool,
  auditOpts: CreateAuditTrailOptions = {}
) => {
  let ctx: AuthoringAuditContext;
  try {
    ctx = auditContextFromRequest(req);
  } catch (error) {
    // The writer's own policy, applied to a context that could not be derived
    // (a synthesized request without a tenant): never silent, fatal on a
    // caller's transaction, best-effort standalone outside production.
    console.error('CRITICAL: Failed to create audit trail:', error);
    if (executor !== pool) throw error;
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Audit logging failed - operation aborted for compliance', { cause: error });
    }
    return;
  }
  await writeAuthoringAuditTrail(ctx, {
    docId,
    sectionId,
    operationType,
    beforeContent,
    afterContent,
    changeReason,
    metadata,
    executor,
    auditOpts,
  });
};

/** The service context a create handler hands to authoring-documents.ts. */
const createContext = (req: Request, tenantId: number, actorId: string) => ({
  pool,
  tenantId,
  actor: { id: actorId, email: req.user?.email ? String(req.user.email).toLowerCase() : null },
  audit: auditContextFromRequest(req),
});

registerAuthoringAssemblyRoutes(router, {
  context: req => createContext(req, getTenantId(req), getActorId(req)!),
  principal: authoringPrincipalFromRequest,
});

/* A legacy wrapper, createAuditEvent, stood here (removed 2026-09-29, D5). It
   rebuilt a request from an email and a tenant, so every row it wrote had no
   actor id — the ledger showed the review, export, submission, signature and
   reorder it recorded as made by "System" — and the invented reason "Legacy
   audit event". Its six callers now call createAuditTrail with the real
   request; the signature's stated reason is its row's reason. */

/**
 * Run `work` on one pooled client between BEGIN and COMMIT; ROLLBACK on any
 * throw. A write and the audit row recording it are both issued on that
 * client, so an audit write that fails takes the write with it. The caller
 * answers the request only after this returns, i.e. after COMMIT.
 */
async function inTransaction<T>(work: (client: Queryable) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await work(client);
    await client.query('COMMIT');
    return out;
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

// Helper function to ensure token table exists
// authoring_tokens is now provisioned by db/migrations/20260730_authoring_runtime_ddl.sql.
// Retained as a no-op so existing call sites need no change; the router no longer
// issues runtime DDL (see authoring-schema-contract test).
const ensureTokenTableExists = async () => {};

// authoring_templates / template_guidance / template_usage / section_guidance are
// now provisioned by db/migrations/20260730_authoring_runtime_ddl.sql. Retained as
// a no-op so existing call sites need no change; the router no longer issues
// runtime DDL (see authoring-schema-contract test).
const ensureTemplateTablesExist = async () => {};

/**
 * §11.200(a)(1): re-verify the signer at the moment of signing, with the
 * platform's one ceremony (services/part11/reverify-signer.ts): the account
 * password, the second factor whenever one is enrolled, and the account's
 * lockout. Answers the refusal itself and returns null when the signature must
 * not be applied.
 *
 * This router verified a separate "signing PIN" instead (VSR-001 §13.3 item 3).
 * A signer with an authenticator enrolled signed without it; the PIN was first
 * set by POST /users/pin with a session alone, so possession of a session was
 * possession of the signing credential; and the product had two credential
 * stores with two lockouts for one act. The PIN routes and verifier are deleted;
 * the replacement for each is named where it stood.
 *
 * Called after every other check, so a code is consumed only by a signature
 * that is otherwise ready to apply.
 */
async function reverifyAuthoringSigner(req: Request, res: Response): Promise<SignerReverified | null> {
  const actor = getActorId(req);
  const userId = actor !== null && /^\d+$/.test(actor) ? Number(actor) : null;
  if (userId === null) {
    res.status(401).json({ error: 'Signing requires an account the server can re-verify', code: 'SIGNER_NOT_VERIFIABLE' });
    return null;
  }
  const { password, mfaToken } = (req.body ?? {}) as { password?: unknown; mfaToken?: unknown };
  const verified = await reverifySigner(userId, { password, mfaToken }, signerReverificationDeps());
  if (!verified.ok) {
    res.status(verified.status).json({ error: verified.error, code: verified.code });
    return null;
  }
  return verified;
}

/**
 * The signer's PRINTED NAME, for 21 CFR §11.50(a)(1).
 *
 * ── The defect this replaces ─────────────────────────────────────────────────
 * Both sign paths read the name as
 *
 *     ((req.user as { name?: string })?.name) || email
 *
 * and this router's own first middleware builds `req.user` from the verified
 * token as `{ id, userId, email, role, roles, organizationId }` — there is no
 * `name` key, and the access token carries no `name` claim to put in one. The
 * left side was therefore ALWAYS undefined, so `signer_name` on every
 * `authoring_signatures` row ever written is the signer's EMAIL ADDRESS.
 *
 * §11.50(a)(1) requires the printed name of the signer. An email address is an
 * identifier, not a printed name, and the fallback silently substituted one for
 * the other on a legally binding attestation.
 *
 * ── Why NULL rather than the email when it cannot be resolved ────────────────
 * Returning the email is what produced the defect: it is indistinguishable, at
 * every later point, from a genuinely resolved name. `signer_name` is nullable,
 * so NULL is available and is the honest value — it lets the manifestation say
 * "no printed name on record for this signer" instead of presenting an address
 * as if it satisfied §11.50(a)(1). The signature itself is NOT refused: a
 * missing display name is a record-quality problem, and blocking a signer from
 * attesting over it would be the worse failure.
 *
 * `users.email` is UNIQUE and `users.name` is NOT NULL, so a matched row always
 * yields a name.
 */
/**
 * The closed set of §11.50(a)(3) signature meanings this subsystem stores.
 * Declared once: `/e-sign` inlined this list and `/sign` had no check at all.
 */
const SIGNATURE_MEANINGS = ['AUTHOR', 'REVIEWER', 'APPROVER'] as const;

// The §11.50(b) manifestation (meaning labels, the ordered manifest lines and
// the tenant-scoped signature read) moved to services/authoring/authoring-export.ts
// with the renderer that is its only consumer.

const resolveSignerName = async (email: string): Promise<string | null> => {
  try {
    // Both call sites (the /e-sign PIN path and the /sign path) pass
    // getActorEmail(req) — the AUTHENTICATED actor's own address, never a body
    // or header value. That was the point of the earlier fix noting
    // "x-user-email here meant anyone could sign as anyone".
    //
    // tenant-isolation-safe: self-lookup of the caller's own §11.50(a)(1) printed name; `users` is the global identity table (membership lives in organization_users) so it has no tenant column to filter on, and getActorEmail(req) makes the caller's own row the only one reachable.
    const r = await pool.query<{ name: string | null }>(
      'SELECT name FROM users WHERE lower(email) = lower($1) LIMIT 1',
      [email]
    );
    const name = r.rows[0]?.name?.trim();
    return name ? name : null;
  } catch (error) {
    // A failed lookup must not take down the signing act. NULL is the honest
    // outcome and the manifestation reports it as unresolved.
    console.error('Signer name lookup failed:', error);
    return null;
  }
};

// Helper to create or update user PIN

// Helper function to create revision automatically — the hash-chained
// doc_revisions writer is services/authoring/authoring-evidence.ts
// createRevision (see its header for the ledger); this keeps the pool default
// the non-transactional call sites here rely on.
const createRevision = (
  sectionId: string | string[] | undefined,
  content: string,
  updatedBy: string,
  tenantId: number,
  executor: Queryable = pool,
  origin: RevisionOrigin = 'human-edit',
  contributors: { id: string; name: string }[] = []
) => createRevisionOn(executor, { sectionId, content, updatedBy, tenantId, origin, contributors });

/**
 * The machine author a doc_revisions row recorded about itself, re-validated
 * (round 15, SEC-A-7 door 3).
 *
 * `inputs.contributors` is written by createRevision from the save door's
 * already-validated list, and it is re-checked here rather than trusted
 * because it is in our own table: `machineContributors` is the one list of ids
 * that may be written as a machine author, and a JSONB column is only as
 * trustworthy as every writer that ever touched it. An unrecognised id yields
 * none, so the filing records NULL — "origin not stated" — rather than a
 * guess, which is the fabrication
 * migrations/20260822_section_version_author_kind_unspecified.sql closed one
 * layer up.
 *
 * Its own function so the revert handler stays inside the file's complexity
 * limit.
 */
function restoredMachineAuthor(inputs: unknown) {
  const contributors = machineContributors((inputs as { contributors?: unknown } | null)?.contributors);
  return { contributors, draftSource: contributors.length > 0 ? contributors[0].id : null };
}

// ============= Token Operations =============
router.post('/sections/:sectionId/tokens', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { cite_id, token_key, payload, source_refs } = req.body;
    const tenantId = getTenantId(req);
    const userEmail = (req.headers['x-user-email'] as string) || 'system';

    await ensureTokenTableExists();

    const sha256 = payload
      ? crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex')
      : null;

    const result = await pool.query(
      `INSERT INTO authoring_tokens
        (section_id, cite_id, token_key, payload, payload_sha256, source_refs, created_by, tenant_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (section_id, cite_id)
       DO UPDATE SET
         token_key = $3,
         payload = $4,
         payload_sha256 = $5,
         source_refs = $6,
         updated_at = NOW()
       RETURNING *`,
      [sectionId, cite_id, token_key, payload, sha256, source_refs, userEmail, tenantId]
    );

    res.json({
      success: true,
      token: result.rows[0],
    });
  } catch (error) {
    console.error('Error saving token:', error);
    return serverError(res, logger, 'saving tokens', error);
  }
});

// DELETE /api/authoring/sections/:sectionId/tokens/:citeId - Delete a token
router.delete('/sections/:sectionId/tokens/:citeId', async (req: Request, res: Response) => {
  try {
    const { sectionId, citeId } = req.params;
    const tenantId = getTenantId(req);

    await ensureTokenTableExists();

    const result = await pool.query(
      `DELETE FROM authoring_tokens
       WHERE section_id = $1 AND cite_id = $2 AND tenant_id = $3
       RETURNING *`,
      [sectionId, citeId, tenantId]
    );

    res.json({
      success: true,
      deleted: ((result.rowCount ?? 0) > 0),
    });
  } catch (error) {
    console.error('Error deleting token:', error);
    return serverError(res, logger, 'deleting tokens', error);
  }
});

// ============= Template Operations =============

// Initialize template tables on startup
(async () => {
  try {
    await ensureTemplateTablesExist();
    console.log('✅ Template tables initialized');
  } catch (error) {
    console.error('Failed to initialize template tables:', error);
  }
})();

/** Project builtin metadata into the same list shape as persisted templates. */
function builtinTemplateListRow(template: BuiltinAuthoringTemplate) {
  return {
    ...builtinTemplateReference(template), name: template.name, template_name: template.name,
    template_type: template.filingContext ? template.filingContext.registryId ?? 'document-component' : 'IND',
    category: template.filingContext ? 'Regulatory reference' : 'IND pyramid',
    regions: template.filingContext ? [template.filingContext.region] : ['FDA'],
    description: template.description, section_count: template.sections.length, active: true,
  };
}

// GET /api/authoring/templates - List all available templates
router.get('/templates', async (req: Request, res: Response) => {
  try {
    const { category, template_type, search } = req.query;
    const tenantId = getTenantId(req);

    // Every column here is one that authoring_templates actually has.
    //
    // This SELECT asked for t.name, t.module, t.region, t.description,
    // t.section_count and t.active — SIX columns the table does not define
    // (ensureTemplateTablesExist above creates template_name, regions and
    // is_active). PostgreSQL rejects an unknown column at plan time, so this
    // was an unconditional 42703: the endpoint 500'd on every request it had
    // ever received.
    //
    // It failed quietly because the only caller degrades well —
    // v2/surfaces/AuthoringCreateExport.tsx:53 wraps the fetch in
    // `catch { /* picker stays blank-only */ }` and only populates when the
    // body parses. So the "Start from" dropdown in the New Document dialog has
    // silently offered nothing but "None" for the life of the feature, with no
    // error anywhere a user or an operator would see.
    //
    // The `// template_type filter removed - column doesn't exist` note below
    // is a previous encounter with this same bug, patched one filter at a time;
    // template_type does exist, and that comment is wrong too. Fixing the
    // SELECT is what actually resolves it.
    //
    // Aliased to the shape the client reads (`t.name ?? t.title`) so the
    // response contract is unchanged.
    let query = `
      SELECT
        t.id,
        t.template_name AS name,
        t.template_name,
        t.template_type,
        t.category,
        t.regions,
        t.metadata ->> 'description' AS description,
        CASE WHEN jsonb_typeof(t.template_content -> 'sections') = 'array'
             THEN jsonb_array_length(t.template_content -> 'sections')
             ELSE 0 END AS section_count,
        t.created_at,
        t.is_active AS active
      FROM authoring_templates t
      WHERE t.tenant_id = $1 AND t.is_active = true
    `;

    const params: any[] = [tenantId];
    let paramCount = 1;

    if (category) {
      paramCount++;
      query += ` AND t.category = $${paramCount}`;
      params.push(category);
    }

    // template_type DOES exist (see ensureTemplateTablesExist); the filter was
    // removed under the mistaken belief that it did not. Restored.
    if (template_type) {
      paramCount++;
      query += ` AND t.template_type = $${paramCount}`;
      params.push(template_type);
    }

    if (search) {
      // Was `OR LOWER(t.name)` — t.name does not exist, so this branch was part
      // of the same 42703.
      paramCount++;
      query += ` AND LOWER(t.template_name) LIKE LOWER($${paramCount})`;
      params.push(`%${search}%`);
    }

    query += ` ORDER BY t.created_at DESC`;

    const result = await pool.query(query, params);
    // Same rule the globals get below: a template with zero sections cannot
    // seed anything and POST /docs refuses it with a 404 — listing it here
    // offered an option the create endpoint was guaranteed to reject.
    const orgRows = result.rows.filter((r: any) => Number(r.section_count) > 0);

    // ── Merge in the GLOBAL regulatory reference templates ──
    //
    // POST /docs resolves template_id against intelligence.document_templates
    // first — the deliberately untenanted store of agency-expectation
    // skeletons (CTD section sets, response letters). A picker that lists only
    // the org's own rows offers a different universe from the one create
    // consumes; with authoring_templates shipping empty, it offered NOTHING
    // for the life of the feature. Org rows stay first (customer content
    // before reference data); shape is aliased to the same contract.
    //
    // FAIL SOFT on the global read: the intelligence schema is a separate
    // bundle, absent in some deployments and in the authoring test harness. An
    // org's own templates must not vanish because the reference store is
    // unreachable.
    let globalRows: any[] = [];
    let globalCatalog: 'ok' | 'unavailable' = 'ok';
    try {
      let globalQuery = `
        SELECT
          t.id,
          t.template_name AS name,
          t.template_name,
          t.document_type AS template_type,
          'Regulatory reference' AS category,
          ARRAY[t.agency]::text[] AS regions,
          t.description,
          (SELECT count(*)::int FROM intelligence.template_sections ts WHERE ts.template_id = t.id) AS section_count,
          t.created_at,
          true AS active
        FROM intelligence.document_templates t
        WHERE t.status = 'active'
      `;
      const globalParams: any[] = [];
      if (category) {
        // Globals carry the synthetic category 'Regulatory reference'; a
        // category filter for anything else excludes them.
        if (String(category) !== 'Regulatory reference') globalQuery += ` AND false`;
      }
      if (template_type) {
        globalParams.push(template_type);
        globalQuery += ` AND t.document_type = $${globalParams.length}`;
      }
      if (search) {
        globalParams.push(`%${search}%`);
        globalQuery += ` AND LOWER(t.template_name) LIKE LOWER($${globalParams.length})`;
      }
      globalQuery += ` ORDER BY t.template_name ASC`;
      const globalResult = await pool.query(globalQuery, globalParams);
      // A template with zero sections cannot seed anything — offering it in
      // "Start from" would recreate the sectionless-document lie server-side.
      globalRows = globalResult.rows.filter((r: any) => Number(r.section_count) > 0);
    } catch (globalErr) {
      logger.warn('Global template store unavailable; listing org templates only', {
        error: globalErr instanceof Error ? globalErr.message : String(globalErr),
      });
      // The fail-soft is deliberate (an unreachable reference catalog must not
      // hide the org's own templates) — but the caller must be able to tell a
      // SHORT list from a FAILED half: the picker says so instead of letting
      // "no shared templates" and "the catalog read failed" render identically.
      globalCatalog = 'unavailable';
    }

    // Builtins project the canonical IND and regional biotech outlines. A
    // failure is a failed catalog read, never a shortened successful roster.
    const builtinRows = (await getBuiltinAuthoringTemplates()).map(builtinTemplateListRow)
      .filter(template => (!category || String(category) === template.category)
      && (!template_type || String(template_type) === template.template_type)
      && (!search || `${template.name} ${template.description} ${template.entryId ?? ''}`.toLowerCase().includes(String(search).toLowerCase())));
    const merged = [...orgRows, ...globalRows, ...builtinRows];
    res.json({
      success: true,
      templates: merged,
      globalCatalog,
      // rows.length, not rowCount: rowCount is a node-postgres field and is not
      // populated by every driver this code is exercised against.
      count: merged.length,
    });
  } catch (error) {
    console.error('Error listing templates:', error);
    return serverError(res, logger, 'loading templates', error);
  }
});

// GET /api/authoring/templates/:id - Get template with guidance
router.get('/templates/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const tenantId = getTenantId(req);

    const templateResult = await pool.query(
      `SELECT id, template_name, template_type, category, regions, template_content, guidance_content, metadata, is_active, usage_count, created_at, updated_at, created_by, tenant_id FROM authoring_templates WHERE id = $1 AND tenant_id = $2`,
      [id, tenantId]
    );

    if (((templateResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({ error: 'Template not found' });
    }

    const guidanceResult = await pool.query(
      `SELECT id, template_id, section_name, section_code, guidance_text, examples, regulatory_references, ai_prompts, compliance_checklist, created_at, updated_at, tenant_id FROM template_guidance WHERE template_id = $1 AND tenant_id = $2 ORDER BY section_code`,
      [id, tenantId]
    );

    res.json({
      success: true,
      template: templateResult.rows[0],
      guidance: guidanceResult.rows,
    });
  } catch (error) {
    console.error('Error fetching template:', error);
    return serverError(res, logger, 'loading templates', error);
  }
});

// POST /api/authoring/templates - Create new template
router.post(
  '/templates',
  requireAny(['ADMIN', 'RA_CMC', 'QA']),
  async (req: Request, res: Response) => {
    try {
      const {
        template_name,
        template_type,
        category,
        regions,
        template_content,
        guidance_content,
        metadata,
      } = req.body;
      const tenantId = getTenantId(req);
      const createdBy = getActorEmail(req);
      if (!createdBy) {
        return res.status(401).json({ success: false, error: 'Authentication required' });
      }

      const result = await pool.query(
        `INSERT INTO authoring_templates
       (template_name, template_type, category, regions, template_content, guidance_content, metadata, created_by, tenant_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
        [
          template_name,
          template_type,
          category,
          regions,
          template_content,
          guidance_content,
          metadata,
          createdBy,
          tenantId,
        ]
      );

      res.status(201).json({
        success: true,
        template: result.rows[0],
      });
    } catch (error) {
      console.error('Error creating template:', error);
      return serverError(res, logger, 'saving templates', error);
    }
  }
);

/* POST /templates/apply/:id is DELETED, not moved. It upserted section
 * content with no revision, no audit row, no lock check and no role gate —
 * an ungoverned overwrite of regulated content on a FROZEN or signed
 * document included — and nothing in the client ever called it (it is in
 * the orphan-endpoints report). The governed equivalent already exists:
 * POST /docs/:docId/apply-template takes a pre-template snapshot revision,
 * records 'template-apply' attribution, and runs in a transaction. Anything
 * that wants apply-onto-existing-document wires there, never here. */

// GET /api/authoring/guidance/:sectionId - Get contextual guidance
router.get('/guidance/:sectionId', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    if (typeof sectionId !== 'string') return res.status(400).json({ success: false, error: 'A section identifier is required.' });
    const tenantId = getTenantId(req);

    // Get section-specific guidance
    const templateGuidance = await savedTemplateGuidance(pool, tenantId, sectionId, authoringPrincipalFromRequest(req));
    const guidanceResult = await pool.query(
      `SELECT id, section_id, document_type, guidance_type, content, metadata, priority, created_at, updated_at, tenant_id FROM section_guidance
       WHERE section_id = $1 AND tenant_id = $2
       ORDER BY priority DESC, guidance_type`,
      [sectionId, tenantId]
    );

    // Get template guidance if section is from a template
    res.json({
      success: true,
      guidance: guidanceResult.rows,
      template_guidance: templateGuidance,
      section_id: sectionId,
    });
  } catch (error) {
    if (error instanceof TemplateGuidanceError || error instanceof AuthoringProgramAccessError) return res.status(error.status).json({ success: false, error: error.message });
    console.error('Error fetching guidance:', error);
    return serverError(res, logger, 'loading guidance', error);
  }
});

// POST /api/authoring/guidance - Create/update guidance for a section
router.post(
  '/guidance',
  requireAny(['ADMIN', 'RA_CMC', 'QA']),
  async (req: Request, res: Response) => {
    try {
      const { section_id, document_type, guidance_type, content, metadata, priority } = req.body;
      const tenantId = getTenantId(req);

      const result = await pool.query(
        `INSERT INTO section_guidance
       (section_id, document_type, guidance_type, content, metadata, priority, tenant_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (section_id, guidance_type, tenant_id)
       DO UPDATE SET
         content = $4,
         metadata = $5,
         priority = $6,
         updated_at = NOW()
       RETURNING *`,
        [section_id, document_type, guidance_type, content, metadata, priority || 0, tenantId]
      );

      res.json({
        success: true,
        guidance: result.rows[0],
      });
    } catch (error) {
      console.error('Error saving guidance:', error);
      return serverError(res, logger, 'saving guidance', error);
    }
  }
);

// ============= CRUD Operations =============

/** Current read identity is captured once; selected program is never ignored. */
function currentAuthoringReadIdentity(req: Request, documentId?: unknown) {
  const program = req.query.programId;
  if ((program !== undefined && (typeof program !== 'string' || !isUuid(program))) ||
      (documentId !== undefined && (typeof documentId !== 'string' || !isUuid(documentId)))) {
    throw new AuthoringReadInputError();
  }
  const actor = getActorId(req);
  return { organizationId: getTenantId(req), userId: actor == null ? undefined : Number(actor),
    programId: typeof program === 'string' ? program.toLowerCase() : undefined,
    ...(typeof documentId === 'string' ? { documentId: documentId.toLowerCase() } : {}) };
}
function currentAuthoringReadFailure(error: unknown, res: Response, operation: string) {
  if (error instanceof AuthoringReadInputError) return res.status(400).json({ success: false, code: error.code, error: error.message });
  if (error instanceof AuthoringReadScopeError || error instanceof ProgramReadAccessError) {
    return res.status(error.status).json({ success: false, code: error.code, error: error.message });
  }
  return serverError(res, logger, operation, error);
}

// GET /api/authoring/docs - No module/status default; current ACL precedes counts.
router.get('/docs', async (req: Request, res: Response) => {
  try {
    const identity = currentAuthoringReadIdentity(req);
    const filter = (key: string) => typeof req.query[key] === 'string' ? req.query[key] as string : undefined;
    const result = await readAuthoringDocuments(requestPgClient(req), identity, {
      module: filter('module'), product_code: filter('product_code'), status: filter('status'),
      conversationId: filter('conversationId'), source: filter('source'),
    });
    return res.json(result);
  } catch (error) { return currentAuthoringReadFailure(error, res, 'loading docs'); }
});

// POST /api/authoring/docs - Create new document
router.post('/docs', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    // The create itself — template resolution before any write, the governed
    // binding, ONE transaction for the document, its identity aliases, its
    // seeded sections and their Part 11 evidence, then the creator's
    // OWNER/AUTHOR grants — is services/authoring/authoring-documents.ts
    // createDocument, shared with POST /docs/from-draft and the AnA tool.
    const outcome = await createDocument(createContext(req, tenantId, createdBy), req.body ?? {});
    if (outcome.kind === 'refused') {
      // `code` (e.g. PROJECT_REQUIRED) is what a client branches on; `error`
      // stays the human-readable message existing callers read.
      return res
        .status(outcome.status)
        .json({ success: false, error: outcome.error, ...(outcome.code ? { code: outcome.code } : {}) });
    }

    res.status(201).json({
      success: true,
      document: outcome.document,
      // How many sections the chosen template actually seeded (absent for a
      // blank create) — the client's confirmation states it instead of
      // implying it.
      ...(outcome.templateSectionCount !== null ? { sections_seeded: outcome.templateSectionCount } : {}),
      message: 'Document created successfully',
      // The binding outcome, always present. A document that is NOT attached to
      // a governed filing must say so at the moment it is created — an unbound
      // document is a legitimate state, but a silently unbound one is how the
      // two stores drifted apart in the first place.
      governance: outcome.binding.documentId
        ? { bound: true, c2cDocumentId: outcome.binding.documentId }
        : { bound: false, reason: outcome.binding.reason },
    });
  } catch (error) {
    if (error instanceof AuthoringCreateOutcomeError) return res.status(503).json(authoringCreationRecoveryPayload(error));
    if (error instanceof DocumentAliasConflictError) {
      // Nothing was persisted: the alias write is inside the transaction.
      return res.status(409).json({
        error: 'DOCUMENT_ALIAS_CONFLICT',
        message: `${error.message}. Nothing was created.`,
      });
    }
    console.error('Error creating document:', error);
    return serverError(res, logger, 'saving docs', error);
  }
});

// POST /api/authoring/docs/from-draft — a drafted document becomes an authoring
// document in one transaction (WM, 2026-09-21, docs/design/ANA_DOCUMENT_CANVAS.md).
//
// body { programId, title, module?, documentType?,
//        sections: [{ code, title, content }],
//        provenance: { source: 'ana' | 'seed' | 'import', conversationId?, turnId?, model?, note? } }
// → 201 { data: { doc, sections } }. Content is sanitized HTML (the server-side
// mirror of the client's audited allowlist); provenance is stored on the row
// and returned by GET /docs/:docId. 400 on an empty section list or a missing
// programId, 403 without a tenant, 503 (nothing written) when the deployment
// cannot record provenance.
router.post('/docs/from-draft', async (req: Request, res: Response) => {
  try {
    const tenantId = authedOrgId(req);
    if (tenantId == null) {
      return res.status(403).json({ success: false, error: 'Tenant context required' });
    }
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const parsed = parseDraftInput(req.body);
    if (!parsed.ok) {
      return res.status(400).json({ success: false, error: parsed.error });
    }
    const outcome = await createDocumentFromDraft(createContext(req, tenantId, createdBy), parsed.value);
    if (outcome.kind === 'refused') {
      return res.status(outcome.status).json({ success: false, error: outcome.error });
    }
    res.status(201).json({
      success: true,
      data: {
        doc: { ...outcome.document, provenance: outcome.provenance },
        sections: outcome.sections,
      },
      governance: outcome.binding.documentId
        ? { bound: true, c2cDocumentId: outcome.binding.documentId }
        : { bound: false, reason: outcome.binding.reason },
    });
  } catch (error) {
    if (error instanceof AuthoringCreateOutcomeError) return res.status(503).json(authoringCreationRecoveryPayload(error));
    if (error instanceof DocumentAliasConflictError) {
      return res.status(409).json({
        error: 'DOCUMENT_ALIAS_CONFLICT',
        message: `${error.message}. Nothing was created.`,
      });
    }
    console.error('Error creating document from draft:', error);
    return serverError(res, logger, 'saving docs', error);
  }
});

// Exact source → a working copy in the SAME editor, with verified provenance.
// The original is retained; one atomic creator writes all authoring evidence.
router.post('/import/source', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const tenantId = authedOrgId(req);
    const actorId = getActorId(req);
    const principal = authoringPrincipalFromRequest(req);
    if (tenantId == null) return res.status(403).json({ success: false, error: 'TENANT_REQUIRED', message: 'Tenant context required.' });
    if (!actorId || !principal) return res.status(401).json({ success: false, error: 'AUTHENTICATION_REQUIRED', message: 'Authentication required.' });
    const result = await importSourceDocument(createContext(req, tenantId, actorId), principal, req.body);
    if (!result.ok) return res.status(result.status).json({ success: false, error: result.code, message: result.message });
    return res.status('preview' in result.data || result.data.reused ? 200 : 201).json({ success: true, data: result.data });
  } catch (error) {
    if (error instanceof AuthoringCreateOutcomeError) return res.status(503).json(authoringCreationRecoveryPayload(error));
    return serverError(res, logger, 'pulling a source into the document editor', error);
  }
});

router.get('/ind-document-catalog', (_req: Request, res: Response) => {
  res.json({ success: true, data: buildIndDocumentCatalog() });
});

// GET /api/authoring/docs/:docId - Current admitted header, source facts and hints.
router.get('/docs/:docId', async (req: Request, res: Response) => {
  try {
    const identity = currentAuthoringReadIdentity(req, req.params.docId);
    if (!identity.documentId) throw new AuthoringReadInputError();
    return res.json(await readAuthoringDocument(requestPgClient(req), { ...identity, documentId: identity.documentId }));
  } catch (error) { return currentAuthoringReadFailure(error, res, 'loading docs'); }
});

// GET /api/authoring/docs/:docId/sections - Exact admitted sections, never siblings.
router.get('/docs/:docId/sections', async (req: Request, res: Response) => {
  try {
    const identity = currentAuthoringReadIdentity(req, req.params.docId);
    if (!identity.documentId) throw new AuthoringReadInputError();
    return res.json(await readAuthoringDocumentSections(requestPgClient(req), { ...identity, documentId: identity.documentId }));
  } catch (error) { return currentAuthoringReadFailure(error, res, 'loading sections'); }
});

// POST /api/authoring/sections - Create new section
router.post('/sections', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    // The create — the parent's immutability lock, the position the code
    // belongs at (FOR UPDATE), the INSERT + lineage gate in one transaction,
    // then the genesis revision and the CREATE audit row — is
    // services/authoring/authoring-documents.ts createSection.
    const outcome = await createSection(createContext(req, tenantId, createdBy), req.body ?? {});
    if (outcome.kind === 'refused') {
      // `code` (e.g. SECTION_CODE_EXISTS, a 409) is what a client branches on.
      return res
        .status(outcome.status)
        .json({
          success: false,
          error: outcome.error,
          ...(outcome.code ? { code: outcome.code } : {}),
          ...(outcome.code === 'SECTION_CODE_EXISTS' ? { field: 'code' } : {}),
        });
    }
    if (outcome.kind === 'lineage_failed') {
      return res.status(500).json({
        success: false,
        error: {
          code: 'LINEAGE_REQUIRED',
          message:
            'The section was not created: its data lineage could not be recorded. ' +
            'Saving content without provenance is not permitted.',
        },
      });
    }

    res.status(201).json({
      success: true,
      section: outcome.section,
      message: 'Section created successfully',
    });
  } catch (error) {
    if (error instanceof AuthoringSectionWriteOutcomeError) return res.status(503).json(authoringSectionRecoveryPayload(error));
    console.error('Error creating section:', error);
    return serverError(res, logger, 'saving sections', error);
  }
});

async function dispatchSavedSectionRefile(req: Request, res: Response, next: NextFunction) {
  if (!Object.prototype.hasOwnProperty.call(req.body ?? {}, 'filingOnly')) return next();
  try {
    const actorId = getActorId(req);
    if (!actorId) return res.status(401).json({ success: false, error: 'Authentication required' });
    if (typeof req.params.sectionId !== 'string') return res.status(400).json({ success: false, code: 'REFILING_REQUEST_INVALID', error: 'A saved section is required.' });
    const result = await refileSavedAuthoringSection({ pool, tenantId: getTenantId(req),
      actor: { id: actorId, email: getActorEmail(req) }, principal: authoringPrincipalFromRequest(req),
      audit: auditContextFromRequest(req), sectionId: req.params.sectionId, body: req.body,
      retainedDraftSource: inputs => restoredMachineAuthor(inputs).draftSource });
    return res.status(result.status).json(result.body);
  } catch (error) {
    logger.error('Saved-section re-filing request could not be completed', { err: error instanceof Error ? error.message : String(error) });
    return res.status(503).json({ success: false, code: 'OUTCOME_UNKNOWN', retryAllowed: false,
      error: 'The re-filing outcome could not be confirmed. Do not retry re-filing.' });
  }
}


// PATCH /api/authoring/sections/:sectionId - Update section (with automatic revision)
router.patch('/sections/:sectionId', dispatchSavedSectionRefile, async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { content, track_changes, title, code } = req.body;
    /* WHICH WORDS a machine author wrote, as the client claims it. Read off
       the marks before accepting strips them; the server keeps only the ids it
       names itself, and each entry carries the AnA turn record the words came
       from so the claim can be CHECKED (round 15, SEC-A-7 door 1). Nothing is
       believed here — `creditMachineClaims` below decides, once, for both
       channels. */
    const acceptedMachine = acceptedMachineText(req.body?.acceptedMachineText);
    /* And WHO the save says contributed. No longer a second, unchecked claim:
       it is disclosed on the Part 11 row, and the contributors the revision
       and the filing actually record are derived from the verdict on the words
       (`contributorsOf`). Before round 15 this list alone set the revision's
       origin to `ai-draft-accept`, wrote the machine into `inputs.contributors`
       and became the filing's `draft_source` — with no words to check against
       any record. `settleAcceptedContributions` in the editor sends no author
       without its text, so the two channels agree for every current client. */
    const claimedAuthors = machineContributors(req.body?.acceptedAuthors);
    const tenantId = getTenantId(req);
    const updatedByUser = getActorId(req);
    if (!updatedByUser) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    // Get current section data for revision
    const currentSection = await pool.query(
      'SELECT id, doc_id, code, title, content, order_index, track_changes, created_at, updated_at, tenant_id FROM authoring_sections WHERE id = $1 AND tenant_id = $2',
      [sectionId, tenantId]
    );

    if (((currentSection.rowCount ?? 0) === 0)) {
      return res.status(404).json({
        success: false,
        error: 'Section not found',
      });
    }

    /* LAST WRITE NO LONGER SILENTLY WINS.
     *
     * This UPDATE was `WHERE id = $n AND tenant_id = $n` and nothing else, and
     * the client sent only `{ content }`. So two authors on one section — the
     * normal case for a CTD module, where a writer and a reviewer work the same
     * §3.2.P.5 at once — ended with whoever saved second replacing the OTHER'S
     * ENTIRE SECTION. No 409, no warning, no merge, no "this changed while you
     * were editing". The overwrite then entered the hash-chained revision
     * ledger as an ordinary authored revision, so the record does not show a
     * collision either; the only way back is for someone to notice and revert.
     *
     * `updated_at` is the concurrency token because it is already on the row
     * the client loaded, already returned by every read, and already bumped by
     * every write — no new column, no new migration, nothing to keep in sync.
     *
     * OPT-IN, deliberately. A client that sends no `expectedUpdatedAt` keeps
     * the old behaviour rather than being refused: a caller that PATCHes a
     * section without having read a timestamp cannot hit the race, and failing
     * it closed would break saving to fix nothing. The editor sends it;
     * anything that does not is exactly as safe as it was yesterday and no
     * less.
     *
     * This comment used to name "the MDX dossier drawer" as one of those
     * callers. It is not a caller of this route at all: it PATCHes
     * `/api/c2c/documents/:id/sections/:key` (mdx/hooks/useSectionSave.ts),
     * the FILING side. Correcting it is not housekeeping — the stale line said
     * the drawer saved through this door, which is seal-guarded, and so helped
     * hide that the door it really uses was not (round 15, the exit-path
     * verification). The other two client PATCHes here carry `track_changes`
     * or `code`/`title` only. */
    const expectedUpdatedAt = req.body?.expectedUpdatedAt;
    if (typeof expectedUpdatedAt === 'string' && expectedUpdatedAt.trim()) {
      const current = currentSection.rows[0]?.updated_at;
      const currentMs = current ? new Date(current).getTime() : NaN;
      const expectedMs = new Date(expectedUpdatedAt).getTime();
      if (Number.isFinite(currentMs) && Number.isFinite(expectedMs) && currentMs !== expectedMs) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'SECTION_CHANGED',
            message:
              'This section was changed by someone else while you were editing. ' +
              'Your text has not been saved and nothing was overwritten — reload the ' +
              'section to see their version, then reapply your changes.',
          },
          /* The caller can show WHEN it moved under them without another read. */
          currentUpdatedAt: current,
        });
      }
    }

    /* ── A SECTION'S CODE IS ITS IDENTITY IN THE FILING ──
     *
     * `commitSectionToFiling` matches `authoring_sections.code` to
     * `c2c_document_sections.section_key`. So changing the code on a BOUND
     * document does not rename anything — it silently re-points the section to
     * a DIFFERENT filing slot (or to none), and the next content save lands
     * there instead, orphaning the old slot's content. Nothing warned; the
     * rename dialog offered the code as a freely editable field.
     *
     * Refused, fail-closed. The title renames freely — that is a label. The
     * code is structure, and re-keying a bound section is not a rename. If a
     * "move this section to another filing slot" operation is ever wanted, it
     * is a deliberate feature with its own rules (is the target occupied? is it
     * in the rule pack?), not a side effect of the rename field. An UNBOUND
     * document has no filing linkage to break, so its codes stay editable. */
    if (code !== undefined && String(code) !== String(currentSection.rows[0].code ?? '')) {
      /* This predicate names c2c_document_id, which a deployment carrying the
         authoring bundle without the c2c one does not have — the same shape the
         create path above already copes with, and which
         commit-section-to-filing.ts treats as a supported deployment rather
         than an error. Unguarded, the catalog raises 42703 and a section
         rename answers 500 on those deployments.

         Each state has a different correct answer, so they are not collapsed:
           present — ask, and lock the code if the document is bound.
           absent  — no document here CAN be bound, so there is no filing
                     linkage to break and the code stays editable, exactly as
                     the comment above says of an unbound document.
           unknown — the check did not run, so whether this document is bound
                     is not known. Refuse. The lock exists to stop a rename
                     silently re-pointing a section to a different filing slot
                     and orphaning the old slot's content; allowing it on an
                     unverified guess risks that, while refusing costs a retry. */
      const columnState = await bindingColumnState();
      if (columnState === 'unknown') {
        return res.status(503).json({
          success: false,
          error: {
            code: 'BINDING_CHECK_UNAVAILABLE',
            message:
              'Whether this section is bound to a filing slot could not be checked, so its code ' +
              'was not changed. Nothing was modified. Try again.',
          },
        });
      }
      const bound =
        columnState === 'present'
          ? await pool.query(
              `SELECT 1 FROM authoring_documents
                WHERE id = $1 AND tenant_id = $2 AND c2c_document_id IS NOT NULL`,
              [currentSection.rows[0].doc_id, tenantId],
            )
          : { rowCount: 0 };
      if ((bound.rowCount ?? 0) > 0) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'CODE_LOCKED_TO_FILING',
            message:
              'This section’s code is its place in the filing, so it cannot be changed here. ' +
              'Re-coding it would break the link between this section and the filing slot it fills, ' +
              'and its content would stop reaching the filing. The title can be renamed freely.',
          },
        });
      }
    }

    // Build update query dynamically
    const updates = [];
    const values = [];
    let paramCount = 0;
    let recordRevision = false;

    if (content !== undefined) {
      /* AN IMAGE IN A SECTION IS AN UPLOADED FIGURE OR NOTHING (periodic review
         2026-09-28, editor family, SEC-B-1, SEC-B-2). This save stored any
         `<img src>` it was sent, so one editor could plant a request that every
         later reader's browser made in the reader's own name (dot segments walk
         `/api/authoring/images/` out to any API route), or an image on another
         site that every reader's browser fetched. Refused with the images named,
         before anything is written, and never rewritten: a governed record's
         content changes only when its author changes it. */
      const { refusedFigures, describeRefusedFigures } = await import(
        '../services/authoring/authoring-html-sanitizer'
      );
      const refused = await refusedFigures(typeof content === 'string' ? content : String(content ?? ''));
      if (refused.length > 0) {
        return res.status(400).json({
          success: false,
          error: { code: 'FIGURE_NOT_UPLOADED', message: describeRefusedFigures(refused) },
          field: 'content',
          refusedImages: refused.map(({ position, src }) => ({
            position,
            src: src.length > 200 ? `${src.slice(0, 200)}…` : src,
          })),
        });
      }
      paramCount++;
      // `$$` is the placeholder's `$` followed by the interpolation. fde9d704 lost
      // it, so the SQL read `content = 1` with the bound value unused, Postgres
      // refused the UPDATE, and every section content save answered 500.
      updates.push(`content = $${paramCount}`);
      values.push(content);
      recordRevision = true;
    }

    // §11.10(e): a content change carries its reason, checked here rather
    // than trusted from the client, and refused before anything is written.
    let changeReason: string | null = null;
    if (recordRevision) {
      const verdict = requireGovernedReason(req.body?.changeReason);
      if (!verdict.ok) return res.status(400).json({ error: verdict.error, field: 'changeReason' });
      changeReason = verdict.reason;
    }

    if (title !== undefined) {
      paramCount++;
      updates.push(`title = $${paramCount}`);
      values.push(title);
    }

    if (code !== undefined) {
      paramCount++;
      updates.push(`code = $${paramCount}`);
      values.push(code);
    }

    if (track_changes !== undefined) {
      paramCount++;
      updates.push(`track_changes = $${paramCount}`);
      values.push(track_changes);
    }

    // Always update the updated_at timestamp
    updates.push('updated_at = NOW()');

    // Add section_id and tenant_id to values
    values.push(sectionId, tenantId);

    const updateQuery = `
      UPDATE authoring_sections
      SET ${updates.join(', ')}
      WHERE id = $${paramCount + 1} AND tenant_id = $${paramCount + 2}
      RETURNING *
    `;

    // ── One atomic save ───────────────────────────────────────────────────────
    // Revision + section update + lineage + filing commit + audit are ONE atomic
    // unit on ONE connection. Previously the revision and audit writes ran as
    // their own pool commits while the lineage/filing gate ran in a separate
    // transaction, so a failure between them left the trail out of step with the
    // section — or, worse, produced saved text with no provenance and no signal
    // it had happened. A single BEGIN/COMMIT makes all of it land together or not
    // at all; any error rolls the whole thing back and the caller is told. A
    // refused save is recoverable; a document that quietly lost its provenance,
    // its filing commit, or its audit record is not.
    /* ── THE GOVERNED-WRITE VERDICT, BEFORE THE TRANSACTION OPENS ───────────
     * One verdict on every machine-text claim this save carries: the record
     * must hold the words, and CLAUDE.md RULE 2 must admit every model that
     * served the turn. Only a credited claim is attributed to the machine;
     * everything else is saved as this person's own assertion, with the claim
     * and its reason on the Part 11 row and on the response.
     *
     * Here rather than inside the transaction because the rows it reads are
     * append-only — so nothing it sees can change under the write — and
     * because a failed statement inside the BEGIN would abort the very write
     * it is checking. Only on a content save: a rename carries no words.
     *
     * An unverifiable claim does not refuse the save; a VERIFIED one whose
     * model RULE 2 does not admit does. governed-machine-claims.ts states why
     * the two cases differ. */
    const machineClaims: GovernedClaimVerdict =
      content !== undefined
        ? await creditMachineClaims(pool, tenantId, acceptedMachine)
        : { credited: [], refused: [], recordOccurrences: () => 0 };

    /* ── A VERIFIED CLAIM RULE 2 WILL NOT ADMIT STOPS THE SAVE ──────────────
     * Not the attribution — the save. The server has checked that the record
     * verifies whole, that the words are inside what AnA produced, and that a
     * serving model is one the rule does not admit for regulatory drafting.
     * Saving it anyway would write a named person as the author of words a
     * model demonstrably wrote, into a §11.10(e) lineage span and into the
     * filing itself. Refused before anything is written, and before the
     * transaction even opens.
     *
     * An UNVERIFIABLE claim is not refused — see governed-machine-claims.ts
     * for why the two cases differ, and why this refusal is only honest
     * because the editor keeps the claim for the retry. */
    const notAdmitted = refusedForModel(machineClaims);
    if (notAdmitted) {
      const refusal = governedSaveRefusal(notAdmitted);
      logger.warn('Section save refused: a verified machine claim names a model RULE 2 does not admit', {
        sectionId, tenantId, servedBy: refusal.servedBy, passages: refusal.passages,
      });
      return res.status(403).json({
        success: false,
        error: { code: refusal.code, message: refusal.message },
        servedBy: refusal.servedBy,
        turnRecordIds: refusal.turnRecordIds,
      });
    }

    /* What the Part 11 row and the saver are each told about the claims.
       Computed once: both are pure functions of the verdict, and calling them
       inside the object literal that uses them read as two decisions. */
    const claimDisclosure = machineClaimDisclosure(machineClaims, claimedAuthors);
    const claimReport = machineClaimReport(machineClaims);

    const client = await pool.connect();
    let result: { rows: any[] };
    // Whether the text reached the filing, and when it did not, why. Reported
    // on the response rather than dropped: an unbound save is legitimate, a
    // silently unbound one is how the two stores drifted apart.
    let governedCommit: CommitSectionResult | null = null;
    try {
      await client.query('BEGIN');
      await reserveWritableSection(client, String(sectionId), tenantId);

      // The previous body is a transaction-held fact, read after the parent
      // reservation and before this update. Client-supplied text and the
      // pre-reservation lookup cannot establish a retained span's integrity.
      const previous = content === undefined ? null : await client.query<{ content: string | null }>(
        'SELECT content FROM authoring_sections WHERE id=$1 AND tenant_id=$2 FOR UPDATE',
        [String(sectionId), tenantId],
      );

      result = await client.query(updateQuery, values);

      // The lineage gate: record an author span per clause and assert coverage,
      // in this transaction, so content and provenance commit together. Empty /
      // undefined content (a metadata-only update) is a no-op inside the helper.
      // req.params is typed `string | string[]`; document_id is the join key
      // every later read depends on, so coerce rather than let an array
      // stringify itself into one.
      const lineage = await enforceAuthorLineage(
        client,
        tenantId,
        { documentTable: 'authoring_sections', documentId: String(sectionId) },
        content,
        updatedByUser,
        {
          previousContent: previous ? previous.rows[0]?.content ?? '' : undefined,
          /* Only the claims a record vouched for. An unverifiable claim's
             clause is not dropped — no accepted-machine text matches it, so
             the gate records it as this person's own assertion, which is what
             they did by saving it. */
          acceptedMachineText: machineClaims.credited.map(({ authorId, text }) => ({ authorId, text })),
          /* And no clause is credited more times than the crediting records
             hold it (the batch-draft accept's rule, round 4, DUP). */
          recordOccurrences: machineClaims.recordOccurrences,
        },
      );

      /* ── WHO THE RECORD NAMES: WHAT THE GATE CREDITED, NOT WHAT WAS CLAIMED ──
       * `clausesInAcceptedText` is the gate's own count, and its contract is
       * explicit: "A caller that says a save accepted a machine's text says it
       * only when this is above zero". A verified claim of ONE WORD credits no
       * clause, and naming AnA on it would make the revision say
       * `ai-draft-accept`, the filing record `draft_source = 'ana'` and the
       * snapshot trigger record `author_kind = 'ana'` for a save in which the
       * lineage credited the machine with nothing — the defect the sibling
       * batch-draft door was corrected for in round 3, at the door that files
       * into c2c_documents.
       *
       * This is why the lineage gate now runs BEFORE the revision here, as it
       * already did at the revert (:2494) and at template-apply (:6142): what
       * a save says about itself has to follow what it credited. The gate
       * reads and writes span rows only, never the section row, so the order
       * is free. One machine author exists in the vocabulary today
       * (MACHINE_AUTHOR_IDS), so one count answers for it; a second id would
       * need the count per author. */
      const contributors = lineage.clausesInAcceptedText > 0 ? contributorsOf(machineClaims) : [];

      // A revision row means "this content, by this author, as of this time".
      // POST /sections already recorded (new content, author); this makes the
      // edit path agree with it. The prior content is not lost — it is the
      // preceding row. Only when content changed.
      if (recordRevision) {
        /* A save that incorporates accepted machine-authored text is not a
           plain human edit, and saying so is the whole point: the origin marks
           it in the chain hash, the contributor list names who drafted it. */
        await createRevision(
          sectionId,
          content,
          updatedByUser,
          tenantId,
          client,
          contributors.length ? 'ai-draft-accept' : 'human-edit',
          contributors,
        );
      }

      // ── Commit the working copy into the filing ─────────────────────────────
      // c2c_documents is the system of record; this store is the editing layer
      // over it. In THIS transaction on purpose: the filing and the working copy
      // move together or neither does, exactly like the lineage gate above.
      // Only when content changed, and only when the document is bound.
      if (content !== undefined) {
        governedCommit = await commitSectionToFiling({
          client,
          sectionId: String(sectionId),
          content: String(content ?? ''),
          actorId: String(updatedByUser),
          tenantId,
          reason: typeof req.body?.changeReason === 'string' ? req.body.changeReason : undefined,
          // Same signal createRevision's `origin` already uses two blocks up.
          // Only the machine-author id is ever written here — never a guessed
          // 'human' for the zero-contributor case, see commit-section-to-filing.ts.
          draftSource: contributors.length > 0 ? contributors[0].id : null,
        });
      }

      // Part 11 change record: operation, actor, before/after content, a SHA-256
      // of each side, reason, IP, user agent, session. Written on the same
      // transaction client so the audit row commits atomically with the edit it
      // records. In production createAuditTrail throws on failure, which rolls
      // the whole edit back rather than committing an un-audited change.
      if (recordRevision) {
        await createAuditTrail(
          req,
          result.rows[0]?.doc_id,
          sectionId,
          'UPDATE',
          currentSection.rows[0].content ?? null,
          content ?? null,
          changeReason,
          {
            titleChanged: title !== undefined,
            /* §11.10(a)/(e): a claim that AnA wrote some of this text is part
               of what changed, and until round 15 this row said nothing about
               one having been made. Credited claims name their turn record;
               refused ones carry the reason and, for a refused model, the
               models the record named. Absent when the save claimed nothing. */
            ...(claimDisclosure ? { machineText: claimDisclosure } : {}),
          },
          client,
        );
      } else {
        /* A METADATA CHANGE IS STILL A CHANGE TO A GOVERNED RECORD.
         *
         * The audit block above fired only on a content change, so a save that
         * renamed a section, re-coded it, or toggled its track-changes mode
         * updated the row and left NO audit trail at all. Renaming a CTD code
         * is not cosmetic — `commitSectionToFiling` matches a section to its
         * filing slot BY that code — and §11.10(e) wants every change to a
         * governed record recorded with who, when, and what moved.
         *
         * No revision (the revision ledger is for content, and none changed)
         * and no reason prompt (the action names itself, exactly like the
         * revert): the row records the field and its before/after, which is a
         * complete answer to "what changed". It rides the same transaction, so
         * a metadata change and its audit row commit together or neither does —
         * and because it goes through createAuditTrail on the caller's client,
         * it lands in the hash-chained ledger too, not only the soft table. */
        const cur = currentSection.rows[0] ?? {};
        const metaChanges: Array<{ field: string; from: unknown; to: unknown }> = [];
        if (title !== undefined && String(title) !== String(cur.title ?? '')) {
          metaChanges.push({ field: 'title', from: cur.title ?? null, to: title });
        }
        if (code !== undefined && String(code) !== String(cur.code ?? '')) {
          metaChanges.push({ field: 'code', from: cur.code ?? null, to: code });
        }
        if (
          track_changes !== undefined &&
          Boolean(track_changes) !== Boolean(cur.track_changes)
        ) {
          metaChanges.push({
            field: 'track_changes',
            from: Boolean(cur.track_changes),
            to: Boolean(track_changes),
          });
        }
        if (metaChanges.length) {
          const renamed = metaChanges.some((c) => c.field === 'title' || c.field === 'code');
          await createAuditTrail(
            req,
            result.rows[0]?.doc_id,
            sectionId,
            renamed ? 'RENAME' : 'TRACK_CHANGES',
            null,
            null,
            null,
            { source: 'section-metadata', changes: metaChanges },
            client,
          );
        }
      }

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      if (workflowGovernanceReply(err, res)) return;
      if (err instanceof UnverifiedMachineFormattingError) {
        return res.status(err.status).json({ success: false,
          error: { code: err.code, message: err.message }, field: 'content' });
      }
      logger.error('Section save refused — content and lineage rolled back together', {
        sectionId,
        tenantId,
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({
        success: false,
        error: {
          code: 'LINEAGE_REQUIRED',
          message:
            'The section was not saved: its data lineage could not be recorded. ' +
            'Saving content without provenance is not permitted.',
        },
      });
    } finally {
      client.release();
    }

    res.json({
      success: true,
      section: result.rows[0],
      message: 'Section updated successfully',
      revision_created: content !== undefined,
      // Whether the text reached the filing. Present on every content save:
      // an unbound save is legitimate, a silently unbound one is the drift.
      ...(governedCommit ? { filing: filingResponse(governedCommit) } : {}),
      /* And what became of each machine-authorship claim. The saver has to be
         told: without it they see an ordinary "Section saved" while the record
         now says they asserted words they believed were attributed to AnA. */
      ...(claimReport ? { machineText: claimReport } : {}),
    });
  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('Error updating section:', error);
    return serverError(res, logger, 'updating sections', error);
  }
});

// ============= History & Revisions =============

// GET /api/authoring/sections/:sectionId/history - Get revision history
router.get('/sections/:sectionId/history', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { limit = 50 } = req.query;
    const tenantId = getTenantId(req);

    const result = await pool.query(
      `SELECT
        r.id, r.section_id, r.content, r.created_by, r.created_at, r.tenant_id,
        r.content_sha256, r.chain_sha256, r.origin,
        u.name as created_by_name,
        u.email as created_by_email
       FROM doc_revisions r
       -- users.id is a serial (shared/schema.ts, migrations/0000_sweet_joseph.sql)
       -- and doc_revisions.created_by is TEXT holding String(req.user.id). The
       -- previous join was u.id = r.created_by::uuid — integer = uuid, which
       -- Postgres rejects at PARSE time (42883), so this endpoint returned 500
       -- on every call regardless of how many revisions existed, and the client
       -- rendered that failure as "No prior revisions".
       --
       -- The name comes from public.actor_name, not users: since users took
       -- row-level security (D3, 2026-09-28) a join on users found no one who
       -- had left the organization (docs/evidence/D3/2026-09-29-actor-names/).
       -- The cast is guarded so a non-numeric created_by cannot raise 22P02;
       -- it simply names nobody and the LEFT JOIN yields a null name.
       LEFT JOIN LATERAL public.actor_name(
         CASE WHEN r.created_by ~ '^[0-9]{1,9}$' THEN r.created_by::int END
       ) u ON TRUE
       WHERE r.section_id = $1 AND r.tenant_id = $2
       ORDER BY r.created_at DESC
       LIMIT $3`,
      [sectionId, tenantId, limit]
    );

    res.json({
      success: true,
      revisions: result.rows,
      count: result.rowCount,
    });
  } catch (error) {
    console.error('Error getting revision history:', error);
    return serverError(res, logger, 'loading history', error);
  }
});

// GET /api/authoring/sections/:sectionId/history/verify — recompute the
// revision ledger. Every verdict is recomputed from stored content; the hash
// columns are treated as claims to check, never as answers. An intact chain
// means: no revision's content was altered after it was written, no link was
// re-pointed, and nothing was appended unchained since the ledger was adopted.
// Rows predating the ledger are reported as pre-ledger, honestly, rather than
// backfilled into an integrity history nobody recorded at the time.
router.get('/sections/:sectionId/history/verify', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const tenantId = getTenantId(req);
    const { rows } = await pool.query(
      `SELECT id, content, created_by, origin, content_sha256, prev_chain_sha256, chain_sha256
         FROM doc_revisions
        WHERE section_id = $1 AND tenant_id = $2
        ORDER BY created_at ASC, id ASC`,
      [sectionId, tenantId]
    );
    const verdict = verifyLedger(rows);
    res.json({ success: true, revisionCount: rows.length, ...verdict });
  } catch (error) {
    console.error('Error verifying revision ledger:', error);
    res.status(500).json({ success: false, error: 'Failed to verify the revision ledger' });
  }
});

// POST /api/authoring/sections/:sectionId/revert - Revert to specific revision
router.post('/sections/:sectionId/revert', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { rev_id } = req.body;
    const tenantId = getTenantId(req);
    const revertedBy = getActorId(req);
    if (!revertedBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    if (!rev_id) {
      return res.status(400).json({
        success: false,
        error: 'rev_id is required',
      });
    }

    /* Get the revision — INCLUDING what it records about its own provenance
       (round 15, SEC-A-7 door 3). `origin` and `inputs.contributors` are on the
       append-only doc_revisions row, written by createRevision from the save
       door's MACHINE_AUTHOR_IDS-validated list. This SELECT used to name
       neither, so the one provenance fact the restored version carries about
       itself was discarded at the moment it was restored, and the filing then
       recorded NULL — "origin not stated" — over model prose. */
    const revResult = await pool.query(
      `SELECT id, section_id, content, created_by, created_at, tenant_id, origin, inputs
         FROM doc_revisions WHERE id = $1 AND section_id = $2 AND tenant_id = $3`,
      [rev_id, sectionId, tenantId]
    );

    if (((revResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({
        success: false,
        error: 'Revision not found',
      });
    }

    const revision = revResult.rows[0];
    const restored = restoredMachineAuthor(revision.inputs);

    const currentSection = await pool.query(
      'SELECT content FROM authoring_sections WHERE id = $1 AND tenant_id = $2',
      [sectionId, tenantId]
    );
    if (((currentSection.rowCount ?? 0) === 0)) {
      return res.status(404).json({ success: false, error: 'Section not found' });
    }

    /* Content, its lineage and its ledger entry commit together or not at all
       — the identical rule the interactive save and the AI accept follow.
       Revert was the one content writer left non-transactional AND outside
       the lineage gate, so a reverted section's provenance quietly went stale.
       The restorer IS asserting this content now: author lineage records
       exactly that, and the revision's `origin: 'revert'` records that it was
       a restoration rather than fresh authorship. The section-row lock the
       UPDATE takes also serializes the ledger chain extension. */
    const client = await pool.connect();
    let result: { rows: any[] };
    /* Whether the restored text reached the filing, and when it did not, why.
       Not `| null` like the save's: a revert ALWAYS commits (the save does so
       only when content changed), and the catch below rethrows, so reaching
       the response means both this and `result` were assigned. Stating that
       keeps the branch out of the response and the handler under the
       complexity ratchet. */
    let governedCommit: CommitSectionResult;
    try {
      await client.query('BEGIN');
      await reserveWritableSection(client, String(sectionId), tenantId);
      result = await client.query(
        `UPDATE authoring_sections
         SET content = $1, updated_at = NOW()
         WHERE id = $2 AND tenant_id = $3
         RETURNING *`,
        [revision.content, sectionId, tenantId]
      );
      await enforceAuthorLineage(
        client,
        tenantId,
        { documentTable: 'authoring_sections', documentId: String(sectionId) },
        revision.content ?? '',
        revertedBy,
      );
      // The revert is itself an authored state: this content, restored by this
      // actor, now. Written AFTER the update for the same reason as the edit
      // path, and it replaces a pre-update createRevision that stored the
      // content being replaced under the reverter's name — the same
      // misattribution the edit path had.
      /* With the restored contributors, so the attribution survives a revert
         OF this revert: without them it would be recorded once and lost on the
         next restoration, which is the same erasure one step later. */
      await createRevision(sectionId, revision.content, revertedBy, tenantId, client, 'revert', restored.contributors);

      /* AND THE FILING MOVES WITH IT.
       *
       * This call was missing, and its absence reopened on the revert path the
       * exact divergence `commitSectionToFiling` exists to close. Revert wrote
       * the restored text to `authoring_sections` — the working copy — and left
       * `c2c_document_sections`, which is what the filing IS, holding whatever
       * the last PATCH had put there.
       *
       * So an author who reverted a bad edit saw the good text in the editor,
       * the revision ledger recorded the restoration, the audit trail recorded
       * a REVERT, and the filed document still contained the bad text. Every
       * record agreed a revert had happened and the one artifact that matters
       * disagreed — and nothing surfaced the disagreement, because each store
       * was internally consistent.
       *
       * The reason is stated rather than defaulted, and that is not the
       * fabrication REASON_NOT_STATED guards against: on an ordinary save the
       * system does not know why a human changed the words, so it must not
       * invent one. Here it does know — this is a restoration of a named
       * revision, which is a complete and truthful answer to "why did this
       * change". A mechanism describing itself is not a person being
       * impersonated. */
      /* The verdict is KEPT and reported, as the save (:2392) and the
         AI-draft accept (:4328) report theirs. It was discarded here, so a
         revert whose filing commit was refused answered a plain success while
         the filing kept the pre-revert text — each store internally
         consistent, nothing saying otherwise, which is the shape of the
         defect this very block's header describes one layer up. Found by the
         exit-path verification of round 15. */
      governedCommit = await commitSectionToFiling({
        client,
        sectionId: String(sectionId),
        content: String(revision.content ?? ''),
        actorId: String(revertedBy),
        tenantId,
        reason: `Reverted to revision ${rev_id}`,
        /* The restored revision's own machine author, so reverting TO
           AI-drafted text does not erase 'ana' from the system of record. An
           absent one still resolves to NULL — never a guessed 'human', which
           is what 20260822_section_version_author_kind_unspecified.sql closed
           one layer up. */
        draftSource: restored.draftSource,
      });

      /* 2026-09-28 (GE-P-1, coverage-gap sweep): the audit record for this
         revert is written HERE, on the transaction client, so it commits with
         the revert or not at all — as the save and freeze paths do. It ran
         after COMMIT on the pool: a failed audit write left a committed,
         unaudited revert, reported as a failure in production and as a
         success, with no audit row, elsewhere. On the caller's client the
         writer also records the hash-chained entry. */
      await createAuditTrail(
        req,
        result.rows[0]?.doc_id,
        sectionId,
        'REVERT',
        currentSection.rows[0]?.content ?? null,
        revision.content ?? null,
        `Reverted to revision ${rev_id}`,
        { revisionId: rev_id, revisionCreatedAt: revision.created_at },
        client,
      );

      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK').catch(() => {});
      throw txErr;
    } finally {
      client.release();
    }

    res.json({
      success: true,
      section: result.rows[0],
      message: `Section reverted to revision ${rev_id}`,
      reverted_from: revision.created_at,
      filing: filingResponse(governedCommit),
    });
  } catch (error) {
    console.error('Error reverting section:', error);
    return authoringWriterFailure(error, res, 'saving revert');
  }
});

// ============= Comments & Review =============

/**
 * What a comment's trail row records beside its words (after_content): the
 * passage it quotes with that passage's own hash, and the hash of the section
 * content the quote was taken from — so a quote can be matched to the
 * revision it read.
 */
function commentRecordMetadata(
  commentId: string,
  sectionId: string,
  parentCommentId: unknown,
  anchor: unknown,
  sectionContent: unknown,
): Record<string, unknown> {
  const quote =
    anchor && typeof anchor === 'object' && typeof (anchor as { quote?: unknown }).quote === 'string'
      ? (anchor as { quote: string }).quote
      : null;
  return {
    comment_id: commentId,
    section_id: sectionId,
    parent_comment_id: parentCommentId ?? null,
    anchor: anchor ?? null,
    quote,
    quoteSha256: quote ? textSha256(quote) : null,
    sectionContentSha256: textSha256(String(sectionContent ?? '')),
  };
}

/**
 * The comment and its record, on the caller's transaction. The section must be
 * this tenant's; the document is the SECTION's, and a body doc_id that names
 * another is refused; a reply belongs to a thread on the same section. Returns
 * the refusal rather than answering (nothing has been written by then), so the
 * caller responds once, after the transaction ends.
 */
async function writeAttributedComment(
  client: Queryable,
  req: Request,
  c: {
    commentId: string;
    sectionId: string;
    tenantId: number;
    body: string;
    anchor: unknown;
    claimedDocId: unknown;
    parentCommentId: unknown;
    positionData: unknown;
    createdBy: string;
    userName: string;
    userEmail: string | null;
  },
): Promise<{ ok: true; comment: Record<string, unknown> } | { ok: false; status: number; error: string }> {
  const section = await client.query(
    'SELECT id, doc_id, content FROM authoring_sections WHERE id = $1 AND tenant_id = $2',
    [c.sectionId, c.tenantId]
  );
  if ((section.rowCount ?? 0) === 0) return { ok: false, status: 404, error: 'Section not found' };
  const docId = String(section.rows[0].doc_id);
  if (c.claimedDocId != null && String(c.claimedDocId).toLowerCase() !== docId.toLowerCase()) {
    return { ok: false, status: 400, error: 'doc_id is not the document this section belongs to. Nothing was saved.' };
  }
  if (c.parentCommentId) {
    const parent = await client.query(
      'SELECT 1 FROM authoring_comments WHERE id::text = $1 AND section_id = $2 AND tenant_id = $3',
      [String(c.parentCommentId), c.sectionId, c.tenantId]
    );
    if ((parent.rowCount ?? 0) === 0) {
      return { ok: false, status: 400, error: 'The comment being replied to is not on this section. Nothing was saved.' };
    }
  }
  const result = await client.query(
    `INSERT INTO authoring_comments
     (id, section_id, doc_id, body, anchor, status, created_by, user_name, user_email,
      parent_comment_id, position_data, created_at, tenant_id)
     VALUES ($1, $2, $3, $4, $5, 'open', $6, $7, $8, $9, $10, NOW(), $11)
     RETURNING *`,
    [c.commentId, c.sectionId, docId, c.body, c.anchor, c.createdBy, c.userName, c.userEmail,
      c.parentCommentId, c.positionData, c.tenantId]
  );
  await createAuditTrail(
    req,
    docId,
    c.sectionId,
    c.parentCommentId ? 'reply_added' : 'comment_added',
    null,
    c.body,
    null,
    commentRecordMetadata(c.commentId, c.sectionId, c.parentCommentId, c.anchor, section.rows[0].content),
    client
  );
  return { ok: true, comment: result.rows[0] };
}

// POST /api/authoring/sections/:sectionId/comment - Add comment
// THE comment-creation endpoint. There used to be two: this one, which the
// editor calls (DocumentAuthoring.tsx:471), and a `POST /comments` that wrote
// the same table with a fuller row — author name and email, threading parent,
// anchor position — and then INSERTed into a `authoring_comment_activity`
// table that no migration creates, so it 500'd after the comment had already
// been written. Nothing called it.
//
// The duplicate is gone and its capability moved here rather than being
// dropped with it: the read path GET /documents/:id/comments selects
// user_name, user_email, parent_comment_id and position_data, and renders
// `COALESCE(c.user_name, c.created_by) AS author_name` — so with only the thin
// write, every comment in the UI was attributed to a raw actor id and no reply
// could ever be threaded.
router.post('/sections/:sectionId/comment', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { body, anchor, doc_id, parent_comment_id, position_data } = req.body;
    const tenantId = getTenantId(req);
    const commentId = crypto.randomUUID();
    // Identity from the VERIFIED JWT only — never from a header or the body.
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const userEmail = req.user?.email ?? null;
    const userName = userEmail || createdBy;

    if (!body) {
      return res.status(400).json({
        success: false,
        error: 'Comment body is required',
      });
    }

    /* The comment and its record commit together, or neither does (D5,
       2026-09-26). This used to INSERT on the pool in autocommit and then
       write the audit row separately through the legacy wrapper — with no
       body, the reason "Legacy audit event" and the actor lost, so the
       inspector's ledger showed the comment as made by "System", and a failed
       audit write left a comment nobody had recorded. The comment belongs to
       the document its SECTION belongs to: a body doc_id that disagrees is
       refused rather than overridden, so a client bug surfaces, and a parent
       must be a comment on this same section (SEC-A-2, periodic review
       2026-09-28). */
    const written = await inTransaction((client) =>
      writeAttributedComment(client, req, {
        commentId,
        sectionId: String(sectionId),
        tenantId,
        body: String(body),
        anchor,
        claimedDocId: doc_id,
        parentCommentId: parent_comment_id ?? null,
        positionData: position_data ?? null,
        createdBy,
        userName,
        userEmail,
      })
    );
    if (!written.ok) return res.status(written.status).json({ success: false, error: written.error });
    const created = written.comment;

    res.status(201).json({
      success: true,
      comment: created,
      message: 'Comment added successfully',
    });
  } catch (error) {
    console.error('Error adding comment:', error);
    return serverError(res, logger, 'saving comment', error);
  }
});

/**
 * The record of a comment's status change, written with the REAL request: the
 * legacy wrapper this used rebuilt a request with no user id, so the chained
 * row had no actor and the ledger showed a person's resolution as "System".
 * The resolution note is the person's stated reason for closing the thread;
 * before and after content are the previous and new notes.
 */
async function recordCommentStatusChange(
  client: Queryable,
  req: Request,
  change: {
    commentId: string;
    status: unknown;
    before: { status: string; resolution_note: string | null };
    updated: { doc_id: string | null; section_id: string; status: string; resolution_note: string | null };
  },
): Promise<void> {
  const { commentId, status, before, updated } = change;
  const transition =
    status === 'resolved' ? 'resolved' : status === 'open' ? 'reopened' : status ? String(status) : 'note';
  await createAuditTrail(
    req,
    updated.doc_id ?? undefined,
    updated.section_id,
    status === 'resolved' ? 'comment_resolved' : 'comment_updated',
    before.resolution_note ?? null,
    updated.resolution_note ?? null,
    status === 'resolved' ? (updated.resolution_note ?? null) : null,
    {
      comment_id: commentId,
      section_id: updated.section_id,
      transition,
      previous_status: before.status,
      status: updated.status,
      previous_resolution_note: before.resolution_note ?? null,
      resolution_note: updated.resolution_note ?? null,
    },
    client
  );
}

/** The SET clauses and their values for a comment status change; empty when nothing changes. */
function commentStatusUpdate(
  status: unknown,
  resolutionNote: unknown,
  resolver: string,
): { updates: string[]; values: unknown[] } {
  const updates: string[] = [];
  const values: unknown[] = [];
  const param = (v: unknown) => `$${values.push(v)}`;
  if (status) {
    updates.push(`status = ${param(status)}`);
    if (status === 'resolved') {
      updates.push(`resolved_at = NOW(), resolved_by = ${param(resolver)}`);
      // The resolution RECORD is this resolution's, whole: a re-resolve
      // without a stated reason must not display the PREVIOUS resolver's
      // note under the new resolver's name. The prior resolution stays in
      // the audit ledger; the row carries only the current one.
      updates.push(`resolution_note = ${param(resolutionNote || null)}`);
    } else if (status === 'open') {
      // Reopen clears the resolution fields — the row reflects CURRENT
      // state ("this thread is open"), and the who/when/why of the earlier
      // resolution lives in the audit trail, not on an open thread.
      updates.push('resolved_at = NULL, resolved_by = NULL, resolution_note = NULL');
    }
  } else if (resolutionNote) {
    updates.push(`resolution_note = ${param(resolutionNote)}`);
  }
  return { updates, values };
}

// PATCH /api/authoring/comments/:commentId - Update comment status
router.patch('/comments/:commentId', async (req: Request, res: Response) => {
  try {
    const { commentId } = req.params;
    const { status, resolution_note } = req.body;
    const tenantId = getTenantId(req);
    const resolvedBy = getActorId(req);
    if (!resolvedBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    const validStatuses = ['open', 'resolved', 'dismissed', 'in_review'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }

    // The same principal convention comment CREATION records (user_name =
    // verified email, falling back to the actor id): the rail displays this
    // value, and "Resolved by 1" is an attribution no reader can use. Still
    // JWT-sourced either way — never a header, never the body.
    const { updates, values } = commentStatusUpdate(status, resolution_note, req.user?.email ?? resolvedBy);
    const paramCount = values.length;

    if (updates.length === 0) {
      // An empty body used to build `SET  WHERE id = $1` — malformed SQL
      // answered as a 500 with the driver's message in the payload.
      return res.status(400).json({ success: false, error: 'No comment changes supplied' });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const before = await client.query(
        `SELECT doc_id, section_id, status, resolution_note
           FROM authoring_comments
          WHERE id = $1 AND tenant_id = $2
          FOR UPDATE`,
        [commentId, tenantId]
      );
      if (((before.rowCount ?? 0) === 0)) {
        await client.query('ROLLBACK');
        return res.status(404).json({ success: false, error: 'Comment not found' });
      }

      values.push(commentId, tenantId);
      const result = await client.query(
        `UPDATE authoring_comments
            SET ${updates.join(', ')}, updated_at = NOW()
          WHERE id = $${paramCount + 1} AND tenant_id = $${paramCount + 2}
          RETURNING *`,
        values
      );

      const updated = result.rows[0];
      await recordCommentStatusChange(client, req, {
        commentId: String(commentId),
        status,
        before: before.rows[0],
        updated,
      });

      await client.query('COMMIT');
      res.json({
        success: true,
        comment: updated,
        message: 'Comment updated successfully',
      });
    } catch (error) {
      await client.query('ROLLBACK').catch(() => undefined);
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error updating comment:', error);
    return serverError(res, logger, 'updating comments', error);
  }
});

// ============= Citations & Data Tokens =============

/* ── Every citation write is on the document's trail, in its transaction ────
   A citation records what a section was drafted from, and its payload_sha256
   the source's checksum at the moment it was cited: the value the Sources rail
   compares against today. No citation write (cite, cite-source, the uncite
   DELETE, refresh-token, refresh-all) wrote an audit row, and the DELETE and
   the overwrites destroyed the cite-time value with no before-image anywhere
   (periodic review 2026-09-28, editor family, P11-A-1 / SEC-A-8). Each now
   writes its row on the same client as the change, carrying the citation as it
   stood before and after, so the prior value survives and an audit write that
   fails takes the change with it. The document is read from the section row,
   never from the URL or the body: the section the guard authorised is the one
   the trail names. */
type CitationAuditOperation = 'CITATION_ADDED' | 'CITATION_UPDATED' | 'CITATION_REMOVED' | 'CITATION_REFRESHED';

const citationJson = (image: CitationImage | null): string | null => (image ? JSON.stringify(image) : null);

async function auditCitationWrite(
  req: Request,
  client: Queryable,
  entry: { sectionId: string; operation: CitationAuditOperation; change: CitationChange; reason: string },
): Promise<void> {
  const section = await client.query(
    'SELECT doc_id FROM authoring_sections WHERE id = $1 AND tenant_id = $2',
    [entry.sectionId, getTenantId(req)]
  );
  const docId = section.rows[0]?.doc_id;
  // Unreachable behind the section guard. Refused rather than written with no
  // document, where no document's trail would ever show it.
  if (docId == null) throw new Error('Citation audit: the section is not in this organization');
  const { before, after } = entry.change;
  const cited = (after ?? before) as CitationImage;
  await createAuditTrail(
    req,
    String(docId),
    entry.sectionId,
    entry.operation,
    citationJson(before),
    citationJson(after),
    entry.reason,
    {
      citation_id: cited.id,
      source: cited.source,
      reference_id: cited.reference_id,
      previous_sha256: before ? before.payload_sha256 : null,
      sha256: after ? after.payload_sha256 : null,
    },
    client
  );
}

// POST /api/authoring/sections/:sectionId/cite - Add citation
router.post('/sections/:sectionId/cite', async (req: Request, res: Response) => {
  try {
    const sectionId = String(req.params.sectionId);
    const { source, anchor, citation_text, reference_id } = req.body;
    const tenantId = getTenantId(req);
    const citationId = crypto.randomUUID();
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    if (!source) {
      return res.status(400).json({
        success: false,
        error: 'Citation source is required',
      });
    }

    const citation = await inTransaction(async (client) => {
      if (source === 'cre_evidence_source') {
        const { citeSource } = await import('../services/clinical-regulatory-evidence/source-usage.service.js');
        const cited = await citeSource(tenantId, { sectionId, sourceId: reference_id, anchor, citationText: citation_text, createdBy }, client);
        if (cited.change) await auditCitationWrite(req, client, {
          sectionId, operation: cited.created ? 'CITATION_ADDED' : 'CITATION_UPDATED', change: cited.change,
          reason: cited.created ? 'Source cited' : 'Citation text changed',
        });
        const recorded = await client.query('SELECT * FROM authoring_citations WHERE id=$1 AND tenant_id=$2', [cited.citationId, tenantId]);
        return recorded.rows[0];
      }
      const result = await client.query(
        `INSERT INTO authoring_citations
         (id, section_id, source, anchor, citation_text, reference_id, created_by, created_at, tenant_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), $8)
         RETURNING *`,
        [citationId, sectionId, source, anchor, citation_text, reference_id, createdBy, tenantId]
      );
      await auditCitationWrite(req, client, {
        sectionId,
        operation: 'CITATION_ADDED',
        change: { before: null, after: result.rows[0] },
        reason: 'Citation recorded',
      });
      return result.rows[0];
    });

    res.status(201).json({
      success: true,
      citation,
      message: 'Citation added successfully',
    });
  } catch (error) {
    if (replyCitationAccessRefusal(res, error)) return;
    const { SourceUsageError } = await import('../services/clinical-regulatory-evidence/source-usage.service.js');
    if (error instanceof SourceUsageError) return res.status(400).json({ success: false, error: error.message });
    console.error('Error adding citation:', error);
    return serverError(res, logger, 'saving cite', error);
  }
});

/** One HTTP boundary for current source/project admission on citation reads and writes. */
function replyCitationAccessRefusal(res: Response, error: unknown): boolean {
  if (!(error instanceof SourceReadAccessError || error instanceof ProgramReadAccessError)) return false;
  res.status(error.status).json({ success: false, error: error.code, message: error.message });
  return true;
}

// ── Canonical source citations ─────────────────────────────────────────────
// The Data Room holds canonical source identities; these endpoints are how a
// section records which of them it was drafted from, and how that record is read
// back. They go through source-usage.service so the convention
// (source = 'cre_evidence_source', reference_id = the source id,
// payload_sha256 = the source's checksum at cite time) is enforced server-side
// rather than trusted from the request body — POST /cite above takes `source` as
// free text, which is why nothing could ever be read back by source id.

// GET /api/authoring/sections/:sectionId/sources — what this section is written from
router.get('/sections/:sectionId/sources', async (req: Request, res: Response) => {
  let client: PoolClient | undefined;
  try {
    const tenantId = getTenantId(req);
    const { listSectionSources } = await import(
      '../services/clinical-regulatory-evidence/source-usage.service.js'
    );
    client = await pool.connect();
    // Checked-out clients receive their RLS scope after BEGIN; checkout alone
    // does not stamp tenant variables. Keep the complete read on that client.
    await client.query('BEGIN READ ONLY');
    const usages = await listSectionSources(tenantId, String(req.params.sectionId), {
      executor: client, userId: Number(getActorId(req)),
    });
    await client.query('COMMIT');
    res.json({ success: true, sectionId: String(req.params.sectionId), sources: usages });
  } catch (error) {
    await client?.query('ROLLBACK').catch(() => undefined);
    if (replyCitationAccessRefusal(res, error)) return;
    console.error('GET /sections/:sectionId/sources', error);
    res.status(500).json({ success: false, error: 'Failed to load section sources' });
  } finally {
    client?.release();
  }
});

// POST /api/authoring/sections/:sectionId/cite-source — record a source citation
router.post('/sections/:sectionId/cite-source', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const createdBy = getActorId(req);
    if (!createdBy) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const { citeSource, SourceUsageError } = await import(
      '../services/clinical-regulatory-evidence/source-usage.service.js'
    );
    const sectionId = String(req.params.sectionId);
    try {
      const result = await inTransaction(async (client) => {
        const cited = await citeSource(
          tenantId,
          {
            sectionId,
            sourceId: req.body?.source_id,
            citationText: req.body?.citation_text ?? null,
            anchor: req.body?.anchor ?? null,
            createdBy,
          },
          client
        );
        // A second cite of the same source writes nothing unless it brings new
        // citation text; it never re-reads the checksum (see citeSource).
        if (cited.change) {
          await auditCitationWrite(req, client, {
            sectionId,
            operation: cited.created ? 'CITATION_ADDED' : 'CITATION_UPDATED',
            change: cited.change,
            reason: cited.created ? 'Source cited' : 'Citation text changed',
          });
        }
        return cited;
      });
      // 201 on a new citation, 200 when the section already cited it — the
      // caller can tell whether it added a source or found one already there.
      return res.status(result.created ? 201 : 200).json({
        success: true,
        citationId: result.citationId,
        citedChecksum: result.citedChecksum,
        created: result.created,
      });
    } catch (e) {
      if (e instanceof SourceUsageError) {
        return res.status(400).json({ success: false, error: e.message });
      }
      throw e;
    }
  } catch (error) {
    if (replyCitationAccessRefusal(res, error)) return;
    console.error('POST /sections/:sectionId/cite-source', error);
    res.status(500).json({ success: false, error: 'Failed to record the source citation' });
  }
});

// DELETE /api/authoring/sections/:sectionId/cite-source/:sourceId — stop citing it
router.delete('/sections/:sectionId/cite-source/:sourceId', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const { removeSourceCitation } = await import(
      '../services/clinical-regulatory-evidence/source-usage.service.js'
    );
    const sectionId = String(req.params.sectionId);
    const removed = await inTransaction(async (client) => {
      const rows = await removeSourceCitation(tenantId, sectionId, String(req.params.sourceId), client);
      // The deleted row is the before-image: the only record left of what the
      // section cited, and against which checksum.
      for (const row of rows) {
        await auditCitationWrite(req, client, {
          sectionId,
          operation: 'CITATION_REMOVED',
          change: { before: row, after: null },
          reason: 'Citation removed',
        });
      }
      return rows.length;
    });
    if (removed === 0) {
      return res.status(404).json({
        success: false,
        error: 'No removable citation of that source on this section (a frozen citation is immutable)',
      });
    }
    res.json({ success: true, removed: true });
  } catch (error) {
    console.error('DELETE /sections/:sectionId/cite-source/:sourceId', error);
    res.status(500).json({ success: false, error: 'Failed to remove the source citation' });
  }
});

// GET /api/authoring/sections/:sectionId/citations - Get all citations
router.get('/sections/:sectionId/citations', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const tenantId = getTenantId(req);

    const result = await pool.query(
      `SELECT id, section_id, source, anchor, citation_text, reference_id, created_by, created_at, tenant_id, payload_sha256, frozen_at FROM authoring_citations
       WHERE section_id = $1 AND tenant_id = $2
       ORDER BY created_at`,
      [sectionId, tenantId]
    );

    res.json({
      success: true,
      citations: result.rows,
      count: result.rowCount,
    });
  } catch (error) {
    console.error('Error getting citations:', error);
    return serverError(res, logger, 'loading citations', error);
  }
});

// ============= Comments and Reviews =============

// GET /api/authoring/documents/:id/comments - Get all comments for document
router.get('/documents/:id/comments', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const tenantId = getTenantId(req);
    const { status, author, includeReplies = 'true' } = req.query;

    let query = `
      SELECT
        c.id, c.doc_id, c.section_id, c.body, c.anchor, c.status, c.created_by, c.user_name, c.user_email, c.parent_comment_id, c.position_data, c.resolution_note, c.resolved_by, c.resolved_at, c.created_at, c.updated_at, c.tenant_id,
        COALESCE(c.user_name, c.created_by) as author_name,
        c.user_email as author_email,
        COUNT(DISTINCT r.id) as reply_count,
        s.code as section_code,
        s.title as section_title
      FROM authoring_comments c
      LEFT JOIN authoring_sections s ON c.section_id = s.id
      LEFT JOIN authoring_comments r ON r.parent_comment_id = c.id
      WHERE c.doc_id = $1 AND c.tenant_id = $2
    `;

    const params: any[] = [id, tenantId];
    let paramIndex = 3;

    if (status) {
      query += ` AND c.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (author) {
      query += ` AND c.created_by = $${paramIndex}`;
      params.push(author);
      paramIndex++;
    }

    // Only get top-level comments by default
    if (includeReplies === 'false') {
      query += ` AND c.parent_comment_id IS NULL`;
    }

    query += ` GROUP BY c.id, s.code, s.title ORDER BY c.created_at DESC`;

    const result = await pool.query(query, params);

    // If includeReplies is true, fetch replies for each comment
    let comments = result.rows;
    if (includeReplies === 'true') {
      for (const comment of comments) {
        if (!comment.parent_comment_id) {
          const repliesResult = await pool.query(
            `SELECT
              c.id, c.doc_id, c.section_id, c.body, c.anchor, c.status, c.created_by, c.user_name, c.user_email, c.parent_comment_id, c.position_data, c.resolution_note, c.resolved_by, c.resolved_at, c.created_at, c.updated_at, c.tenant_id,
              COALESCE(c.user_name, c.created_by) as author_name,
              c.user_email as author_email
             FROM authoring_comments c
             WHERE c.parent_comment_id = $1 AND c.tenant_id = $2
             ORDER BY c.created_at ASC`,
            [comment.id, tenantId]
          );
          comment.replies = repliesResult.rows;
        }
      }
      // Filter out replies from top level
      comments = comments.filter(c => !c.parent_comment_id);
    }

    res.json({
      success: true,
      comments,
      total: comments.length,
    });
  } catch (error) {
    console.error('Error fetching comments:', error);
    return serverError(res, logger, 'loading comments', error);
  }
});

/* PUT /comments/:id and DELETE /comments/:id are DELETED, not moved. Neither
 * was reachable from the client (the rail's only status writer is
 * PATCH /comments/:id), and both let any authenticated tenant member rewrite
 * or hard-delete ANY user's review comment: the PUT updated `body` in place
 * with no prior-text capture anywhere (the audit event logged that an edit
 * happened, never what changed), and the DELETE removed the row and its
 * replies for good with only the comment id in the ledger — the reviewer's
 * actual words unrecoverable even from the audit trail. Review history is
 * immutable here: threads are resolved or reopened through PATCH (verified
 * resolver, resolved_at, note kept), never rewritten, never erased. If
 * retraction is ever wanted, it is a tombstone that retains and renders the
 * original content as retracted — a new capability, not these routes. */

/** The native review service receives only the verified actor and pinned tenant client. */
function peerReviewInput(req: Request) {
  const actorId = getActorId(req);
  if (!actorId) throw new AuthoringPeerReviewRefused(401, 'REVIEW_ACTOR_REQUIRED', 'Authentication required.');
  const documentId = req.params.id;
  if (typeof documentId !== 'string' || !isUuid(documentId)) {
    throw new AuthoringPeerReviewRefused(400, 'REVIEW_DOCUMENT_INVALID', 'A valid document identifier is required.');
  }
  return { tenantId: getTenantId(req), actorId, documentId: documentId.toLowerCase() };
}

function peerReviewAudit(req: Request) {
  return { ipAddress: req.ip || req.connection?.remoteAddress || 'unknown',
    userAgent: req.headers['user-agent'] || 'unknown' };
}

function peerReviewFailure(res: Response, error: unknown): Response {
  if (error instanceof AuthoringPeerReviewCommitUnconfirmed) return res.status(503).json({ success: false,
    error: { code: 'REVIEW_COMMIT_UNCONFIRMED', message: 'The review write could not be confirmed. Reload the document and review request before trying again.' } });
  if (!(error instanceof AuthoringPeerReviewRefused) || error.status === 503) {
    logger.error('Authoring peer review could not be verified', { error });
    return res.status(503).json({ success: false,
      error: { code: 'REVIEW_UNAVAILABLE', message: 'The review could not be verified. Reload before trying again.' } });
  }
  if (error.status === 409 && error.code === 'REVIEWER_IS_AUTHOR') return res.status(409).json(REVIEWER_IS_AUTHOR_REFUSAL);
  return res.status(error.status).json({ success: false, error: { code: error.code, message: error.message } });
}

function validPeerReviewers(reviewers: unknown): reviewers is Array<{ id: string | number; name?: string; email?: string }> {
  if (!Array.isArray(reviewers) || !reviewers.length) return false;
  const ids = new Set<string>();
  return reviewers.every(r => {
    if (!r || !(typeof r.id === 'string' && r.id.trim() || Number.isSafeInteger(r.id) && r.id > 0)) return false;
    if (r.name !== undefined && typeof r.name !== 'string' || r.email !== undefined && typeof r.email !== 'string') return false;
    const id = String(r.id).trim();
    if (ids.has(id)) return false;
    ids.add(id); return true;
  });
}

// GET /api/authoring/documents/:id/reviews - Read the complete saved review context.
router.get('/documents/:id/reviews', async (req: Request, res: Response) => {
  try { return res.json(await readAuthoringPeerReviews(requestConnectable(req), peerReviewInput(req))); }
  catch (error) { return peerReviewFailure(res, error); }
});

type ReviewTaskLedgerRow = import('../services/tasking/task-audit').AuditTaskActionParams;
type ReviewTaskNotice = import('../services/tasking/task-side-effects').TaskEventNotice;

/** What a verdict did to its reviewer's review tasks on the document. */
interface VerdictTaskClosure {
  /** Completed by the verdict, in task-id order. */
  completed: string[];
  /** Left open, and why: completing it needs the reviewer's signature, or its predecessors are not done. */
  leftOpen: Array<{ taskId: string; why: 'signature-required' | 'blocked' }>;
  /** Sent once the verdict has committed. */
  notices: ReviewTaskNotice[];
  /** Writes the tasks' ledger rows; called after the verdict's own audit row. */
  record: () => Promise<void>;
}

/**
 * A reviewer's verdict completes their open review tasks on the same document,
 * on the verdict's own transaction (wave 2D; outside-file request E of wave 2C,
 * docs/evidence/D2-ONE-ANA/2026-10-08/ana-2d-review-loop-closes/).
 *
 * The verdict lives in authoring_reviews. The reviewer's My work task lives in
 * unified_tasks: SendForReviewDialog.tsx creates it with sourceEntityType
 * 'authoring_document', sourceEntityId <docId>, taskType 'review' and the
 * reviewer as assignee. Nothing joined the two, so a verdict left its task open
 * and the Tasks rail could only reconcile them on screen. The task now moves
 * through the tasking path's own audited transition, composed as
 * PATCH /api/regulatory/tasks/:id/status composes it: the state machine
 * (isLegalTransition), the canonical status write
 * (unifiedTaskService.updateTaskStatus, a compare-and-set), the completion
 * cascade (cascadeUnblockOnCompletionInTx) and one `task.transition` lineage
 * row per move (auditTaskActionInTx). Nothing here writes a task column itself.
 * The verdict, the task and their ledger rows commit together, or none of them
 * does.
 *
 * Two phases, for lock order. Every task row lock (the task, then its
 * dependents) is taken here, before the verdict's own audit row takes the
 * audit-chain lock: the one order every task transaction uses
 * (taskManagement.routes.ts). The ledger rows are written by `record`, after
 * the verdict's row, so the trail shows the verdict before the task it closed.
 *
 * What it does not do:
 *   - an approval-gated task that is not yet approved is left open. Completing
 *     it is the reviewer's §11.50 signature, and a verdict is not one. The
 *     Tasks rail offers Complete once the verdict exists, and the server takes
 *     the signature there.
 *   - a blocked task is left open: its predecessors are not complete.
 *   - a pending task is started, then completed. The state machine has no
 *     pending → completed move, and each step gets its own ledger row.
 *   - a reviewer id that is not a users.id integer has no task (assignee_id is
 *     an integer column), so nothing is looked up.
 */
async function closeReviewTasksOnVerdict(
  client: Queryable,
  v: { tenantId: number; docId: string; reviewerId: string; verdict: string; reviewId: string; reason: string | null },
): Promise<VerdictTaskClosure> {
  const closure: VerdictTaskClosure = { completed: [], leftOpen: [], notices: [], record: async () => undefined };
  const actor = /^[1-9][0-9]*$/.test(v.reviewerId) ? Number(v.reviewerId) : NaN;
  if (!Number.isSafeInteger(actor)) return closure;

  const [{ drizzle }, schema, orm, { default: unifiedTaskService }, { isLegalTransition }, sideEffects, { auditTaskActionInTx }] =
    await Promise.all([
      import('drizzle-orm/node-postgres'),
      import('../../shared/schema'),
      import('drizzle-orm'),
      import('../services/unifiedTaskService'),
      import('../services/tasking/task-state-machine'),
      import('../services/tasking/task-side-effects'),
      import('../services/tasking/task-audit'),
    ]);
  const { unifiedTasks } = schema;
  // Drizzle over this transaction's own client: every read, write and ledger
  // row below runs on the verdict's connection.
  const tx = drizzle(client as never, { schema });
  const open = await tx
    .select({
      taskId: unifiedTasks.taskId,
      status: unifiedTasks.status,
      title: unifiedTasks.title,
      createdById: unifiedTasks.createdById,
      approvalRequired: unifiedTasks.approvalRequired,
      approvalStatus: unifiedTasks.approvalStatus,
    })
    .from(unifiedTasks)
    .where(orm.and(
      orm.eq(unifiedTasks.organizationId, v.tenantId),
      orm.eq(unifiedTasks.sourceEntityType, 'authoring_document'),
      orm.eq(unifiedTasks.sourceEntityId, v.docId),
      orm.eq(unifiedTasks.taskType, 'review'),
      orm.eq(unifiedTasks.assigneeId, actor),
      orm.isNull(unifiedTasks.deletedAt),
      orm.inArray(unifiedTasks.status, ['pending', 'in-progress', 'review', 'blocked']),
    ))
    .orderBy(unifiedTasks.taskId)
    .for('no key update');

  const ledger: ReviewTaskLedgerRow[] = [];
  const cause = { cause: 'review-verdict', verdict: v.verdict, reviewId: v.reviewId, docId: v.docId };
  for (const t of open) {
    if (t.approvalRequired === true && t.approvalStatus !== 'approved') {
      closure.leftOpen.push({ taskId: t.taskId, why: 'signature-required' });
      continue;
    }
    const steps = isLegalTransition(t.status, 'completed') ? ['completed'] : t.status === 'pending' ? ['in-progress', 'completed'] : null;
    if (!steps) {
      closure.leftOpen.push({ taskId: t.taskId, why: 'blocked' });
      continue;
    }
    let from = t.status;
    for (const to of steps) {
      const moved = await unifiedTaskService.updateTaskStatus(t.taskId, to, actor, { organizationId: v.tenantId, expectedStatus: from }, tx);
      // The row is locked above, so a lost compare-and-set is a defect, not a
      // race: it rolls the verdict back with it.
      if (!moved) throw new Error(`Review task ${t.taskId} did not move from ${from} to ${to} under its lock.`);
      ledger.push({
        orgId: v.tenantId,
        userId: actor,
        command: 'task.transition',
        taskId: t.taskId,
        payload: { from, to, ...cause },
        // The reason the reviewer stated with the verdict (none for an approval
        // given without one), never a sentence composed here.
        reason: v.reason,
        summary: to === 'completed' ? 'Completed by the reviewer’s verdict on the document' : 'Started by the reviewer’s verdict on the document',
      });
      from = to;
    }
    const cascade = await sideEffects.cascadeUnblockOnCompletionInTx(v.tenantId, t.taskId, { tx, actorUserId: actor });
    ledger.push(...cascade.ledger);
    closure.notices.push(...cascade.notices);
    if (t.createdById && t.createdById !== actor) {
      closure.notices.push({ organizationId: v.tenantId, recipientUserId: t.createdById, category: 'task_completed', title: `Completed: ${t.title}`, taskId: t.taskId });
    }
    closure.completed.push(t.taskId);
  }
  closure.record = async () => {
    for (const entry of ledger) await auditTaskActionInTx(tx, entry);
  };
  return closure;
}

// POST /api/authoring/documents/:id/review - Record an assigned, saved-content-bound verdict.
router.post('/documents/:id/review', async (req: Request, res: Response) => {
  try {
    const body = authoringReviewInputSchema.safeParse(req.body);
    if (!body.success) return res.status(400).json({ success: false,
      error: { code: 'REVIEW_INPUT_INVALID', message: 'A verdict and the exact saved review context are required.' } });
    const saved = await submitAuthoringPeerReview(requestConnectable(req), { ...peerReviewInput(req), body: body.data },
      { audit: peerReviewAudit(req), closeTasks: closeReviewTasksOnVerdict });
    if (saved.tasks.notices.length) {
      const { notifyTaskEvent } = await import('../services/tasking/task-side-effects');
      for (const notice of saved.tasks.notices) notifyTaskEvent(notice);
    }
    return res.json({ success: true, review: saved.review,
      tasks: { completed: saved.tasks.completed, leftOpen: saved.tasks.leftOpen }, auditTrail: saved.auditTrail });
  } catch (error) { return peerReviewFailure(res, error); }
});

// POST /api/authoring/documents/:id/request-review - Request review from users
/** The pool the permission helpers take; a transaction client answers the same queries. */
/** Whether each requested reviewer was granted review access, and why not. */
type ReviewGrantOutcome =
  | { reviewerId: string; granted: true; permissionId: string }
  | { reviewerId: string; granted: false; reason: string };

/**
 * The reviewer named in a review request gets what reviewing needs: the
 * REVIEWER role on the document (view, comment, review — and, with a signing
 * role in the organization, the review e-signature). QA 2026-10-08 (j4): a
 * request granted nothing and the grant API had no caller, so the person asked
 * to review could do neither. Granted only by someone who may manage the
 * document's access — its owner or an administrator, the rule
 * POST /docs/:docId/permissions applies — on the caller's transaction, with a
 * chained ledger row per grant. Anyone else's request is recorded and the
 * answer says no grant was made.
 */
async function grantRequestedReviewers(args: {
  client: Queryable;
  req: Request;
  docId: string;
  tenantId: number;
  scope: Awaited<ReturnType<typeof resolveAuthoringDocumentScope>>;
  principal: ReturnType<typeof authoringPrincipalFromRequest>;
  reviews: Array<{ id: string; reviewer_id: string | number; reviewer_email?: string | null }>;
  reason: string | null;
}): Promise<ReviewGrantOutcome[]> {
  const { client, req, docId, tenantId, scope, principal, reviews, reason } = args;
  const manage = scope && principal
    ? await decideAuthoringPermission({ pool: client, principal, scope, action: 'manage_permissions' })
    : null;
  if (!manage?.allowed || !principal) {
    return reviews.map((r) => ({
      reviewerId: String(r.reviewer_id),
      granted: false as const,
      reason:
        'No review access was granted: only the document’s owner or an administrator grants access to it. ' +
        'Ask one of them to grant this reviewer the Reviewer role.',
    }));
  }
  const grants: ReviewGrantOutcome[] = [];
  for (const review of reviews) {
    const reviewerId = String(review.reviewer_id);
    const permission = await grantAuthoringPermission({
      pool: client,
      tenantId,
      docId,
      principalId: reviewerId,
      email: review.reviewer_email ?? null,
      role: 'REVIEWER',
      grantedBy: principal.id,
      reason: `Review requested${reason ? `: ${reason}` : ''}`,
    });
    await writeChainedAuditRow(client, {
      tenantId,
      userId: getActorId(req) ?? undefined,
      action: 'authoring.permission.grant',
      resourceType: 'authoring_document_permission',
      resourceId: String(permission.id),
      ipAddress: (req.ip ?? undefined) as string | undefined,
      userAgent: req.headers['user-agent'] as string | undefined,
      details: { docId, principalId: reviewerId, role: 'REVIEWER', via: 'request-review', reviewId: review.id },
    });
    grants.push({ reviewerId, granted: true, permissionId: String(permission.id) });
  }
  return grants;
}

/** The refusal for a review request that names the document's author. */
const REVIEWER_IS_AUTHOR_REFUSAL = {
  success: false,
  error: {
    code: 'REVIEWER_IS_AUTHOR',
    message: 'The author of a document cannot review it. Choose someone else as the reviewer. Nothing was requested.',
  },
  field: 'reviewers',
} as const;

router.post('/documents/:id/request-review', async (req: Request, res: Response) => {
  try {
    const { reviewers } = req.body;
    if (!validPeerReviewers(reviewers)) return res.status(400).json({ success: false,
      error: 'reviewers must be a non-empty array of distinct reviewer identities with valid optional name and email fields' });
    const stated = optionalGovernedReason(req.body?.reason);
    if (!stated.ok) return res.status(400).json({ success: false, error: stated.error, field: 'reason' });
    const input = peerReviewInput(req);
    const saved = await requestAuthoringPeerReviews(requestConnectable(req), { ...input, reviewers, reason: stated.reason }, {
      audit: peerReviewAudit(req),
      grant: (client, current) => grantRequestedReviewers({ client, req, docId: input.documentId,
        tenantId: input.tenantId, scope: current.scope, principal: current.actor.principal,
        reviews: current.reviews.map(review => ({ id: review.id, reviewer_id: review.reviewer_id,
          reviewer_email: typeof review.reviewer_email === 'string' ? review.reviewer_email : null })), reason: current.reason }),
    });
    return res.json({ success: true, ...saved, message: `Review requested from ${reviewers.length} reviewer(s)` });
  } catch (error) { return peerReviewFailure(res, error); }
});

// ============= AI Integration =============

async function readDraftAssemblySources(q: Queryable, identity: { organizationId: number; userId: number; programId: unknown },
  raw: unknown, options: { lock?: boolean; invalidStatus?: 400 | 409 } = {}) {
  const { readSelectedAuthoringSources, AssemblySourceError } = await import('../services/authoring/authoring-assembly-sources');
  const manifest = readAssemblySourceManifest(raw);
  if (!manifest) throw new AssemblySourceError(options.invalidStatus ?? 400, 'ASSEMBLY_SOURCES_INVALID', 'The selected source receipt is invalid. Select the sources again before drafting.');
  if (typeof identity.programId !== 'string' || manifest.programId.toLowerCase() !== identity.programId.toLowerCase()) {
    throw new AssemblySourceError(409, 'ASSEMBLY_SOURCES_CHANGED', 'The selected sources do not belong to this document project. Select the sources again.');
  }
  return readSelectedAuthoringSources(q, { ...identity, programId: identity.programId },
    manifest.entries.map(entry => entry.source), { expectedManifest: manifest, lock: options.lock });
}

async function reserveDraftAssemblySources(q: Queryable, identity: { organizationId: number; userId: number; sectionId: string }, raw: unknown) {
  const parent = await q.query(`SELECT to_jsonb(d)->>'client_program_id' AS program_id
    FROM authoring_sections s JOIN authoring_documents d ON d.id=s.doc_id AND d.tenant_id=s.tenant_id
    WHERE s.id=$1 AND s.tenant_id=$2`, [identity.sectionId, identity.organizationId]);
  return readDraftAssemblySources(q, { organizationId: identity.organizationId, userId: identity.userId,
    programId: parent.rows[0]?.program_id }, raw, { lock: true, invalidStatus: 409 });
}

function assemblySourceErrorDetails(error: unknown) {
  const failure = error as { status?: number; code?: string; message?: string } | null;
  if (!failure || typeof failure.code !== 'string' || !failure.code.startsWith('ASSEMBLY_SOURCES_') ||
      ![400, 403, 404, 409, 503].includes(failure.status ?? 0)) return null;
  return { status: failure.status!, code: failure.code, message: failure.message };
}

function draftAcceptUnconfirmed(res: Response) {
  return res.status(503).json({ success: false, error: { code: 'DRAFT_ACCEPT_UNCONFIRMED',
    message: 'The server could not confirm whether this draft was accepted. Check the exact saved section before another acceptance.' } });
}

// POST /api/authoring/sections/:sectionId/ai/draft - Generate AI draft
router.post('/sections/:sectionId/ai/draft', async (req: Request, res: Response) => {
  /* The turn this draft is (RT-6, AnA reasoning round 12): one record, opened
     before the model is asked and filed however the request ends, as the
     conversation's turns are (services/ana/turn-record.ts). */
  let draftTurn: DraftTurn | null = null;
  try {
    const { sectionId } = req.params;
    const { tone = 'professional', region = 'FDA', context, requirements } = req.body;
    const tenantId = getTenantId(req);

    // Get section details
    const sectionResult = await pool.query(
      `SELECT s.id, s.doc_id, s.code, s.title, s.content, s.order_index, s.track_changes, s.created_at, s.updated_at,
              s.updated_at::text AS base_updated_at, s.tenant_id, d.module, d.product_code,
              to_jsonb(d)->>'client_program_id' AS client_program_id
       FROM authoring_sections s
       JOIN authoring_documents d ON d.id = s.doc_id AND d.tenant_id = s.tenant_id
       WHERE s.id = $1 AND s.tenant_id = $2`,
      [sectionId, tenantId]
    );

    if (((sectionResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({
        success: false,
        error: 'Section not found',
      });
    }

    const section = sectionResult.rows[0];
    // Project evidence belongs to the document's saved project, never a caller
    // field or the rest of the organization's projects. Admission re-reads the
    // actor's membership and sharing policy for this generation request.
    const projectScope = section.client_program_id == null ? null : await admitAnaProjectScope(pool, {
      organizationId: tenantId,
      userId: Number(getActorId(req)),
      projectRef: section.client_program_id,
    });
    const sourceIdentity = { organizationId: tenantId, userId: Number(getActorId(req)), programId: section.client_program_id };
    const selectedSources = Object.hasOwn(req.body ?? {}, 'sources')
      ? await readDraftAssemblySources(requestConnectable(req), sourceIdentity, req.body.sources) : null;
    const assemblySources = selectedSources?.manifest;

    // ── Retrieve this document's program Vault evidence ──────────────
    let evidenceBlock = '';
    let sourcesRetrieved = 0;
    /** Whether Data Room retrieval ran, and what it found. 'empty' (ran, found
     *  nothing) and 'failed' (did not run to completion) are different facts
     *  and only one of them says anything about the corpus. */
    let retrievalStatus: 'ok' | 'empty' | 'failed' = 'empty';
    let retrievalError: string | null = null;
    // The chunks this draft is retrieved from, captured so the accept endpoint can
    // record verified source spans against them (source-attribution Phase 3). Each
    // carries the canonical capture key when the exact Vault bytes resolve to
    // a cre_evidence_sources.id; that key is verified again below — at the
    // generation boundary, which holds the numeric orgId the resolver needs. Read
    // defensively (best-effort): a build without the retrieval enrichment simply
    // leaves sourceId null and the draft is still attributed honestly (all author).
    const retrievedChunks: Array<{ content: string; title: string; sourceId: string | null }> = [];
    let vaultSourceReceipt: import('../services/authoring/authoring-draft-sources.js').SectionDraftSourceReceipt | undefined;
    try {
      if (!projectScope?.projectId) throw new Error('This document has no verified project scope. No Data Room sources were read.');
      const searchQuery = `${section.module} ${section.code} ${section.title} ${
        section.product_code || ''
      }`.trim();
      // The session's tenant key. This search used to pass none, so it ranked
      // every tenant's Data Room atoms wherever RLS was not filtering — a CTD
      // section draft could cite another sponsor's evidence. No key is a failed
      // retrieval, reported as one below, never an unscoped search.
      const orgUuid = selectedSources ? null : await currentTenantOrgUuid(pool);
      if (!selectedSources && !orgUuid) throw new TenantKeyRequiredError('no tenant key for this session');
      // F03: the document's saved program determines the canonical Vault
      // corpus. There is no organization-wide atom fallback for absent scope.
      const retrieved = selectedSources ?? await (await import('../services/authoring/authoring-draft-sources.js')).retrieveSectionDraftSources({
        executor: requestConnectable(req), userId: Number(getActorId(req)), organizationId: tenantId,
        organizationUuid: orgUuid, programId: section.client_program_id, query: searchQuery });
      const searchResults = retrieved.chunks;
      if ('receipt' in retrieved) vaultSourceReceipt = retrieved.receipt;
      if (searchResults.length > 0) {
        sourcesRetrieved = searchResults.length;
        for (const r of searchResults as any[]) {
          retrievedChunks.push({
            content: typeof r.content === 'string' ? r.content : '',
            title: typeof r.title === 'string' ? r.title : '',
            sourceId: typeof r.sourceId === 'string' ? r.sourceId : null,
          });
        }
        evidenceBlock =
          '\n\n--- PROJECT DATA ROOM EVIDENCE (cite as [SRC-n]; not organization reference material) ---\n' +
          searchResults
            .map((r: any, i: number) => {
              const content = assemblySources ? r.content :
                r.content.length > 600 ? r.content.substring(0, 600) + '…' : r.content;
              return `[SRC-${i + 1}] "${r.title}"\n${content}`;
            })
            .join('\n\n') +
          '\n--- END EVIDENCE ---\n\n' +
          'Record which sources you used ONLY through the structured "attributions" ' +
          'field requested below — do NOT put [SRC-n] markers in the drafted prose, ' +
          'and never cite a source not shown above.';
        retrievalStatus = 'ok';
      } else {
        // Retrieval RAN and the corpus had nothing above threshold. Distinct
        // from a failure: here we know there is no evidence, which is itself a
        // fact about the Data Room.
        retrievalStatus = 'empty';
      }
    } catch (e: any) {
      if (selectedSources) throw e;
      /* A failed retrieval used to warn to the console and continue, leaving
         `sourcesRetrieved = 0` — indistinguishable from "the corpus had
         nothing". The model then drafted with no evidence block and the
         response said "AI draft generated successfully". So the one case where
         a reviewer most needs to know the draft is ungrounded looked exactly
         like the ordinary case. Recorded and reported instead. */
      retrievalStatus = 'failed';
      retrievalError = e?.message ? String(e.message).slice(0, 300) : 'unknown error';
      console.warn('[Authoring] Data Room retrieval failed (non-fatal):', retrievalError);
    }

    // ── Generate with the AI gateway. There is no other source of a draft. ──
    //
    // This route used to fall through to a hardcoded section skeleton when no
    // provider was enabled or the model call failed, answering HTTP 200
    // `success:false, degraded:true, source:'template'` with a full template
    // body — and the client rendered it as a draft (VSR-001 §8 F-10). A
    // deployment with no enabled provider is refused with 503
    // GATEWAY_UNAVAILABLE, the same code AnA answers with, and NO draft body;
    // a gateway failure is refused with its own classified code; a fault of
    // ours is a 500. Nothing on this path fabricates content (URS-AUTH-012;
    // working agreement: fail closed, never fabricate).
    const { getGateway } = await import('../services/ai-gateway/gateway.js');
    const { GATEWAY_ERROR_HTTP_STATUS, classifyGatewayError, isGatewayError } = await import(
      '../services/ai-gateway/gateway-error-map.js'
    );
    const gw = getGateway();
    if (gw.getEnabledProviders().length === 0) {
      logger.warn('ai/draft refused: no AI provider is enabled on the gateway', { sectionId });
      return res.status(503).json({
        success: false,
        error: {
          code: 'GATEWAY_UNAVAILABLE',
          message:
            'No AI provider is configured for this deployment, so this section cannot be drafted. Nothing was changed.',
        },
      });
    }

    const prompt = `Generate professional ${region} regulatory content for:
Module: ${section.module}
Section: ${section.code} - ${section.title}
Product: ${section.product_code || 'Medical Product'}
Tone: ${tone}
${context ? `Context: ${context}` : ''}
${requirements ? `Requirements: ${requirements}` : ''}
${evidenceBlock}

Return ONLY a JSON object of this exact shape:
{"content": "<the drafted section as clean prose>", "attributions": [{"quote": "<a sentence copied verbatim from content>", "src": <the SRC number>}]}
- "content" is the full section a reviewer reads — do NOT put [SRC-n] markers in it.
- Add one "attributions" entry for each sentence you DERIVED from a provided [SRC-n] source: "quote" copied EXACTLY from "content", "src" the integer n.
- Omit sentences that are your own analysis or not based on a provided source. Never cite a src not shown above.
Provide detailed, compliance-ready content following ${region} guidelines.`;

    draftTurn = openDraftTurn(pool, {
      orgId: tenantId,
      userId: getActorId(req),
      sectionId: String(sectionId),
      request: { tone, region, context: context ?? null, requirements: requirements ?? null,
        ...(assemblySources ? { sources: assemblySources } : {}) },
      prompt,
      audit: { ipAddress: req.ip, userAgent: req.get('user-agent') ?? undefined },
    });
    let gwResponse: Awaited<ReturnType<typeof gw.route>>;
    try {
      gwResponse = await gw.route({
        taskType: 'document_drafting',
        messages: [{ role: 'user', content: prompt }],
        maxTokens: 3000,
        temperature: 0.3,
        // Structured envelope so the model can report which sentences it derived
        // from which source (source-attribution Phase 4). On the default
        // Anthropic provider jsonMode is prompt-instructed; the parse below is
        // tolerant and degrades to plain prose so a malformed response can never
        // break drafting.
        jsonMode: true,
        callerModule: 'authoring-router/generate-draft',
      });
    } catch (aiError) {
      /* A gateway refusal (rate limit, overload, too large, no provider that
         could serve it) answers with its classified code and status; a fault of
         ours is a 500. Neither ever answers with content. */
      if (isGatewayError(aiError)) {
        const { code, message } = classifyGatewayError(aiError);
        logger.warn('ai/draft refused: the AI gateway declined the request', { code, sectionId });
        await fileFailedDraftTurn(draftTurn, `The AI gateway refused this draft (${code}).`);
        return res
          .status(GATEWAY_ERROR_HTTP_STATUS[code])
          .json({ success: false, error: { code, message } });
      }
      await fileFailedDraftTurn(draftTurn, 'The model call failed on the server.');
      return serverError(res, logger, 'drafting AI', aiError);
    }

    // Retain the served response for the failed turn, but never expose or park
    // known cutoff prose, even when its structured envelope looks usable.
    draftTurn?.served(gwResponse);
    assertEditorDraftNotTruncated({ finishReason: gwResponse.finishReason });

    // Parse the structured envelope tolerantly. On ANY shortfall the whole
    // response becomes the draft with no attributions — the draft still lands
    // and is attributed by verified quotes + author lineage (Phase 3).
    // Structured paraphrase is additive; it must never break drafting. The
    // parser is pure and lives in authoring-draft-envelope.ts so the malformed
    // shapes it has to survive are unit-testable without the route.
    const { content: generatedContent, attributions: modelAttributions } =
      parseDraftEnvelope(gwResponse.content);
    if (!generatedContent) {
      /* The provider answered and said nothing usable. That is not a draft and
         it is not an outage; it is refused as an invalid response. */
      logger.warn('ai/draft refused: the provider returned no draft content', {
        sectionId,
        model: gwResponse.model ?? null,
      });
      await fileFailedDraftTurn(draftTurn, 'The AI provider returned no draft content.');
      return res.status(GATEWAY_ERROR_HTTP_STATUS.INVALID_AI_RESPONSE).json({
        success: false,
        error: {
          code: 'INVALID_AI_RESPONSE',
          message:
            'The AI provider returned no draft content, so nothing was drafted. Nothing was changed.',
        },
      });
    }
    if (assemblySources) await readDraftAssemblySources(requestConnectable(req), sourceIdentity, assemblySources);
    /* The engine's check of the draft against what the model was SHOWN, and
       the turn's record, filed before the candidate is parked so the parked
       generator can name it. */
    const drafted = await draftTurn?.drafted(generatedContent, {
      label: `${section.code} ${section.title}`,
      authoringDocId: String(section.doc_id),
      shownEvidence: retrievalStatus === 'ok' ? evidenceShown(evidenceBlock) : null,
      // The header lines exactly as the prompt shows them.
      sectionHeader: `Module: ${section.module}\nSection: ${section.code} - ${section.title}\nProduct: ${section.product_code || 'Medical Product'}`,
      personWords: [context, requirements].filter((v) => typeof v === 'string' && v.trim()).join('\n'),
      retrievalStatus,
    });
    // Park the draft + the sources it came from so the accept endpoint can
    // record verified span-level source lineage (Phase 3). Best-effort:
    // attribution prep must never break drafting, so any failure just omits
    // draftId and the client falls back to a plain save (author lineage).
    let draftId: string | undefined;
    let attributableSources = 0;
    try {
      const rawSourceIds = [
        ...new Set(
          retrievedChunks
            .map((c) => c.sourceId)
            .filter((s): s is string => typeof s === 'string' && s.length > 0),
        ),
      ];
      let evidenceByRaw = new Map<string, number>();
      if (rawSourceIds.length > 0) {
        const { resolveEvidenceSourceIdsByArtifact } = await import(
          '../services/clinical-regulatory-evidence/retrieval-source-link.js'
        );
        // tenantId is the numeric org id (getTenantId → authedOrgId), exactly
        // what the resolver and the lineage writers require.
        evidenceByRaw = await resolveEvidenceSourceIdsByArtifact(tenantId, rawSourceIds);
      }
      const candidateSources = retrievedChunks
        .filter((c) => c.sourceId && evidenceByRaw.has(c.sourceId))
        .map((c) => ({
          evidenceSourceId: evidenceByRaw.get(c.sourceId as string) as number,
          content: c.content,
          title: c.title || null,
        }));
      attributableSources = new Set(candidateSources.map((s) => s.evidenceSourceId)).size;

      // Resolve the model's [SRC-n] paraphrase claims to canonical source
      // ids. SRC-n is the 1-based position in retrievedChunks (the order the
      // evidence block showed the model); keep only a claim whose chunk
      // resolved to a canonical cre_evidence_sources.id — an unresolved or
      // out-of-range src is dropped, never guessed at. The accept gate
      // re-checks each id is one that was retrieved before recording it.
      const assertions = modelAttributions
        .map((a) => {
          const chunk = retrievedChunks[a.src - 1];
          const esid = chunk && chunk.sourceId ? evidenceByRaw.get(chunk.sourceId) : undefined;
          return esid && a.quote.trim() ? { quote: a.quote, sourceId: esid } : null;
        })
        .filter((x): x is { quote: string; sourceId: number } => x !== null);

      const { createDraftCandidate, savedSectionDraftBase } = await import(
        '../services/clinical-regulatory-evidence/draft-candidate-store.js'
      );
      const candidate = await createDraftCandidate(
        tenantId,
        String(sectionId),
        generatedContent,
        candidateSources,
        getActorId(req),
        undefined,
        /* What produced this draft, parked with the source chunks rather
           than round-tripped through the client — "which model wrote
           this" must not be a forgeable claim. The prompt is composed
           inline here, so there is no version to name and a digest of
           the bytes actually sent is the honest identifier. */
        {
          model: gwResponse.model ?? null,
          provider: gwResponse.provider ?? null,
          promptSha256: crypto.createHash('sha256').update(prompt).digest('hex'),
          generatedAt: new Date().toISOString(),
          requestId: gwResponse.requestId ?? null,
          turnRecordId: drafted?.turnRecord.status === 'recorded' ? drafted.turnRecord.id : null,
          finishReason: gwResponse.finishReason ?? null,
          truncated: isTruncated(gwResponse.finishReason),
          ...(vaultSourceReceipt ? { vaultSources: vaultSourceReceipt } : {}),
          ...(assemblySources ? { assemblySources } : {}),
          savedSectionBase: savedSectionDraftBase(section),
        },
        assertions,
      );
      draftId = candidate.id;
    } catch (attrErr: any) {
      console.warn(
        '[Authoring] draft-candidate creation failed (non-fatal):',
        attrErr?.message,
      );
    }

    return res.json({
      success: true,
      /* The only source a draft can have. Declared so a reader of the envelope
         never has to infer from the absence of a `degraded` flag. */
      source: 'model',
      draft: {
        content: generatedContent,
        // Present when the draft was parked for attributed acceptance; POST
        // …/ai/draft/accept with this id records source + author lineage.
        draftId,
        // The engine's check of the draft as generated, and whether its turn was filed.
        check: drafted?.check ?? null,
        turnRecord: drafted?.turnRecord ?? { status: 'not_recorded', reason: 'This draft had no organization to file it under.' },
        metadata: {
          tone,
          region,
          generated_at: new Date().toISOString(),
          model: gwResponse.model,
          provider: gwResponse.provider,
          source: 'model',
          sourcesRetrieved,
          attributableSources,
          /* Carried so a reader can tell an ungrounded draft from a
             grounded one, and a retrieval outage from an empty corpus. */
          retrievalStatus,
          retrievalError,
          retrievalScope: projectScope
            ? { kind: 'project', programId: projectScope.programId, projectId: projectScope.projectId }
            : { kind: 'unavailable', programId: null, projectId: null },
        },
      },
      message:
        sourcesRetrieved > 0
          ? `AI draft generated with ${sourcesRetrieved} Data Room source${
              sourcesRetrieved !== 1 ? 's' : ''
            }`
          : retrievalStatus === 'failed'
            ? 'AI draft generated WITHOUT Data Room evidence — retrieval failed, so this draft is ungrounded and its claims are unverified'
            : 'AI draft generated with no Data Room sources above the relevance threshold',
    });
  } catch (error) {
    if (error instanceof DraftTruncatedError) {
      await fileFailedDraftTurn(draftTurn, 'The AI draft was cut off (DRAFT_TRUNCATED). No candidate was retained.');
      return res.status(422).json({ success: false, error: { code: error.code, message: error.message } });
    }
    const sourceFailure = assemblySourceErrorDetails(error);
    if (sourceFailure) {
      await fileFailedDraftTurn(draftTurn, 'The selected source receipt could not be verified. No candidate was retained.');
      return res.status(sourceFailure.status).json({ success: false, error: { code: sourceFailure.code, message: sourceFailure.message } });
    }
    if (error instanceof AnaProjectScopeError) {
      return res.status(error.status).json({ success: false, error: { code: error.code, message: error.message } });
    }
    console.error('Error generating AI draft:', error);
    await fileFailedDraftTurn(draftTurn, 'Drafting failed on the server.');
    return serverError(res, logger, 'drafting AI', error);
  }
});

// POST /api/authoring/sections/:sectionId/ai/draft/accept - Adopt an AI draft as
// section content AND record span-level source + author lineage, atomically.
//
// This is the persistence point automated source attribution needs: the draft's
// retrieved chunks (parked by POST …/ai/draft) and the accepted text are both in
// hand here, so verified quotes can be recorded against the exact sources the
// draft came from, in the SAME transaction as the content. The save fails closed
// if lineage cannot be recorded — exactly like the manual save gate on
// PATCH /sections/:id. See docs/architecture/SOURCE_ATTRIBUTION_AUTOMATED_DESIGN.md
// Phase 3.
router.post('/sections/:sectionId/ai/draft/accept', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { draftId } = req.body ?? {};
    const tenantId = getTenantId(req);
    const actor = getActorId(req);
    if (!actor) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    if (!draftId || typeof draftId !== 'string') {
      return res.status(400).json({ success: false, error: 'draftId is required' });
    }

    // Section must exist and belong to this tenant.
    const sectionResult = await pool.query(
      `SELECT id, doc_id, content FROM authoring_sections WHERE id = $1 AND tenant_id = $2`,
      [sectionId, tenantId],
    );
    if ((sectionResult.rowCount ?? 0) === 0) {
      return res.status(404).json({ success: false, error: 'Section not found' });
    }

    const priorContent: string | null = sectionResult.rows[0].content ?? null;

    const { consumeDraftCandidate, DraftCandidateBaseChangedError } = await import(
      '../services/clinical-regulatory-evidence/draft-candidate-store.js'
    );
    const { enforceSourceAndAuthorLineage } = await import(
      '../services/clinical-regulatory-evidence/lineage-gate.js'
    );

    // Content, its source citations and its author spans commit together or not at
    // all — the same one-connection transaction + gate the manual save uses. The
    // candidate is claimed INSIDE the transaction (single-use), so a rolled-back
    // accept leaves it available for a retry.
    const client = await pool.connect();
    let saved: { rows: any[] } = { rows: [] };
    let acceptedContent = '';
    let attribution = { sourceSpans: 0, authorSpans: 0, distinctSources: 0, coverage: 0 };
    /* Held for the audit entry below. The candidate row is claimed with
       DELETE … RETURNING, so this is the last moment the generator exists
       anywhere — after the transaction it lives only in what we record. */
    let generator: Record<string, unknown> | null = null;
    /* Whether the caller's accepted text still IS the generated draft. */
    let draftModifiedOnAccept = false;
    /* The draft as the model wrote it. When the author edited it before
       accepting, the saved content no longer contains it, and the candidate
       row is consumed below — so it is recorded here or nowhere. */
    let generatedDraft = '';
    /* Whether the accepted content reached the bound filing, and when it did
       not, why — surfaced on the response exactly as the manual save does. */
    let governedCommit: CommitSectionResult | null = null;
    const transaction: AuthoringTransactionState = { began: false, commitAttempted: false };
    let acceptedDraftId: string | undefined;
    let acceptedAssemblySources: AssemblySourceManifest | undefined;
    try {
      transaction.began = true;
      await client.query('BEGIN');
      await reserveWritableSection(client, String(sectionId), tenantId);

      const candidate = await consumeDraftCandidate(tenantId, String(sectionId), draftId, client, true);
      if (!candidate) {
        await rollbackAuthoringTransaction(client, transaction);
        return res.status(410).json({
          success: false,
          error: {
            code: 'DRAFT_EXPIRED',
            message:
              'This AI draft has expired or was already accepted. Regenerate the draft and try again.',
          },
        });
      }
      acceptedDraftId = candidate.id;
      generator = candidate.generator as Record<string, unknown> | null;
      assertEditorDraftNotTruncated(candidate.generator);
      const { reserveSectionDraftSources } = await import('../services/authoring/authoring-draft-sources.js');
      await reserveSectionDraftSources(client, tenantId, candidate.generator?.vaultSources, Number(actor));
      if (candidate.generator?.assemblySources !== undefined) {
        acceptedAssemblySources = (await reserveDraftAssemblySources(client,
          { organizationId: tenantId, userId: Number(actor), sectionId: String(sectionId) }, candidate.generator.assemblySources)).manifest;
      }

      // The author may have edited the draft before accepting; attribute what they
      // actually save. Fall back to the draft as generated when no edit is sent.
      // Whether the accepted text still IS the generated draft is recorded on
      // the audit row (draft_modified_on_accept below): "accepted AI draft"
      // must not vouch for words the model never produced.
      acceptedContent =
        typeof req.body?.content === 'string' ? req.body.content : candidate.content;
      draftModifiedOnAccept = acceptedContent !== candidate.content;
      generatedDraft = candidate.content;

      saved = await client.query(
        `UPDATE authoring_sections SET content = $1, updated_at = NOW()
          WHERE id = $2 AND tenant_id = $3 RETURNING *`,
        [acceptedContent, sectionId, tenantId],
      );

      const sources = candidate.sources.map((s) => ({
        sourceId: s.evidenceSourceId,
        content: s.content,
        title: s.title,
      }));
      attribution = await enforceSourceAndAuthorLineage(
        client,
        tenantId,
        { documentTable: 'authoring_sections', documentId: String(sectionId) },
        acceptedContent,
        actor,
        sources,
        // The model's own paraphrase claims, parked at draft time with their
        // source ids already resolved. The gate records each still-present,
        // still-retrieved one as a usage='paraphrased' span — an assertion behind
        // the verified-quote pass, never ahead of it.
        {
          assertions: candidate.assertions,
          // The accepted content IS the machine's draft wherever the author
          // left it unedited: a clause verbatim in what was generated is
          // recorded as AnA's, accepted by this actor; a clause the author
          // changed is the author's own. Attribution by verbatim match against
          // the draft as generated — never by a flag on the whole save.
          acceptedMachineText: [{ authorId: ANA_MACHINE_AUTHOR_ID, text: candidate.content }],
        },
      );

      /* AND THE ACCEPTED DRAFT REACHES THE FILING.
       *
       * This call was missing, exactly as it was on the revert path, and with
       * the same consequence: accepting an AI draft wrote the working copy
       * (`authoring_sections`) and its lineage, and left `c2c_document_sections`
       * — what the filing IS — holding the pre-draft content. So an author
       * accepted a page of regulatory text, saw it in the editor, the audit
       * trail recorded it, and the system of record still showed the old text.
       * AI-assisted drafting is a primary use of this surface, which made this
       * the widest instance of the working-copy/filing drift `commitSectionToFiling`
       * exists to close.
       *
       * In THIS transaction, so the working copy and the filing move together
       * or neither does — the same guarantee the manual save gives. The reason
       * is the author's if they stated one, and otherwise NOT invented: the
       * fact that it came from an AI draft is provenance, recorded on the
       * revision origin and the audit metadata, not a justification for the
       * change. */
      governedCommit = await commitSectionToFiling({
        client,
        sectionId: String(sectionId),
        content: String(acceptedContent ?? ''),
        actorId: String(actor),
        tenantId,
        reason:
          typeof req.body?.changeReason === 'string' && req.body.changeReason.trim()
            ? req.body.changeReason
            : undefined,
        // Unconditional, unlike the manual-save call site above: this whole
        // route exists to accept an AI draft, so the content it commits is by
        // definition AI-drafted — there is no ambiguous zero-contributor case
        // here the way there is on an ordinary interactive save.
        draftSource: 'ana',
      });

      /* The revision and the Part 11 record, IN this transaction (D5,
         2026-09-26). They used to be written after COMMIT, on their own
         connections, with a failure logged as non-fatal — so an accepted AI
         draft could stand in the document with no revision and no record of
         who accepted it. The accept now lands with both or not at all. */
      await createRevision(String(sectionId), acceptedContent, actor, tenantId, client, 'ai-draft-accept');
      await createAuditTrail(
        req,
        saved.rows[0]?.doc_id,
        sectionId,
        'UPDATE',
        candidate.savedPriorContent === undefined ? priorContent : candidate.savedPriorContent,
        acceptedContent,
        /* THE REASON IS THE AUTHOR'S, OR NOT STATED — never "Accepted AI draft".
           Accepting an AI draft is provenance (the revision origin
           'ai-draft-accept' and the metadata below), not a reason WHY this
           regulatory text was chosen. */
        typeof req.body?.changeReason === 'string' && req.body.changeReason.trim()
          ? req.body.changeReason
          : null,
        /* Which model, which provider, which prompt; whether the author edited
           the draft before accepting; and, when they did, the draft as the
           model wrote it, so "accepted AI draft" never vouches for words the
           model did not produce and the words it did produce are not lost. */
        {
          source: 'ai-draft-accept',
          generator,
          ...(acceptedAssemblySources ? { assemblySourceUse: 'verified_generation_input', assemblySources: acceptedAssemblySources } : {}),
          draft_modified_on_accept: draftModifiedOnAccept,
          generated_draft_sha256: textSha256(generatedDraft),
          ...(draftModifiedOnAccept ? { generated_draft: generatedDraft } : {}),
        },
        client,
      );

      transaction.commitAttempted = true;
      await client.query('COMMIT');
      transaction.began = false;
    } catch (caught) {
      const recovery = { organizationId: tenantId, documentId: String(sectionResult.rows[0].doc_id), sectionId: String(sectionId), draftId: acceptedDraftId };
      const err = await settleAuthoringTransactionFailure(client, transaction, caught, new AuthoringSectionWriteOutcomeError('ai-accept', recovery));
      if (err instanceof AuthoringSectionWriteOutcomeError) return res.status(503).json(authoringSectionRecoveryPayload(err));
      // Preserve the selected-source flow's conservative hold when its
      // pre-COMMIT rollback failed; the shared lifecycle already marks eviction.
      if (transaction.discardConnection) return draftAcceptUnconfirmed(res);
      const sourceFailure = assemblySourceErrorDetails(err);
      if (sourceFailure) return res.status(sourceFailure.status).json({ success: false, error: { code: sourceFailure.code, message: sourceFailure.message } });
      if (err instanceof DraftTruncatedError) {
        return res.status(422).json({ success: false, error: { code: err.code, message: err.message } });
      }
      if (err instanceof DraftCandidateBaseChangedError) {
        return res.status(409).json({ success: false, error: { code: err.code, message: err.message } });
      }
      if ((err as { code?: string }).code === 'DRAFT_SOURCES_UNAVAILABLE') {
        return res.status(409).json({ success: false, error: { code: 'DRAFT_SOURCES_UNAVAILABLE', message: (err as Error).message } });
      }
      if (workflowGovernanceReply(err, res)) return;
      logger.error('AI draft accept refused — content and lineage rolled back together', {
        sectionId,
        tenantId,
        err: err instanceof Error ? err.message : String(err),
      });
      return res.status(500).json({
        success: false,
        error: {
          code: 'LINEAGE_REQUIRED',
          message:
            'The draft was not saved: its source/author lineage or its audit record could not be written. ' +
            'Saving content without provenance or a record is not permitted.',
        },
      });
    } finally {
      client.release(transaction.discardConnection);
    }

    res.json({
      success: true,
      section: saved.rows[0],
      attribution,
      message: `AI draft accepted — ${attribution.sourceSpans} verified source citation(s) across ${attribution.distinctSources} source(s); ${attribution.coverage}% of content quoted, the remainder recorded as author-original.`,
      /* Whether the accepted text reached the filing — honest either way, the
         same as the manual save. An unbound accept says it did not, rather than
         letting the two stores drift apart in silence. */
      ...(governedCommit ? { filing: filingResponse(governedCommit) } : {}),
    });
  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('Error accepting AI draft:', error);
    return serverError(res, logger, 'saving accept', error);
  }
});

/* ── What the record says the open section must contain ──────────────────────
   The scan's section-specific expectations came from `ctdRequiredElements`
   below: a table of five CMC codes (3.2.S.1/.2/.3/.4/.7) declared inside the
   handler. For every other code in the CTD — 2.5, 2.7.3, 2.7.4, 4.2.3, 3.2.P,
   1.14.4.1, 5.3.5.x — the author was shown nothing at all about the section's
   required content, while server/services/ind/ctd/authoring-guidance.ts has
   carried `keyContentElements` for all 134 registered codes since the record
   landed.

   The record's elements are DESCRIPTIONS ("Product development rationale
   linking unmet need, MOA, and program design (2.5.1)"), so substring-testing
   content against them would flag essentially every element of every section
   and bury the author in false deficiencies. A substring test cannot verify a
   description, and this does not pretend it can: the elements are served as a
   READ-ONLY statement of what the section must contain, explicitly NOT
   verified by this scan, and they add no check and move no denominator.

   The resolver answers, not a dictionary lookup, because the record carries
   leaves and not parents: '4.2.3' and '3.2.P' have no entry of their own, and
   resolveRequirements / resolveSectionBriefSource handle exact, ancestor and
   parent. A code the record does not index comes back with the resolver's own
   reason and reads as "not indexed" — never as "nothing required". */

/** The record's statement about a section, or its honest absence. */
type RecordRequirements =
  | {
      indexed: true;
      /** Whose entry answered: the section's own, its containing section's, or its children. */
      source: 'exact' | 'ancestor' | 'parent';
      /** The code whose entry answered (the section's own code when `source` is 'exact'). */
      answered_by: string;
      title: string;
      /** What the record says must be present. Empty only for a parent code, which has `contains`. */
      elements: string[];
      /**
       * For a parent code: the registered sections it contains, each with its
       * own requirements, capped at CONTAINS_CAP.
       */
      contains?: Array<{ code: string; title: string }>;
      /** How many contained sections the cap withheld. Zero when all are listed. */
      contains_omitted?: number;
      /** Always false: a description cannot be verified by a keyword test. */
      verified_by_this_check: false;
      note: string;
      /** basisLabel() — recall never reads as the regulator's own text. */
      basis: string;
    }
  | { indexed: false; reason: string };

/* The record carries no typed RegulatoryBasis for a CTD section yet —
   requirements-resolver returns `basis: []` for them and says so in its own
   RequirementAnswer doc — so the basis is stated as exactly what it is:
   compiled recall, rendered through basisLabel, which never lets recall read as
   checked regulator text.

   The record meant here is server/services/ind/ctd/authoring-guidance.ts. That
   path stays in this comment and in the step's -facts.md: `ref` is rendered
   verbatim to a regulatory associate, and a repository path is not something
   the reader of a regulatory statement can act on. */
const CTD_RECORD_BASIS: RegulatoryBasis = {
  ref: 'ICH M4 CTD content, as compiled in the platform record',
  confidence: 'recall',
  note: 'Compiled drafting guidance, not a verbatim regulator citation for this section.',
};

/* The panel is a compact note, so a parent code's listing is capped the way
   the record's own renderer caps the same list — section-brief.ts
   `LIST_CAPS.children` (12) — and the remainder is carried as a count so the
   author is told what was withheld rather than shown a silently short list.
   LIST_CAPS is module-private there; changing that is not this step's file. */
const CONTAINS_CAP = 12;

function recordRequirementsFor(code: unknown): RecordRequirements {
  const requested = String(code ?? '').trim();
  const answer = resolveRequirements({ document: requested });

  if (answer.kind === 'not_indexed') return { indexed: false, reason: answer.reason };
  if (answer.kind !== 'answer' || answer.source.kind !== 'ctd-section') {
    return {
      indexed: false,
      reason:
        `The platform's guidance indexes no CTD section entry for "${requested}". ` +
        'It is not stated here; do not supply requirements from memory as if it were.',
    };
  }

  const src = resolveSectionBriefSource(requested);
  if (!src) {
    return {
      indexed: false,
      reason:
        `The platform's guidance indexes no CTD section entry for "${requested}". ` +
        'It is not stated here; do not supply requirements from memory as if it were.',
    };
  }

  const basis = basisLabel(CTD_RECORD_BASIS);

  if (src.kind === 'parent') {
    const children = src.children ?? [];
    return {
      indexed: true,
      source: 'parent',
      answered_by: src.requested,
      /* The panel prefixes the code, so the title must not repeat it:
         `answer.title` is already "4.2.3 — the sections it contains". */
      title: 'the sections it contains',
      elements: [],
      contains: children.slice(0, CONTAINS_CAP).map((c) => ({ code: c.code, title: c.title })),
      contains_omitted: Math.max(0, children.length - CONTAINS_CAP),
      verified_by_this_check: false,
      note:
        `${src.requested} has no entry of its own in the record; the record carries the requirements of ` +
        'each section it contains. This check does not verify them.',
      basis,
    };
  }

  const entry = src.entry!;
  return {
    indexed: true,
    source: src.kind,
    answered_by: entry.code,
    title: entry.title,
    elements: [...entry.keyContentElements],
    verified_by_this_check: false,
    note: `What the record states section ${entry.code} must contain. This check does not verify these elements.`,
    basis,
  };
}

/**
 * Does the open document agree with itself? One engine run over every section of it
 * (document-figure-consistency.ts): the same figure, in the same frame, stated twice in two
 * sections with two different values — a synopsis against its own body, an overall paragraph
 * against its per-study one. It needs no cited sources, so unlike the save-time check in
 * section-claims-check.ts it reaches a document a person wrote, imported or edited by hand.
 *
 * The role is read from the open section's code. Both sides of a within-document pair carry the
 * same role, so it cancels out of every verdict; reading it from the record keeps it a fact rather
 * than a guess.
 *
 * Null when the read fails — a failed read is never an empty result, which here would read as
 * "the document agrees with itself".
 */
async function documentFigureConsistency(docId: unknown, tenantId: unknown, sectionCode: unknown): Promise<DocumentConsistencyCheck | null> {
  try {
    const rows = await pool.query(
      `SELECT code, title, content FROM authoring_sections
        WHERE doc_id = $1 AND tenant_id = $2
        ORDER BY order_index ASC, code ASC`,
      [docId, tenantId],
    );
    const sections: ConsistencySection[] = rows.rows.map((r: { code: string | null; title: string | null; content: string | null }) => ({
      code: String(r.code ?? ''),
      title: String(r.title ?? ''),
      text: sectionReadableText(r.content),
    }));
    return checkDocumentFigureConsistency(claimDocRoleOf({ ctdSection: String(sectionCode ?? '') }), sections);
  } catch {
    return null;
  }
}

/**
 * The consistency field, present only when the sections were read. An absent field says nothing;
 * an empty one would say "the document agrees with itself", which is the one thing a failed read
 * must never say. A function rather than a ternary in the response literal: the handler is already
 * at the branch-count ceiling, and a reader of the response should see one named thing here.
 */
function consistencyField(check: DocumentConsistencyCheck | null): { document_figure_consistency?: DocumentConsistencyCheck } {
  return check ? { document_figure_consistency: check } : {};
}

// POST /api/authoring/sections/:sectionId/ai/deficiency-scan - Scan for deficiencies
router.post('/sections/:sectionId/ai/deficiency-scan', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const { region = 'FDA', scan_type = 'comprehensive' } = req.body;
    const tenantId = getTenantId(req);

    // Get section content
    const sectionResult = await pool.query(
      `SELECT s.id, s.doc_id, s.code, s.title, s.content, s.order_index, s.track_changes, s.created_at, s.updated_at, s.tenant_id, d.module
       FROM authoring_sections s
       JOIN authoring_documents d ON d.id = s.doc_id
       WHERE s.id = $1 AND s.tenant_id = $2`,
      [sectionId, tenantId]
    );

    if (((sectionResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({
        success: false,
        error: 'Section not found',
      });
    }

    const section = sectionResult.rows[0];
    // One engine run over every section of the open document, before the heuristics below.
    const documentConsistency = await documentFigureConsistency(section.doc_id, tenantId, section.code);

    // Perform deficiency analysis
    const deficiencies: Array<Record<string, unknown>> = [];
    const content = section.content || '';
    const contentLength = content.length;

    /* Which distinct checks ran, and which of them flagged.
       The score was `(10 - deficiencies.length) / 10`, where 10 was a constant
       unrelated to the checks actually performed. The module-keyword check
       alone pushes one deficiency PER missing term — six of them — so a poor
       section reached thirteen deficiencies and scored -30%. A percentage
       below zero is not a signal, it is a bug wearing one. Counting distinct
       checks makes the denominator mean something and keeps the range 0-100,
       and it lets the response say "passed N of M" instead of asking a reader
       to trust a bare number. */
    const checks: Array<{ id: string; flagged: boolean }> = [];
    const checksSkipped: Array<{ id: string; reason: string }> = [];
    const runCheck = (id: string, fn: () => void) => {
      const before = deficiencies.length;
      fn();
      checks.push({ id, flagged: deficiencies.length > before });
    };

    const contentLower = content.toLowerCase();

    runCheck('content_length', () => {
      if (contentLength < 100) {
        deficiencies.push({
          type: 'content_length',
          severity: 'high',
          message:
            'Section content appears insufficient. Regulatory sections typically require detailed information.',
          recommendation: 'Expand content to include all required regulatory elements.',
          location: 'entire_section',
        });
      }
    });

    // Keyword expectations exist only for the five supported CTD module labels.
    // CTIS groups, notifications and other document labels must not inherit CMC
    // expectations or count an unsupported profile as a performed check.
    const requiredKeywords: Record<string, string[]> = {
      M3: ['specification', 'validation', 'stability', 'quality', 'manufacture', 'control'],
      M5: ['efficacy', 'safety', 'adverse', 'clinical', 'endpoint', 'statistical'],
      M2: ['summary', 'overview', 'quality', 'nonclinical', 'clinical'],
      M4: ['toxicology', 'pharmacology', 'ADME', 'carcinogenicity'],
      M1: ['form', 'administrative', 'regulatory'],
    };

    const moduleLabel = String(section.module ?? '');
    const moduleKeywords = Object.prototype.hasOwnProperty.call(requiredKeywords, moduleLabel)
      ? requiredKeywords[moduleLabel] : undefined;
    if (moduleKeywords) {
      runCheck('module_keywords', () => {
        moduleKeywords.forEach(keyword => {
          if (!contentLower.includes(keyword)) {
            deficiencies.push({
              type: 'missing_keyword',
              severity: 'medium',
              /* 2026-10-11: this recommended "Include discussion of <keyword>
                 as required by ${region} guidelines" — a keyword-presence
                 heuristic reported as a requirement of the agency, in the same
                 response this handler frames as "not a compliance
                 determination". The check cannot establish that any agency
                 requires the word, only that the module's keyword profile
                 expects to see the topic discussed, so that is all it now
                 claims. The region is still reported on the response; it is no
                 longer cited as the author of this expectation. */
              message: `Expected term not found in the saved content: "${keyword}"`,
              recommendation:
                `The keyword profile for module ${moduleLabel} expects ${keyword} to be discussed. ` +
                'This is a word-presence signal from that profile, not an agency requirement.',
              location: 'content',
            });
          }
        });
      });
    } else {
      checksSkipped.push({ id: 'module_keywords', reason: `No heuristic keyword profile is defined for document module "${moduleLabel}".` });
    }

    /* CTD required-element check, migrated from POST /ai/validate-compliance.
       That endpoint was a second, callerless implementation of this same
       capability — heuristic keyword presence over section content — and it
       reported `overall_compliance: 'PASS'` whenever its list came back empty.
       Its list was only ever populated for five hardcoded 3.2.S.* codes, so
       for every other section in the CTD it checked nothing and answered PASS.
       The useful half is these per-section element lists; they belong on the
       one scan that has a caller and an honest frame, and the endpoint is
       deleted in the same change (zero duplication). */
    const ctdRequiredElements: Record<string, string[]> = {
      '3.2.S.1': ['nomenclature', 'structure', 'general properties'],
      '3.2.S.2': ['manufacturer', 'manufacturing process', 'controls'],
      '3.2.S.3': ['elucidation of structure', 'impurities'],
      '3.2.S.4': ['specifications', 'analytical procedures', 'validation'],
      '3.2.S.7': ['stability data', 'post-approval stability', 'storage conditions'],
    };
    const ctdElements = ctdRequiredElements[String(section.code)];
    /* Only counted as a check when there IS a list for this section code.
       Running it against a section it has no expectations for and recording a
       pass would inflate the score with a check that never looked at anything
       — the exact arithmetic that let the deleted endpoint answer PASS. */
    if (ctdElements) {
      runCheck('ctd_required_elements', () => {
        ctdElements.forEach(element => {
          if (!contentLower.includes(element)) {
            deficiencies.push({
              type: 'missing_ctd_element',
              severity: 'medium',
              message: `Section ${section.code} would normally discuss ${element}`,
              recommendation: `Add information about ${element} to ${section.code}`,
              location: 'content',
            });
          }
        });
      });
    }

    runCheck('data_presence', () => {
      if (!content.includes('[') && !content.includes('Table') && !content.includes('Figure')) {
        deficiencies.push({
          type: 'missing_data',
          severity: 'medium',
          message: 'No data tables or figures detected',
          recommendation: 'Consider adding supporting data, tables, or figures',
          location: 'content',
        });
      }
    });

    runCheck('placeholder_text', () => {
      const placeholderPatterns = [/\[.*?\]/g, /TBD/gi, /TODO/gi, /XXX/gi];
      placeholderPatterns.forEach(pattern => {
        const matches = content.match(pattern);
        if (matches && matches.length > 0) {
          deficiencies.push({
            type: 'placeholder_text',
            severity: 'high',
            message: `Found placeholder text: ${matches.slice(0, 3).join(', ')}${
              matches.length > 3 ? '...' : ''
            }`,
            recommendation: 'Replace all placeholder text with actual content',
            location: 'multiple',
          });
        }
      });
    });

    runCheck('structure', () => {
      if (!content.includes('\n') || content.split('\n').length < 5) {
        deficiencies.push({
          type: 'poor_structure',
          severity: 'low',
          message: 'Content lacks proper structure and formatting',
          recommendation: 'Add headings, paragraphs, and proper formatting',
          location: 'formatting',
        });
      }
    });

    // Heuristic quality/completeness signal — NOT a 21 CFR compliance
    // determination. It is derived purely from word-count and keyword presence
    // and cannot prove regulatory compliance; labelling a section "compliant" /
    // "non_compliant" on that basis overstates what the check establishes. It is
    // reported as a review signal ('review required' / 'heuristic quality').
    const checksRun = checks.length;
    const checksPassed = checks.filter(c => !c.flagged).length;
    const qualityScore = checksRun > 0 ? Math.round((checksPassed / checksRun) * 100) : 0;

    res.json({
      success: true,
      scan_results: {
        section_id: sectionId,
        section_code: section.code,
        section_title: section.title,
        scan_type,
        region,
        // Heuristic quality/completeness signal. `compliance_score` is retained
        // for backward compatibility with existing readers, but it mirrors the
        // quality signal and is not a compliance determination.
        signal_type: 'heuristic_quality',
        quality_score: qualityScore,
        compliance_score: qualityScore,
        /* The denominator, so a reader is never asked to take the percentage
           on trust — and so the UI can name how many checks actually ran
           rather than hardcoding a number that drifts from the code. */
        checks_run: checksRun,
        checks_passed: checksPassed,
        ...(checksSkipped.length ? { checks_skipped: checksSkipped } : {}),
        /* The record's own statement of what this section must contain, or the
           resolver's reason when it indexes no entry for the code. Always
           present: an omitted field reads as "nothing required", which is the
           one thing this must never say. It is not a check and not counted as
           one — see recordRequirementsFor above. */
        record_requirements: recordRequirementsFor(section.code),
        /* Whether the open DOCUMENT agrees with itself: the same figure stated
           twice in two sections with two different values. Absent when the
           sections could not be read — never an empty result, which would read
           as "it agrees". Not a check and not counted as one. */
        ...consistencyField(documentConsistency),
        status:
          qualityScore >= 80
            ? 'heuristic_ok'
            : qualityScore >= 60
            ? 'review_recommended'
            : 'review_required',
        deficiencies,
        deficiency_count: deficiencies.length,
        scanned_at: new Date().toISOString(),
      },
      message:
        'Heuristic quality scan completed (word-count/keyword signal, not a compliance determination)',
    });
  } catch (error) {
    console.error('Error scanning for deficiencies:', error);
    return serverError(res, logger, 'saving deficiency scan', error);
  }
});

// ============= Export =============
// Additional endpoints for comprehensive functionality

// NOTE: Removed duplicate database-based templates endpoint - using file-based templates at line ~1834

// GET /api/authoring/stats - Get authoring statistics
router.get('/stats', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);

    const stats = await pool.query(
      `
      SELECT
        COUNT(DISTINCT d.id) as total_documents,
        -- The store holds MIXED-case statuses: create writes 'draft', the
        -- workflow writes 'IN_REVIEW'/'APPROVED', freeze writes 'FROZEN'. The
        -- old literals ('draft'/'review'/'approved') matched only the first,
        -- so every counter past draft sat at 0 forever (BP-W0-7 defect class).
        COUNT(DISTINCT CASE WHEN upper(d.status) = 'DRAFT' THEN d.id END) as draft_documents,
        COUNT(DISTINCT CASE WHEN upper(d.status) = 'IN_REVIEW' THEN d.id END) as review_documents,
        COUNT(DISTINCT CASE WHEN upper(d.status) = 'APPROVED' THEN d.id END) as approved_documents,
        COUNT(DISTINCT s.id) as total_sections,
        COUNT(DISTINCT c.id) as total_comments,
        COUNT(DISTINCT CASE WHEN c.status = 'open' THEN c.id END) as open_comments,
        COUNT(DISTINCT r.id) as total_revisions
      FROM authoring_documents d
      LEFT JOIN authoring_sections s ON s.doc_id = d.id
      LEFT JOIN authoring_comments c ON c.doc_id = d.id
      LEFT JOIN doc_revisions r ON r.section_id = s.id
      WHERE d.tenant_id = $1
    `,
      [tenantId]
    );

    res.json({
      success: true,
      statistics: stats.rows[0],
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error getting statistics:', error);
    return serverError(res, logger, 'loading stats', error);
  }
});

/* The three "Step 5 helpers" that stood here — sha256(), extractPlainText()
   and buildPdfFromDocx() — were called by nothing. buildPdfFromDocx was the
   one worth naming: it took a DOCX buffer, ignored it, and returned an EMPTY
   PDF, with a comment calling that a placeholder. A helper that answers a
   request for a rendered document with a blank one is the fabrication this
   repo refuses; leaving it in place meant the next caller would ship empty
   exports and see nothing wrong. Hashing goes through sha256Hex / crypto
   directly at each site, which is where the rest of the file already does it.
*/

// ============= Step 5 Export, Submit, Sign, Freeze Endpoints =============

// ============= 21 CFR Part 11 Compliance Endpoints =============

/* POST /api/authoring/docs/:docId/create-pin has been DELETED.
 *
 * It was a second endpoint for the same thing POST /users/pin does — setting
 * the signing PIN that gates every electronic signature in this router — with
 * no caller anywhere, and it bypassed both controls the canonical one exists
 * to enforce.
 *
 * NO OLD-PIN CHECK. /users/pin requires the current PIN, bcrypt-verified,
 * before it will overwrite an existing one; its own header records why, citing
 * §11.200(a)(1): possession of a session must not become possession of the
 * signing credential. This route called createUserPin() straight through, so
 * any authenticated session could replace another sitting PIN it did not know.
 *
 * IT CLEARED THE LOCKOUT. createUserPin's upsert ended in
 * `failed_attempts = 0, locked_until = NULL`. verifyUserPin enforces three
 * attempts and a thirty-minute lockout, and this endpoint reset both — so the
 * brute-force control could be cleared between guesses by the same session
 * doing the guessing.
 *
 * createUserPin() is deleted with it: this was its only call site.
 *
 * NOTE, deliberately left as a finding rather than fixed here: `pin_expires_at`
 * was written ONLY by createUserPin (90 days) and is read by nothing —
 * verifyUserPin selects pin_hash, failed_attempts and locked_until and never
 * consults it. PIN aging therefore looks implemented and is not enforced, and
 * after this deletion the column has no writer either. Enforcing expiry would
 * start locking real signers out of a governed action, which is a product
 * decision and not a cleanup.
 *
 * 2026-09-23: moot. /users/pin and verifyUserPin are deleted as well, and the
 * PIN signs nothing; see "Signing credential" below.
 */


/* ── A freeze is a signature (DP-35, plan P1-32) ─────────────────────────────
 *
 * FROZEN is a locked state, and a frozen document counts as `finalized` for
 * eCTD leaf completeness and COMPLETE on the IND checklist
 * (coauthor-snapshot.ts snapshotStatusFor, leaf-source-resolver.ts,
 * ind-checklist-view-assembler.ts). Freeze asked for neither signing authority
 * nor re-authentication, so one session — a stolen one included — could move
 * any document its holder owned into a state that satisfies the per-leaf
 * approval checks, permanently (there is no unfreeze).
 *
 * So freezing is now the platform's one signing ceremony, as /e-sign and /sign
 * are: §11.10(g) authority before anything else, a §11.50 meaning, the §11.200
 * re-verification last (a code is spent only on a freeze otherwise ready), and
 * an authoring_signatures row bound to the snapshot it seals — its
 * covered_freeze_version / covered_content_hash are that snapshot's — written
 * in the freeze's own transaction with the chained audit row that names it.
 *
 * The meanings: the signer sealed it as its AUTHOR, or as a REVIEWER locking
 * it for approval. APPROVER is not a freeze meaning: an approval is /e-sign,
 * which approves AND freezes in one act, and a second approval path that
 * froze without approving would be two answers to one question. */
const FREEZE_SIGNATURE_MEANINGS = ['AUTHOR', 'REVIEWER'] as const;
type FreezeMeaning = (typeof FREEZE_SIGNATURE_MEANINGS)[number];
const isFreezeMeaning = (v: unknown): v is FreezeMeaning =>
  typeof v === 'string' && (FREEZE_SIGNATURE_MEANINGS as readonly string[]).includes(v);

/** The authoring_signatures row, written on the caller's transaction client. */
async function insertAuthoringSignature(
  client: Queryable,
  req: Request,
  row: {
    id: string;
    docId: string | string[] | undefined;
    signerEmail: string;
    signerName: string | null;
    meaning: string;
    reason: string;
    method: string;
    contentHash: string;
    signatureDigest: string;
    covered: { version: string; contentHash: string } | null;
    tenantId: number;
  },
): Promise<void> {
  // `method` is what the ceremony verified ('password' or 'password+mfa'),
  // never a claim from the request. `pin_verified` stays false: no PIN is
  // involved, and rows signed with one keep 'PIN' and true.
  await client.query(
    `INSERT INTO authoring_signatures
     (id, doc_id, signer_email, signer_name, meaning, reason, method,
      content_hash, signature_digest, covered_freeze_version, covered_content_hash,
      pin_verified, ip_address, user_agent, tenant_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, FALSE, $12, $13, $14)`,
    [
      row.id,
      row.docId,
      row.signerEmail,
      row.signerName,
      row.meaning,
      row.reason,
      row.method,
      row.contentHash,
      row.signatureDigest,
      row.covered?.version ?? null,
      row.covered?.contentHash ?? null,
      req.ip,
      req.headers['user-agent'],
      row.tenantId,
    ],
  );
}

/* ── A FROZEN DOCUMENT IS NOT ALLOWED TO STILL BE ASKING QUESTIONS ──
 *
 * Freeze is the seal: after it the content is seseal-hashed, signed under
 * §11.50 and filed. Nothing here checked whether the document was actually
 * finished, so a section carrying forty open reviewer comments and a dozen
 * unaccepted tracked changes could be frozen, signed and submitted.
 *
 * Both then disappear in a way nobody can see downstream. Comments are not
 * part of the exported content at all, so the questions simply do not
 * travel — the filed document looks settled and the forty unanswered
 * queries exist only in a UI nobody opens after the seal. Unresolved
 * suggestions do travel, and now travel visibly (they render as
 * `[-old-][+new+]`), which means an unfinished sentence reaches a reviewer
 * mid-argument.
 *
 * So the refusal is the honest default: a document with outstanding work is
 * not ready to be sealed, and the seal is exactly the wrong moment to
 * discover that.
 *
 * It is a refusal, not a prohibition. Freezing a draft with open comments
 * is legitimate — an internal baseline before a review round is a real
 * thing to want — so the caller may proceed by SAYING SO, and what they
 * acknowledged is recorded in the audit trail and in the freeze reason.
 * That is the Part 11 shape: you may act, but you must state that you know,
 * and the record keeps it. Silently sealing an unfinished document is the
 * only option removed. */
async function freezeCensus(
  docId: string | string[] | undefined,
  tenantId: number,
  sections: ReadonlyArray<{ content: string | null }>,
  executor: Queryable = pool,
): Promise<{ openCommentCount: number; pendingEdits: number }> {
  const openComments = await executor.query(
    `SELECT COUNT(*)::text AS n FROM authoring_comments
      WHERE doc_id = $1 AND tenant_id = $2 AND status = 'open'`,
    [docId, tenantId]
  );
  const openCommentCount = Number(openComments.rows[0]?.n ?? 0);

  /* The same census the export takes, from the same parser, so the two can
     never disagree about whether a document has unsettled edits. */
  const { sectionContentToBlocks: toBlocks, countPendingSuggestions: countPending } =
    await import('../export/authoring-section-content.js');
  let pendingEdits = 0;
  for (const section of sections) {
    const p = countPending(toBlocks(section.content));
    pendingEdits += p.insertions + p.deletions;
  }
  return { openCommentCount, pendingEdits };
}

/** The 409 a freeze answers while work is outstanding — naming it, never a status code. */
function notSettledRefusal(openCommentCount: number, pendingEdits: number) {
  const parts: string[] = [];
  if (openCommentCount > 0) {
    parts.push(`${openCommentCount} unresolved comment${openCommentCount === 1 ? '' : 's'}`);
  }
  if (pendingEdits > 0) {
    parts.push(`${pendingEdits} tracked change${pendingEdits === 1 ? '' : 's'} nobody has accepted or rejected`);
  }
  return {
    success: false,
    error: {
      code: 'DOCUMENT_NOT_SETTLED',
      message:
        `Not frozen — this document still has ${parts.join(' and ')}. ` +
        'Freezing seals the content for signature and filing, so the questions ' +
        'would go unanswered and the proposed edits would reach a reviewer ' +
        'undecided. Resolve them, or freeze again confirming you intend to ' +
        'seal it as it stands.',
    },
    unresolved: { openComments: openCommentCount, pendingEdits },
  };
}

/**
 * The 409 a freeze answers when the filed copy is not this document's text
 * (P-29, `docs/EXIT_ATTESTATION_DECISION_2026-10-18.md`).
 *
 * The seals are where this refusal belongs, and the remedy is why: saving the
 * section rewrites the filed copy (`commitSectionToFiling`), so the author can
 * clear it on the surface they are already on. After the seal the remedy is
 * narrow — a QMS-controlled document can be revised into a new editing copy
 * (`reviseControlledQmsDocument`), and every other document has no path at all
 * — which is exactly why a divergence must never be allowed to reach one.
 *
 * The editor's deliberate Re-file saved text action repairs an unchanged saved
 * body without inventing a content revision or replacing its authorship.
 */
function filingDivergedRefusal(
  diverged: ReadonlyArray<{ key: string; section: { code: string } }>,
  act: 'frozen' | 'signed',
) {
  /* NAME WHAT THE AUTHOR CAN OPEN, not only the node. For an assembled node the
     key is `2.5` and no authoring section has that code, so a refusal naming
     only the key sends the author looking for a section that does not exist.
     The contributing section's code rides along on the divergence for exactly
     this. Where they are the same — an exact-code node — say it once. */
  const named = diverged.map((d) => (d.section.code === d.key ? d.key : `${d.section.code} (filed at ${d.key})`));
  const one = named.length === 1;
  return {
    success: false,
    error: {
      code: 'FILING_DIVERGED',
      message:
        `Not ${act} — the filed copy of ${one ? 'section' : 'sections'} ${named.join(', ')} ` +
        `${one ? 'is' : 'are'} not the text this document holds. ${act === 'frozen' ? 'Freezing' : 'Signing'} ` +
        'seals the text for filing, so the signature would attest to text the submission does not ' +
        `contain. Open ${one ? 'that section' : 'those sections'} and choose Re-file saved text, ` +
        `which restores the saved text to its filing. Then ${act === 'frozen' ? 'freeze' : 'sign'} again.`,
    },
    diverged,
  };
}

/**
 * The one place the three seals ask whether the filing still holds this
 * document's text (P-29.2, docs/EXIT_ATTESTATION_DECISION_2026-10-18.md).
 *
 * Runs on the SEALING transaction, so the answer is the one the seal is about
 * to act on. Only `different` refuses — a node the filing holds nothing for is
 * reported on the response, because six editing-layer writers still do not
 * commit and that population is large and legitimate until they are routed.
 */
async function filingBlocksSeal(
  client: Queryable, docId: string | string[] | undefined, tenantId: number, act: 'frozen' | 'signed',
): Promise<{ refusal: ReturnType<typeof filingDivergedRefusal> | null; unfiled: string[] }> {
  const agreement = await filingAgreesWithEditing(client, { authoringDocId: String(docId), tenantId });
  const rewritten: FilingDivergence[] = agreement.diverged.filter((d) => d.filed === 'different');
  return {
    refusal: rewritten.length > 0 ? filingDivergedRefusal(rewritten, act) : null,
    unfiled: agreement.diverged.filter((d) => d.filed === 'empty').map((d) => d.key),
  };
}

/**
 * The seal check as ONE statement at a signing handler: sends the 409 and
 * answers true when the filing has been rewritten, so the caller returns.
 *
 * It exists in this shape for a reason worth keeping. The two signing handlers
 * sit at the lint ratchet's function-length limit, and the obvious way to
 * free room — hoisting the APPROVER approval stamp into a helper — is refused
 * by `ci:sign-ceremony`, correctly: an approval stamp whose handler writes no
 * signature row is exactly what that gate catches. So the check shrinks
 * instead of the ceremony.
 */
async function sealRefusedForFiling(
  client: Queryable, res: Response, docId: string | string[] | undefined, tenantId: number,
): Promise<boolean> {
  const { refusal } = await filingBlocksSeal(client, docId, tenantId, 'signed');
  if (refusal) res.status(409).json(refusal);
  return refusal !== null;
}

async function lockedSigningContent(client: Queryable, req: Request, docId: string, tenantId: number) {
  const document = await client.query(
    "SELECT d.*, to_jsonb(d)->'provenance' AS provenance, to_jsonb(d)->>'client_program_id' AS client_program_id FROM authoring_documents d WHERE d.id=$1 AND d.tenant_id=$2 FOR UPDATE",
    [docId, tenantId],
  );
  if (!document.rows[0]) throw new WorkflowImportGovernanceError(404, 'DOCUMENT_NOT_FOUND', 'Document not found');
  const sections = await client.query(
    'SELECT id, doc_id, code, title, content, order_index, track_changes, created_at, updated_at, tenant_id FROM authoring_sections WHERE doc_id=$1 AND tenant_id=$2 ORDER BY order_index, created_at, id',
    [docId, tenantId],
  );
  return { organizationId: tenantId, doc: document.rows[0], sections: sections.rows,
    actor: { id: String(getActorId(req) ?? ''), email: getActorEmail(req) } };
}

async function adoptionForSigning(client: Queryable, req: Request, current: Awaited<ReturnType<typeof lockedSigningContent>>, meaning: string) {
  const explicit = req.body?.adoptWorkflowSource === true;
  if (explicit && meaning !== 'REVIEWER') throw new WorkflowImportGovernanceError(400, 'WORKFLOW_ADOPTION_MEANING', 'Workflow adoption requires REVIEWER meaning.');
  if (meaning === 'REVIEWER') return prepareWorkflowImportAdoption(client, { ...current, explicit });
  await assertWorkflowImportRelease(client, current);
  return null;
}

function workflowGovernanceReply(error: unknown, res: Response): boolean {
  if (error instanceof DocumentWriteReservationError) {
    res.status(error.status).json({ success:false,code:error.code,error:error.code,message:error.message });
    return true;
  }
  if ((error as { code?: unknown } | null)?.code === '40001') {
    res.status(409).json({ success:false,code:'DOCUMENT_CHANGED_DURING_GOVERNANCE',error:'DOCUMENT_CHANGED_DURING_GOVERNANCE',
      message:'The document or its source changed while this action waited. Nothing was committed. Refresh the current record and retry the signing ceremony.' });
    return true;
  }
  if (!(error instanceof WorkflowImportGovernanceError)) return false;
  res.status(error.status).json({ success: false, code: error.code, error: error.code, message: error.message });
  return true;
}

function authoringWriterFailure(error: unknown, res: Response, operation: string) {
  if (workflowGovernanceReply(error, res)) return;
  return serverError(res, logger, operation, error);
}

// POST /api/authoring/docs/:docId/freeze - Freeze document with immutable snapshot, signed
router.post('/docs/:docId/freeze', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const { reason, version, meaning } = req.body;
    // §11.10(e): the reason is validated here and recorded as given — never
    // replaced by a placeholder in the ledger.
    const reasonVerdict = requireGovernedReason(reason);
    if (!reasonVerdict.ok) return res.status(400).json({ error: reasonVerdict.error, field: 'reason' });
    const freezeReason = reasonVerdict.reason;
    // Freeze attribution from the verified JWT; the old x-user-email ||
    // 'system' fallback let an unauthenticated caller freeze as "system".
    const email = getActorEmail(req) || null;
    if (!email) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    const tenantId = getTenantId(req);

    // §11.10(g) authority, before the credentials (see /e-sign for the order).
    const authority = await checkSigningAuthority(Number(getActorId(req)), getTenantId(req));
    if (authority) return res.status(authority.status).json({ error: authority.message, code: authority.code });
    if (!isFreezeMeaning(meaning)) {
      return res.status(400).json({
        error:
          'A freeze is signed: state its meaning, AUTHOR or REVIEWER. An approval is applied with E-sign, which approves and freezes the document in one act.',
        field: 'meaning',
      });
    }

    const client = await pool.connect();
    let committed = false;
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
      const current = await lockedSigningContent(client, req, String(docId), tenantId);
      const doc = current.doc;
      if (['FROZEN', 'APPROVED'].includes(String(doc.status ?? '').toUpperCase())) {
        return res.status(400).json({ error: 'Document is already frozen' });
      }
      await assertWorkflowImportRelease(client, current);
      const sectionsResult = { rows: current.sections };
      const { openCommentCount, pendingEdits } = await freezeCensus(docId, tenantId, sectionsResult.rows, client);
      const acknowledged = req.body?.acknowledgeUnresolved === true;
      if ((openCommentCount > 0 || pendingEdits > 0) && !acknowledged) {
        return res.status(409).json(notSettledRefusal(openCommentCount, pendingEdits));
      }

      /* P-29.2 — the seal is the last point at which the two stores can still
         be made to agree, so the comparison happens here, on this transaction
         client, before anything is sealed. Only a node whose filed text DIFFERS
         refuses; a node the filing holds nothing for is reported on the
         response instead. The split is deliberate and is not a soft landing:
         six editing-layer writers do not commit to the filing at all
         (apply-template, createSection-with-content, the genesis seed loop,
         reorder, the title rename), so `empty` has a large and legitimate
         population today, and refusing on it would block freezes across the
         product for a gap whose fix is to route those writers. `different`
         has no legitimate population: something overwrote the filed copy
         outside the editor. */
      const seal = await filingBlocksSeal(client, docId, tenantId, 'frozen');
      if (seal.refusal) return res.status(409).json(seal.refusal);
      const filingUnfiled = seal.unfiled;

      /* What was sealed over is part of why it was sealed, so it goes into the
         reason the frozen record carries rather than only into the audit row. */
      const acknowledgedNote =
        acknowledged && (openCommentCount > 0 || pendingEdits > 0)
          ? ` [Sealed with ${openCommentCount} unresolved comment(s) and ` +
            `${pendingEdits} undecided tracked change(s), acknowledged by ${email}.]`
          : '';

      // §11.200(a)(1): the signer re-verified by the platform ceremony, LAST —
      // after every refusal above — so a code is spent only on a freeze that is
      // otherwise ready to seal.
      const signer = await reverifyAuthoringSigner(req, res);
      if (!signer) return;
      const signerName = await resolveSignerName(email);
      const docHash = sectionsDigest(sectionsResult.rows);

      // Create frozen content snapshot
      const frozenContent = JSON.stringify({
        document: doc,
        sections: sectionsResult.rows,
        frozenAt: new Date().toISOString(),
      });

      const contentHash = crypto.createHash('sha256').update(frozenContent).digest('hex');
      const versionNumber = version || `v${doc.version || '1.0'}.frozen`;
      // §11.70: the signature names the snapshot it seals, inside a recomputable digest.
      const signatureId = crypto.randomUUID();
      const signatureDigest = computeSignatureDigest({
        signerEmail: email,
        meaning,
        contentHash: docHash,
        coveredContentHash: contentHash,
      });

      // Frozen-snapshot insert + status flip + signature + audit are ONE atomic unit. Run as
      // separate pool commits, a failure after the snapshot but before the status
      // update left a frozen_documents row for a document still marked editable
      // (or the reverse), and a failure before the audit left a freeze with no
      // trail. A single BEGIN/COMMIT makes the three land together or roll back
      // together.
      // Store frozen snapshot
      await client.query(
        `INSERT INTO frozen_documents
         (document_id, version, frozen_content, content_hash, frozen_by, frozen_reason, tenant_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [docId, versionNumber, frozenContent, contentHash, email,
         `${freezeReason}${acknowledgedNote}`, tenantId]
      );

      // Update document status, and when it was frozen (QA 2026-10-08, j4:
      // frozen_at stayed NULL on every frozen document).
      await client.query(
        'UPDATE authoring_documents SET status = $1, frozen_at = COALESCE(frozen_at, NOW()) WHERE id = $2 AND tenant_id = $3',
        ['FROZEN', docId, tenantId]
      );

      // The freeze's signature, bound to the snapshot just written (DP-35).
      await insertAuthoringSignature(client, req, {
        id: signatureId,
        docId,
        signerEmail: email,
        signerName,
        meaning,
        reason: freezeReason,
        method: signer.authenticationMethod,
        contentHash: docHash,
        signatureDigest,
        covered: { version: versionNumber, contentHash },
        tenantId,
      });

      // Create audit trail
      await createAuditTrail(
        req,
        docId,
        null,
        'FREEZE',
        null,
        frozenContent,
        `${freezeReason}${acknowledgedNote}`,
        { contentHash, version: versionNumber, openCommentCount, pendingEdits, acknowledged, signatureId, meaning },
        client,
        // This handler writes its own richer chained row below.
        { chainedRowWrittenByCaller: true },
      );

      /* §11.10(e) — the HASH-CHAINED ledger, on this transaction.
         `createAuditTrail` above writes authoring_audit_trail, which carries no
         chain and no HMAC, and its mirror into the chained `audit_logs` runs
         ONLY when the executor is the pool (see the guard at its foot). Every
         governed handler here passes its own transaction client — correctly, so
         the record commits with the mutation — which meant the mirror was
         skipped and these events never reached the chain at all. So
         verifyAuditChain had nothing to verify for the three actions that most
         need it, and the document's own audit view read an unchained table.
         writeChainedAuditRow is the primitive built for this case and is what
         /api/esignature/sign already uses: on the caller's client, so if the
         audit row cannot be written the whole transaction rolls back and the
         signature never exists either. */
      await writeChainedAuditRow(client, {
        tenantId,
        userId: getActorId(req) ?? undefined,
        action: 'authoring.document.freeze',
        resourceType: 'authoring_document',
        resourceId: String(docId ?? ''),
        ipAddress: (req.ip ?? undefined) as string | undefined,
        userAgent: req.headers['user-agent'] as string | undefined,
        // signatureId: the §11.70 link the audit-trail ledger joins on to show
        // this freeze as signed, with its meaning.
        details: { contentHash, version: versionNumber, reason: reason ?? null, signatureId, meaning, signer: email },
      });

      await client.query('COMMIT');
      committed = true;
      res.json({
        success: true,
        contentHash,
        version: versionNumber,
        signatureId,
        documentHash: docHash,
        frozenAt: new Date().toISOString(),
        /* P-29.2: the sealed document has text these filing nodes do not hold,
           so the submission built from the filing will not carry it. Reported,
           not refused — see the comparison above for why — but never silent:
           an author who is told nothing would reasonably believe the seal
           covers what ships. */
        ...(filingUnfiled.length > 0 ? { filingUnfiled } : {}),
      });
    } finally {
      if (!committed) await client.query('ROLLBACK').catch(() => {});
      client.release();
    }

  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('Error freezing document:', error);
    res.status(500).json({ error: 'Failed to freeze document' });
  }
});

/**
 * The APPROVER e-signature's approval and seal, written BEFORE the signature so
 * the signature can name the snapshot it creates. Returns that snapshot.
 *
 * QA 2026-10-08 (j4): the signature used to be written first, bound to no
 * snapshot, and every manifestation of the approval said "no frozen snapshot
 * was in force when this was signed"; the freeze route has always bound its
 * signature this way (DP-35). approved_at and frozen_at record the act (they
 * stayed NULL on an APPROVED document, so the document journey never showed the
 * approval); COALESCE keeps the first approval's time when an approved document
 * is signed again.
 *
 * Auto-freeze on approval — capture the FULL approved snapshot (document +
 * sections) and hash the SNAPSHOT BYTES, exactly like the manual freeze. The
 * prior code stored a 3-field stub {approvedBy, documentHash, timestamp} and set
 * content_hash = docHash (the hash of the live SECTIONS, not of the stub): the
 * approved content was captured nowhere immutable, and GET /docs/:docId/frozen —
 * which recomputes sha256(frozen_content) and compares to content_hash — raised
 * a false "tampering detected" 500 on EVERY e-sign-approved document. Runs on
 * the caller's transaction client.
 */
async function approveAndSnapshotForSignature(args: {
  client: Queryable;
  docId: string;
  tenantId: number;
  email: string;
  docHash: string;
}): Promise<{ version: string; contentHash: string }> {
  const { client, docId, tenantId, email, docHash } = args;
  // The approval stamp itself (status, approved_at, frozen_at) is written by
  // the caller, inline in the signing handler that re-verifies the signer and
  // writes the signature row on this same client — so ci:sign-ceremony sees the
  // stamp beside its ceremony. This function only reads the approved row back
  // and freezes its snapshot.
  const approvedDoc = await client.query(
    'SELECT * FROM authoring_documents WHERE id = $1 AND tenant_id = $2',
    [docId, tenantId]
  );
  const approvedSections = await client.query(
    // 2026-09-23 (W5/D7, co-author final pass): the seal's section order is the editor's
    // (order_index, created_at; id makes it total), the order the filing copy assembles in.
    'SELECT id, doc_id, code, title, content, order_index, track_changes, created_at, updated_at, tenant_id FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2 ORDER BY order_index, created_at, id',
    [docId, tenantId]
  );
  const frozenContent = JSON.stringify({
    document: approvedDoc.rows[0] ?? null,
    sections: approvedSections.rows,
    approvedBy: email,
    documentHash: docHash,
    frozenAt: new Date().toISOString(),
  });
  const frozenContentHash = crypto.createHash('sha256').update(frozenContent).digest('hex');
  const written = await client.query(
    `INSERT INTO frozen_documents
     (document_id, version, frozen_content, content_hash, frozen_by, frozen_reason, tenant_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (document_id, version, tenant_id) DO NOTHING
     RETURNING version, content_hash`,
    [docId, 'approved', frozenContent, frozenContentHash, email, 'Approved and frozen', tenantId]
  );
  /* The approval covers the 'approved' snapshot: the one just written, or, when
     the document was approved before (ON CONFLICT DO NOTHING), the one that
     already stands — never a snapshot this transaction did not keep. */
  const writtenHash = (written.rows[0] as { content_hash?: string } | undefined)?.content_hash;
  if (writtenHash) return { version: 'approved', contentHash: String(writtenHash) };
  const standing = await client.query(
    `SELECT version, content_hash FROM frozen_documents
      WHERE document_id = $1 AND version = 'approved' AND tenant_id = $2 LIMIT 1`,
    [docId, tenantId]
  );
  const row = standing.rows[0] as { content_hash?: string } | undefined;
  if (!row?.content_hash) throw new Error('The approval snapshot could not be written or read back');
  return { version: 'approved', contentHash: String(row.content_hash) };
}

// POST /api/authoring/docs/:docId/e-sign - Electronic signature, re-verified by the platform ceremony
router.post('/docs/:docId/e-sign', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const { meaning, intent } = req.body;
    // Part 11 §11.100 attribution: the SIGNER identity on an electronic
    // signature must come from the verified JWT, never from client-supplied
    // headers. x-user-email here meant anyone could sign as anyone.
    const email = getActorEmail(req);
    const tenantId = getTenantId(req);

    if (!email) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // §11.10(g) authority, checked BEFORE the credentials. Order matters: an
    // unauthorized caller must not learn whether a password is correct, and
    // must not be able to use this endpoint as a password oracle.
    const authority = await checkSigningAuthority(Number(getActorId(req)), getTenantId(req));
    if (authority) return res.status(authority.status).json({ error: authority.message, code: authority.code });

    if (!meaning || !SIGNATURE_MEANINGS.includes(meaning)) {
      return res.status(400).json({ error: 'Invalid signature meaning' });
    }

    if (!intent) return res.status(400).json({ error: 'Signature intent is required' });

    // §11.70 — a signature must be linked to the record it signs. Without this
    // an unknown or cross-tenant docId produced a signature bound to sha256("").
    if (!await documentExistsForTenant(docId, tenantId)) return res.status(404).json({ error: 'Document not found' });

    // §11.50(a)(1) printed name, from the user record — never `req.user.name`,
    // which this router never populates, and never the email in its place.
    const name = await resolveSignerName(email);

    const client = await pool.connect();
    let committed = false;
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
      const current = await lockedSigningContent(client, req, String(docId), tenantId);
      const workflowSourceAdoption = await adoptionForSigning(client, req, current, meaning);

      /* P-29.2 — THE SEAL THIS DECISION WAS ACTUALLY ABOUT. An APPROVER
         e-signature reaches the same sealed state a freeze does: it writes
         status APPROVED, frozen_at, the snapshot and the signature. The freeze
         route's own refusal copy even directs people here. So gating only the
         freeze left the path a client actually uses to approve a document
         passing no check at all — a gate the product routes around, which
         reads as coverage it does not have.

         Before `reverifyAuthoringSigner`, so a refusal spends no
         re-authentication code; before the status flip, the snapshot and the
         signature row, so a refused approval seals nothing. */
      if (meaning === 'APPROVER' && await sealRefusedForFiling(client, res, docId, tenantId)) return;

      const signer = await reverifyAuthoringSigner(req, res);
      if (!signer) return;
      const docHash = sectionsDigest(current.sections);
      const signatureId = crypto.randomUUID();
      let covered = meaning === 'APPROVER' ? null : await currentFrozenSnapshot(docId, tenantId, client);

      /* On APPROVER the approval and its snapshot come FIRST, so the signature
         can name the snapshot it creates (approveAndSnapshotForSignature).
         THE STAMP STAYS IN THIS HANDLER. It was briefly extracted on
         2026-10-18 to free a line for the P-29 seal check, and
         `ci:sign-ceremony` refused the push: an approval stamp whose handler
         writes no signature row is the shape that gate exists to catch, and
         its baseline is shrink-only. The gate was right — an approval stamp
         belongs beside the signature that justifies it. */
      if (meaning === 'APPROVER') {
        await client.query(
          `UPDATE authoring_documents
              SET status = $1, approved_at = COALESCE(approved_at, NOW()), frozen_at = COALESCE(frozen_at, NOW())
            WHERE id = $2 AND tenant_id = $3`,
          ['APPROVED', docId, tenantId]
        );
        covered = await approveAndSnapshotForSignature({ client, docId: String(docId), tenantId, email, docHash });
      }

      // One line, not six: this handler is at the lint ratchet's function-length
      // limit, and the room the P-29 seal check needs had to come from
      // somewhere that is not the signing ceremony — `ci:sign-ceremony`
      // (correctly) refuses hoisting the approval stamp out of this handler.
      // Formatting only; the arguments are unchanged.
      const signatureDigest = computeSignatureDigest({ signerEmail: email, meaning, contentHash: docHash, coveredContentHash: covered?.contentHash ?? null });
      await insertAuthoringSignature(client, req, {
        id: signatureId,
        docId,
        signerEmail: email,
        signerName: name,
        meaning,
        reason: intent,
        method: signer.authenticationMethod,
        contentHash: docHash,
        signatureDigest,
        covered,
        tenantId,
      });

      // Spine F1: the approval signature approves the filing sections it
      // covers, in this transaction, recorded through recordGovernedAction.
      // Only APPROVER means approval; AUTHOR and REVIEWER move no section.
      const filingApproval = await filingApprovalForSignature(client, req, {
        approves: meaning === 'APPROVER', docId: String(docId), tenantId, signatureId, meaning, reason: intent, via: 'e-sign',
      });

      // Create audit trail
      await createAuditTrail(req, docId, null, 'E_SIGN', null, null, intent, {
        signatureId,
        meaning,
        documentHash: docHash,
        coveredFreezeVersion: covered?.version ?? null,
        timestamp: new Date().toISOString(),
        ...(workflowSourceAdoption ? { workflowSourceAdoption } : {}),
      }, client,
      // This handler writes its own richer chained row below.
      { chainedRowWrittenByCaller: true });

      /* §11.10(e) — the HASH-CHAINED ledger, on this transaction.
         `createAuditTrail` above writes authoring_audit_trail, which carries no
         chain and no HMAC, and its mirror into the chained `audit_logs` runs
         ONLY when the executor is the pool (see the guard at its foot). Every
         governed handler here passes its own transaction client — correctly, so
         the record commits with the mutation — which meant the mirror was
         skipped and these events never reached the chain at all. So
         verifyAuditChain had nothing to verify for the three actions that most
         need it, and the document's own audit view read an unchained table.
         writeChainedAuditRow is the primitive built for this case and is what
         /api/esignature/sign already uses: on the caller's client, so if the
         audit row cannot be written the whole transaction rolls back and the
         signature never exists either. */
      await writeChainedAuditRow(client, {
        tenantId,
        userId: getActorId(req) ?? undefined,
        action: 'authoring.document.e-sign',
        resourceType: 'authoring_document',
        resourceId: String(docId ?? ''),
        ipAddress: (req.ip ?? undefined) as string | undefined,
        userAgent: req.headers['user-agent'] as string | undefined,
        // signatureId: §11.70's link from this audit row to the signature it
        // records — what the audit-trail ledger joins on to show the row as
        // signed, with the signer's meaning (#24).
        details: { meaning, intent, documentHash: docHash, signer: email, signatureId, covers: covered, ...(workflowSourceAdoption ? { workflowSourceAdoption } : {}) },
      });

      await client.query('COMMIT');
      committed = true;
      res.json({
        success: true,
        signatureId,
        documentHash: docHash,
        digest: signatureDigest,
        // The frozen snapshot this signature attests to (§11.70), or null.
        covers: covered,
        workflowSourceAdoption,
        signedAt: new Date().toISOString(),
        // Spine F1: what the approval did to the filing's sections; null for a
        // signature that does not mean approval.
        filingApproval: filingApprovalReply(filingApproval),
      });
    } finally {
      if (!committed) await client.query('ROLLBACK').catch(() => {});
      client.release();
    }

  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('Error creating electronic signature:', error);
    res.status(500).json({ error: 'Failed to create electronic signature' });
  }
});
// GET /api/authoring/docs/:docId/frozen - Get frozen document snapshot
router.get('/docs/:docId/frozen', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const { version } = req.query;
    const tenantId = getTenantId(req);

    let query = `SELECT id, document_id, version, frozen_content, content_hash, frozen_by, frozen_reason, frozen_at, tenant_id FROM frozen_documents WHERE document_id = $1 AND tenant_id = $2`;
    const params = [docId, tenantId];

    if (version) {
      query += ' AND version = $3';
      params.push(version as string);
    } else {
      query += ' ORDER BY frozen_at DESC LIMIT 1';
    }

    const result = await pool.query(query, params);

    if (((result.rowCount ?? 0) === 0)) {
      return res.status(404).json({ error: 'No frozen version found' });
    }

    const frozen = result.rows[0];

    // Verify content hash
    const computedHash = crypto.createHash('sha256').update(frozen.frozen_content).digest('hex');

    if (computedHash !== frozen.content_hash) {
      console.error('CRITICAL: Frozen document tampering detected!');
      return res.status(500).json({ error: 'Document integrity check failed' });
    }

    // Log access in audit trail
    await createAuditTrail(
      req,
      docId,
      null,
      'VIEW_FROZEN',
      null,
      null,
      'Accessed frozen document',
      { version: frozen.version, hash: frozen.content_hash }
    );

    res.json({
      success: true,
      version: frozen.version,
      contentHash: frozen.content_hash,
      frozenAt: frozen.frozen_at,
      frozenBy: frozen.frozen_by,
      content: JSON.parse(frozen.frozen_content),
    });
  } catch (error) {
    console.error('Error fetching frozen document:', error);
    res.status(500).json({ error: 'Failed to fetch frozen document' });
  }
});

// GET all citations by doc (grouped)
router.get('/docs/:docId/citations', async (req: Request, res: Response) => {
  let client: PoolClient | undefined;
  try {
    // Tenant-scoped like every other read in this router. This query carried
    // tenant_id in its SELECT list and nowhere in its WHERE, so any
    // authenticated user could enumerate another organization's citations —
    // source names, citation text, checksums — by guessing document UUIDs.
    const tenantId = getTenantId(req);
    // BEGIN applies this router's existing verified tenant scope to the owned
    // connection before both the citation census and current source admission.
    client = await pool.connect();
    await client.query('BEGIN READ ONLY');
    const { rows } = await client.query(
      `
      SELECT c.id, c.section_id, c.source, c.anchor, c.citation_text, c.reference_id, c.created_by, c.created_at, c.tenant_id, c.payload_sha256, c.frozen_at, s.code, s.title
      FROM authoring_citations c
      JOIN authoring_sections s ON s.id=c.section_id
      WHERE s.doc_id=$1 AND c.tenant_id=$2 AND s.tenant_id=$2
      ORDER BY c.created_at ASC
    `,
      [req.params.docId, tenantId]
    );
    const { listCitationSources } = await import('../services/clinical-regulatory-evidence/source-usage.service.js');
    const metadata = new Map<string, Awaited<ReturnType<typeof listCitationSources>>>();
    for (const sectionId of new Set(rows.map(row => String(row.section_id)))) {
      const ids = rows.filter(row => row.section_id === sectionId && row.source === 'cre_evidence_source').map(row => String(row.reference_id));
      metadata.set(sectionId, await listCitationSources(tenantId, ids, {
        documentId: String(req.params.docId), sectionId, userId: Number(getActorId(req)),
      }, client));
    }
    await client.query('COMMIT');
    res.json(rows.map(row => ({ ...row, source_details: row.source === 'cre_evidence_source'
      ? metadata.get(String(row.section_id))?.find(source => source.id === String(row.reference_id)) ?? null : undefined })));
  } catch (e) {
    await client?.query('ROLLBACK').catch(() => undefined);
    if (e instanceof SourceReadAccessError || e instanceof ProgramReadAccessError) {
      res.status(e.status).json({ error: e.code, message: e.message });
      return;
    }
    console.error('GET /docs/:docId/citations', e);
    res.status(500).json({ error: 'Failed to list citations' });
  } finally {
    client?.release();
  }
});
router.post('/docs/:docId/send-to-packager', async (req: Request, res: Response) => {
  try {
    const { seqId, path: relPath, title, fmt } = req.body || {};
    if (!seqId || !relPath) {
      return res.status(400).json({ error: 'seqId and path are required' });
    }

    /* This bridge re-enters the platform's own HTTP routes, and as written it
       could never have worked:
         - it sent NO Authorization header, so the export route's own JWT
           middleware answered 401 on every call;
         - it passed `?fmt=` while the export handler reads `req.body.format`,
           so even authenticated it would always have exported DOCX;
         - it never checked the export response, so that 401 JSON body was
           base64-encoded and shipped to the packager as the "document".
       The caller's verified credentials are forwarded to both hops (the export
       and the packager enforce their own authorization with them), and every
       hop is checked before its output is used. */
    const authHeaders: Record<string, string> = {};
    if (req.headers.authorization) authHeaders.Authorization = String(req.headers.authorization);

    // 1) Export DOCX (or PDF if requested)
    const exp = await fetch(
      `${req.protocol}://${req.get('host')}/api/authoring/docs/${req.params.docId}/export`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ format: fmt || 'docx' }),
      }
    );
    if (!exp.ok) {
      return res
        .status(502)
        .json({ error: `Export failed (HTTP ${exp.status}) — nothing was sent to the packager` });
    }
    const buf = Buffer.from(await exp.arrayBuffer());
    const base64 = buf.toString('base64');

    // 2) Upload as leaf (calls your existing packager route)
    const up = await fetch(
      `${req.protocol}://${req.get('host')}/api/regulatory/ectd/${seqId}/leaf`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          module: 3,
          path: relPath,
          title: title || 'Module 3 Document',
          operation: 'new',
          base64,
        }),
      }
    );

    if (!up.ok) {
      return res.status(502).json({ error: 'Packager upload failed' });
    }

    const leaf = await up.json();
    res.json({ ok: true, leaf });
  } catch (e) {
    console.error('POST /docs/:id/send-to-packager', e);
    res.status(500).json({ error: 'Bridge to packager failed' });
  }
});

// ============= Step 8: Export logging, Diff since Export, Document-level refresh =============
// ============= Step 7: Token Node API Endpoints =============

// GET /api/authoring/sections/:sectionId/tokens - Get tokens (citations) for a section
router.get('/sections/:sectionId/tokens', async (req: Request, res: Response) => {
  try {
    const { sectionId } = req.params;
    const tenantId = getTenantId(req);

    const result = await pool.query(
      `SELECT
        c.id as cite_id,
        c.source,
        c.citation_text,
        c.created_at,
        c.payload_sha256,
        c.anchor,
        c.reference_id
       FROM authoring_citations c
       WHERE c.section_id = $1 AND c.tenant_id = $2
       ORDER BY c.created_at DESC`,
      [sectionId, tenantId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Error getting section tokens:', error);
    return serverError(res, logger, 'loading tokens', error);
  }
});

// POST /api/authoring/sections/:sectionId/refresh-token - Refresh a specific token
router.post('/sections/:sectionId/refresh-token', async (req: Request, res: Response) => {
  try {
    /* The citation re-read is the one the PATH section owns. The section guard
       and the gateway both authorise :sectionId, so :sectionId is what binds
       the write. This route used to treat it as addressing only and look
       cite_id up by tenant, which let an editor of one section re-baseline a
       citation on any document, frozen or signed ones included, with no audit
       row (periodic review 2026-09-28, editor family, SEC-A-1). A cite_id from
       another section is "not found", and nothing is written. */
    const { cite_id } = req.body;
    const tenantId = getTenantId(req);
    const sectionId = String(req.params.sectionId);

    if (!cite_id) {
      return res.status(400).json({
        success: false,
        error: 'cite_id is required',
      });
    }

    // A REAL re-resolution. What was here before bumped `created_at` to NOW() and
    // returned sha256(cite_id + Date.now()) as the refreshed content hash — a
    // manufactured content identity on a regulated surface, and a created_at that
    // then claimed the citation had just been made. Nothing was re-read.
    //
    // Now: the checksum comes from the cited source row, created_at is left alone,
    // and the response says plainly whether the source's content moved. A citation
    // kind with no source system behind it gets an honest 409 rather than a
    // fabricated hash.
    const { refreshSourceCitation } = await import(
      '../services/clinical-regulatory-evidence/source-usage.service.js'
    );
    const outcome = await inTransaction(async (client) => {
      const refreshed = await refreshSourceCitation(tenantId, { sectionId, citationId: String(cite_id), userId: Number(getActorId(req)) }, client);
      if (refreshed.ok && refreshed.change) {
        await auditCitationWrite(req, client, {
          sectionId,
          operation: 'CITATION_REFRESHED',
          change: refreshed.change,
          reason: 'Source re-read: its checksum changed since the citation was recorded',
        });
      }
      return refreshed;
    });

    if (!outcome.ok) {
      const status = outcome.reason === 'not_found' ? 404 : 409;
      const message = citationRefreshRefusalMessage(outcome.reason);
      return res.status(status).json({ success: false, error: outcome.reason, message });
    }

    res.json({
      success: true,
      message: outcome.changed
        ? 'Source content has changed since this citation was made; the citation now records the current checksum.'
        : 'Re-read the source: its content is unchanged since this citation was made.',
      changed: outcome.changed,
      source_id: outcome.sourceId,
      previous_sha256: outcome.previousChecksum,
      sha256: outcome.currentChecksum,
    });
  } catch (error) {
    if (replyCitationAccessRefusal(res, error)) return;
    console.error('Error refreshing token:', error);
    return serverError(res, logger, 'saving refresh token', error);
  }
});

// ============= Step 8: Export Logging & Document-Level Features =============

// Helper function to ensure export history table exists with all required fields
// authoring_export_history is now provisioned by
// db/migrations/20260730_authoring_runtime_ddl.sql. Retained as a no-op so
// existing call sites need no change; the router no longer issues runtime DDL.
const ensureExportHistoryTableExists = async () => {};

// Helper: record export with comprehensive metadata — now
// services/authoring/authoring-export.ts logExport, shared with the vault filing.

// Helper: list tokens for a whole doc (with section metadata)
// Called only by GET /docs/:docId/diff-since-export. That endpoint could never
// reach this helper (it read a table nothing creates — ledger C-14), which is why
// two wrong column names survived here: authoring_sections has `code` and
// `doc_id`, never `section_number` or `document_id`. Now tenant-scoped too.
async function listDocTokens(docId: string | string[] | undefined, tenantId: number) {
  const result = await pool.query(
    `
    SELECT c.id, c.section_id, c.source, c.anchor, c.citation_text, c.reference_id, c.created_by, c.created_at, c.tenant_id, c.payload_sha256, c.frozen_at, s.code as section_code, s.title as section_title
    FROM authoring_citations c
    JOIN authoring_sections s ON s.id = c.section_id
    WHERE s.doc_id = $1 AND s.tenant_id = $2
    ORDER BY c.created_at ASC
  `,
    [docId, tenantId]
  );
  return result.rows;
}

// Note: computeDocHash function already exists above, reusing existing implementation

// List exports for a doc (latest first) - Enhanced with full history
router.get('/docs/:docId/exports', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);

    /* An unknown or cross-tenant docId used to return `exports: []` — the same
       answer as a real document nobody has exported yet. Those are opposite
       facts, and the second one is the whole point of the rail. Refuse instead.
       This also protects the hash below: computeDocHash walks the section rows
       and hashes the empty string when there are none, so an unguarded call
       would hand back sha256("") as if it described a document. */
    if (!(await documentExistsForTenant(req.params.docId, tenantId))) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }

    // Ensure table exists
    await ensureExportHistoryTableExists();

    // Get filter parameters from query
    const { start_date, end_date, export_type, limit = 100 } = req.query;

    let query = `
      SELECT
        id,
        document_id,
        export_type,
        exported_by,
        exported_at,
        file_name,
        file_size,
        doc_sha256,
        metadata,
        download_url,
        cached_until
      FROM authoring_export_history
      WHERE document_id = $1 AND tenant_id = $2
    `;

    const params: any[] = [req.params.docId, tenantId];
    let paramIndex = 3;

    // Add filters if provided
    if (start_date) {
      query += ` AND exported_at >= $${paramIndex}`;
      params.push(start_date);
      paramIndex++;
    }

    if (end_date) {
      query += ` AND exported_at <= $${paramIndex}`;
      params.push(end_date);
      paramIndex++;
    }

    if (export_type) {
      query += ` AND export_type = $${paramIndex}`;
      params.push(export_type);
      paramIndex++;
    }

    query += ` ORDER BY exported_at DESC LIMIT $${paramIndex}`;
    params.push(parseInt(limit as string) || 100);

    const result = await pool.query(query, params);

    // Get total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as total FROM authoring_export_history
       WHERE document_id = $1 AND tenant_id = $2`,
      [req.params.docId, tenantId]
    );

    /* Is the most recently exported file still the current document?
       `doc_sha256` on each row is computeDocHash at export time, so the same
       function now answers it for the live document and the two are directly
       comparable. Returned as the two hashes AND the derived verdict: the
       verdict is what a reader acts on, the hashes are what makes it checkable.

       `content_changed_since_last_export` is null — not false — when there is
       no export to compare against, or when the stored row carried no hash.
       "Nothing to compare" is not "nothing has changed", and a UI that renders
       the second for the first tells an author their stale file is current.

       Scope, stated because the verdict is narrower than it sounds: this
       compares section CODE and CONTENT in order. It says nothing about
       citations, attachments, or signatures — the citation drift that
       …/diff-since-export reports is a separate question with a separate
       answer. */
    const lastExport = result.rows[0] || null;
    const currentContentHash = await computeDocHash(req.params.docId, tenantId);
    const lastHash =
      typeof lastExport?.doc_sha256 === 'string' && lastExport.doc_sha256.length > 0
        ? lastExport.doc_sha256
        : null;

    res.json({
      success: true,
      exports: result.rows,
      total: parseInt(countResult.rows[0]?.total || '0'),
      last_export: lastExport,
      current_content_hash: currentContentHash,
      content_changed_since_last_export: lastHash === null ? null : lastHash !== currentContentHash,
    });
  } catch (error) {
    console.error('GET /docs/:id/exports', error);
    res.status(500).json({ success: false, error: 'Failed to list exports' });
  }
});

// DELETE /api/authoring/export-history/:id - Delete export history entry
router.delete('/export-history/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const tenantId = getTenantId(req);
    /* SECURITY (21 CFR Part 11): DELETING a filing's export-history record is a
       governed action and must be attributed to the VERIFIED principal. This
       read `x-user-email || 'system'` — a header the router's middleware clears,
       falling through to the anonymous 'system' that is nobody, and the value
       drove BOTH the permission check (`entry.exported_by !== userEmail`) and
       the EXPORT_HISTORY_DELETED audit event. Use getActorEmail, the JWT-derived
       accessor every other governed mutation here uses, and fail closed when the
       token carries no identity rather than record a record-deletion against
       'system'. */
    const userEmail = getActorEmail(req);
    if (!userEmail) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Check if user has permission (only QA or the original exporter can delete)
    const roles = ((req.headers as any)['x-roles'] || '').toString().toUpperCase();
    const isQA = roles.includes('QA');

    // Get the export entry
    const exportEntry = await pool.query(
      `SELECT exported_by, document_id FROM authoring_export_history
       WHERE id = $1 AND tenant_id = $2`,
      [id, tenantId]
    );

    if (((exportEntry.rowCount ?? 0) === 0)) {
      return res.status(404).json({ error: 'Export entry not found' });
    }

    const entry = exportEntry.rows[0];

    // Check permission
    if (!isQA && entry.exported_by !== userEmail) {
      return res.status(403).json({
        error: 'Permission denied. Only QA or the original exporter can delete this entry.',
      });
    }

    // Delete the entry
    await pool.query(`DELETE FROM authoring_export_history WHERE id = $1 AND tenant_id = $2`, [
      id,
      tenantId,
    ]);

    // Log the deletion
    await createAuditTrail(req, entry.document_id, null, 'EXPORT_HISTORY_DELETED', null, null, null, {
      export_id: id,
      deleted_by: userEmail,
    });

    res.json({ success: true, message: 'Export history entry deleted successfully' });
  } catch (error) {
    console.error('DELETE /export-history/:id', error);
    res.status(500).json({ error: 'Failed to delete export history entry' });
  }
});

// Diff since latest export = tokens created/updated after export timestamp
router.get('/docs/:docId/diff-since-export', async (req: Request, res: Response) => {
  try {
    // Reads authoring_export_history — the table recordExport() actually writes.
    // This previously read `doc_exports`, which no migration and no runtime DDL
    // in this repo creates, so the query threw "relation does not exist" and the
    // catch below turned every call into a 500. See ledger C-14.
    await ensureExportHistoryTableExists();
    const tenantId = getTenantId(req);
    /* Same guard as GET …/exports, for the same reason: an unknown or
       cross-tenant docId answered `{ baseline: null, changed: [] }`, which is
       the response a real document with no export yet gets. Those are opposite
       facts. Nothing surfaces the difference today — the Exports rail renders
       citation drift only when `baseline` is non-null — but a future caller
       reading "no exports" for a document it cannot see is a defect waiting on
       a caller, which is precisely how the rest of this router accumulated its
       silent 500s. */
    if (!(await documentExistsForTenant(req.params.docId, tenantId))) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }
    const lastExportResult = await pool.query(
      // Export history stores wall-clock TIMESTAMP; citations use TIMESTAMPTZ.
      // Resolve the export in the database's timezone before the driver turns
      // it into a JS Date. Otherwise host/DB timezone differences invent drift.
      `
      SELECT COALESCE(exported_at, created_at)::timestamptz AS exported_at
      FROM authoring_export_history
      WHERE document_id = $1 AND tenant_id = $2
      ORDER BY COALESCE(exported_at, created_at) DESC LIMIT 1
    `,
      [req.params.docId, tenantId]
    );

    if (((lastExportResult.rowCount ?? 0) === 0)) {
      return res.json({ baseline: null, changed: [] });
    }

    const lastExport = lastExportResult.rows[0];
    const tokens = await listDocTokens(req.params.docId, tenantId);
    const t0 = new Date(lastExport.exported_at).getTime();
    const changed = tokens.filter(t => new Date(t.created_at).getTime() > t0);

    res.json({
      baseline: lastExport.exported_at,
      count: changed.length,
      changed,
    });
  } catch (error) {
    console.error('GET /docs/:id/diff-since-export', error);
    res.status(500).json({ error: 'Diff failed' });
  }
});

// Refresh ALL source citations in a document (skips frozen).
//
// This handler was broken three ways at once, which is part of why nothing ever
// noticed the refresh it drove was simulated:
//   1. `WHERE document_id = $1` — the column is `doc_id`, so every call raised
//      42703 and returned 500. The endpoint had never once succeeded.
//   2. Neither query filtered `tenant_id`, so had it worked it would have walked
//      another tenant's sections and citations.
//   3. It re-entered the API over HTTP against its own host with no Authorization
//      header, so each inner call would have failed the JWT gate anyway.
// Now: one tenant-scoped read, and a direct service call per citation.
//
// The whole batch is one transaction with an audit row per citation whose
// checksum moved (P11-A-1), so a failure part-way re-reads nothing — which is
// what the workbench tells the author ("Nothing was changed"). A sealed
// document is refused here as well as at the gateway, as the section routes
// refuse it in the router's own guard.
router.post('/docs/:docId/refresh-all', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const docId = String(req.params.docId);
    const { refreshSourceCitation } = await import(
      '../services/clinical-regulatory-evidence/source-usage.service.js'
    );

    const result = await inTransaction(async (client) => {
      const lock = await checkDocumentWritable(client, docId, tenantId);
      if (!lock.writable) return { done: false as const, lock };

      const cites = await client.query(
        `SELECT c.id AS cite_id, c.section_id
           FROM authoring_citations c
           JOIN authoring_sections s ON s.id = c.section_id AND s.tenant_id = c.tenant_id
          WHERE s.doc_id = $1 AND c.tenant_id = $2 AND c.frozen_at IS NULL
          ORDER BY c.created_at ASC`,
        [docId, tenantId]
      );

      let refreshed = 0;
      let changed = 0;
      const skipped: Array<{ cite_id: string; reason: string }> = [];
      for (const cite of cites.rows as Array<{ cite_id: string; section_id: string }>) {
        const sectionId = String(cite.section_id);
        const outcome = await refreshSourceCitation(tenantId, { sectionId, citationId: String(cite.cite_id), userId: Number(getActorId(req)) }, client);
        if (!outcome.ok) {
          // Reported, not silently counted as refreshed. A citation with no source
          // behind it is exactly what the caller needs to see.
          skipped.push({ cite_id: cite.cite_id, reason: outcome.reason });
          continue;
        }
        refreshed++;
        if (outcome.change) {
          changed++;
          await auditCitationWrite(req, client, {
            sectionId,
            operation: 'CITATION_REFRESHED',
            change: outcome.change,
            reason: 'Source re-read: its checksum changed since the citation was recorded',
          });
        }
      }
      return { done: true as const, refreshed, changed, skipped };
    });

    if (!result.done) {
      return res
        .status(result.lock.code === 'DOCUMENT_FROZEN' ? 403 : 404)
        .json({ error: result.lock.code, message: result.lock.reason });
    }
    res.json({ ok: true, refreshed: result.refreshed, changed: result.changed, skipped: result.skipped });
  } catch (error) {
    if (replyCitationAccessRefusal(res, error)) return;
    console.error('POST /docs/:id/refresh-all', error);
    res.status(500).json({ error: 'Refresh-all failed' });
  }
});

// Step 8: export logging — DONE. POST /docs/:docId/export calls logExport() after
// generating the file, so the record carries the real file name and size.

// ============= Step 10: Templates API =============

// Helper function to get templates directory
function templatesDir() {
  return path.join(process.cwd(), 'server', 'templates', 'm3');
}

// Load templates from disk
function loadTemplates(locale: string | null) {
  const dir = templatesDir();
  if (!fs.existsSync(dir)) return [];

  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  const templates = [];

  for (const file of files) {
    try {
      const content = fs.readFileSync(path.join(dir, file), 'utf8');
      const template = JSON.parse(content);

      // Filter by locale if specified
      if (!locale || (Array.isArray(template.locale) && template.locale.includes(locale))) {
        templates.push(template);
      }
    } catch (e) {
      console.warn('Template parse failed:', file, e);
    }
  }

  return templates;
}
// POST /api/authoring/docs/:docId/apply-template - Apply template to document
router.post('/docs/:docId/apply-template', async (req: Request, res: Response) => {
  try {
    const { templateKey, mode = 'merge' } = req.body || {};
    const tenantId = getTenantId(req);

    if (!templateKey) {
      return res.status(400).json({ error: 'templateKey required' });
    }

    // Get document locale — tenant-scoped. The section writes below were
    // already scoped; this read was the one predicate-free query left in the
    // handler, and 404-vs-200 on it confirmed whether a guessed document UUID
    // exists in another organization (plus that document's locale).
    const docResult = await pool.query(
      'SELECT locale FROM authoring_documents WHERE id = $1 AND tenant_id = $2',
      [req.params.docId, tenantId]
    );

    if (((docResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({ error: 'Document not found' });
    }

    const locale = docResult.rows[0].locale || 'en';
    const template = loadTemplates(locale).find(x => x.templateKey === templateKey);

    if (!template) {
      return res.status(404).json({ error: 'Template not found for current locale' });
    }

    // COLUMN NAMES. authoring_sections is (id, doc_id, code, title, content,
    // order_index, track_changes, tenant_id, created_at, updated_at) — see
    // db/migrations/20260725_authoring_document_loop_tables.sql. There is no
    // ALTER TABLE for it anywhere, so that is the complete schema.
    //
    // This block used `document_id`, `order_idx`, `created_by` and `updated_by`:
    // four columns that do not exist. Every statement below was an
    // unconditional 42703, so applying a template has never once succeeded.
    // `order_idx` is the field name in the template JSON on disk, which is
    // where the confusion came from — it is not the column name.
    //
    // TENANCY. The SELECT and UPDATE also matched on document/section id alone.
    // Left unscoped, fixing only the column names would have converted a broken
    // statement into a working cross-tenant write — a template applied to
    // another tenant's document. tenantId is already resolved above; it is now
    // in every predicate.
    // `content` is selected as well as id/code because overwrite mode has to
    // snapshot what it is about to destroy — see the createRevision call below.
    const existingResult = await pool.query(
      'SELECT id, code, content FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2',
      [req.params.docId, tenantId]
    );

    const existingMap = new Map<string, { id: string; content: string | null }>(
      existingResult.rows.map(x => [x.code, { id: x.id, content: x.content ?? null }]),
    );

    let upserts = 0;

    /* Every content write below passes the lineage gate and lands a ledger
       revision, inside ONE transaction — the identical rule the interactive
       save, the AI accept and the revert follow. Template apply was the last
       content writer outside it: it wrote sections with no lineage and (for
       the insert branch) no revision at all, so a template-applied section
       had provenance for neither its words nor its arrival. */
    const applyActor = getActorId(req) ?? 'template';
    const txClient = await pool.connect();
    try {
    await txClient.query('BEGIN');
    /* 2026-09-23 (W5/D7, co-author final pass): the lock. Every other section
       writer consults document-lock.ts; this one did not, so any org member
       could overwrite (or add to) the sections of an APPROVED or FROZEN
       document — its seal then no longer matched and it could never be filed
       or re-sealed again. The document row is locked for the transaction, so
       a freeze or approval cannot land between this check and the writes. */
    await reserveWritableDocument(txClient, String(req.params.docId), tenantId);
    // Apply template sections
    for (const section of template.sections || []) {
      const existing = existingMap.get(section.code);
      const existingId = existing?.id;

      if (existingId && mode !== 'overwrite') {
        // In merge mode, skip existing sections
        continue;
      }

      if (existingId) {
        // PART 11. Overwrite mode replaces authored content with template
        // boilerplate. Every other content-changing path in this router
        // snapshots first via createRevision (the section PATCH at ~:1600, the
        // revert at ~:1784); this one did not, so applying a template in
        // overwrite mode destroyed an author's work with no recoverable
        // history.
        //
        // It went unnoticed because the whole handler was dead: it referenced
        // document_id/order_idx/created_by, none of which are columns, so every
        // statement was an unconditional 42703. Repairing those column names
        // made this path reachable for the first time — which makes closing
        // this gap part of that same change, not a follow-up.
        //
        // Snapshot before the UPDATE, not after: the point is to preserve the
        // superseded text.
        if (existing?.content) {
          await createRevision(existingId, existing.content, applyActor, tenantId, txClient, 'pre-template-snapshot');
        }

        // Update existing section
        const templContent = JSON.stringify(section.content || {});
        await txClient.query(
          `UPDATE authoring_sections
              SET title = $2, order_index = $3, content = $4, updated_at = NOW()
            WHERE id = $1 AND tenant_id = $5`,
          [
            existingId,
            section.title || '',
            section.order_idx || 0,
            templContent,
            tenantId,
          ]
        );
        await enforceAuthorLineage(
          txClient,
          tenantId,
          { documentTable: 'authoring_sections', documentId: String(existingId) },
          templContent,
          applyActor,
        );
        await createRevision(existingId, templContent, applyActor, tenantId, txClient, 'template-apply');
        upserts++;
      } else {
        // Insert new section
        const newSectionId = crypto.randomUUID();
        const templContent = JSON.stringify(section.content || {});
        await txClient.query(
          `INSERT INTO authoring_sections (id, doc_id, code, title, order_index, content, tenant_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [
            newSectionId,
            req.params.docId,
            section.code,
            section.title || '',
            section.order_idx || 0,
            templContent,
            tenantId,
          ]
        );
        await enforceAuthorLineage(
          txClient,
          tenantId,
          { documentTable: 'authoring_sections', documentId: newSectionId },
          templContent,
          applyActor,
        );
        await createRevision(newSectionId, templContent, applyActor, tenantId, txClient, 'template-apply');
        upserts++;
      }
    }
    await txClient.query('COMMIT');
    } catch (txErr) {
      await txClient.query('ROLLBACK').catch(() => {});
      throw txErr;
    } finally {
      txClient.release();
    }

    res.json({ ok: true, upserts });
  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('POST /docs/:id/apply-template', error);
    res.status(500).json({ error: 'Failed to apply template' });
  }
});

/* REMOVED: GET /guidance/compose — unreachable by construction since the day
   it was written. Express matches in registration order and GET
   /guidance/:sectionId registers ~3,600 lines earlier, so this path bound
   sectionId='compose'; that handler then ran `WHERE s.id = 'compose'` against
   a UUID column, which is a Postgres 22P02 on every call — a permanent 500.
   Even if it had been reachable, its body was a hardcoded two-entry guidance
   map presented as a guidance service. The real per-section guidance read is
   GET /guidance/:sectionId (section_guidance + template_guidance tables). */

/* POST /api/authoring/docs/:docId/seed-stability has been DELETED.
 *
 * It spawned `node scripts/seed-stability.mjs` from a request handler, with no
 * caller anywhere and no environment guard of any kind — so a UAT fixture
 * seeder, defaulting to product_code 'UAT-PROD' and study_code 'SS-UAT-001',
 * was reachable over HTTP by any authenticated user in any deployment
 * including production. CLAUDE.md's working agreement is explicit: no fixture
 * data in governed paths. This was the mechanism for putting it there.
 *
 * It was also broken in a way that would have hidden its own failures. The
 * handler ended with
 *
 *     process.on('error', …)
 *
 * — the GLOBAL Node process, not the spawned child. A child that failed to
 * start emits 'error' on `childProcess`, which nothing listened to, so the
 * request hung rather than answering; and every call added another permanent
 * listener to the global process, each closing over a response object long
 * since finished.
 *
 * scripts/seed-stability.mjs is KEPT. Its own header documents it as a command
 * an operator runs (`node scripts/seed-stability.mjs`), which is the right
 * shape for a seeder: a deliberate act at a terminal, not an endpoint on the
 * governed authoring API.
 */


/* ── DELETE /docs/:docId — the governed delete (DP-33, plan P1-30) ──────────
 *
 * This stood here as "UAT-only; admin-guarded": a static `x-admin-token`
 * header compared with the ADMIN_TOKEN environment variable authorised it, not the session;
 * the read and the DELETE carried no tenant predicate; and the record was an
 * auditService.logAction call with no actor and no organisation, best-effort,
 * on the pool, before a DELETE it could not roll back with. Whoever held the
 * one shared string was nobody the ledger could name (§11.10(d), (e), (g)).
 *
 * Now, like every other governed act in this router:
 *   - the session is the authority (this router's own JWT gate, then the
 *     object gate in front of it, which already resolves the document inside
 *     the caller's organisation);
 *   - the caller's role in THIS organisation, read from organization_users
 *     (resolveSignerOrgRole — the persisted membership, never the token's
 *     claim), is owner, admin or manager;
 *   - a reason is stated, and recorded as given;
 *   - the organisation's own document only, read FOR UPDATE: a foreign or
 *     unknown id is 404, saying nothing about other organisations;
 *   - a sealed record (FROZEN / APPROVED) is not deleted — its seal and any
 *     signature over it are evidence (§11.10(c)); nor is one with revision
 *     history, which the append-only ledger keeps; nor a draft that carries a
 *     signature (an AUTHOR or REVIEWER e-sign does not freeze), which would
 *     otherwise be left naming a record that is gone (§11.70) — so, in
 *     practice, what can be deleted is a document that never had a section or
 *     a signature: a mistaken create, a bare fixture;
 *   - the DELETE and the chained audit row naming the actor commit in one
 *     transaction, so neither can exist without the other.
 *
 * The x-admin-token path is removed, not kept beside this: two doors to one
 * act is the parallel path CLAUDE.md rules out. Its one caller,
 * scripts/cleanup-fixtures.mjs, now signs in like any other client. */
// P-18: an approver may do what a manager may (shared/constants/org-roles.ts).
const DOCUMENT_DELETE_ROLES: ReadonlySet<string> = new Set(withExtendingRoles(['owner', 'admin', 'manager']));

type GovernedDeleteOutcome =
  | { kind: 'deleted' }
  | { kind: 'not-found' }
  | { kind: 'sealed'; status: string }
  | { kind: 'has-history' }
  | { kind: 'signed' };

async function deleteAuthoringDocument(
  req: Request,
  docId: string,
  tenantId: number,
  reason: string,
): Promise<GovernedDeleteOutcome> {
  return inTransaction<GovernedDeleteOutcome>(async (client) => {
    const found = await client.query(
      `SELECT id, title, product_code, status, version FROM authoring_documents
        WHERE id = $1 AND tenant_id = $2 FOR UPDATE`,
      [docId, tenantId],
    );
    const doc = found.rows?.[0];
    if (!doc) return { kind: 'not-found' };
    const status = String(doc.status ?? '').toUpperCase();
    if (LOCKED_DOCUMENT_STATUSES.has(status)) return { kind: 'sealed', status };
    /* The revision ledger is append-only, enforced by a trigger
       (20260817_doc_revisions_immutable_ledger.sql), and the section cascade
       reaches it — every section has at least its genesis revision. Asked
       first, so the answer is an honest 409 rather than the trigger's
       exception surfacing as a 500 after the DELETE was attempted. */
    const history = await client.query(
      `SELECT 1 FROM doc_revisions r
         JOIN authoring_sections s ON s.id = r.section_id AND s.tenant_id = r.tenant_id
        WHERE s.doc_id = $1 AND s.tenant_id = $2 LIMIT 1`,
      [docId, tenantId],
    );
    if ((history.rowCount ?? 0) > 0) return { kind: 'has-history' };
    /* authoring_signatures has no foreign key to the document, so the DELETE
       would succeed and leave each signature bound to nothing. */
    const signed = await client.query(
      'SELECT 1 FROM authoring_signatures WHERE doc_id = $1 AND tenant_id = $2 LIMIT 1',
      [docId, tenantId],
    );
    if ((signed.rowCount ?? 0) > 0) return { kind: 'signed' };

    // What was removed, so the record outlives the row: the same section
    // digest the signatures store as content_hash.
    const contentHash = await computeDocHashOn(client, docId, tenantId);
    await client.query('DELETE FROM authoring_documents WHERE id = $1 AND tenant_id = $2', [docId, tenantId]);
    await writeChainedAuditRow(client, {
      tenantId,
      userId: getActorId(req) ?? undefined,
      action: 'authoring.document.delete',
      resourceType: 'authoring_document',
      resourceId: docId,
      ipAddress: (req.ip ?? undefined) as string | undefined,
      userAgent: req.headers['user-agent'] as string | undefined,
      details: {
        reason,
        actorEmail: getActorEmail(req),
        title: doc.title ?? null,
        productCode: doc.product_code ?? null,
        status: doc.status ?? null,
        version: doc.version ?? null,
        contentHash,
      },
    });
    return { kind: 'deleted' };
  });
}

/** The answer to a delete that did not happen — what is kept, and why. */
function governedDeleteRefusal(
  outcome: Exclude<GovernedDeleteOutcome, { kind: 'deleted' }>,
): { status: number; body: { error: string; code?: string } } {
  switch (outcome.kind) {
    case 'not-found':
      return { status: 404, body: { error: 'Document not found' } };
    case 'sealed':
      return {
        status: 409,
        body: {
          error: `Not deleted — the document is ${outcome.status}. A sealed record and the signatures over it are kept.`,
          code: 'AUTHORING_DOCUMENT_SEALED',
        },
      };
    case 'has-history':
      return {
        status: 409,
        body: {
          error:
            'Not deleted — the document has revision history, and the revision ledger is append-only (21 CFR Part 11 §11.10(e)). Only a document with no sections can be deleted.',
          code: 'AUTHORING_DOCUMENT_HAS_HISTORY',
        },
      };
    case 'signed':
      return {
        status: 409,
        body: {
          error:
            'Not deleted — the document carries an electronic signature, and a signature is kept with the record it signs (21 CFR Part 11 §11.70).',
          code: 'AUTHORING_DOCUMENT_SIGNED',
        },
      };
  }
}

router.delete('/docs/:docId', async (req: Request, res: Response) => {
  try {
    const docId = String(req.params.docId ?? '');
    const actorId = getActorId(req);
    if (!actorId || !getActorEmail(req)) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    const tenantId = getTenantId(req);

    // The role first: a caller who may not delete learns nothing about the
    // document, and is not asked for a reason it cannot use.
    const role = await resolveSignerOrgRole(Number(actorId), tenantId);
    if (!role || !DOCUMENT_DELETE_ROLES.has(role)) {
      return res.status(403).json({
        error: 'Deleting an authoring document needs the owner, admin or manager role in this organization.',
        code: 'AUTHORING_DELETE_NOT_PERMITTED',
      });
    }

    const reasonVerdict = requireGovernedReason(req.body?.reason);
    if (!reasonVerdict.ok) return res.status(400).json({ error: reasonVerdict.error, field: 'reason' });

    if (!isUuid(docId)) return res.status(404).json({ error: 'Document not found' });

    const outcome = await deleteAuthoringDocument(req, docId, tenantId, reasonVerdict.reason);
    if (outcome.kind === 'deleted') return res.json({ ok: true, deleted: docId });
    const refusal = governedDeleteRefusal(outcome);
    return res.status(refusal.status).json(refusal.body);
  } catch (error) {
    return serverError(res, logger, 'deleting the authoring document', error);
  }
});

/* POST and GET /docs/:docId/permissions have been DELETED from this router.
 *
 * They were UNREACHABLE. server/bootstrap/register-inline-routes.ts mounts
 * authoringPermissionsRouter on '/api' at line 312 — BEFORE this router is
 * mounted on '/api/authoring' at 319 — and that router registers
 * '/authoring/docs/:docId/permissions' with the prefix baked in, so it owns the
 * same full path and never calls next(). Express matched it first, every time.
 * These two handlers had never run.
 *
 * They were also a divergent second implementation of a governed capability.
 * What the canonical one in authoring-permissions.ts does that these did not:
 * an explicit permission-manager authorization gate, a reason-for-change, an
 * expiry (validUntil), structured error codes, and — the one that matters most
 * here — recordPermissionAudit on grant and revoke. The legacy POST below wrote
 * a bare INSERT INTO doc_permissions with NO audit row and no ON CONFLICT, and
 * there was no revoke at all.
 *
 * Worth naming what this cost, because it is the argument for deleting rather
 * than leaving dead code in place: the deleted POST carried a careful C2C-AUTHOR-002
 * tenant-scoping fix — a role allowlist, a document-in-tenant check, a
 * section-belongs-to-this-document check, each with its own 404 and an
 * explanatory comment. That work was written into a route Express never reaches,
 * and anyone reading it would reasonably believe those guards were in force. The
 * canonical router's requirePermissionManager does the same scoping properly
 * (resolveAuthoringDocumentScope against the verified tenant, 404 on a miss), so
 * nothing is lost by removing them — but a reader's confidence was.
 */

// ============= EXPORT Operations =============

function exportFailureVerdict(recordConfirmed: boolean, recordAttempted: boolean) {
  if (recordConfirmed) return {
    code: 'EXPORT_DELIVERY_FAILED',
    message: 'The export was recorded, but file delivery could not be completed. Check export history before retrying; retrying creates another export record.',
  };
  if (recordAttempted) return {
    code: 'EXPORT_OUTCOME_UNKNOWN',
    message: 'We cannot confirm whether the export was recorded. Check export history before retrying.',
  };
  return {
    code: 'EXPORT_NOT_RECORDED',
    message: 'The export could not be completed. No export was recorded. Retry after resolving the failure.',
  };
}

/** Converter refusals apply only before a write/delivery outcome can be uncertain. */
function sendPdfRenderingFailure(error: unknown, res: Response): boolean {
  if (respondIfConverterBusy(res, error)) return true;
  if (!(error instanceof AuthoringPdfRenderingError)) return false;
  res.status(error.status).json({ error: 'PDF rendering unavailable', code: error.code, message: error.message });
  return true;
}

function sendExportFailure(error: unknown, res: Response, recordConfirmed: boolean, recordAttempted: boolean): void {
  if (workflowGovernanceReply(error, res)) return;
  if (error instanceof SavedDraftSourceError) {
    res.status(409).json({ error: 'Saved source references require review', code: error.code, message: error.message });
    return;
  }
  // The caught detail belongs in the log; the client receives the receipt verdict.
  console.error('Export error:', error);
  if (res.headersSent) { res.destroy(); return; }
  res.removeHeader('Content-Disposition');
  res.removeHeader('Content-Type');
  res.removeHeader('Content-Length');
  if (!recordAttempted && !recordConfirmed && sendPdfRenderingFailure(error, res)) return;
  res.status(500).json({ error: 'Export failed', ...exportFailureVerdict(recordConfirmed, recordAttempted) });
}

// POST /api/authoring/docs/:docId/export - Export document in various formats
router.post('/docs/:docId/export', async (req: Request, res: Response) => {
  // Rendering, recording, and delivering are different outcomes. Once the
  // INSERT is sent its reply can be lost after persistence; a delivery failure
  // cannot undo a confirmed export or its history baseline.
  let recordAttempted = false;
  let recordConfirmed = false;
  try {
    const { docId } = req.params;
    const { format = 'docx', options = {} } = req.body;
    const tenantId = getTenantId(req);
    /* SECURITY (21 CFR Part 11): the exporter recorded on the EXPORT audit row
       and in the export ledger must come from the verified JWT — never from
       `req.body.exported_by`, which the caller controls. */
    const exportedBy = getActorEmail(req);
    if (!exportedBy) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Validate format
    if (!EXPORT_FORMATS.includes(format)) {
      return res.status(400).json({ error: 'Invalid format. Must be docx, pdf, or xml' });
    }

    // Get document and sections
    const docResult = await pool.query(
      "SELECT id, title, module, product_code, locale, status, created_at, updated_at, created_by, template_id, submitted_at, current_workflow_id, approved_at, frozen_at, locked_at, locked_by, tenant_id, version, to_jsonb(authoring_documents)->'provenance' AS provenance, to_jsonb(authoring_documents)->>'client_program_id' AS client_program_id FROM authoring_documents WHERE id = $1 AND tenant_id = $2",
      [docId, tenantId]
    );

    if (((docResult.rowCount ?? 0) === 0)) {
      return res.status(404).json({ error: 'Document not found' });
    }

    const doc = docResult.rows[0];

    /* SECURITY (21 CFR Part 11 §11.50): EXPORT IS A FILING ARTIFACT, NOT A
       PREVIEW — gate it on the record being sealed. A DRAFT / IN_REVIEW
       document has no immutable snapshot and no certified signature manifest,
       so exporting it byte-for-byte like an approved one would present
       whatever reviewer signatures exist as certifying a final record nobody
       approved. Fail closed: refuse unless the document is in a LOCKED/sealed
       state — the same canonical LOCKED_DOCUMENT_STATUSES set the write gate
       uses, plus an explicit locked_at. 409 says the document's state — not
       the caller's authority — forbids the action. Freeze or approve it first.
       (The project-vault filing of a working draft is a different act and says
       so on page one; see POST /docs/:docId/file-to-vault.) */
    const sealedForExport =
      LOCKED_DOCUMENT_STATUSES.has(String(doc.status ?? '').toUpperCase()) ||
      doc.locked_at != null;
    if (!sealedForExport) {
      return res.status(409).json({
        error: 'Document not approved for export',
        message:
          `Only an approved or frozen document can be exported as a 21 CFR Part 11 filing artifact. ` +
          `This document is still editable (status: ${doc.status ?? 'unknown'}) — it has no immutable ` +
          `snapshot and no certified electronic-signature manifest. Freeze or approve it first.`,
      });
    }

    const sectionsResult = await pool.query(
      'SELECT id, doc_id, code, title, content, order_index, track_changes, created_at, updated_at, tenant_id FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2 ORDER BY order_index, created_at, id',
      [docId, tenantId]
    );

    const exportId = crypto.randomUUID();
    /* The digest of the rows about to be rendered — one read, so the hash on
       the export record, the manifest's verdicts and the refusal below all
       describe the same content. Same function the signing routes store as
       content_hash (sectionsDigest via computeDocHash). */
    const fileHash = sectionsDigest(sectionsResult.rows);

    // The export record is written by logExport() AFTER the file is generated,
    // so file_name and file_size are the real ones (ledger C-14).

    /* §11.70 — a sealed record's signatures have to cover it.

       Narrow on purpose. A signature that does not match is usually NOT a
       fault: an AUTHOR signature does not lock the document, so the ordinary
       flow (author signs, editing continues, approver signs the final text)
       leaves the author's signature legitimately covering earlier content, and
       the manifest says so per signature. What cannot be right is a document
       this route has already required to be sealed (above) carrying signatures
       of which NOT ONE covers the content being filed: the content moved after
       it was sealed, and the manifest would attest to a record nobody signed.

       Checked BEFORE the EXPORT audit event, so a refusal leaves no record of
       an export that never happened. */
    const exportSignatures = await readSignaturesForExport(pool, String(docId), tenantId);
    if (exportSignatures.length > 0 && !anySignatureCovers(exportSignatures, fileHash)) {
      return res.status(409).json({
        error: 'Signatures do not cover this document',
        code: 'SIGNATURE_CONTENT_MISMATCH',
        message:
          'Every signature on this document was applied to different content than the ' +
          'sections it now contains, so none of them covers what would be exported. ' +
          'Exporting would produce a filing whose signature manifestation attests to a ' +
          'record it does not contain (21 CFR 11.70). Re-sign the document as it now ' +
          'stands, or restore the content that was signed.',
        exportedContentHash: fileHash,
        signatureCount: exportSignatures.length,
      });
    }

    // Source-linked renditions reserve current versions before their EXPORT
    // event and keep them stable through rendering and receipt commit.
    const rendered = await withSavedDraftSourceReservation(doc, pool, tenantId, async executor => {
      const current = await lockedSigningContent(executor, req, String(docId), tenantId);
      if (sectionsDigest(current.sections) !== fileHash) throw new WorkflowImportGovernanceError(409, 'DOCUMENT_CHANGED_DURING_EXPORT', 'The content changed before export; review the current document and retry.');
      await assertWorkflowImportRelease(executor, current);
      /* The rendering — the §11.50(b) manifest, figures, cross-references,
         citations and captions resolved once, and the XML / DOCX / PDF branches —
         is services/authoring/authoring-export.ts renderAuthoringExport, shared
         with the project-vault filing so the two cannot drift. */
      const output = await renderAuthoringExport({
        executor,
        tenantId,
        doc,
        sections: sectionsResult.rows,
        format,
        signatures: exportSignatures,
        actor: { id: String(getActorId(req) ?? ''), email: exportedBy },
      });

      // A converter refusal is not a successful export. For an ordinary manual
      // document the source reservation calls work(pool) without a transaction,
      // so even its EXPORT audit must wait until rendering has succeeded.
      await createAuditTrail(req, docId, null, 'EXPORT', null, null, null, { format, exportId, options }, executor);

      /* §11.10(b): the record carries a hash of the SOURCE section rows
         (doc_sha256, for content_changed_since_last_export) AND of the DELIVERED
         ARTIFACT BYTES (artifactSha256), so it can attest that a re-download is
         the identical artifact. */
      recordAttempted = true;
      await logExport(executor, {
        docId: String(docId),
        format,
        docSha256: fileHash,
        exportedBy: exportedBy as string,
        fileName: output.fileName,
        fileSize: output.fileContent.length,
        // Keep the actual rendering and delivered-byte hash in export history.
        // Authoring PDFs require the rich Word converter; they have no fallback.
        metadata: { options, exportId, artifactSha256: output.artifactSha256, rendering: output.rendering },
        tenantId,
      });
      return output;
    }, { id: String(getActorId(req) ?? ''), email: exportedBy });
    recordConfirmed = true;

    res.setHeader('Content-Type', rendered.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${rendered.fileName}"`);
    // The body is the file, so the rendering travels as a header the client reads.
    res.setHeader('X-Export-Rendering', rendered.rendering);
    res.send(rendered.fileContent);
  } catch (error) {
    sendExportFailure(error, res, recordConfirmed, recordAttempted);
  }
});

// POST /api/authoring/docs/:docId/working-copy — an uncontrolled working copy
// (docs/design/ONE_ANA_ONE_CANVAS.md §4.5, slice 7; a CPO decision under the
// founder's delegation of 2026-10-07: "I want to be able to pull them down and
// see them and work with them").
//
// A different act from the export above, and it must never pass for it:
//  - any status: a draft is exactly what a person wants to read away from the
//    screen, and the export refuses it (409) because it is a filing artifact;
//  - "DRAFT — uncontrolled copy" in the header and footer of EVERY page, with
//    the document id, version, status, time and who downloaded it;
//  - no §11.50(b) signature manifestation, so no copy of a draft can say a
//    signature covers it;
//  - DOCX or PDF only; the file name says "working_copy";
//  - one audited row (WORKING_COPY: format, version, status, the delivered
//    bytes' SHA-256), committed BEFORE the bytes leave; when it cannot be
//    written the answer is 503 and nothing is sent;
//  - no export-history row: the Exports tab lists controlled acts only, and
//    "changed since last export" is not re-baselined by a working copy.
// POST, not GET: the CSRF middleware skips GET, and a download that writes an
// audit row must not be triggerable from another site.
const WORKING_COPY_FORMATS = ['docx', 'pdf'] as const;
router.post('/docs/:docId/working-copy', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const format = String(req.body?.format ?? 'docx');
    const tenantId = getTenantId(req);
    const downloadedBy = getActorEmail(req);
    if (!downloadedBy) return res.status(401).json({ error: 'Authentication required' });
    if (!(WORKING_COPY_FORMATS as readonly string[]).includes(format)) {
      return res.status(400).json({ error: 'Invalid format. A working copy is docx or pdf', code: 'WORKING_COPY_FORMAT' });
    }
    const docResult = await pool.query(
      "SELECT id, title, module, status, created_at, version, tenant_id, to_jsonb(authoring_documents)->'provenance' AS provenance, to_jsonb(authoring_documents)->>'client_program_id' AS client_program_id FROM authoring_documents WHERE id = $1 AND tenant_id = $2",
      [docId, tenantId],
    );
    if ((docResult.rowCount ?? 0) === 0) return res.status(404).json({ error: 'Document not found' });
    const doc = docResult.rows[0];
    const sectionsResult = await pool.query(
      'SELECT id, code, title, content, order_index FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2 ORDER BY order_index, created_at, id',
      [docId, tenantId],
    );
    const at = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
    const status = String(doc.status ?? 'DRAFT').toUpperCase();
    const banner =
      `DRAFT — uncontrolled copy · not a controlled record · ${doc.id} · v${doc.version ?? 1} · ${status} · ` +
      `downloaded ${at} by ${downloadedBy}`;
    const rendered = await withSavedDraftSourceReservation(doc, pool, tenantId, (executor) =>
      renderAuthoringExport({
        executor,
        tenantId,
        doc,
        sections: sectionsResult.rows,
        format: format as ExportFormat,
        workingCopy: { banner },
        actor: { id: String(getActorId(req) ?? ''), email: downloadedBy },
      }),
      { id: String(getActorId(req) ?? ''), email: downloadedBy },
    );
    /* Recorded before anything leaves, inside a transaction so a failed write
       throws (a standalone audit write is best-effort outside production). */
    try {
      await inTransaction((client) =>
        createAuditTrail(req, docId, null, 'WORKING_COPY', null, null, null, {
          format,
          version: doc.version ?? null,
          status,
          fileName: rendered.fileName,
          artifactSha256: rendered.artifactSha256,
          contentSha256: sectionsDigest(sectionsResult.rows),
          downloadedAt: at,
        }, client),
      );
    } catch (auditError) {
      console.error('Working copy not recorded:', auditError);
      return res.status(503).json({
        error: 'The working copy could not be recorded, so it was not sent',
        code: 'WORKING_COPY_NOT_RECORDED',
      });
    }
    res.setHeader('Content-Type', rendered.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${rendered.fileName}"`);
    res.setHeader('X-Artifact-Sha256', rendered.artifactSha256);
    return res.send(rendered.fileContent);
  } catch (error) {
    if (error instanceof SavedDraftSourceError) {
      return res.status(409).json({ error: 'Saved source references require review', code: error.code, message: error.message });
    }
    if (sendPdfRenderingFailure(error, res)) return;
    return serverError(res, logger, 'rendering a working copy', error);
  }
});

// POST /api/authoring/docs/:docId/file-to-vault — render (the export renderer),
// ingest (the vault ingest service, in-process), file (the project-vault
// filing service) and record ONE governed action (WM, 2026-09-21).
//
// body { format: 'pdf' | 'docx', folderId?, documentType? }
// → 201 { data: { vaultDocumentId, version, supersedesDocumentId, folder, sha256, format } }
// 409 DOCUMENT_HAS_NO_PROGRAM / DOCUMENT_MID_FREEZE; the ingest's own refusals
// (400/403/409/503) pass through with their codes. Only a proven new admission
// can be compensated; uncertain transaction/cleanup outcomes require review
// of current Vault records (OUTCOME_UNKNOWN). Existing versions are retained.
router.post('/docs/:docId/file-to-vault', async (req: Request, res: Response) => {
  try {
    const tenantId = authedOrgId(req);
    if (tenantId == null) {
      return res.status(403).json({ success: false, error: { code: 'TENANT_REQUIRED', message: 'Tenant context required' } });
    }
    const actorId = getActorId(req);
    if (!actorId) {
      return res.status(401).json({ success: false, error: { code: 'AUTH_REQUIRED', message: 'Authentication required' } });
    }
    const body = (req.body ?? {}) as Record<string, unknown>;
    const format = typeof body.format === 'string' ? body.format.trim().toLowerCase() : '';
    if (!(VAULT_FILE_FORMATS as readonly string[]).includes(format)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_FORMAT', message: `format must be one of: ${VAULT_FILE_FORMATS.join(', ')}` },
      });
    }
    if (body.folderId !== undefined && body.folderId !== null && !isPlausibleFolderId(body.folderId)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_FOLDER', message: 'folderId must be a vault folder id (a short slug).' },
      });
    }
    const outcome = await fileAuthoringDocumentToVault({
      ...createContext(req, tenantId, actorId),
      docId: String(req.params.docId),
      format: format as VaultFileFormat,
      folderId: typeof body.folderId === 'string' ? body.folderId : null,
      documentType: typeof body.documentType === 'string' ? body.documentType : null,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'] as string | undefined,
    });
    if (outcome.kind === 'refused') {
      return res.status(outcome.status).json({ success: false, error: { code: outcome.code, message: outcome.error } });
    }
    res.status(201).json({
      success: true,
      data: {
        vaultDocumentId: outcome.vaultDocumentId,
        version: outcome.version,
        supersedesDocumentId: outcome.supersedesDocumentId,
        folder: outcome.folder,
        sha256: outcome.sha256,
        format: outcome.format,
        fileName: outcome.fileName,
        programId: outcome.programId,
        sealed: outcome.sealed,
        // FD5 (c): whether the Authoring approval carried to this Vault version, and why not.
        approval: outcome.approval,
      },
    });
  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('File-to-vault error:', error);
    return serverError(res, logger, 'filing to vault', error, { docId: req.params.docId });
  }
});

// This endpoint is replaced by the enhanced version above

// ============= SUBMIT Operations =============

/** Formal review state, workflow steps and the audit row share one transaction.
 *
 * 2026-10-17 (D2, document store consolidation step 6): this is the review's
 * only record. The submit used to project the document into
 * concept2cure_artifacts afterwards (services/ana/authoring-canonical-bridge.ts,
 * through the AnA document spine): an artifact set to 'review' that no later
 * approval or rejection ever moved, versioned as an AnA Document Studio
 * generation. No reader keyed on it; the Review board and Tasks read this
 * workflow (services/review/authoring-review-board.ts). A filed Vault version's
 * lifecycle is canonical_documents. So the projection is not written, and its
 * retry (`retry_canonical`) is refused by name. Rows written before stay. */
async function submitReviewWorkflow(
  req: Request, docId: string, tenantId: number,
  steps: Array<{ role: string; approver_email: string }>,
  reason: string | null,
) {
  return inTransaction(async (client) => {
    const result = await client.query(
      'SELECT id, status, current_workflow_id FROM authoring_documents WHERE id = $1 AND tenant_id = $2 FOR UPDATE',
      [docId, tenantId],
    );
    const doc = result.rows[0];
    if (!doc) return { done: false as const, status: 404, error: 'Document not found' };
    if (doc.status !== 'DRAFT' && doc.status !== 'draft') {
      return { done: false as const, status: 400, error: 'Document must be in DRAFT status to submit' };
    }
    const workflowId = crypto.randomUUID();
    for (const [i, step] of steps.entries()) {
      await client.query(
        `INSERT INTO authoring_workflow_steps
         (workflow_id, doc_id, step_no, role, approver_email, status, tenant_id, created_at)
         VALUES ($1,$2,$3,$4,$5,'PENDING',$6,NOW())`,
        [workflowId, docId, i + 1, step.role, step.approver_email, tenantId],
      );
    }
    await client.query(
      `UPDATE authoring_documents SET status='IN_REVIEW', submitted_at=NOW(), current_workflow_id=$1
       WHERE id=$2 AND tenant_id=$3`, [workflowId, docId, tenantId],
    );
    await createAuditTrail(req, docId, null, 'SUBMIT', null, null, reason, { workflowId, steps }, client);
    return { done: true as const, workflowId, steps: steps.length };
  });
}

// POST /api/authoring/docs/:docId/submit - Submit for review (the approval chain).
router.post('/docs/:docId/submit', async (req: Request, res: Response) => {
  try {
    const docId = String(req.params.docId);
    const tenantId = getTenantId(req);
    if (!getActorEmail(req)) return res.status(401).json({ error: 'Authentication required' });
    if (req.body?.retry_canonical !== undefined) {
      return res.status(410).json({ success: false, error: {
        code: 'CANONICAL_PROJECTION_RETIRED',
        message: 'A review is no longer copied into the artifact store, so there is nothing to retry. The review is the document\'s workflow: GET /api/authoring/docs/:docId/workflow.',
      } });
    }
    const statedReason = optionalGovernedReason(req.body?.reason);
    if (!statedReason.ok) return res.status(400).json({ success: false, error: statedReason.error, field: 'reason' });
    const steps = req.body?.workflow_steps ?? [{ role: 'QA' }, { role: 'RA_CMC' }];
    if (!Array.isArray(steps) || steps.length === 0) return res.status(400).json({ error: 'workflow_steps must be a non-empty array' });
    const invalid = steps.findIndex((s) => typeof s?.role !== 'string' || !s.role.trim() ||
      typeof s?.approver_email !== 'string' || !s.approver_email.trim());
    if (invalid >= 0) return res.status(400).json({ error: `Workflow step ${invalid + 1} needs a role and approver_email` });
    const workflow = await submitReviewWorkflow(req, docId, tenantId, steps, statedReason.reason);
    if (!workflow.done) return res.status(workflow.status).json({ error: workflow.error });
    return res.json({
      success: true, reviewSubmitted: true, message: 'Document submitted for review',
      workflowId: workflow.workflowId, steps: workflow.steps,
      // Where this review's state is read from: the one record, named.
      reviewRecord: { store: 'authoring_workflow_steps', documentStatus: 'IN_REVIEW', workflowId: workflow.workflowId, steps: workflow.steps },
    });
  } catch (error) {
    return serverError(res, logger, 'submitting docs', error);
  }
});

// GET /api/authoring/docs/:docId/workflow - Get current workflow status
router.get('/docs/:docId/workflow', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const tenantId = getTenantId(req);

    // Get current workflow ID from document
    const docResult = await pool.query(
      'SELECT current_workflow_id FROM authoring_documents WHERE id = $1 AND tenant_id = $2',
      [docId, tenantId]
    );

    if (((docResult.rowCount ?? 0) === 0) || !docResult.rows[0].current_workflow_id) {
      return res.json({ success: true, workflow: null });
    }

    const workflowId = docResult.rows[0].current_workflow_id;

    const stepsResult = await pool.query(
      `SELECT workflow_id, doc_id, step_no, role, approver_email, status, decision_note, decided_at, created_at, tenant_id FROM authoring_workflow_steps
       WHERE workflow_id = $1 AND tenant_id = $2
       ORDER BY step_no`,
      [workflowId, tenantId]
    );

    res.json({ success: true, workflowId, steps: stepsResult.rows });
  } catch (error) {
    console.error('Error getting workflow:', error);
    res.status(500).json({ error: 'Failed to get workflow status' });
  }
});

interface ApproveBoundSectionsInput {
  /** The signing handler's OPEN transaction — the one that writes the signature. */
  client: Queryable;
  /** authoring_documents.id that the approval signature was applied to. */
  authoringDocId: string;
  /** Verified tenant. */
  tenantId: number;
  /** Verified signer id (numeric; the sign paths re-verify it before this runs). */
  actorId: string;
  /** authoring_signatures.id of the approval signature — the §11.70 link. */
  signatureId: string;
  /** The signature's meaning, as recorded on the signature. */
  meaning: string;
  /** The signer's stated reason / intent, as recorded on the signature. */
  reason: string;
  /** Which signing path approved: '/e-sign' (APPROVER) or '/sign' (last workflow step). */
  via: 'e-sign' | 'sign';
}

type ApproveBoundSectionsResult =
  | {
      /** Sections moved to 'approved' by this signature. */
      approved: string[];
      /** Bound sections this signature did not approve, and still not approved —
       *  no text, or filing text that is not the text signed. */
      notApproved: string[];
      documentId: string;
      /** c2c_ana_actions id of the governed-action record; null when nothing moved. */
      actionId: string | null;
      /** Why nothing moved, when the filing is locked or submitted (filing-lock.ts). */
      reason?: string;
    }
  | { approved: []; notApproved: []; documentId: null; actionId: null; reason: string };

/**
 * The approval signature approves the filing's sections it covers (spine F1).
 *
 * ── The defect ────────────────────────────────────────────────────────────────
 * Approving a document in the editor — the APPROVER e-signature, or the
 * signature that clears the last step of its approval workflow — flipped
 * authoring_documents.status and froze the working copy, and left every
 * c2c_document_sections row where it was. Readiness counts only 'approved' and
 * 'locked' sections (c2c_recompute_document_readiness), so a signed, approved
 * filing read 0% ready, and the dispatch gate (leaf-source-resolver) reported
 * its sections unfinalized.
 *
 * ── What moves ────────────────────────────────────────────────────────────────
 * Only sections the signer actually signed: a governed section of the BOUND
 * document that one of this document's authored sections files into (its own
 * code, or the undivided node it sits under — filingSectionKey; 2026-10-08
 * merge of spine F1 with QA walk 2 j4), that has written text
 * (sectionHasContentSql's test), and whose filing text is exactly the text the
 * signature covers: the section's own, or the node's sections assembled. A section whose filing text
 * differs (written elsewhere after the last save) was not signed and is not
 * approved; it is reported in `notApproved`. Only forward: 'todo', 'drafted'
 * and 'review' move; 'approved' stays; 'locked' is never touched.
 *
 * ── Recorded, in the signature's transaction ──────────────────────────────────
 * One recordGovernedAction row (audit_logs + c2c_ana_actions, hash-chained) on
 * the caller's client, naming the sections and the signature. A throw anywhere
 * aborts the caller's transaction, so the signature and the section approval
 * land together or not at all.
 */
async function approveBoundFilingSections(
  input: ApproveBoundSectionsInput,
): Promise<ApproveBoundSectionsResult> {
  const { client, authoringDocId, tenantId, actorId, signatureId, meaning, reason, via } = input;

  // The same can-not-fail probe commitSectionToFiling makes, for the same
  // reason: this runs inside the signing transaction, and the governed store
  // (and the binding column) is optional per deployment. Absent is "not
  // applicable"; a write failing against a present store aborts the signature.
  const capable = await client.query(
    `SELECT (to_regclass('public.c2c_document_sections') IS NOT NULL
             AND to_regclass('public.c2c_documents') IS NOT NULL
             AND EXISTS (SELECT 1 FROM information_schema.columns
                          WHERE table_schema = 'public'
                            AND table_name = 'authoring_documents'
                            AND column_name = 'c2c_document_id')) AS ok`,
  );
  if (!capable.rows[0]?.ok) {
    return {
      approved: [], notApproved: [], documentId: null, actionId: null,
      reason: 'The governed document store is not provisioned here, so there is no filing to approve.',
    };
  }

  const bound = await client.query(
    `SELECT c2c_document_id FROM authoring_documents WHERE id = $1 AND tenant_id = $2 LIMIT 1`,
    [authoringDocId, tenantId],
  );
  const documentId: string | null = bound.rows[0]?.c2c_document_id ?? null;
  if (!documentId) {
    return {
      approved: [], notApproved: [], documentId: null, actionId: null,
      reason: 'This document is not bound to a filing, so no governed section was approved.',
    };
  }

  // What each node holds when this document's sections are saved as signed:
  // the section's own text at its own key, or the document's sections under an
  // undivided node assembled (filingSectionKey / filingSectionText, the rule a
  // save writes by). Tenant-scoped on both stores: the authored sections by
  // tenant_id, the governed document by org_id (c2c_document_sections has no
  // org column).
  const signed = await signedFilingSectionTexts(client, { authoringDocId, tenantId, documentId });
  const signedKeys = signed.map((t) => t.key);
  // A locked or submitted filing's sections are not moved (filing-lock.ts).
  // The signature still stands on the editing copy; the reply says why the
  // filing did not move with it.
  const lock = await readFilingLock(client, documentId, tenantId);
  const moved = lock ? { rows: [] as Array<{ section_key: string }> } : await client.query(
    `UPDATE c2c_document_sections ds
        SET status = 'approved', updated_at = now()
       FROM unnest($2::text[], $3::text[]) AS sig(section_key, text)
      WHERE ds.document_id = $1
        AND sig.section_key = ds.section_key
        AND ds.status IN ('todo', 'drafted', 'review')
        AND jsonb_typeof(ds.content) = 'object'
        AND (ds.content ->> 'text') !~ '^\\s*$'
        AND (ds.content ->> 'text') = sig.text
        AND EXISTS (SELECT 1 FROM c2c_documents d
                     WHERE d.id = ds.document_id AND d.org_id = $4)
      RETURNING ds.section_key`,
    [documentId, signedKeys, signed.map((t) => t.text), tenantId],
  );
  // rows, never rowCount: PGlite does not populate rowCount.
  const movedKeys: string[] = moved.rows.map((r: { section_key: string }) => r.section_key);
  const approved = [...new Set(movedKeys)].sort();

  const left = await client.query(
    `SELECT DISTINCT ds.section_key
       FROM c2c_document_sections ds
      WHERE ds.document_id = $1 AND ds.section_key = ANY($2::text[])
        AND ds.status NOT IN ('approved', 'locked')
        AND EXISTS (SELECT 1 FROM c2c_documents d
                     WHERE d.id = ds.document_id AND d.org_id = $3)
      ORDER BY ds.section_key`,
    [documentId, signedKeys, tenantId],
  );
  const notApproved: string[] = left.rows.map((r: { section_key: string }) => r.section_key);

  if (approved.length === 0) {
    return {
      approved: [], notApproved, documentId, actionId: null,
      ...(lock ? { reason: `The filing this document is written for ${lock.words}, so none of its sections was approved.` } : {}),
    };
  }

  const userId = Number(actorId);
  if (!Number.isInteger(userId)) {
    // The sign paths refuse a non-numeric signer before this runs
    // (reverifyAuthoringSigner). Reaching here without one is a fault: fail
    // the whole signing transaction rather than approve without a record.
    throw new Error('approveBoundFilingSections: the signer id is not a user id');
  }
  const recorded = await recordGovernedAction(client, {
    orgId: tenantId,
    userId,
    command: 'approve',
    target: `c2c_document:${documentId}`,
    reason: reason && reason.trim() ? reason.trim() : null,
    payload: {
      sections: approved,
      notApproved,
      status: 'approved',
      signatureId,
      meaning,
      via,
      authoringDocumentId: authoringDocId,
    },
    domain: 'documents',
    surface: `authoring-${via}`,
  });

  return { approved, notApproved, documentId, actionId: recorded.actionId };
}

/**
 * The signing handlers' one call into approveBoundFilingSections: null when this
 * signature does not approve the document (`approves` false), so a signature of
 * any other meaning moves no section. The signer id is the verified principal.
 */
async function filingApprovalForSignature(
  client: Queryable,
  req: Request,
  args: {
    approves: boolean;
    docId: string;
    tenantId: number;
    signatureId: string;
    meaning: string;
    reason: string;
    via: 'e-sign' | 'sign';
  },
): Promise<ApproveBoundSectionsResult | null> {
  if (!args.approves) return null;
  return approveBoundFilingSections({
    client,
    authoringDocId: args.docId,
    tenantId: args.tenantId,
    actorId: String(getActorId(req) ?? ''),
    signatureId: args.signatureId,
    meaning: args.meaning,
    reason: args.reason,
    via: args.via,
  });
}

/**
 * What a signing response says the approval did to the filing's sections.
 * `documentId` names the filing; when there is none (no governed store, or the
 * document is not bound) it is null and `reason` says why, so "no filing" never
 * reads like "every bound section was already approved".
 */
function filingApprovalReply(
  result: ApproveBoundSectionsResult | null,
): { approved: string[]; notApproved: string[]; documentId: string | null; reason?: string } | null {
  if (!result) return null;
  const reply = { approved: result.approved, notApproved: result.notApproved, documentId: result.documentId };
  return 'reason' in result ? { ...reply, reason: result.reason } : reply;
}

/**
 * The last workflow signature has cleared the chain: approve the document and
 * leave the immutable record that approval means.
 *
 * Lifted out of POST /docs/:docId/sign as one named act, because it is one:
 * the status flip and the freeze must land together or not at all, and at four
 * blocks deep inside the handler that pairing was something a reader had to
 * reconstruct. It runs on the CALLER'S transaction client for exactly that
 * reason — it is not a step that may independently succeed.
 */
async function approveAndFreezeDocument(args: {
  client: Queryable;
  docId: string;
  tenantId: number;
  signerEmail: string;
  contentHash: string;
}): Promise<void> {
  const { client, docId, tenantId, signerEmail, contentHash } = args;
  await client.query(
    `UPDATE authoring_documents
     SET status = 'APPROVED', approved_at = NOW()
     WHERE id = $1 AND tenant_id = $2`,
    [docId, tenantId]
  );

  // Auto-freeze on approval — the final workflow signature approving the
  // document must leave the same immutable legal record the e-sign
  // APPROVER path produces. Without this the /sign workflow ended a
  // document APPROVED with NO frozen_documents row: the approved content
  // survived only in the editable authoring_sections table, and this
  // approval signature's covered_freeze_version / covered_content_hash
  // (bound above to `covered`, the pre-existing snapshot) were null —
  // an approval that attests to "no snapshot". Mirror the proven e-sign
  // pattern exactly: capture the FULL {document, sections, approvedBy,
  // documentHash, frozenAt} snapshot, set content_hash to sha256 of the
  // SNAPSHOT BYTES (so GET /docs/:docId/frozen's recompute-and-compare
  // verifies), and INSERT ... ON CONFLICT DO NOTHING on THIS transaction
  // client so the freeze lands with the status flip or rolls back with it.
  const approvedDoc = await client.query(
    'SELECT * FROM authoring_documents WHERE id = $1 AND tenant_id = $2',
    [docId, tenantId]
  );
  const approvedSections = await client.query(
    // 2026-09-23 (W5/D7, co-author final pass): the seal's section order is the editor's
    // (order_index, created_at; id makes it total), the order the filing copy assembles in.
    'SELECT id, doc_id, code, title, content, order_index, track_changes, created_at, updated_at, tenant_id FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2 ORDER BY order_index, created_at, id',
    [docId, tenantId]
  );
  const frozenContent = JSON.stringify({
    document: approvedDoc.rows[0] ?? null,
    sections: approvedSections.rows,
    approvedBy: signerEmail,
    documentHash: contentHash,
    frozenAt: new Date().toISOString(),
  });
  const frozenContentHash = crypto.createHash('sha256').update(frozenContent).digest('hex');

  await client.query(
    `INSERT INTO frozen_documents
     (document_id, version, frozen_content, content_hash, frozen_by, frozen_reason, tenant_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (document_id, version, tenant_id) DO NOTHING`,
    [docId, 'approved', frozenContent, frozenContentHash, signerEmail, 'Approved and frozen', tenantId]
  );
}

/**
 * Advance this document's approval workflow on the strength of one signature.
 *
 * Only a signer whose VERIFIED roles carry the signature's meaning (or QA /
 * RA_CMC) decides a step; when that clears the last pending step of a workflow
 * that actually exists, the document is approved and frozen. Everything runs on
 * the caller's transaction client, so a signature and the step it approves land
 * together or not at all.
 */
async function workflowApprovalMayRelease(client: Queryable, current: Awaited<ReturnType<typeof lockedSigningContent>>, meaning: string): Promise<boolean> {
  try {
    await assertWorkflowImportRelease(client, current);
    return true;
  } catch (error) {
    // The review signature records review while release remains held.
    if (meaning === 'REVIEWER' && error instanceof WorkflowImportGovernanceError
      && ['WORKFLOW_HUMAN_ADOPTION_REQUIRED', 'WORKFLOW_MODEL_QUALIFICATION_REQUIRED'].includes(error.code)) return false;
    throw error;
  }
}

async function advanceWorkflowForSignature(args: {
  client: Queryable;
  req: Request;
  docId: string;
  tenantId: number;
  signerEmail: string;
  meaning: string;
  reason: string;
  contentHash: string;
  current: Awaited<ReturnType<typeof lockedSigningContent>>;
}): Promise<boolean> {
  const { client, req, docId, tenantId, signerEmail, meaning, reason, contentHash } = args;
  // Update workflow step if applicable. Roles come from the VERIFIED token
  // (req.user.roles), not from the x-roles header — the header is derived from
  // claims by this router's JWT middleware, but reading the claim directly
  // means an approval decision can never depend on a mutable header at all
  // (ledger C-18).
  const userRoles = (((req.user as { roles?: unknown } | undefined)?.roles ?? []) as unknown[])
    .map((r) => String(r).toUpperCase());
  if (userRoles.includes(meaning) || userRoles.includes('QA') || userRoles.includes('RA_CMC')) {
    // RETURNING, read as rows (PGlite does not populate rowCount): whether THIS
    // signature decided a pending step. Spine F1 approves filing sections only
    // for the signature that clears the last step, never for a later signature
    // on a workflow that was already complete (that one decides nothing).
    const decided = await client.query(
      `UPDATE authoring_workflow_steps
       SET status = 'APPROVED', decision_note = $1, decided_at = NOW()
       WHERE doc_id = $2 AND approver_email = $3 AND status = 'PENDING' AND tenant_id = $4
       RETURNING id`,
      [reason, docId, signerEmail, tenantId]
    );
    const decidedAStep = (decided?.rows ?? []).length > 0;

    /* Are all approvals in — or were there never any?
       This counted only PENDING steps and treated '0' as "all approved".
       That count is also '0' when NO STEPS EXIST, and the only thing that
       creates them is POST /docs/:docId/submit, which has no caller
       anywhere in the client. So on the ordinary path — a document never
       submitted for approval — the first APPROVER signature found zero
       pending steps, concluded the chain was complete, flipped the document
       to APPROVED and inserted a frozen_documents row. An approval chain
       that was never required read exactly like one that finished, and the
       result is the strongest and least reversible transition in this
       lifecycle: APPROVED is sealed, and the content becomes immutable.

       A check that ran zero assertions must not report a pass. The total is
       counted alongside the pending, and the flip now requires that an
       approval workflow actually EXISTED and is complete. A document with
       no workflow is signed — the signature above is recorded either way —
       and simply not approved, which is the truth about it. */
    const stepCounts = await client.query(
      `SELECT COUNT(*) FILTER (WHERE status = 'PENDING') AS pending,
              COUNT(*) AS total
         FROM authoring_workflow_steps
        WHERE doc_id = $1 AND tenant_id = $2`,
      [docId, tenantId]
    );
    const totalSteps = Number(stepCounts.rows[0]?.total ?? 0);
    const pendingCount = Number(stepCounts.rows[0]?.pending ?? 0);

    if (totalSteps > 0 && pendingCount === 0) {
      if (!await workflowApprovalMayRelease(client, args.current, meaning)) return false;
      await approveAndFreezeDocument({ client, docId, tenantId, signerEmail, contentHash });
      // Spine F1: true only when this signature cleared the last pending step.
      // A signature after the workflow was complete decided no step, so it is
      // not the approval and approves no filing section.
      return decidedAStep;
    }
  }
  return false;
}

/**
 * What this signature is bound to: the document's content hash, the frozen
 * snapshot it attests to, and the digest over both.
 *
 * The digest used to hash `new Date().toISOString()`, which made it impossible
 * for anyone to recompute — a hash nobody can reproduce proves nothing. It
 * covers only durable columns, including the frozen snapshot (§11.70
 * signature/record link, C-11 residual 2), which is why the three are computed
 * in one place rather than assembled at each signing path.
 */
// ============= SIGN Operations =============

// POST /api/authoring/docs/:docId/sign - Sign document (21 CFR Part 11)
router.post('/docs/:docId/sign', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const { meaning = 'REVIEWER', reason } = req.body;
    const tenantId = getTenantId(req);
    // Part 11 §11.100: the signer is the VERIFIED principal. This took its
    // identity from `x-user-email || req.body.signer_email || 'system'`, so a
    // caller could sign as anyone — or as "system", which is nobody. The defect
    // survived because this endpoint writes authoring_signatures, a table that
    // did not exist, so it failed before attribution ever mattered. See C-11
    // residual 1 and C-18.
    const signerEmail = getActorEmail(req);
    if (!signerEmail) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    // §11.50(a)(1) printed name — see resolveSignerName. NULL when the user
    // record yields none, so a manifestation can say so rather than render an
    // address as a printed name.
    const signerName = await resolveSignerName(signerEmail as string);

    // §11.10(g) authority, before the credentials — same reasoning as /e-sign.
    // This path also advances a workflow step, and it already consulted the
    // caller's roles to decide THAT (below); it never consulted them to decide
    // whether the signature itself could be applied.
    const authority = await checkSigningAuthority(Number(getActorId(req)), getTenantId(req));
    if (authority) return res.status(authority.status).json({ error: authority.message, code: authority.code });

    // Validate required fields
    if (!reason) {
      return res.status(400).json({ error: 'A reason is required for signing' });
    }

    // §11.50(a)(3) — the MEANING of the signature is a closed set, and this
    // path took it as a free string with a default. `/e-sign` has validated it
    // against this same list since it was written; this one did not, so an
    // arbitrary token could be stored as the meaning of a legally binding
    // attestation and would render verbatim in any manifestation of it.
    if (!SIGNATURE_MEANINGS.includes(meaning)) {
      return res.status(400).json({ error: 'Invalid signature meaning' });
    }

    // §11.70 — the signature must be linked to a real record in this tenant.
    if (!(await documentExistsForTenant(docId, tenantId))) {
      return res.status(404).json({ error: 'Document not found' });
    }

    const client = await pool.connect();
    let committed = false;
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
      const current = await lockedSigningContent(client, req, String(docId), tenantId);
      const workflowSourceAdoption = await adoptionForSigning(client, req, current, meaning);

      /* P-29.2 — the third seal. A signature here records `content_hash` over
         the editing layer, and at the last cleared step it also approves and
         freezes the document (`advanceWorkflowForSignature` →
         `approveAndFreezeDocument`).
         REFUSED FOR EVERY MEANING, not only the step that seals, and
         deliberately: whether this signature is the last one is not known
         until the workflow is advanced, which is after the signature row is
         written — and a reviewer's "I reviewed this" that attests to text the
         submission will not carry is a defective record whichever step it is
         on. `different` means something overwrote the filed copy outside the
         editor, which is a reason to stop a workflow rather than to sign
         around it. If evidence later shows reviewers blocked by a divergence
         they cannot clear, narrow this to the sealing step — do not weaken the
         refusal. */
      if (await sealRefusedForFiling(client, res, docId, tenantId)) return;

      const signer = await reverifyAuthoringSigner(req, res);
      if (!signer) return;
      const contentHash = sectionsDigest(current.sections);
      const covered = await currentFrozenSnapshot(docId, tenantId, client);
      const signatureDigest = computeSignatureDigest({ signerEmail, meaning, contentHash, coveredContentHash: covered?.contentHash ?? null });
      const signatureId = crypto.randomUUID();
      let filingApproval: ApproveBoundSectionsResult | null = null;

      // `method`: the factors the ceremony verified, as /e-sign records them.
      await client.query(
        `INSERT INTO authoring_signatures
         (id, doc_id, signer_email, signer_name, meaning, reason, method, content_hash,
          signature_digest, covered_freeze_version, covered_content_hash, tenant_id, signed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())`,
        [
          signatureId,
          docId,
          signerEmail,
          signerName,
          meaning,
          reason,
          signer.authenticationMethod,
          contentHash,
          signatureDigest,
          covered?.version ?? null,
          covered?.contentHash ?? null,
          tenantId,
        ]
      );

      const approvedDocument = await advanceWorkflowForSignature({
        client,
        req,
        docId: String(docId),
        tenantId,
        signerEmail,
        meaning,
        reason,
        contentHash,
        current,
      });

      // Spine F1: only the signature that approves the document — the one that
      // clears the last step of an existing workflow — approves the filing
      // sections it covers, in this transaction, through recordGovernedAction.
      // Any other signature on this path moves no section.
      filingApproval = await filingApprovalForSignature(client, req, {
        approves: approvedDocument, docId: String(docId), tenantId, signatureId, meaning, reason, via: 'sign',
      });

      // Create audit event
      // The signer's stated reason is the row's reason. This handler writes
      // its own richer chained row below.
      await createAuditTrail(
        req,
        docId,
        null,
        'SIGN',
        null,
        null,
        typeof reason === 'string' && reason.trim() ? reason.trim() : null,
        { signatureId, meaning, reason, contentHash, ...(workflowSourceAdoption ? { workflowSourceAdoption } : {}) },
        client,
        { chainedRowWrittenByCaller: true }
      );

      /* §11.10(e) — the HASH-CHAINED ledger, on this transaction.
         `createAuditTrail` above writes authoring_audit_trail, which carries no
         chain and no HMAC, and its mirror into the chained `audit_logs` runs
         ONLY when the executor is the pool (see the guard at its foot). Every
         governed handler here passes its own transaction client — correctly, so
         the record commits with the mutation — which meant the mirror was
         skipped and these events never reached the chain at all. So
         verifyAuditChain had nothing to verify for the three actions that most
         need it, and the document's own audit view read an unchained table.
         writeChainedAuditRow is the primitive built for this case and is what
         /api/esignature/sign already uses: on the caller's client, so if the
         audit row cannot be written the whole transaction rolls back and the
         signature never exists either. */
      await writeChainedAuditRow(client, {
        tenantId,
        userId: getActorId(req) ?? undefined,
        action: 'authoring.document.sign',
        resourceType: 'authoring_document',
        resourceId: String(docId ?? ''),
        ipAddress: (req.ip ?? undefined) as string | undefined,
        userAgent: req.headers['user-agent'] as string | undefined,
        details: { signatureId, meaning, reason, contentHash, signer: signerEmail, ...(workflowSourceAdoption ? { workflowSourceAdoption } : {}) },
      });

      await client.query('COMMIT');
      committed = true;
      res.json({
        success: true,
        message: 'Document signed successfully',
        signatureId,
        workflowSourceAdoption,
        digest: signatureDigest,
        // Spine F1: what the approval did to the filing's sections, or null.
        filingApproval: filingApprovalReply(filingApproval),
      });
    } finally {
      if (!committed) await client.query('ROLLBACK').catch(() => {});
      client.release();
    }

  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    console.error('Sign error:', error);
    return serverError(res, logger, 'signing docs', error);
  }
});

// GET /api/authoring/docs/:docId/signatures - Get document signatures
router.get('/docs/:docId/signatures', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const tenantId = getTenantId(req);

    const result = await pool.query(
      /* covered_freeze_version / covered_content_hash are the §11.70
         signature-to-record link: WHICH frozen snapshot this signature covers.
         The freeze-binding migration added them and this SELECT never returned
         them, so a manifestation built from this endpoint could show that a
         document was signed but not what was signed. pin_verified likewise
         records that the signature was PIN-authenticated (§11.200(a)(1)) and
         was unreadable. */
      `SELECT id, doc_id, signer_email, signer_name, meaning, reason, method,
              content_hash, signature_digest, covered_freeze_version,
              covered_content_hash, pin_verified, signed_at, tenant_id
         FROM authoring_signatures
        WHERE doc_id = $1 AND tenant_id = $2
        ORDER BY signed_at DESC`,
      [docId, tenantId]
    );

    res.json({ success: true, signatures: result.rows });
  } catch (error) {
    console.error('Error getting signatures:', error);
    res.status(500).json({ error: 'Failed to get signatures' });
  }
});

// ============= FREEZE Operations =============

// The duplicate POST /docs/:docId/freeze that stood here has been removed.
//
// It was UNREACHABLE: an identical path is registered at the top of this file
// (search "Freeze document with immutable snapshot") and express matches the
// first registration, so this one never ran. It also took its attribution from
// `x-user-email || req.body.frozen_by || 'system'` — the header-trust defect
// fixed elsewhere in this router — which made it a live hazard the moment any
// reordering made it reachable. Deleted rather than fixed: there is one freeze
// endpoint, and it is the one above. See ledger C-18.

// ============= AUDIT Operations =============

// GET /api/authoring/docs/:docId/audit - Get audit trail
//
// Reads authoring_audit_trail — the ledger createAuditTrail() has always
// written. This endpoint used to SELECT from `authoring_audit_events`, a table
// with no CREATE statement anywhere in the repository and no writer: not a
// migration, not shared/schema.ts, not one of the router's own runtime DDL
// helpers. So the only Part 11 read-back surface in the authoring stack was an
// unconditional 42P01, while a complete audit record — actor, operation,
// before/after hashes, IP, session — accumulated in the table next to it.
//
// event_type/actor are kept as the response field names so the shape callers
// were coded against is unchanged; they are aliased from the real columns.
/**
 * Whether the caller may read (`view`) or export (`export`) this document's
 * audit trail, answering the refusal itself when not (DP-42, 2026-09-29).
 *
 * The trail holds every edit's text before and after, every comment, every
 * rejected suggestion and every actor's address. It was tenant-scoped only —
 * the object authorization middleware passes every GET — so a member with no
 * grant on the document, or one whose grant was revoked, could read and
 * download it. Now: a holder of the action on the document (doc_permissions,
 * through decideAuthoringPermission — the same decision the writes use), or an
 * organization audit reader (owner, admin, manager: canReadAuditTrail, the
 * DP-18 rule every other audit read follows). 404 for a document this tenant
 * does not have, 403 otherwise; fails closed on an error.
 */
async function auditTrailAccess(
  req: Request,
  res: Response,
  docId: string,
  action: 'view' | 'export',
): Promise<boolean> {
  const tenantId = getTenantId(req);
  const scope = isUuid(docId) ? await resolveAuthoringDocumentScope(pool, tenantId, docId) : null;
  if (!scope) {
    res.status(404).json({ success: false, error: 'Document not found' });
    return false;
  }
  if (canReadAuditTrail(req)) return true;
  const decision = await decideAuthoringPermission({ pool, principal: authoringPrincipalFromRequest(req), scope, action });
  if (decision.allowed) return true;
  res.status(403).json({
    success: false,
    error: {
      code: 'AUDIT_TRAIL_NOT_PERMITTED',
      message:
        action === 'export'
          ? "Exporting this document's record needs export access to the document, or an audit role in the organization."
          : "Reading this document's record needs access to the document, or an audit role in the organization.",
    },
  });
  return false;
}

/** The rail reads the latest rows; the export carries the whole record. */
const AUDIT_READ_MAX_ROWS = 500;
const AUDIT_EXPORT_MAX_ROWS = 10000;

router.get('/docs/:docId/audit', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const { limit = 100 } = req.query;
    const tenantId = getTenantId(req);

    /* Each row now carries `integrity`: whether a chained entry names it and,
       when one does, whether its content, metadata, reason and operation still
       match what the chain carries (D5, 2026-09-26). The before/after content
       is read to check it and is not returned — the response keeps the shape
       callers were coded against. */
    // A malformed id names no document: 404, not the uuid cast's 500.
    if (!(await auditTrailAccess(req, res, String(docId), 'view'))) return;
    const rows = Math.min(Number(limit) || 100, AUDIT_READ_MAX_ROWS);
    const record = await loadAuthoringRecord(pool, tenantId, String(docId), { limit: rows });
    const events = record.events.map((e) => ({
      id: e.id,
      doc_id: e.doc_id,
      section_id: e.section_id,
      event_type: e.operation_type,
      actor: e.actor_email,
      actor_role: e.actor_role,
      change_reason: e.change_reason,
      content_hash_before: e.content_hash_before,
      content_hash_after: e.content_hash_after,
      metadata: e.metadata,
      created_at: e.created_at,
      tenant_id: tenantId,
      integrity: record.verdicts.get(e.id) ?? null,
    }));

    res.json({ success: true, events, count: events.length });
  } catch (error) {
    console.error('Error getting audit trail:', error);
    res.status(500).json({ error: 'Failed to get audit trail' });
  }
});

export const AUTHORING_RECORD_EXPORT_FORMAT = 'authoring-record-export/1';

/**
 * GET /api/authoring/docs/:docId/audit/export — the document's whole authoring
 * record for an inspector: every trail row with its full content (the words of
 * every comment and the passage it quoted, every tracked change's proposed text
 * and the decision on it, every section edit before and after), each row's
 * chained entry and verdict, the tenant chain walked now, and how to check it
 * all offline. Recorded on the chain before anything leaves, refused when that
 * record cannot be written. Exportable by a holder of `export` on the
 * document or an organization audit reader (auditTrailAccess). A record longer
 * than AUDIT_EXPORT_MAX_ROWS says so (summary.truncated) rather than reading
 * as complete.
 */
router.get('/docs/:docId/audit/export', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    if (!(await auditTrailAccess(req, res, String(docId), 'export'))) return;
    const tenantId = getTenantId(req);
    const doc = await pool.query(
      'SELECT id, title, status, module FROM authoring_documents WHERE id = $1 AND tenant_id = $2',
      [docId, tenantId]
    );
    if ((doc.rowCount ?? 0) === 0) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }
    const record = await loadAuthoringRecord(pool, tenantId, String(docId), { limit: AUDIT_EXPORT_MAX_ROWS, order: 'asc' });
    const totalRows = Number(
      (await pool.query('SELECT count(*)::int AS n FROM authoring_audit_trail WHERE doc_id = $1 AND tenant_id = $2', [docId, tenantId]))
        .rows[0]?.n ?? record.events.length
    );
    const truncated = totalRows > record.events.length;
    const verdicts = Object.fromEntries(record.verdicts);
    const intact = [...record.verdicts.values()].filter((v) => v.intact === true).length;
    const broken = [...record.verdicts.values()].filter((v) => v.intact === false).length;
    const tenantChain = await walkTenantChain(tenantId);
    const exportedAt = new Date().toISOString();
    const actorId = getActorId(req);
    return sendAuditedExport(pool, res, {
      tenantId,
      userId: actorId,
      action: 'authoring.record.exported',
      resourceType: 'authoring_document',
      resourceId: String(docId),
      details: {
        format: AUTHORING_RECORD_EXPORT_FORMAT,
        events: record.events.length,
        intact,
        broken,
        tenantChainOk: tenantChain.ok,
        truncated,
        exportedAt,
      },
      ipAddress: req.ip,
      userAgent: req.get('user-agent') ?? undefined,
      filename: `authoring-record-${docId}.json`,
      refusalCode: 'AUTHORING_RECORD_EXPORT_NOT_RECORDED',
      body: {
        format: AUTHORING_RECORD_EXPORT_FORMAT,
        exportedAt,
        exportedBy: { userId: actorId },
        document: doc.rows[0],
        events: record.events,
        chain: Object.fromEntries(record.chain),
        verdicts,
        summary: {
          events: record.events.length,
          intact,
          broken,
          notChained: record.events.length - intact - broken,
          truncated,
          ...(truncated ? { totalEvents: totalRows } : {}),
        },
        tenantChain,
        howToVerify: [
          'For each event, find chain[event.id]; its details.trailId equals event.id.',
          'SHA-256 of before_content and of after_content (UTF-8) equal details.contentHashBefore / contentHashAfter (null when empty).',
          'SHA-256 of the canonical JSON (keys sorted, no whitespace) of event.metadata equals details.metadataSha256 — the metadata holds a comment\'s quoted passage and a tracked change\'s proposed text.',
          'event.change_reason equals details.changeReason and event.operation_type equals details.operationType.',
          'SHA-256 of JSON.stringify(details) equals the chain entry\'s payloadHash — the value its chain link was computed over.',
          'Events with no chain entry were written before 2026-09-26 or on the standalone index path: unverifiable here, not intact.',
          "tenantChain is the server's walk of the organization's whole audit chain at export time; `npm run ops:verify-audit-chain` repeats it.",
        ],
      },
    });
  } catch (error) {
    console.error('Error exporting authoring record:', error);
    return serverError(res, logger, 'exporting the authoring record', error);
  }
});

// ============= Signing credential =============

/* POST /api/authoring/users/pin has been DELETED (2026-09-23, VSR-001 §13.3
 * item 3). It set the "signing PIN" this router's two signature routes used to
 * verify. The first PIN needed only a session, so whoever held one could set
 * the credential that signed as its owner; and it made a second credential
 * store, with its own lockout, for the one act the rest of the product
 * re-verifies with the account password and enrolled second factor.
 *
 * Replacement, by path: the signature routes above re-verify through
 * reverifyAuthoringSigner -> server/services/part11/reverify-signer.ts, the
 * ceremony every other signing surface runs; the credentials are the account
 * password and the authenticator enrolled through POST /api/auth/mfa/setup and
 * /mfa/enable (server/routes/auth.ts). Reachability: authoring-sign-ceremony
 * .test.ts drives both signature routes with them and pins this route's 404.
 * The client panel that called it (SigningPinPanel in AuthoringSignatures.tsx)
 * is deleted with it; the e-sign dialog asks for the password and code.
 *
 * `user_pins` is left in place with its rows (Rule 1: no DROP of an object a
 * migration in the set creates). Nothing reads or writes it now. */

// ============= AI ANALYSIS & SUGGESTIONS =============

/* POST /api/authoring/ai/suggestions has been DELETED.
 *
 * It had no caller. The route was mounted — register-inline-routes.ts mounts
 * this router on '/api/authoring' — so the full path was
 * /api/authoring/ai/suggestions, and the only occurrence of that path anywhere
 * in the repository was the comment that used to sit on this line. The nearby
 * "suggestions" matches in the client are all the editor's own
 * `editor/suggestions` module, the tracked-change marks, which is a different
 * thing entirely and is why a fragment search reports this endpoint as live.
 *
 * There was no AI in it. It was six hardcoded regexes — three grammar, three
 * regulatory-terminology — each returning a `confidence` of 0.95 or 0.9.
 * Nothing scored anything, so those numbers had nothing behind them, and a
 * fabricated confidence on a governed document surface is the defect this
 * repository keeps deleting.
 *
 * Two of the three grammar rules emitted DESTRUCTIVE replacements, because the
 * suggestion was built as `match[0].replace(issue.pattern, ' ')` — replacing the
 * whole match with one space instead of repairing it:
 *
 *     "the the"  ->  " "     (deletes the word, at confidence 0.95)
 *     "Done..."  ->  " "     (an ellipsis becomes a space)
 *     "Stop!!"   ->  " "     (the punctuation is deleted)
 *
 * Only the multiple-spaces rule was right. Accepting a suggestion from this
 * endpoint would have removed the author's text from a regulated document.
 *
 * The terminology rules also overlapped: /adverse event/ and
 * /serious adverse event/ both match "A serious adverse event occurred.", at
 * offsets 10 and 2, so one phrase drew two contradictory edits over overlapping
 * ranges — and both fired unconditionally, so text already reading
 * "adverse event (AE)" was told to become "adverse event (AE)" again.
 *
 * The capability it claimed is served by the canonical paths: real drafting by
 * AuthoringAiDraft (surfaces/AuthoringAiDraft.tsx, mounted inside
 * DocumentAuthoring), and heuristic section checks by
 * POST /sections/:sectionId/ai/deficiency-scan. This was a third parallel path,
 * which the zero-duplication rule does not allow.
 *
 * Pinned by tests/routes/aiSuggestionsDeleted.test.ts.
 */

/* POST /api/authoring/ai/validate-compliance has been DELETED.
 *
 * It was a second implementation of the capability POST
 * /sections/:sectionId/ai/deficiency-scan already provides — heuristic keyword
 * presence over a section's text — with no caller anywhere in the repository,
 * and it ended in a verdict it could not support:
 *
 *     overall_compliance: missing_elements.length === 0 ? 'PASS' : 'NEEDS_IMPROVEMENT'
 *
 * `missing_elements` was only ever populated for five hardcoded 3.2.S.* codes.
 * For every other section in the CTD — all of M1, M2, M4, M5, and most of M3 —
 * the array was empty because nothing had been examined, and the response said
 * PASS. A check that ran zero assertions reporting a compliance pass is the
 * defect this repository keeps finding, and this one named the field
 * `overall_compliance`.
 *
 * Its ICH block had already been repaired once: it used to fabricate
 * `compliant: Math.random() > 0.3` and a random score against Q1A/Q3A/Q6A/E6/M4,
 * and was changed to report `not_assessed`. That left the endpoint returning an
 * honest "we did not assess ICH" beside a dishonest "PASS" in the same body.
 *
 * The one part worth keeping — the per-section CTD required-element lists — is
 * now a check inside the deficiency scan, which has a caller and frames its
 * output as signals rather than a determination. Migrated and deleted in the
 * same change, per the zero-duplication rule.
 */

// ── Tracked Change Decisions (persist accept/reject) ──────────────────────────

/**
 * Who PROPOSED a tracked change, for the audit event — never validated against
 * a roster, because there is no roster this could safely check. `authorId` on
 * a human mark is the editor's own email (client/src/concept2cure/v2/editor/
 * suggestions.ts), not a numeric user id, so it cannot be matched against
 * doc_permissions or organization_users; a legitimate proposer can also be a
 * live co-author whose mark predates any grant, a person whose grant was later
 * revoked, or (per suggestions.ts's own doc comment) simply the case where the
 * proposer and the decider are different people entirely — refusing an
 * unrecognised proposer would drop a verified, hash-audited DECISION to guard
 * an unverifiable PROPOSAL, which is the wrong thing to fail closed on here.
 *
 * What IS checkable is whether the claimed proposer is this server's own AI
 * system, because that identity is a closed, server-owned vocabulary
 * (MACHINE_AUTHOR_IDS — the same list machineContributors validates against
 * for the revision ledger). So the one thing this function does is stop a
 * caller from relabelling that identity: when `authorId` names a machine
 * author, the CANONICAL name is recorded and the caller's own `authorName` is
 * discarded, exactly as machineContributors discards it for the same reason
 * ("the id is the claim being checked, and echoing a caller-supplied display
 * name would put unvalidated text in the attribution position of a filed
 * record" — revision-ledger.ts). Everything else is recorded as what it is:
 * text the editing client asserted, not a verified identity — the audit rail
 * already renders it qualified as "(proposed by X, as recorded by the editing
 * client)" (DocumentAuthoring.tsx), and `proposedByVerified` carries that same
 * fact into the stored row for any reader that does not go through the rail.
 */
function describeProposer(authorName: unknown, authorId: unknown): {
  proposedBy?: string;
  proposedByVerified?: boolean;
} {
  // Own keys only: `constructor` or `toString` is not a machine author.
  if (typeof authorId === 'string' && Object.hasOwn(MACHINE_AUTHOR_IDS, authorId)) {
    return { proposedBy: MACHINE_AUTHOR_IDS[authorId], proposedByVerified: true };
  }
  const claimed = typeof authorName === 'string' ? authorName : typeof authorId === 'string' ? authorId : null;
  if (!claimed) return {};
  return { proposedBy: claimed.slice(0, 200), proposedByVerified: false };
}

/** The kinds of tracked change the editor has (suggestions.ts SuggestionRange
 *  `kind`). Anything else in a decision's `changeType` is not recorded: the
 *  field is read back as what the reviewer decided about. */
function decisionChangeType(value: unknown): 'insertion' | 'deletion' | null {
  return value === 'insertion' || value === 'deletion' ? value : null;
}

/**
 * Whether a decision's `sectionId` names a section of THIS document, in this
 * tenant (SEC-A-7, second half; editor-family review 2026-09-28,
 * docs/evidence/D5/2026-09-29-decision-section/). Both decision routes used to
 * check only the document's lock and then record the body's sectionId as
 * given, so a decision could be written to this document's hash-chained trail
 * against another document's section, or another tenant's, and be read back
 * as a decision on it.
 *
 * True when the body names no section (a decision without one is recorded as
 * before). A value that is not a uuid is refused without a query: both columns
 * are uuid, and Postgres would answer 22P02, which this router reports as 500.
 * The workbench always sends the open document's active section, so only a
 * forged or stale caller is refused.
 */
async function decisionSectionIsOfDocument(docId: string, sectionId: unknown, tenantId: number): Promise<boolean> {
  if (sectionId === undefined || sectionId === null) return true;
  if (typeof sectionId !== 'string' || !isUuid(sectionId) || !isUuid(docId)) return false;
  const found = await pool.query(
    'SELECT 1 FROM authoring_sections WHERE id = $1 AND doc_id = $2 AND tenant_id = $3 LIMIT 1',
    [sectionId, docId, tenantId],
  );
  return (found.rowCount ?? found.rows.length) > 0;
}

const SECTION_NOT_IN_DOCUMENT = {
  success: false,
  error: {
    code: 'SECTION_NOT_IN_DOCUMENT',
    message: 'The section named is not a section of this document. Nothing was recorded.',
  },
} as const;

/**
 * Write one reviewer act on tracked changes — a single decision or an "Accept
 * all" — inside the caller's transaction: the current-verdict upserts (an
 * index), then ONE trail row describing every change decided, whole. Returns
 * the upserted rows.
 */
async function recordTrackedChangeAct(
  client: Queryable,
  req: Request,
  act: {
    artifactId: string;
    tenantId: number;
    userId: string;
    userName: string;
    decision: 'accept' | 'reject';
    sectionId: string | null;
    changes: Array<{ changeId: string; context: Record<string, unknown> }>;
    bulk: boolean;
  },
): Promise<any[]> {
  const rows: any[] = [];
  const described: Record<string, unknown>[] = [];
  // The AnA turn each change names, verified against the words decided, once for the act (round 10).
  const sources = await resolveTurnRecordSources(
    client,
    act.tenantId,
    act.changes.map(({ context }) => ({ claimed: context.sourceRecord, text: decidedText(context.text) })),
  );
  for (const [i, { changeId, context }] of act.changes.entries()) {
    const result = await client.query(
      `INSERT INTO authoring_tracked_change_decisions
         (artifact_id, change_id, decision, user_id, user_name, tenant_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (artifact_id, change_id, tenant_id)
       DO UPDATE SET decision = $3, user_id = $4, user_name = $5, decided_at = NOW()
       RETURNING *`,
      [act.artifactId, changeId, act.decision, act.userId, act.userName, act.tenantId]
    );
    rows.push(result.rows[0]);
    described.push(
      describeTrackedChange(
        {
          changeId,
          changeType: context.changeType,
          text: context.text,
          authorName: context.authorName,
          authorId: context.authorId,
          at: context.at,
        },
        sources[i],
      )
    );
  }
  // sectionId in the details as well as the row's own column: readers of the
  // details (the rail, an export) name the section without a join.
  const section = act.sectionId ? { sectionId: act.sectionId } : {};
  const metadata = act.bulk
    ? { changeIds: act.changes.map((c) => c.changeId), decision: act.decision, count: act.changes.length, ...section, changes: described }
    : { decision: act.decision, ...section, ...described[0] };
  await createAuditTrail(
    req,
    act.artifactId,
    act.sectionId,
    act.bulk ? 'tracked_change_bulk_decision' : 'tracked_change_decision',
    null,
    null,
    statedReason(req.body?.reason),
    metadata,
    client
  );
  return rows;
}


/** A reason the person stated, or null — never one this server makes up. */
function statedReason(reason: unknown): string | null {
  return typeof reason === 'string' && reason.trim() ? reason.trim().slice(0, 2000) : null;
}

/** The words a decision names: a non-empty string, or none. */
const decidedText = (text: unknown): string | null => (typeof text === 'string' && text.length > 0 ? text : null);

/**
 * What was decided, whole: the change, its full proposed text and that text's
 * hash, who proposed it as the editing client recorded it (describeProposer),
 * when, and the AnA turn record it came from — verified in this tenant against
 * the words decided (resolveTurnRecordSources), or recorded as
 * claimed-but-unverified with why.
 */
function describeTrackedChange(
  c: { changeId: unknown; changeType: unknown; text: unknown; authorName: unknown; authorId: unknown; at: unknown },
  source: TurnRecordSource | null,
): Record<string, unknown> {
  const text = decidedText(c.text);
  /* A machine author's name is canonical (describeProposer), but the claim
     that the machine proposed this change is the editing client's until a
     turn record of this organization is named for it: only then is it
     `proposedByVerified` (DP-43, 2026-09-29). Any caller could send
     authorId 'ana'. What the turn record proves is that the named turn
     wrote these words (round 10: it proved only that the turn existed);
     the text's own hash is recorded beside it. */
  const proposer = describeProposer(c.authorName, c.authorId);
  if (proposer.proposedByVerified && source?.verified !== true) proposer.proposedByVerified = false;
  return {
    changeId: typeof c.changeId === 'string' ? c.changeId : String(c.changeId ?? ''),
    changeType: decisionChangeType(c.changeType),
    text,
    textSha256: text ? textSha256(text) : null,
    ...proposer,
    proposedAt: typeof c.at === 'string' ? c.at : null,
    ...(source ? { source } : {}),
  };
}

// authoring_tracked_change_decisions is now provisioned by
// db/migrations/20260730_authoring_runtime_ddl.sql. Retained as a no-op so
// existing call sites need no change; the router no longer issues runtime DDL.
const ensureTrackedChangeDecisionsTable = async () => {};

let trackedChangeTableReady = false;

// POST /api/authoring/documents/:id/tracked-change-decisions
// Persist a single accept/reject decision for a tracked change
router.post('/documents/:id/tracked-change-decisions', async (req: Request, res: Response) => {
  try {
    if (!trackedChangeTableReady) {
      await ensureTrackedChangeDecisionsTable();
      trackedChangeTableReady = true;
    }

    const { id: artifactId } = req.params;
    const { changeId, decision } = req.body;
    const tenantId = getTenantId(req);
    // SECURITY (21 CFR Part 11): the actor who accepted/rejected a tracked
    // change must come from the verified JWT, never from headers.
    const userId = getActorId(req);
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const userName = req.user?.email || userId;

    if (!changeId || !decision) {
      return res.status(400).json({
        success: false,
        error: 'changeId and decision (accept|reject) are required',
      });
    }

    if (decision !== 'accept' && decision !== 'reject') {
      return res.status(400).json({
        success: false,
        error: 'decision must be "accept" or "reject"',
      });
    }

    /* This route sits under /documents/:id, outside the /sections/:sectionId
       prefix guard that refuses a FROZEN/APPROVED document on every other
       authoring write. Nothing else here resolves the parent document at all,
       so an accept against a sealed filing reached the INSERT unconditionally
       and the hash-chained audit event below recorded a decision the record
       itself was no longer able to accept. */
    const lock = await checkDocumentWritable(pool, String(artifactId), tenantId);
    if (!lock.writable) {
      /* DOCUMENT_NOT_FOUND refuses too (D5, 2026-09-29): only FROZEN did, so a
         decision on a document id this tenant does not have was upserted,
         written to the trail and chained, and read back as a decision on it. */
      return res.status(lock.code === 'DOCUMENT_FROZEN' ? 403 : 404).json({ error: lock.code, message: lock.reason });
    }
    if (!(await decisionSectionIsOfDocument(String(artifactId), req.body?.sectionId, tenantId))) {
      return res.status(400).json(SECTION_NOT_IN_DOCUMENT);
    }

    /* The decision and its record commit together (D5, 2026-09-26). The
       upsert below is the CURRENT verdict per change — an index; the record is
       the trail row, append-only, and it keeps every decision ever made on the
       change with the whole proposed text. That text used to be cut to 500
       characters and the row written after the upsert had already committed,
       through a wrapper that lost the actor. Accepting a suggestion strips its
       mark, so this row is the only place the proposed words survive. */
    const rows = await inTransaction((client) =>
      recordTrackedChangeAct(client, req, {
        artifactId: String(artifactId),
        tenantId,
        userId,
        userName,
        decision,
        sectionId: typeof req.body?.sectionId === 'string' ? req.body.sectionId : null,
        changes: [{ changeId: String(changeId), context: req.body ?? {} }],
        bulk: false,
      })
    );

    res.json({ success: true, decision: rows[0] });
  } catch (error) {
    console.error('Error persisting tracked change decision:', error);
    return serverError(res, logger, 'saving tracked change decisions', error);
  }
});

// POST /api/authoring/documents/:id/tracked-change-decisions/bulk
// Persist accept/reject for all pending changes at once
router.post('/documents/:id/tracked-change-decisions/bulk', async (req: Request, res: Response) => {
  try {
    if (!trackedChangeTableReady) {
      await ensureTrackedChangeDecisionsTable();
      trackedChangeTableReady = true;
    }

    const { id: artifactId } = req.params;
    const { changeIds, decision } = req.body;
    const tenantId = getTenantId(req);
    // SECURITY (21 CFR Part 11): the actor who accepted/rejected tracked
    // changes must come from the verified JWT, never from headers.
    const userId = getActorId(req);
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const userName = req.user?.email || userId;

    if (!Array.isArray(changeIds) || changeIds.length === 0 || !decision) {
      return res.status(400).json({
        success: false,
        error: 'changeIds (array) and decision (accept|reject) are required',
      });
    }

    if (decision !== 'accept' && decision !== 'reject') {
      return res.status(400).json({
        success: false,
        error: 'decision must be "accept" or "reject"',
      });
    }

    // See the single-decision route above: this endpoint is equally outside
    // the /sections/:sectionId lock guard, and "Accept all" is the single
    // click by which an entire AI draft is adopted — the case with the most
    // to lose from writing past a sealed document.
    const lock = await checkDocumentWritable(pool, String(artifactId), tenantId);
    if (!lock.writable) {
      /* DOCUMENT_NOT_FOUND refuses too (D5, 2026-09-29): only FROZEN did, so a
         decision on a document id this tenant does not have was upserted,
         written to the trail and chained, and read back as a decision on it. */
      return res.status(lock.code === 'DOCUMENT_FROZEN' ? 403 : 404).json({ error: lock.code, message: lock.reason });
    }
    if (!(await decisionSectionIsOfDocument(String(artifactId), req.body?.sectionId, tenantId))) {
      return res.status(400).json(SECTION_NOT_IN_DOCUMENT);
    }

    /* "Accept all" is the one click by which a whole AI draft is adopted, so
       its record is complete: every change, with its whole proposed text and
       the AnA turn it came from — no longer the first 20, cut to 200
       characters each. One act, one trail row; the upserts and that row commit
       together or not at all. */
    const rawChanges: any[] = Array.isArray(req.body?.changes) ? req.body.changes : [];
    const byId = new Map<string, any>();
    for (const c of rawChanges) if (c && typeof c.changeId === 'string') byId.set(c.changeId, c);
    const results = await inTransaction((client) =>
      recordTrackedChangeAct(client, req, {
        artifactId: String(artifactId),
        tenantId,
        userId,
        userName,
        decision,
        sectionId: typeof req.body?.sectionId === 'string' ? req.body.sectionId : null,
        changes: changeIds.map((id: unknown) => ({ changeId: String(id), context: byId.get(String(id)) ?? {} })),
        bulk: true,
      })
    );

    res.json({ success: true, decisions: results, count: results.length });
  } catch (error) {
    console.error('Error persisting bulk tracked change decisions:', error);
    return serverError(res, logger, 'saving bulk', error);
  }
});

// GET /api/authoring/documents/:id/tracked-change-decisions
// Fetch all persisted decisions for an artifact
router.get('/documents/:id/tracked-change-decisions', async (req: Request, res: Response) => {
  try {
    if (!trackedChangeTableReady) {
      await ensureTrackedChangeDecisionsTable();
      trackedChangeTableReady = true;
    }

    const { id: artifactId } = req.params;
    const tenantId = getTenantId(req);

    const result = await pool.query(
      `SELECT * FROM authoring_tracked_change_decisions
       WHERE artifact_id = $1 AND tenant_id = $2
       ORDER BY decided_at DESC`,
      [artifactId, tenantId]
    );

    res.json({ success: true, decisions: result.rows });
  } catch (error) {
    console.error('Error fetching tracked change decisions:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch tracked change decisions',
    });
  }
});

/* ════ Section order ═════════════════════════════════════════════════════════
 *
 * Every reader of a document — the tree, the export assembler, the PDF and
 * DOCX branches — orders sections by `order_index`, and nothing could ever
 * change it: POST /sections defaulted it and PATCH does not accept it, so a
 * document whose sections were created out of order ASSEMBLED out of order,
 * permanently. Order is part of the filed record, so the write is governed
 * like one: refused on FROZEN/APPROVED (the sealed assembly is what the
 * signatures attest to), the submitted list must be an exact permutation of
 * the document's sections (a partial or foreign list is refused, never
 * partially applied), the renumbering commits in one transaction, and the
 * audit trail records the new order under the actor.
 */
async function assertCurrentSectionPermutation(client: Queryable, docId: string, tenantId: number, ids: string[]): Promise<void> {
  const current = await client.query('SELECT id FROM authoring_sections WHERE doc_id=$1 AND tenant_id=$2', [docId,tenantId]);
  const expected = new Set(current.rows.map((row: { id:string }) => String(row.id)));
  if (new Set(ids).size !== ids.length || ids.length !== expected.size || !ids.every(id => expected.has(id))) {
    throw new WorkflowImportGovernanceError(409,'DOCUMENT_CHANGED_DURING_REORDER','The current sections changed before reordering. Reload the document and retry. Nothing was reordered.');
  }
}

router.post('/docs/:docId/sections/reorder', async (req: Request, res: Response) => {
  try {
    const { docId } = req.params;
    const tenantId = getTenantId(req);
    const actor = getActorEmail(req);
    if (!actor) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const ids: unknown = (req.body ?? {}).section_ids;
    if (
      !Array.isArray(ids) ||
      ids.length === 0 ||
      !ids.every((x): x is string => typeof x === 'string' && x.length > 0)
    ) {
      return res.status(400).json({
        success: false,
        error: 'section_ids must be a non-empty array of section ids in the desired order.',
      });
    }

    const parentDoc = await pool.query(
      `SELECT status FROM authoring_documents WHERE id = $1 AND tenant_id = $2`,
      [docId, tenantId]
    );
    if ((parentDoc.rowCount ?? 0) === 0) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }
    const parentStatus = String(
      (parentDoc.rows[0] as { status?: string | null }).status ?? ''
    ).toUpperCase();
    if (LOCKED_DOCUMENT_STATUSES.has(parentStatus)) {
      return res.status(403).json({
        success: false,
        error: 'Document is FROZEN/APPROVED; its section order is part of the sealed record.',
      });
    }

    const current = await pool.query(
      `SELECT id FROM authoring_sections WHERE doc_id = $1 AND tenant_id = $2`,
      [docId, tenantId]
    );
    const currentIds = new Set<string>(current.rows.map((r: { id: string }) => String(r.id)));
    const submitted = new Set(ids);
    const isPermutation =
      submitted.size === ids.length && // no duplicates
      submitted.size === currentIds.size &&
      ids.every((id) => currentIds.has(id));
    if (!isPermutation) {
      return res.status(409).json({
        success: false,
        error:
          'section_ids must list exactly this document’s sections, each once. ' +
          'The document’s sections changed since you loaded them — reload and retry. Nothing was reordered.',
      });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await reserveWritableDocument(client, String(docId), tenantId);
      await assertCurrentSectionPermutation(client, String(docId), tenantId, ids);
      for (let i = 0; i < ids.length; i++) {
        await client.query(
          `UPDATE authoring_sections SET order_index = $1, updated_at = NOW()
             WHERE id = $2 AND doc_id = $3 AND tenant_id = $4`,
          [i, ids[i], docId, tenantId]
        );
      }
      await createAuditTrail(req, docId, null, 'REORDER_SECTIONS', null, null, null, { order: ids }, client);
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      throw e;
    } finally {
      client.release();
    }

    return res.json({ success: true, order: ids });
  } catch (error) {
    if (workflowGovernanceReply(error, res)) return;
    logger.error('section reorder failed', { error });
    return res.status(500).json({
      success: false,
      error: 'Failed to reorder sections. The previous order is unchanged.',
    });
  }
});

/* ════ Section images — the governed figure store ═══════════════════════════
 *
 * Section HTML stores a figure as a REFERENCE (`/api/authoring/images/<id>`),
 * never as base64: the append-only revision ledger and the Part 11 audit rows
 * copy section content on every save, so inlined bytes would multiply every
 * figure by every revision, and the editor's per-keystroke device cache would
 * blow the browser's storage quota on the first chromatogram.
 *
 * Storage REUSES the canonical upload store (`file_uploads` +
 * `uploads/org-{id}/{id}` on disk, via saveDerivedUpload/loadUploadedFile in
 * server/services/ana/uploaded-file-access.ts — the single sanctioned
 * upload-id→bytes resolver, which enforces tenancy on both the org column and
 * the path prefix). A second binary store for the same capability is exactly
 * the parallel path CLAUDE.md rules out.
 *
 * The accepted formats are the ones the DOCX exporter can embed (PNG, JPEG,
 * GIF). WebP is refused at upload rather than dropped at export; SVG is
 * refused because it is a script container, not a picture.
 */

const AUTHORING_IMAGE_MAX_BYTES = 8 * 1024 * 1024;

/* The canonical allowlist (middleware/uploadAllowlist.ts), narrowed to the
   three formats: admitted by extension or by declared type, never by an
   `image/` prefix — SVG and WebP declare one. What gets through is then held to
   its bytes and its name by assertUploadSafe in the handler (IAM-14). */
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: AUTHORING_IMAGE_MAX_BYTES, files: 1 },
  fileFilter: makeUploadFileFilter({
    extensions: ['png', 'jpg', 'jpeg', 'gif'],
    mimeTypes: ['image/png', 'image/jpeg', 'image/gif'],
  }),
});

/** Multer refusals (size, type) arrive as errors; they are client mistakes,
 *  not server faults, and must say so as a 400 with the reason. */
const imageUploadErrors = (err: unknown, _req: Request, res: Response, next: (e?: unknown) => void) => {
  if (!err) return next();
  const message =
    (err as { code?: string })?.code === 'LIMIT_FILE_SIZE'
      ? 'The image is larger than 8 MB. Nothing was uploaded.'
      : err instanceof multer.MulterError
        ? err.message
        : 'Only PNG, JPEG and GIF images are accepted — they are the formats a Word export can embed.';
  return res.status(400).json({ success: false, error: message });
};

/**
 * assertUploadSafe (middleware/uploadSafety.ts) on the bytes in hand: the
 * signature matches the declared type, the name binds the type, and the content
 * scan — fail-CLOSED in production — ran clean. Answers the refusal itself and
 * returns false when the file must not be used.
 */
async function refuseUnsafeUpload(
  res: Response,
  file: { buffer: Buffer; originalname?: string },
  verifyAs: string,
): Promise<boolean> {
  try {
    await assertUploadSafe(file.buffer, verifyAs, file.originalname || 'upload');
    return false;
  } catch (err) {
    if (err instanceof UploadSafetyError) {
      const said = /[.!?]$/.test(err.body.error) ? err.body.error : `${err.body.error}.`;
      res.status(err.status).json({ success: false, error: `${said} Nothing was uploaded.`, code: err.code });
      return true;
    }
    throw err;
  }
}

router.post(
  '/images',
  imageUpload.single('file'),
  imageUploadErrors as never,
  async (req: Request, res: Response) => {
    try {
      const tenantId = getTenantId(req);
      const actorId = getActorId(req);
      if (!actorId) {
        return res.status(401).json({ success: false, error: 'Authentication required' });
      }
      const file = (req as { file?: { buffer?: Buffer; mimetype?: string; originalname?: string } }).file;
      if (!file?.buffer || file.buffer.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Send the image as multipart/form-data under the field name "file".',
        });
      }

      // The bytes, the name and the scan (IAM-14). This ran the signature
      // check and the scan by hand and read only `scan.clean`, which the
      // scanner reports true when it did not run at all — so a production
      // deployment with no reachable scanner stored every figure unscanned,
      // and `figure.gif` with PNG bytes declared image/png was stored as is.
      if (await refuseUnsafeUpload(res, { buffer: file.buffer, originalname: file.originalname }, file.mimetype ?? '')) {
        return;
      }

      /* Multer's busboy parse breaks the AsyncLocalStorage tenant scope the
         middleware opened (its stream listeners run in the socket's context),
         so under RLS enforcement every query from here on would fail closed.
         Re-enter the exact scope this request was granted — the same repair
         vault-ingest documents. */
      const { runWithTenantScope } = await import('../db/tenantStore');
      const saved = await runWithTenantScope(
        {
          tenantId: String(tenantId),
          orgUuid: (req as { tenantContext?: { organizationUuid?: string | null } }).tenantContext?.organizationUuid ?? null,
          role: (req.user as { role?: string | null })?.role ?? null,
          source: 'request',
          caller: 'server/routes/authoring.router.ts:images',
        },
        async () => {
          const { saveAuthoringImage } = await import('../services/authoring/authoring-image-import');
          return saveAuthoringImage({ pool, tenantId, actor: { id: actorId, email: getActorEmail(req) },
            principal: authoringPrincipalFromRequest(req) }, { documentId: req.body?.documentId,
            file: { buffer: file.buffer!, mimetype: file.mimetype, originalname: file.originalname } });
        }
      );

      return res.status(201).json({
        success: true,
        image: {
          id: saved.fileId,
          url: `/api/authoring/images/${saved.fileId}`,
          mimeType: file.mimetype,
          byteSize: file.buffer.length,
        },
      });
    } catch (error) {
      if (error instanceof AnaProjectScopeError) return res.status(error.status).json({ success:false,code:error.code,error:error.message });
      logger.error('authoring image upload failed', { error });
      return res.status(500).json({ success: false, error: 'Failed to store the image. Nothing was saved.' });
    }
  }
);

router.get('/images/:id', async (req: Request, res: Response) => {
  try {
    const tenantId = getTenantId(req);
    const { loadUploadedFile } = await import('../services/ana/uploaded-file-access.js');
    const { AUTHORING_IMAGE_MIMES } = await import('../export/authoring-images.js');
    // Throws for an unknown id, a foreign tenant's id, or bytes gone from
    // disk — all collapse to the same 404 below, confirming nothing.
    const file = await loadUploadedFile(String(req.params.id), tenantId, { userId: Number(getActorId(req)) });
    if (!AUTHORING_IMAGE_MIMES.has(file.mimeType)) {
      // This endpoint serves figures, not arbitrary tenant uploads.
      return res.status(404).json({ success: false, error: 'Image not found' });
    }
    // Bytes are stable, but project/object grants and source dispositions are
    // current decisions. A year-long fresh cache would bypass their recheck.
    res.setHeader('Content-Type', file.mimeType);
    res.setHeader('Content-Length', String(file.buffer.length));
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('ETag', `"${file.fileId}"`);
    return res.end(file.buffer);
  } catch (error) {
    if (error instanceof AnaProjectScopeError) return res.status(error.status).json({ success: false, code: error.code, error: error.message });
    return res.status(404).json({ success: false, error: 'Image not found' });
  }
});

export default router;

/* ════ Word import ═══════════════════════════════════════════════════════════
 *
 * Four services in this repo already read .docx, and all four call mammoth's
 * `extractRawText` — a flat string, which is correct for the search and
 * retrieval they do and wrong for authoring. A regulatory author importing a
 * technical file needs the TABLES: a predicate comparison, a GSPR matrix, a
 * stability table IS the content, and raw text throws every one away while
 * leaving enough words on screen to look like a successful import
 * (MDX_WORK_ORDER W3-5).
 *
 * This route PARSES ONLY. It writes nothing: it returns the sections it found
 * so the author can see what arrived — how many sections, how many tables, and
 * every warning the conversion produced — and then create them deliberately
 * through POST /sections, which is the governed write with its lineage gate.
 * Importing straight into a document would put un-reviewed content into the
 * governed record on the strength of a drag-and-drop.
 */
const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

const docxImport = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024, files: 1 },
  // A .docx name or the .docx type; the bytes are held to it in the handler.
  fileFilter: makeUploadFileFilter({ extensions: ['docx'], mimeTypes: [DOCX_MIME] }),
});

const docxImportErrors = (err: unknown, _req: Request, res: Response, next: (e?: unknown) => void) => {
  if (!err) return next();
  const message =
    (err as { code?: string })?.code === 'LIMIT_FILE_SIZE'
      ? 'The document is larger than 25 MB. Nothing was imported.'
      : err instanceof multer.MulterError
        ? err.message
        : 'Only .docx files can be imported. A .doc (Word 97-2003) must be saved as .docx first.';
  return res.status(400).json({ success: false, error: message });
};

router.post(
  '/import/docx',
  docxImport.single('file'),
  docxImportErrors,
  async (req: Request, res: Response) => {
    try {
      if (!getActorId(req)) {
        return res.status(401).json({ success: false, error: 'Authentication required' });
      }
      const file = (req as Request & { file?: { buffer?: Buffer; originalname?: string } }).file;
      if (!file?.buffer?.length) {
        return res.status(400).json({ success: false, error: 'No document was uploaded.' });
      }
      /* Verified as the one format this route parses (IAM-14): a Word
         container, scanned, before mammoth opens it. Verifying against the
         .docx type rather than the declared one is deliberate — a browser on a
         machine without Office may declare application/octet-stream for a
         .docx, and the route never stores or serves the file, it only reads
         it as Word. */
      if (await refuseUnsafeUpload(res, { buffer: file.buffer, originalname: file.originalname }, DOCX_MIME)) {
        return;
      }

      const { importDocx } = await import('../import/docx-to-authoring.js');
      const result = await importDocx(file.buffer);

      return res.json({
        success: true,
        sections: result.sections,
        /* Surfaced, never swallowed: an author who is not told a style was
           dropped will file the document believing it arrived intact. */
        warnings: result.warnings,
        counts: result.counts,
      });
    } catch (error) {
      return serverError(res, logger, 'importing the Word document', error);
    }
  },
);
