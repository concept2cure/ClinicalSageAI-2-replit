from pathlib import Path
import os,sys,subprocess,time,json,gzip,hashlib
r=Path('/workspace/Concept2cure-v2');e=r/'docs/evidence/F1/2026-11-06-workflow-project-admission';kind=sys.argv[1]
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';env=os.environ.copy();env['PATH']=str(Path(node).parent)+':'+env['PATH']
unit=['server/services/tasking','server/routes/__tests__/task-management-governed-writes.test.ts','server/routes/__tests__/task-management-governed-writes-review.test.ts','server/routes/__tests__/task-management-reasons.test.ts','server/routes/__tests__/task-template-list.test.ts','server/routes/__tests__/task-template-merge.test.ts','server/routes/__tests__/task-assignment.pglite.test.ts','server/routes/__tests__/route-task-guard.pglite.integration.test.ts','server/routes/__tests__/route-task-guard-unified.pglite.integration.test.ts','server/services/review/__tests__/route-writer-setting.gate.test.ts','client/src/concept2cure/v2/__tests__/taskBoardTarget.test.tsx','client/src/concept2cure/v2/__tests__/taskBoardRefusalHonesty.test.tsx','client/src/concept2cure/v2/__tests__/taskBoardViewOnly.test.tsx']
native=['tests/db/workflow-project-admission.dbtest.ts','tests/db/task-assignment-delegation.dbtest.ts']
if kind=='unit':args=[node,'node_modules/vitest/vitest.mjs','run',*unit,'--reporter=dot']
elif kind=='native':
 args=[node,'node_modules/vitest/vitest.mjs','run','--config','vitest.db.config.ts',*native,'--reporter=dot'];env.update(TEST_DATABASE_URL='postgresql://postgres:workflow-local-owner@127.0.0.1:55432/c2c_workflow_dbtest',DATABASE_URL='postgresql://postgres:workflow-local-owner@127.0.0.1:55432/c2c_workflow_dbtest',NODE_ENV='test',CI='true')
elif kind=='typecheck':args=[node,'--max-old-space-size=12288','node_modules/typescript/bin/tsc','--project','/tmp/c2c-workflow-admission-types.json','--pretty','false','--listFiles']
elif kind=='build':args=['npm','run','build'];env['NODE_OPTIONS']='--max-old-space-size=6144'
elif kind=='gates':args=['sh','.husky/pre-push'];env['TYPECHECK_HEAP_MB']='12288'
elif kind=='lint':
 changed=subprocess.check_output(['git','diff','HEAD','--name-only','-z'],cwd=r).decode().split('\0')
 new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
 files=sorted({x for x in changed+new if x.endswith(('.ts','.tsx'))});args=[node,'node_modules/eslint/bin/eslint.js',*files]
else:raise ValueError(kind)
paths=subprocess.check_output(['git','ls-files','-z','client/src','server','shared','agents','tests/db'],cwd=r).decode().split('\0')
paths+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
paths=sorted({p for p in paths if p.endswith(('.ts','.tsx','.mjs')) and (r/p).is_file()})
paths+=['package.json','package-lock.json','tsconfig.json','docs/design/ONE_DESIGN_PLAN.md','docs/design/one-design-plan.json','AGENTS.md','CLAUDE.md','.husky/pre-push','scripts/ci/sql-interpolation-baseline.json']
def hashes():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths}
before=hashes();status=Path('/tmp/workflow-admission-'+kind+'-status.json');status.unlink(missing_ok=True);log=Path('/tmp/workflow-admission-'+kind+'.txt');start=time.time()
with log.open('w') as f:done=subprocess.run(args,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
after=hashes();code=done.returncode if before==after else 2
v={'exitCode':code,'processExitCode':done.returncode,'sourcesUnchanged':before==after,'sourceHashesBefore':before,'sourceHashesAfter':after,'args':args,'elapsedSeconds':round(time.time()-start,2)}
status.write_text(json.dumps(v)+'\n');dest=e/('green' if code==0 else 'red');dest.mkdir(exist_ok=True)
if (dest/(kind+'-status.json')).exists():
 old=(dest/(kind+'-status.json')).read_bytes();suffix=hashlib.sha256(old).hexdigest()[:10];(dest/(kind+'-'+suffix+'-status.json')).write_bytes(old)
 if (dest/(kind+'.txt.gz')).exists():(dest/(kind+'-'+suffix+'.txt.gz')).write_bytes((dest/(kind+'.txt.gz')).read_bytes())
(dest/(kind+'-status.json')).write_text(json.dumps(v,indent=2)+'\n');(dest/(kind+'.txt.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
print(json.dumps({'check':kind,'exitCode':code,'processExitCode':done.returncode,'sourcesUnchanged':before==after,'elapsedSeconds':v['elapsedSeconds'],'hashedFiles':len(before)}));sys.exit(code)
