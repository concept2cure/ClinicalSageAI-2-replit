from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,gzip,tarfile,io,tempfile,re
r=Path('/workspace/Concept2cure-v2');out=Path('/workspace/artifacts');out.mkdir(exist_ok=True)
e=r/'docs/evidence/F1/2026-11-06-workflow-project-admission';name='concept2cure-workflow-project-admission-2026-11-06'
sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:(json.dumps(v,indent=2)+'\n').encode()
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
v=json.loads((e/'verification.json').read_text());assert v['scopeVerified'] and all(x['exitCode']==0 for x in v['checks'].values())
assert git('rev-parse','HEAD').decode().strip()==v['HEAD'] and git('branch','--show-current').strip()==b'concept2cure-v2'
paths=sorted({p for p in (git('diff','HEAD','--name-only','-z')+git('ls-files','--others','--exclude-standard','-z')).decode().split('\0') if p})
changes={}
for p in paths:
 parts=PurePosixPath(p).parts;assert not PurePosixPath(p).is_absolute() and '..' not in parts
 assert not any(x in {'.git','node_modules','.env'} or x.startswith('.env.') for x in parts),p
 assert p in ['server/routes/taskManagement.routes.ts','server/services/tasking/task-project.ts','server/routes/__tests__/_task-management-governed-harness.ts','server/services/tasking/__tests__/task-project-admission.test.ts','tests/db/workflow-project-admission.dbtest.ts'] or p.startswith('docs/evidence/F1/2026-11-06-workflow-project-admission/'),p
 f=r/p;assert not f.is_symlink();new=f.read_bytes() if f.is_file() else None
 x=subprocess.run(['git','show','HEAD:'+p],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);old=x.stdout if x.returncode==0 else None
 if old!=new:changes[p]=(old,new)
members={}
with tempfile.TemporaryDirectory(prefix='workflow-admission-export-') as d:
 tmp=Path(d)
 for folder in ['before','after','verify']:(tmp/folder).mkdir()
 for p,(old,new) in changes.items():
  for folder,data in [('before',old),('verify',old),('after',new)]:
   if data is not None:f=tmp/folder/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
  if old is not None:members['before/'+p]=old
  if new is not None:members['files/'+p]=new
 x=subprocess.run(['git','diff','--no-index','--binary','--full-index','--no-renames','before/','after/'],cwd=tmp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert x.returncode==1
 lines=[]
 for line in x.stdout.splitlines(keepends=True):
  if line.startswith((b'diff --git ',b'--- ',b'+++ ')):
   for a,b in [(b'a/before/',b'a/'),(b'b/after/',b'b/'),(b'a/after/',b'a/'),(b'b/before/',b'b/')]:line=line.replace(a,b)
  lines.append(line)
 patch=b''.join(lines)
 for args in [['git','apply','--check','--whitespace=nowarn','-'],['git','apply','--whitespace=nowarn','-']]:subprocess.run(args,cwd=tmp/'verify',input=patch,check=True)
 for p,(_,new) in changes.items():f=tmp/'verify'/p;assert (f.read_bytes() if f.is_file() else None)==new,p
members['changes.patch']=patch;members['EXPORT.py']=Path(__file__).read_bytes();members['README.md']=(e/'DELIVERY.md').read_bytes()
state={'branch':'concept2cure-v2','HEAD':v['HEAD'],'scopeVerified':True,'committed':False,'pushed':False,'patchAppliedAndCompared':True,'paths':{p:{'beforeSha256':sha(old) if old is not None else None,'sha256':sha(new) if new is not None else None,'size':len(new) if new is not None else None} for p,(old,new) in changes.items()},'restore':'Use the exact HEAD above, apply changes.patch or copy files/ over it. before/ contains exact original bytes. This delta does not contain earlier October uncommitted work.'}
members['state.json']=enc(state)
manifest={p:{'sha256':sha(b),'size':len(b)} for p,b in members.items()};members['manifest.json']=enc(manifest)
dest=out/(name+'.tar.gz');assert not dest.exists()
with tarfile.open(dest,'w:gz') as a:
 for p,b in sorted(members.items()):t=tarfile.TarInfo(p);t.mode=0o600;t.mtime=0;t.size=len(b);a.addfile(t,io.BytesIO(b))
with tarfile.open(dest) as a:
 assert sorted(a.getnames())==sorted(members)
 for t in a.getmembers():assert t.isfile() and a.extractfile(t).read()==members[t.name],t.name
for p,(_,new) in changes.items():assert ((r/p).read_bytes() if (r/p).is_file() else None)==new,p
rules={'aws-key':rb'(?:AKIA|ASIA)[A-Z0-9]{16}','github-token':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})','openai-key':rb'(?<![A-Za-z0-9])sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}','private-key':rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----','jwt':rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'}
scanned=0;containers=0;findings=[]
def scan(p,b,depth=0):
 global scanned,containers
 assert depth<8
 if p.endswith('.tar.gz'):
  containers+=1
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as a:
   for t in a.getmembers():
    assert t.isfile() or t.isdir()
    if t.isfile():scan(p+':'+t.name,a.extractfile(t).read(),depth+1)
 elif p.endswith('.gz'):containers+=1;scan(p[:-3],gzip.decompress(b),depth+1)
 else:
  scanned+=1
  for kind,pattern in rules.items():
   if re.search(pattern,b):findings.append({'path':p,'kind':kind})
scan(dest.name,dest.read_bytes());assert not findings,json.dumps(findings)
report={'archive':str(dest),'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'paths':len(changes),'membersVerified':len(members),'patchAppliedAndCompared':True,'allMembersReadBack':True,'allCopiedPathsMatchLiveTree':True,'actualPackedCredentialScan':{'textPayloads':scanned,'containers':containers,'findings':findings},'scopeVerified':True,'committed':False,'pushed':False}
(out/(name+'.sha256')).write_text(report['sha256']+'  '+dest.name+'\n');(out/(name+'-manifest.json')).write_bytes(enc(manifest));(out/(name+'-verified.json')).write_bytes(enc(report));print(json.dumps(report,indent=2))
