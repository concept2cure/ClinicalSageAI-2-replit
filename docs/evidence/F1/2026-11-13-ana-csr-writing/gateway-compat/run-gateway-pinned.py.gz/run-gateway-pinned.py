import datetime, hashlib, json, os, pathlib, subprocess, sys, time

phase = sys.argv[1]
root = pathlib.Path('/workspace/ClinicalSageAI-2-replit')
out = pathlib.Path('/workspace/scratch/ana-csr-20261113/gateway-compat')
tests = ['server/services/ana/__tests__/run-coordination-dispositions.test.ts', 'server/services/ana/__tests__/turn-plan-and-context.test.ts', 'server/services/submission-gateways/__tests__/gateway-accounts.test.ts', 'server/services/submission-gateways/__tests__/gateway-qualification.test.ts', 'server/services/submission-gateways/__tests__/refused-before-wire.test.ts', 'server/services/submission-gateways/__tests__/sent-record-rederive.test.ts']
selected = ['server/services/ana/__tests__/run-coordination-dispositions.test.ts', 'server/services/ana/__tests__/turn-plan-and-context.test.ts', 'server/services/submission-gateways/__tests__/gateway-accounts.test.ts', 'server/services/submission-gateways/__tests__/gateway-qualification.test.ts', 'server/services/submission-gateways/__tests__/refused-before-wire.test.ts', 'server/services/submission-gateways/__tests__/sent-record-rederive.test.ts', 'server/services/ana/turn-plan.ts', 'server/services/submission-gateways/gateway-accounts.ts', 'server/services/submission-gateways/index.ts', 'server/services/ana/AnaDocumentDraftingService.ts', 'server/services/ana/statistical-narrator.ts', 'server/services/ana/medical-writing.ts', 'server/services/ana/skills/library/clinical.ts', 'server/services/authoring/authoring-draft-template.ts', 'server/services/ai-governance/approved-models.ts', 'server/eval/pq/pq-protocol.json', 'vitest.config.ts', 'package.json', 'package-lock.json', 'tests/setup.ts']
def snapshot():
    return {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in selected}
before = snapshot()
(out/(phase+'-source-before.json')).write_text(json.dumps(before, indent=2)+'\n')
env = os.environ.copy()
env['PATH'] = '/home/agent/.npm/_npx/6d82ddbdd7da268b/node_modules/node/bin:'+env['PATH']
env['NODE_OPTIONS'] = '--max-old-space-size=4096'
argv = ['npx','vitest','run','--config','vitest.config.ts',*tests,'--reporter=json','--outputFile='+str(out/(phase+'.json'))]
command = {'argv':argv,'cwd':str(root),'node':'22.22.0','environment':{'NODE_OPTIONS':env['NODE_OPTIONS']},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start = time.monotonic()
with (out/(phase+'.txt')).open('w') as log:
    result = subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
command.update(exitCode=result.returncode,processSeconds=round(time.monotonic()-start,3))
(out/(phase+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
after=snapshot()
(out/(phase+'-source-after.json')).write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({'phase':phase,**command,'selectedPins':len(before),'sourceStable':before==after}))
if before!=after:sys.exit(3)
sys.exit(result.returncode)
