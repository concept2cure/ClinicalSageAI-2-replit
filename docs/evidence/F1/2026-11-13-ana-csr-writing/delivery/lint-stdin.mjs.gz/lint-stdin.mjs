import fs from 'node:fs';
import path from 'node:path';
import { ESLint } from 'eslint';
const root=process.cwd();const out='/workspace/scratch/ana-csr-20261113/delivery';const eslint=new ESLint({cwd:root});
const files=[['service','server/services/ana/AnaDocumentDraftingService.ts','service-before.ts'],['template','server/services/authoring/authoring-draft-template.ts','template-before.ts']];
const counts=[];
for(const [label,file,old] of files){
 const before=await eslint.lintText(fs.readFileSync(path.join(out,old),'utf8'),{filePath:path.join(root,file)});
 const after=await eslint.lintFiles([file]);
 fs.writeFileSync(path.join(out,'lint-before-'+label+'.json'),JSON.stringify(before,null,2)+'\n');
 fs.writeFileSync(path.join(out,'lint-after-'+label+'.json'),JSON.stringify(after,null,2)+'\n');
 counts.push({file,beforeErrors:before[0].errorCount,beforeWarnings:before[0].warningCount,afterErrors:after[0].errorCount,afterWarnings:after[0].warningCount});
}
const test='server/services/ana/__tests__/csr-writing-delivery.test.ts';const result=await eslint.lintFiles([test]);fs.writeFileSync(path.join(out,'lint-after-test.json'),JSON.stringify(result,null,2)+'\n');counts.push({file:test,afterErrors:result[0].errorCount,afterWarnings:result[0].warningCount});
fs.writeFileSync(path.join(out,'lint-checks.json'),JSON.stringify({method:'ESLint API, original text at actual same filePath; no source swaps',counts},null,2)+'\n');console.log(JSON.stringify(counts));
