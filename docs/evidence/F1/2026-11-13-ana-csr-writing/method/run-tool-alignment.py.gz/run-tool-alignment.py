import pathlib,json,subprocess,os,time,datetime,hashlib,sys
root=pathlib.Path('/workspace/ClinicalSageAI-2-replit');out=pathlib.Path('/workspace/scratch/ana-csr-20261113/method');phase=sys.argv[1]
selection=json.loads((out/'tool-alignment-selection.json').read_text())
files=selection['files']
def snapshot():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=snapshot();(out/(phase+'-source-before.json')).write_text(json.dumps(before,indent=2)+'\n')
argv=['npx','vitest','run','--config','vitest.config.ts',*selection['tests'],'--reporter=json','--outputFile='+str(out/(phase+'.json'))]
env=os.environ.copy();env['PATH']='/home/agent/.npm/_npx/6d82ddbdd7da268b/node_modules/node/bin:'+env['PATH'];env['NODE_OPTIONS']='--max-old-space-size=4096';t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(phase+'.txt')).open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();(out/(phase+'-source-after.json')).write_text(json.dumps(after,indent=2)+'\n');record={'argv':argv,'cwd':str(root),'environment':{'node':'22.22.0','PATH_prefix':env['PATH'].split(':')[0],'NODE_OPTIONS':env['NODE_OPTIONS']},'startedAt':started,'exitCode':r.returncode,'processSeconds':round(time.monotonic()-t,3),'sourcePins':len(before),'sourceUnchanged':before==after};(out/(phase+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(r.returncode)
