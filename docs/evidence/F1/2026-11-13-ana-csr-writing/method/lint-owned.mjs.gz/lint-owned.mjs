import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const root='/workspace/ClinicalSageAI-2-replit';
const out='/workspace/scratch/ana-csr-20261113/method';
const require=createRequire(path.join(root,'package.json'));
const { ESLint }=require('eslint');
const eslint=new ESLint({cwd:root});
const initial=JSON.parse(fs.readFileSync(path.join(out,'initial-owned-source.json'),'utf8'));
const baseline=[];
for(const f of Object.keys(initial)){
 const text=fs.readFileSync(path.join(out,f.replaceAll('/','__')+'.original'),'utf8');
 baseline.push(...await eslint.lintText(text,{filePath:path.join(root,f)}));
}
const files=[...Object.keys(initial),'server/services/ana/__tests__/csr-authoring-method.test.ts'];
const current=await eslint.lintFiles(files.map(f=>path.join(root,f)));
fs.writeFileSync(path.join(out,'lint-baseline.json'),JSON.stringify(baseline,null,2)+'\n');
fs.writeFileSync(path.join(out,'lint-current.json'),JSON.stringify(current,null,2)+'\n');
const byFile=new Map(baseline.map(r=>[path.relative(root,r.filePath),r]));
const comparison=current.map(r=>{
 const f=path.relative(root,r.filePath);const before=byFile.get(f);
 return {path:f,newTest:!before,before:before?{errors:before.errorCount,warnings:before.warningCount}:null,
  current:{errors:r.errorCount,warnings:r.warningCount},warningDelta:r.warningCount-(before?.warningCount??0),
  messages:r.messages.map(m=>({line:m.line,ruleId:m.ruleId,severity:m.severity,message:m.message}))};
});
fs.writeFileSync(path.join(out,'lint-comparison.json'),JSON.stringify(comparison,null,2)+'\n');
console.log(JSON.stringify(comparison));
process.exit(current.some(r=>r.errorCount)||comparison.some(r=>r.warningDelta>0)?1:0);
