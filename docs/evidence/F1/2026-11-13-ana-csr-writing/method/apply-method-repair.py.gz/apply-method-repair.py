from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/ClinicalSageAI-2-replit');out=Path('/workspace/scratch/ana-csr-20261113/method')
def old(path):return subprocess.check_output(['git','show','5b611fb6898f70105e327b2d9a1819177daa5fd6:'+path],cwd=root,text=True)
def replace_once(text,before,after):
 assert text.count(before)==1,before[:100]
 return text.replace(before,after,1)
initial=json.loads((out/'initial-owned-source.json').read_text())
for f,sha in initial.items():
 if '__tests__' not in f:assert hashlib.sha256((root/f).read_bytes()).hexdigest()==sha,f
# Extend only the current first medical-writing skill, preserving later overview/summary tools and methods.
f='server/services/ana/skills/library/medical-writing.ts';p=root/f;s=p.read_text();prior=old(f)
s=replace_once(s,"    key: 'medical-writing',\n","    key: 'medical-writing',\n    version: 2,\n")
a=s.index('    instructions: `');b=s.index('\n`,',a)+4
x=prior.index('    instructions: `');y=prior.index('\n`,',x)+4
s=s[:a]+prior[x:y]+s[b:];p.write_text(s)
# Extend only the study-report skill; preserve its current figure receipts, tools, and canvas/editor step12.
f='server/services/ana/skills/library/clinical.ts';p=root/f;s=p.read_text();prior=old(f)
s=replace_once(s,"    key: 'clinical.study-report',\n","    key: 'clinical.study-report',\n    version: 2,\n")
start=s.index("    key: 'clinical.study-report',");end=s.index('\n  skill({',start)
block=s[start:end];priorstart=prior.index("    key: 'clinical.study-report',");priorend=prior.index('\n  skill({',priorstart);ob=prior[priorstart:priorend]
for step in (6,11):
 line=next(t for t in block.splitlines() if t.startswith(str(step)+'. '));oldline=next(t for t in ob.splitlines() if t.startswith(str(step)+'. '));block=replace_once(block,line,oldline)
method=next(t for t in ob.splitlines() if t.startswith('12. Author in stages: '))[4:]
block=replace_once(block,'\n## Pitfalls reviewers raise','\n## Compose and revise\n'+method+'\n\n## Pitfalls reviewers raise')
s=s[:start]+block+s[end:];p.write_text(s)
# Recover only the source/craft/therapeutic wording hunks; current exemplar controls and APIs are unchanged.
f='server/services/ana/medical-writing.ts';p=root/f;s=p.read_text();prior=old(f)
for opening in ('  \'Lead with the conclusion;', '  \'Every data statement is traceable', '  \'Consistency is law:'):
 original=next(t for t in s.splitlines() if t.startswith(opening))
 lookup={'  \'Lead with the conclusion;':'  \'Lead with the answer appropriate', '  \'Every data statement is traceable':'  \'Every data statement is traceable', '  \'Consistency is law:':'  \'Compare like with like:'}[opening]
 fixed=next(t for t in prior.splitlines() if t.startswith(lookup));s=replace_once(s,original,fixed)
for area in ('oncology','cardiology'):
 start=s.index("    id: '"+area+"'");end=s.index('\n  },',start)
 b=s[start:end];ps=prior.index("    id: '"+area+"'");pe=prior.index('\n  },',ps);pb=prior[ps:pe]
 for prefix in (['    csrVocabulary:'] if area=='oncology' else ['    reportingConventions:','    csrVocabulary:']):
  before=next(t for t in b.splitlines() if t.startswith(prefix));after=next(t for t in pb.splitlines() if t.startswith(prefix));b=replace_once(b,before,after)
 s=s[:start]+b+s[end:]
a=s.index("  parts.push(\n    '\\n## How to use the evidence")
b=s.index('\n  );',a)+5
x=prior.index("  parts.push(doc?.id === 'csr'");y=prior.index('\n  );',x)+5
s=s[:a]+prior[x:y]+s[b:];p.write_text(s)
# Extend the existing canonical rules, without replacing current sentence patterns or scientific gates.
f='server/services/ind/ctd/csr-e3-writing.ts';p=root/f;s=p.read_text();prior=old(f)
s=replace_once(s," | 'estimand' | 'source';"," | 'estimand' | 'source' | 'composition' | 'revision';")
newrules='\n'.join(t for t in prior.splitlines() if t.startswith("  { topic: 'composition'") or t.startswith("  { topic: 'revision'"))
s=replace_once(s,"  { topic: 'source', rule: CONDUCT_SOURCE_RULE, basis: CRAFT },","  { topic: 'source', rule: CONDUCT_SOURCE_RULE, basis: CRAFT },\n"+newrules);p.write_text(s)
# Report approval as it currently stands; retain the actual unexecutable-component and model qualification holds.
f='server/eval/pq/run-pq.ts';p=root/f;s=p.read_text()
s=replace_once(s,"      'Approve the canonical PQ protocol and acceptance criteria through the responsible system-owner process.',","      ...(protocol.status === 'approved' && protocol.approvedBy && protocol.approvedOn ? []\n        : ['Approve the canonical PQ protocol and acceptance criteria through the responsible system-owner process.']),\n      ...Object.entries(protocol.components).filter(([, component]) => component.required && !component.executable)\n        .map(([name, component]) => `Required PQ component ${name} cannot be executed yet: ${component.notExecutableReason ?? 'Complete its existing qualification harness and evidence checks before running qualification.'}`),")
p.write_text(s)
print('Applied current-source writing/IA status repairs to five owned runtime files')
