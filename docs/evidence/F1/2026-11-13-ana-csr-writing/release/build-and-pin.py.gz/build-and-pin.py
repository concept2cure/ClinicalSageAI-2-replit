import datetime, hashlib, json, os, pathlib, subprocess, sys, time

root=pathlib.Path('/workspace/ClinicalSageAI-2-replit')
out=pathlib.Path('/workspace/scratch/ana-csr-20261113/release')
out.mkdir(parents=True,exist_ok=True)
def snapshot():
    names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
    selected=sorted({name for name in names if name and (name.startswith(('client/','server/','shared/','scripts/')) or pathlib.Path(name).name in ['package.json','package-lock.json','.npmrc','.nvmrc','.node-version'] or ('/' not in name and ('config' in name or name.startswith('eslint'))))})
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in selected if (root/name).is_file()}}
before=snapshot()
(out/'build-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
env['PATH']='/home/agent/.npm/_npx/6d82ddbdd7da268b/node_modules/node/bin:'+env['PATH']
env['NODE_OPTIONS']='--max-old-space-size=6144'
command={'argv':['npm','run','build'],'cwd':str(root),'node':'22.22.0','environment':{'NODE_OPTIONS':env['NODE_OPTIONS']},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start=time.monotonic()
with (out/'build.txt').open('w') as log:
    result=subprocess.run(command['argv'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot()
(out/'build-after.json').write_text(json.dumps(after,indent=2)+'\n')
command.update(exitCode=result.returncode,processSeconds=round(time.monotonic()-start,3),selectedSourceFiles=len(before['files']),sourceStable=before==after)
(out/'build-command.json').write_text(json.dumps(command,indent=2)+'\n')
print(json.dumps(command))
sys.exit(result.returncode if before==after else 3)
