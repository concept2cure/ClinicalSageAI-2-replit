import { Router, Request, Response } from 'express';
import { db } from '../db';
import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';
import { and, eq, desc, asc, isNull, sql } from 'drizzle-orm';
import {
  unifiedTasks,
  taskTemplates,
  taskAutomation,
  taskDependencies,
  users,
  organizationUsers,
} from '../../shared/schema';
import { getSecureOrgId } from '../utils/tenantContext';
import { requireEditorAccess, governedActorId } from '../middleware/orgMembership';
import { governedWriter, auditWriteFailed, outcomeUnknown } from '../services/tasking/governed-task-write';
import {
  auditTaskAction,
  auditTaskActionInTx,
  TaskAuditNotRecordedError,
} from '../services/tasking/task-audit';
import { loadTaskAnalytics } from '../services/tasking/task-analytics';
import { listTemplatesForOrg } from '../services/tasking/task-template-catalog';
import { createNotification } from '../services/notifications/notification-service';
import {
  getBuiltinWorkflowTemplate,
} from '../services/tasking/workflow-templates';
import {
  TASK_STATUSES,
  TASK_TRANSITIONS,
  CREATABLE_TASK_STATUSES,
  isLegalTransition,
  refuseRouteColumnsInInput,
  refuseRouteTaskWrite,
  RouteTaskWriteRefused,
  routeTaskRefusalBody,
  type TaskStatus,
} from '../services/tasking/task-state-machine';
import {
  notifyTaskEvent,
  cascadeUnblockOnCompletionInTx,
  wouldCreateDependencyCycle,
  type TaskEventNotice,
} from '../services/tasking/task-side-effects';
import { requireTaskSignoff, type SignoffManifestation } from '../services/tasking/task-signoff';
import {
  calculateCriticalPath,
  getOptimalAssignee,
} from '../services/tasking/task-planning';
import { requestDb, requestPgClient, type RequestDb } from '../db/requestDb';
import { createTaskInTx, type TaskInsertRunner } from '../services/tasking/create-task';
import { readMyWork } from '../services/tasking/my-work';
import { routeRemindRefusal } from '../services/review/review-route';
import { queryableFromDrizzle } from '../db/drizzle-queryable';
import { projectForTaskSource, PROJECT_TELLING_SOURCES, requireTaskProjectId,
  admitTaskCreationProject, TaskProjectAdmissionError } from '../services/tasking/task-project';
import { assignTask, assignmentExpectedSchema, assignmentFailure, namedAssignmentSchema, TaskAssignmentUnknown } from '../services/tasking/task-assignment';

const router = Router();
const storage = { db };

/* Every write below is ROLE-GATED with requireEditorAccess (the repo's one
   governed-write gate): an org `viewer` reads the board but may not author a
   task, a transition or a ledger row naming them. Reads stay open. The sibling
   router over this table (unifiedTasks.routes.ts, /api/regulatory/tasks) is
   held to the same rules and gives the same answers: both import
   governedWriter / auditWriteFailed / outcomeUnknown from
   services/tasking/governed-task-write. */

const taskStatusSchema = z.enum(TASK_STATUSES);
// Creation cannot mint a terminal status — see CREATABLE_TASK_STATUSES.
const creatableStatusSchema = z.enum(CREATABLE_TASK_STATUSES);

const jsonPrimitiveSchema = z.union([z.string(), z.number(), z.boolean(), z.null()]);
type JsonValue = z.infer<typeof jsonPrimitiveSchema> | { [key: string]: JsonValue } | JsonValue[];
const jsonValueSchema: z.ZodType<JsonValue> = z.lazy(() =>
  z.union([jsonPrimitiveSchema, z.array(jsonValueSchema), z.record(z.string(), jsonValueSchema)])
);
const stringArraySchema = z.array(z.string());
const taskDefinitionSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(1),
  description: z.string().optional(),
  moduleType: z.string().optional(),
  category: z.string().optional(),
  taskType: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high', 'critical']).optional(),
  dayOffset: z.number().int().optional(),
  duration: z.number().int().positive().optional(),
  estimatedHours: z.number().positive().optional(),
});
const templateDependencySchema = z.object({
  predecessor: z.string().min(1),
  successor: z.string().min(1),
  type: z.enum(['finish-to-start', 'start-to-start', 'finish-to-finish', 'start-to-finish']).optional(),
  lag: z.number().int().optional(),
});

// Task creation schema
const createTaskSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  moduleType: z.string(),
  moduleSource: z.string().optional(),
  moduleData: jsonValueSchema.optional(),
  projectId: z.number().optional(),
  category: z.string().optional(),
  taskType: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  // Initial board column chosen in the create form (real column). Defaults to
  // 'pending' when omitted; constrained to the CREATABLE domain — free text let
  // a create mint a status no view could render (assessment D23), and a
  // terminal status let it mint an already-completed approval-gated task
  // without the sign-off ceremony (the gate only runs on transitions).
  status: creatableStatusSchema.optional(),
  assigneeId: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).optional(),
  startDate: z.string().optional(),
  dueDate: z.string().optional(),
  estimatedHours: z.number().optional(),
  // Polymorphic origin — the entity this task was raised from (a section, a
  // safety case, a filing). Real unified_tasks columns; the launcher captures
  // them and they now persist instead of being dropped.
  sourceEntityType: z.string().max(80).optional(),
  sourceEntityId: z.string().max(200).optional(),
  // Governance flags collected by the ui-v2 create form — real unified_tasks
  // columns, so the form's inputs persist instead of being silently dropped.
  impactScore: z.number().min(0).max(10).optional(),
  criticalPath: z.boolean().optional(),
  regulatoryImpact: z.boolean().optional(),
  approvalRequired: z.boolean().optional(),
  dependencies: z.array(z.string()).optional(),
  tags: z.array(z.string()).optional(),
  automationRules: jsonValueSchema.optional(),
  escalationPath: jsonValueSchema.optional(),
});

// Bulk task creation schema
const bulkCreateTasksSchema = z.object({
  tasks: z.array(createTaskSchema),
  linkDependencies: z.boolean().default(true),
});

// Task dependency schema
const createDependencySchema = z.object({
  predecessorTaskId: z.string(),
  successorTaskId: z.string(),
  dependencyType: z.enum([
    'finish-to-start',
    'start-to-start',
    'finish-to-finish',
    'start-to-finish',
  ]),
  lagTime: z.number().default(0),
  isBlocking: z.boolean().default(true),
});

// Task template creation schema
const createTemplateSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  category: z.string(),
  submissionType: z.string().optional(),
  milestone: z.string().optional(),
  tasks: z.array(taskDefinitionSchema),
  dependencies: z.array(templateDependencySchema).optional(),
  milestones: z.array(z.string()).optional(),
  defaultDuration: z.number().optional(),
  bestPractices: z.string().optional(),
  regulatoryRequirements: stringArraySchema.optional(),
  riskFactors: stringArraySchema.optional(),
});

// Automation rule schema
const createAutomationSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  ruleType: z.enum(['event-based', 'schedule-based', 'condition-based']),
  triggerModule: z.string().optional(),
  triggerEvent: z.string(),
  triggerConditions: jsonValueSchema.optional(),
  actionType: z.string(),
  taskTemplate: taskDefinitionSchema.optional(),
  taskDefaults: jsonValueSchema.optional(),
  delayMinutes: z.number().optional(),
  recurringSchedule: jsonValueSchema.optional(),
  workloadBalancing: z.boolean().default(true),
  smartAssignment: jsonValueSchema.optional(),
});

/**
 * The project a new task is on, or null once a refusal has been sent.
 *
 * A task raised on an authoring document is on that document's program's
 * project (services/tasking/task-project.ts), read on the request's RLS client.
 * Assign review sends no projectId — the editor holds the program UUID, not
 * projects.id — so the reviewer's task was stored with project_id NULL and the
 * program's Review tab, which reads work by project, listed nothing (QA
 * 2026-10-08, second walk, j1). A project the caller named is kept. A read that
 * cannot complete refuses the create (503): a task whose project could not be
 * told is not written.
 */
async function taskProjectOrRefuse(
  req: Request,
  res: Response,
  organizationId: number,
  data: { projectId?: number; sourceEntityType?: string; sourceEntityId?: string },
): Promise<{ projectId: number | undefined } | null> {
  if (data.projectId !== undefined || !PROJECT_TELLING_SOURCES.includes(String(data.sourceEntityType))) {
    return { projectId: data.projectId };
  }
  try {
    const projectId = await projectForTaskSource(requestDb(req), {
      orgId: organizationId,
      sourceEntityType: data.sourceEntityType,
      sourceEntityId: data.sourceEntityId,
    });
    return { projectId: projectId ?? undefined };
  } catch (err) {
    console.error('Task create: the source document\'s project could not be read:', err instanceof Error ? err.message : err);
    res.status(503).json({
      success: false,
      code: 'TASK_PROJECT_UNREADABLE',
      error: 'The project of the document this task is for could not be read. Nothing was created; try again.',
    });
    return null;
  }
}

/** Tell a new task's assignee it is theirs, unless they created it themselves. */
function notifyNewAssignee(
  organizationId: number,
  assigneeId: number | undefined,
  actorUserId: number,
  task: { title: string; description?: string },
  taskId: string,
): void {
  if (!assigneeId || assigneeId === actorUserId) return;
  notifyTaskEvent({
    organizationId,
    recipientUserId: assigneeId,
    category: 'task_assigned',
    title: `Task assigned: ${task.title}`,
    body: task.description ?? null,
    taskId,
  });
}

// Critical-path + workload-balancing helpers live in
// services/tasking/task-planning (extracted for the repo-health line gate).
// Create single task
router.post('/tasks', requireEditorAccess, async (req: Request, res: Response) => {
  let commitInFlight = false;
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    // A route member is written only by the review route (RR1a, B1/M9).
    refuseRouteColumnsInInput(req.body, 'task.create');
    const validatedData = createTaskSchema.parse(req.body);
    const taskId = `TASK-${Date.now()}-${uuidv4().substr(0, 8)}`;

    // Auto-assign if not specified
    let assigneeId = validatedData.assigneeId;
    let assigneeName: string | null = null;
    /* A NAMED assignee is someone in this organization, recorded with who
       assigned the task and when (QA 2026-10-08, j4: the review task Assign
       review creates was stored with assignee_name, assigned_by and assigned_at
       all NULL — "ASSIGNED BY --" in the drawer — and any integer was accepted
       as the assignee). Resolved before anything is written; a non-member is
       refused. */
    let assignment: { assignedBy: number; assignedAt: Date } | null = null;
    if (assigneeId) {
      const [member] = await storage.db
        .select({ id: users.id, name: users.name, email: users.email })
        .from(users)
        .innerJoin(organizationUsers, eq(organizationUsers.userId, users.id))
        .where(and(eq(users.id, assigneeId), eq(organizationUsers.organizationId, organizationId)))
        .limit(1);
      if (!member) {
        return res.status(400).json({
          success: false,
          code: 'ASSIGNEE_NOT_MEMBER',
          error: 'The assignee is not a member of this organization. Nothing was created.',
        });
      }
      assigneeName = member.name || (member.email ? String(member.email).split('@')[0] : null);
      assignment = { assignedBy: actorUserId, assignedAt: new Date() };
    }

    const project = await taskProjectOrRefuse(req, res, organizationId, validatedData);
    if (!project) return;

    if (!assigneeId) {
      const optimalAssignee = await getOptimalAssignee(organizationId, validatedData);
      if (optimalAssignee) {
        assigneeId = optimalAssignee.id;
        assigneeName = optimalAssignee.name;
      }
    }

    const { startDate, dueDate, ...taskFields } = validatedData;
    // Part 11 lineage — the create is written to the governed ledger on THIS
    // path too (assessment D11), in the create's own transaction.
    const newTask = await storage.db.transaction(async (tx) => {
      const row = await createTaskInTx(tx as unknown as TaskInsertRunner, {
        organizationId,
        actorUserId,
        taskId,
        values: {
          ...taskFields,
          projectId: project.projectId,
          startDate: startDate ? new Date(startDate) : undefined,
          dueDate: dueDate ? new Date(dueDate) : undefined,
          assigneeId,
          assigneeName,
          ...(assignment ?? {}),
          status: validatedData.status ?? 'pending',
          progress: 0,
          completionPercentage: 0,
        },
        auditPayload: {
          moduleType: validatedData.moduleType,
          title: validatedData.title,
          priority: validatedData.priority,
          status: validatedData.status ?? 'pending',
          assigneeId: assigneeId ?? null,
          sourceEntityType: validatedData.sourceEntityType ?? null,
          sourceEntityId: validatedData.sourceEntityId ?? null,
        },
        reason: typeof req.body?.reason === 'string' ? req.body.reason : undefined,
      });
      commitInFlight = true;
      return row;
    });
    commitInFlight = false;

    notifyNewAssignee(organizationId, assigneeId, actorUserId, validatedData, taskId);

    res.json({
      success: true,
      data: newTask,
    });
  } catch (error) {
    if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
    if (error instanceof TaskAuditNotRecordedError) return auditWriteFailed(res, 'The task');
    if (commitInFlight) return outcomeUnknown(res);
    console.error('Error creating task:', error);
    res.status(400).json({
      success: false,
      error: error instanceof z.ZodError ? error.issues : 'Failed to create task',
    });
  }
});

// Update a task's board column / progress — backs the ui-v2 board's move
// between columns. Org-scoped (taskId + organizationId), so no cross-org task
// can be moved. Transitions run the state machine, write the Part 11 ledger,
// cascade the unblock on completion, and notify the people affected.
const updateTaskStatusSchema = z.object({
  status: taskStatusSchema,
  progress: z.number().min(0).max(100).optional(),
  reason: z.string().max(1000).optional(),
  // The e-signature ceremony for approval-gated completion: the signer's
  // password, and the authenticator code when one is enrolled, re-verified by
  // services/part11/reverify-signer.ts. Used for verification only — never
  // logged, audited, or echoed back.
  signature: z
    .object({
      password: z.string().min(1).max(256),
      mfaToken: z.string().max(12).optional(),
      meaning: z.string().max(40),
    })
    .optional(),
});

/**
 * The columns PATCH /tasks/:taskId's compare-and-set UPDATE writes for one
 * transition. Called at the UPDATE, inside its transaction, so the timestamps
 * are the write's own.
 */
function transitionChanges(t: {
  status: TaskStatus;
  progress: number | undefined;
  isDone: boolean;
  isReopen: boolean;
  statusChanges: boolean;
  manifestation: SignoffManifestation | null;
  actorUserId: number;
}) {
  const { progress, isDone, isReopen, statusChanges, manifestation } = t;
  return {
    status: t.status,
    progress,
    completionPercentage: progress,
    // Only a real move into `completed` stamps the time. Signing a task
    // that is already complete attests to that completion; the
    // manifestation carries its own signedAt.
    completedAt: isDone && statusChanges ? new Date() : isReopen ? null : undefined,
    // Reopening retires the signature. The stored manifestation attests to
    // the record as it stood at first completion; once the task is reopened
    // and worked on, that attestation is stale, so the gate has to close
    // again. Without this, a task signed once could be reopened, changed
    // and re-completed indefinitely with no new signature, meaning or reason —
    // and it rendered "approved" the whole time it sat back in progress.
    ...(isReopen ? { approvalStatus: 'pending' as string } : {}),
    // Placed after the reopen reset so a real signature always wins.
    // Appended in SQL rather than read-then-written: two concurrent
    // sign-offs each reading the same prior array would write
    // [...same, mine] and silently drop one verified §11.50 manifestation
    // while its ledger entry persisted. approval_history is `json`, so the
    // concat casts through jsonb and back.
    ...(manifestation
      ? {
          approvalStatus: 'approved',
          approvalHistory: sql`(COALESCE(${unifiedTasks.approvalHistory}, '[]'::json)::jsonb || ${JSON.stringify([manifestation])}::jsonb)::json`,
        }
      : {}),
    lastModifiedBy: t.actorUserId,
    updatedAt: new Date(),
  };
}

router.patch('/tasks/:taskId', (req, res, next) => {
  if (req.body?.action === 'assign') return next();
  return requireEditorAccess(req, res, next);
}, async (req: Request, res: Response) => {
  if (req.body?.action === 'assign') {
    try {
      const input = namedAssignmentSchema.parse(req.body);
      const data = await assignTask(req, { ...input, taskId: String(req.params.taskId), method: 'named' });
      return res.json({ success: true, data });
    } catch (error) { return assignmentFailure(res, error); }
  }
  if (req.body && ['assigneeId','expectedAssigneeId','expectedVersion','action'].some(key => key in req.body)) {
    return res.status(400).json({ success: false, code: 'VALIDATION_ERROR', error: 'Assignment and status changes must be separate requests.' });
  }
  // Set while the transaction's COMMIT is in flight: a failure then leaves the
  // change — a signed completion and its cascade included — neither confirmed
  // nor refuted, and the answer must say so rather than guess.
  let commitInFlight = false;
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const taskId = String(req.params.taskId);
    const parsed = updateTaskStatusSchema.parse(req.body);

    // Fetch-first: the transition is validated against the task's REAL current
    // status, and a cross-org id 404s before anything is written.
    const [existing] = await storage.db
      .select()
      .from(unifiedTasks)
      .where(
        and(
          eq(unifiedTasks.taskId, taskId),
          eq(unifiedTasks.organizationId, organizationId),
          isNull(unifiedTasks.deletedAt)
        )
      )
      .limit(1);
    if (!existing) {
      return res.status(404).json({ success: false, error: 'Task not found' });
    }
    // A route member's status is the route's (RR1a, B1).
    refuseRouteTaskWrite(existing, 'task.transition');

    if (!isLegalTransition(existing.status, parsed.status)) {
      return res.status(409).json({
        success: false,
        error: `A task in "${existing.status}" cannot move to "${parsed.status}".`,
        from: existing.status,
        allowed: TASK_TRANSITIONS[existing.status as TaskStatus] ?? [],
      });
    }

    // Approval-gated completion demands the §11.50 signature ceremony —
    // re-verified identity, stated meaning, reason. 428 tells the client to
    // run the ceremony; nothing is written until it verifies.
    const signoff = await requireTaskSignoff({
      organizationId,
      task: existing,
      toStatus: parsed.status,
      actor: {
        userId: actorUserId,
        email: typeof (req as any).userEmail === 'string'
          ? (req as any).userEmail
          : ((req as any).user?.email ?? null),
        name: (req as any).userName ?? (req as any).user?.name ?? null,
      },
      signature: parsed.signature,
      reason: parsed.reason,
    });
    if (signoff.required && !signoff.ok) {
      return res.status(signoff.status).json({
        success: false,
        code: signoff.code,
        error: signoff.error,
      });
    }
    const manifestation = signoff.required && signoff.ok ? signoff.manifestation : null;

    const isDone = parsed.status === 'completed';
    const progress = parsed.progress ?? (isDone ? 100 : undefined);
    const isReopen = existing.status === 'completed' && parsed.status !== 'completed';
    const statusChanges = existing.status !== parsed.status;
    // isLegalTransition passes from === to, so a same-status PATCH reaches here.
    // It is a write only if it carries a signature or moves progress; otherwise
    // the caller's view is stale (a board still showing a task someone else
    // completed) and re-running the UPDATE would rewrite a signed record's
    // completion time and last editor with nothing to record. Refused, not 200:
    // the change this caller asked for did not happen.
    if (!statusChanges && !manifestation && (progress === undefined || progress === existing.progress)) {
      return res.status(409).json({
        success: false,
        code: 'CONFLICT_STALE',
        error: `This task is already "${existing.status}", so nothing was changed. Reload to see its current state.`,
        from: existing.status,
      });
    }
    // Every UPDATE below commits with its ledger row, including a same-status
    // one (a late §11.50 signature, a progress change): a signed completion or
    // any task write with no ledger entry must not exist. A move into
    // `completed` also unblocks the dependents on THIS transaction, each change
    // with its own ledger row after the completion's, so the completion and its
    // cascade commit or roll back as one; their notifications wait for COMMIT.
    const outcome = await storage.db.transaction(async (tx) => {
      const [row] = await tx
        .update(unifiedTasks)
        .set(
          transitionChanges({
            status: parsed.status,
            progress,
            isDone,
            isReopen,
            statusChanges,
            manifestation,
            actorUserId,
          })
        )
        // Compare-and-set on the status we read above. The state machine
        // constrains what each request BELIEVES the row holds, not what it
        // actually holds, and the signer's re-verification sits between the read
        // and this write — a window of order-100ms. Without this predicate two
        // concurrent transitions both pass isLegalTransition and both commit.
        .where(
          and(
            eq(unifiedTasks.taskId, taskId),
            eq(unifiedTasks.organizationId, organizationId),
            eq(unifiedTasks.status, existing.status),
            // Archived after the read above: out of reach, as on every write.
            isNull(unifiedTasks.deletedAt),
            // A same-status signature has no status to race on, so it sets on
            // the approval it read instead: one signature clears the gate, and
            // a second concurrent one gets CONFLICT_STALE rather than stacking.
            manifestation ? sql`${unifiedTasks.approvalStatus} IS DISTINCT FROM 'approved'` : undefined
          )
        )
        .returning();
      if (!row) return { row, unblocked: [] as TaskEventNotice[] };
      // Before any ledger row: every row lock (this task's, then its
      // dependents') is taken before the first ledger write takes the
      // audit-chain lock — the one order every task transaction uses.
      const cascade =
        isDone && statusChanges
          ? await cascadeUnblockOnCompletionInTx(organizationId, taskId, { tx, actorUserId })
          : null;
      await auditTaskActionInTx(tx, {
        orgId: organizationId,
        userId: actorUserId,
        command: 'task.transition',
        taskId,
        payload: {
          from: existing.status,
          to: parsed.status,
          progress: progress ?? null,
          previousProgress: existing.progress ?? null,
          // Signature manifestation (never the credentials) rides the governed record.
          ...(manifestation
            ? {
                signature: {
                  signedByName: manifestation.signedByName,
                  meaning: manifestation.meaning,
                  signedAt: manifestation.signedAt,
                  method: manifestation.method,
                },
              }
            : {}),
        },
        reason: parsed.reason,
      });
      // The dependents' rows follow the completion that caused them.
      for (const entry of cascade?.ledger ?? []) await auditTaskActionInTx(tx, entry);
      commitInFlight = true;
      return { row, unblocked: cascade?.notices ?? [] };
    });
    commitInFlight = false;
    const updated = outcome.row;

    if (!updated) {
      // The row was there a moment ago (we read it), so an empty result means
      // the status moved under us. Reporting that as 404 would misread a lost
      // race as a missing task.
      return res.status(409).json({
        success: false,
        code: 'CONFLICT_STALE',
        error: 'This task changed while your request was in flight. Reload and try again.',
      });
    }

    if (statusChanges) {
      if (isDone) {
        for (const notice of outcome.unblocked) notifyTaskEvent(notice);
        if (existing.createdById && existing.createdById !== actorUserId) {
          notifyTaskEvent({
            organizationId,
            recipientUserId: existing.createdById,
            category: 'task_completed',
            title: `Completed: ${existing.title}`,
            taskId,
          });
        }
      } else if (parsed.status === 'blocked') {
        notifyTaskEvent({
          organizationId,
          recipientUserId: existing.assigneeId,
          category: 'task_blocked',
          severity: 'warning',
          title: `Blocked: ${existing.title}`,
          body: parsed.reason ?? null,
          taskId,
        });
      }
    }

    return res.json({ success: true, data: updated });
  } catch (error) {
    if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
    if (error instanceof TaskAuditNotRecordedError) return auditWriteFailed(res, 'The status change');
    if (error instanceof z.ZodError) return res.status(400).json({ success: false, error: error.issues });
    console.error('Error updating task:', error);
    // Lost at COMMIT: it may have landed. Nobody is notified of it, and the
    // caller is told it is unknown — never that it failed.
    if (commitInFlight) return outcomeUnknown(res);
    // A server failure before or inside the transaction (the cascade's
    // included), which rolled the change back.
    return res.status(500).json({ success: false, error: 'Failed to update task' });
  }
});

/**
 * One task of POST /tasks/bulk-create, on its own transaction (row + ledger
 * row). Its id is mapped by title before the write, for the dependency edges;
 * `at.unconfirmed` names it while its COMMIT is in flight; once committed it is
 * appended to `createdTasks` before its assignee is notified.
 */
async function bulkCreateOne(
  writer: { organizationId: number; actorUserId: number },
  taskData: z.infer<typeof createTaskSchema>,
  taskIdMapping: Record<string, string>,
  createdTasks: (typeof unifiedTasks.$inferSelect)[],
  at: { unconfirmed: string | null }
): Promise<void> {
  const { organizationId, actorUserId } = writer;
  const taskId = `TASK-${Date.now()}-${uuidv4().substr(0, 8)}`;
  if (taskData.title) taskIdMapping[taskData.title] = taskId;

  let assigneeId = taskData.assigneeId;
  let assigneeName = null;
  if (!assigneeId) {
    const optimalAssignee = await getOptimalAssignee(organizationId, taskData);
    if (optimalAssignee) {
      assigneeId = optimalAssignee.id;
      assigneeName = optimalAssignee.name;
    }
  }

  const { startDate, dueDate, ...taskFields } = taskData;
  const newTask = await storage.db.transaction(async (tx) => {
    const [row] = await tx
      .insert(unifiedTasks)
      .values({
        taskId,
        organizationId,
        ...taskFields,
        startDate: startDate ? new Date(startDate) : undefined,
        dueDate: dueDate ? new Date(dueDate) : undefined,
        assigneeId,
        assigneeName,
        status: 'pending',
        progress: 0,
        completionPercentage: 0,
        createdById: actorUserId,
      })
      .returning();
    await auditTaskActionInTx(tx, {
      orgId: organizationId,
      userId: actorUserId,
      command: 'task.create',
      taskId,
      payload: { moduleType: taskData.moduleType, title: taskData.title, priority: taskData.priority, status: 'pending', bulk: true },
    });
    at.unconfirmed = taskData.title;
    return row;
  });
  at.unconfirmed = null;
  if (newTask) {
    createdTasks.push(newTask);
    if (assigneeId && assigneeId !== actorUserId) {
      notifyTaskEvent({
        organizationId,
        recipientUserId: assigneeId,
        category: 'task_assigned',
        title: `Task assigned: ${taskData.title}`,
        body: taskData.description ?? null,
        taskId,
      });
    }
  }
}

// Bulk create tasks
router.post('/tasks/bulk-create', requireEditorAccess, async (req: Request, res: Response) => {
  const createdTasks: (typeof unifiedTasks.$inferSelect)[] = [];
  // Where a failure left the batch. `unconfirmed` is set while a transaction's
  // COMMIT is in flight: a failure then leaves that write neither confirmed nor
  // refuted, and the answer must say so rather than guess.
  const at: { stage: 'tasks' | 'links'; unconfirmed: string | null } = { stage: 'tasks', unconfirmed: null };
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    refuseRouteColumnsInInput(req.body, 'task.create');
    for (const each of Array.isArray(req.body?.tasks) ? req.body.tasks : []) refuseRouteColumnsInInput(each, 'task.create');
    const validatedData = bulkCreateTasksSchema.parse(req.body);
    const taskIdMapping: Record<string, string> = {};

    // One transaction PER TASK (row + ledger row), not one for the batch: each
    // workload-balanced pick must see the assignments committed before it.
    for (const taskData of validatedData.tasks) {
      await bulkCreateOne(ctx, taskData, taskIdMapping, createdTasks, at);
    }

    // Dependency edges, if requested: one transaction, each edge with its
    // task.link ledger row as POST /tasks/dependencies records one. Every edge
    // is inserted before the first ledger row (the audit-chain lock last).
    const edges: { predecessorTaskId: string; successorTaskId: string }[] = [];
    if (validatedData.linkDependencies) {
      for (const task of validatedData.tasks) {
        for (const depTitle of task.dependencies ?? []) {
          if (!taskIdMapping[depTitle] || !taskIdMapping[task.title]) continue;
          edges.push({ predecessorTaskId: taskIdMapping[depTitle], successorTaskId: taskIdMapping[task.title] });
        }
      }
    }
    if (edges.length) {
      at.stage = 'links';
      await storage.db.transaction(async (tx) => {
        for (const edge of edges) {
          await tx.insert(taskDependencies).values({
            dependencyId: `DEP-${Date.now()}-${uuidv4().substr(0, 8)}`,
            organizationId,
            ...edge,
            dependencyType: 'finish-to-start',
            status: 'active',
          });
        }
        for (const edge of edges) {
          await auditTaskActionInTx(tx, {
            orgId: organizationId,
            userId: actorUserId,
            command: 'task.link',
            taskId: edge.predecessorTaskId,
            payload: { successorTaskId: edge.successorTaskId, dependencyType: 'finish-to-start', bulk: true },
          });
        }
        at.unconfirmed = 'links';
      });
      at.unconfirmed = null;
    }

    res.json({ success: true, data: createdTasks, count: createdTasks.length });
  } catch (error) {
    if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
    if (error instanceof z.ZodError) return res.status(400).json({ success: false, error: error.issues });
    const audit = error instanceof TaskAuditNotRecordedError;
    if (!audit) console.error('Error bulk creating tasks:', error);
    // Tasks commit one at a time, so a failure after the first leaves real
    // rows — whatever the failure was. Name them, and name what is unknown.
    if (createdTasks.length > 0 || at.unconfirmed) {
      const n = createdTasks.length;
      const what = audit ? 'recorded in the audit trail' : 'saved';
      let message: string;
      if (at.stage === 'links') {
        message = at.unconfirmed
          ? `All ${n} task(s) were created and recorded, but whether their dependency links were saved is unknown. Reload the board before linking them again.`
          : `All ${n} task(s) were created and recorded, but their dependency links could not be ${what}, so none were linked.`;
      } else if (at.unconfirmed) {
        message = `${n} task(s) were created and recorded. The request then failed: whether "${at.unconfirmed}" was created is unknown, and the rest were not created. Reload the board before trying again.`;
      } else {
        message = `${n} task(s) were created and recorded; the next could not be ${audit ? what : 'created'}, so it and the rest were not created.`;
      }
      return res.status(500).json({
        success: false,
        error: at.unconfirmed ? 'OUTCOME_UNKNOWN' : audit ? 'AUDIT_WRITE_FAILED' : 'PARTIALLY_APPLIED',
        message,
        data: createdTasks,
      });
    }
    if (audit) return auditWriteFailed(res, 'The task');
    res.status(500).json({ success: false, error: 'Failed to bulk create tasks' });
  }
});

// Create tasks from template
type TemplateShape = { templateId: string; name: string; tasks: unknown; dependencies?: unknown };
async function workflowCreateFailure(req: Request, res: Response, error: unknown, committing: boolean) {
  if (committing) {
    try { await requestPgClient(req).discard?.(new Error('Workflow COMMIT acknowledgement was not confirmed')); }
    catch { /* The request owner may already have discarded its ended lease. */ }
    return outcomeUnknown(res);
  }
  if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
  if (error instanceof TaskProjectAdmissionError) return res.status(error.status).json({
    success: false, code: error.code, error: error.message,
  });
  if (error instanceof TaskAuditNotRecordedError) return auditWriteFailed(res, 'The workflow');
  console.error('Error creating tasks from template:', error);
  return res.status(500).json({ success: false, error: 'Failed to create tasks from template' });
}
router.post('/tasks/from-template/:templateId', requireEditorAccess, async (req: Request, res: Response) => {
  let committing = false;
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const templateId = String(req.params.templateId);
    refuseRouteColumnsInInput(req.body, 'task.create');
    const { projectId: requestedProjectId, startDate, adjustDates } = req.body ?? {};

    // Get template — the org's own row wins; a built-in catalog entry serves
    // when the org has none, so "Start workflow" works with zero seeding
    // (assessment D9/D10). Built-ins carry no DB row, so usage stats are only
    // bumped for stored templates below.
    // The table read is guarded the same way GET /templates guards it: on an
    // install where task_templates was never provisioned, an advertised
    // built-in must still instantiate rather than falling into the catch-all
    // 500 (the list endpoint offers built-ins in exactly that situation).
    // Shape shared by a stored row and a built-in catalog entry — the fields
    // the instantiation below reads.
    let storedTemplate: TemplateShape | undefined;
    try {
      [storedTemplate] = await storage.db
        .select()
        .from(taskTemplates)
        .where(
          and(
            eq(taskTemplates.templateId, templateId),
            eq(taskTemplates.organizationId, organizationId)
          )
        )
        .limit(1);
    } catch (err: any) {
      if (err?.code !== '42P01') throw err;
    }

    const builtin = storedTemplate ? null : getBuiltinWorkflowTemplate(templateId);
    const template = storedTemplate ?? builtin;
    if (!template) return res.status(404).json({ success: false, error: 'Template not found' });

    const taskDefinitions = template.tasks as any[];
    // A stored template's task definitions are org-authored data: one naming
    // a route column instantiates nothing (RR1a, M9).
    for (const taskDef of taskDefinitions) refuseRouteColumnsInInput(taskDef, 'task.create');
    const projectId = requireTaskProjectId(requestedProjectId);
    const taskIdMapping: Record<string, string> = {};

    // The workflow is instantiated as ONE transaction — every task, its ledger
    // row, the dependency edges with theirs and the usage bump — so a failure
    // part-way leaves no half-built workflow and nothing without its lineage.
    const createdTasks = await requestDb(req).transaction(async (tx) => {
      const parent = await admitTaskCreationProject(queryableFromDrizzle(tx),
        { ...ctx, projectId, clientWorkspaceId: req.tenantContext?.clientWorkspaceId });
      // Stored templates only — built-ins have no row to bump. First, so its
      // row lock is taken before the first ledger write (the audit-chain lock
      // last, the order every task transaction takes them in).
      if (storedTemplate) {
        await tx
          .update(taskTemplates)
          .set({ usageCount: sql`${taskTemplates.usageCount} + 1`, lastUsedAt: new Date(), updatedAt: new Date() })
          .where(and(eq(taskTemplates.templateId, templateId), eq(taskTemplates.organizationId, organizationId)));
      }
      const created: (typeof unifiedTasks.$inferSelect)[] = [];
      for (let i = 0; i < taskDefinitions.length; i++) {
        const taskDef = taskDefinitions[i];
        const taskId = `TASK-${Date.now()}-${uuidv4().substr(0, 8)}`;

        taskIdMapping[taskDef.id || i.toString()] = taskId;

        // Calculate dates if needed
        let taskStartDate = startDate;
        let taskDueDate = null;

        // `taskDef.dayOffset` was truthiness-tested, so the workflow's day-0
        // tasks never got dates even when adjustDates was requested.
        if (adjustDates && startDate && taskDef.dayOffset != null) {
          const start = new Date(startDate);
          start.setDate(start.getDate() + taskDef.dayOffset);
          taskStartDate = start.toISOString();

          if (taskDef.duration) {
            const due = new Date(start);
            due.setDate(due.getDate() + taskDef.duration);
            taskDueDate = due.toISOString();
          }
        }

        const [newTask] = await tx
          .insert(unifiedTasks)
          .values({
            taskId,
            organizationId,
            projectId: parent.projectId,
            clientWorkspaceId: parent.clientWorkspaceId,
            title: taskDef.title,
            description: taskDef.description,
            moduleType: taskDef.moduleType || 'general',
            category: taskDef.category,
            taskType: taskDef.taskType,
            priority: taskDef.priority || 'medium',
            startDate: taskStartDate ? new Date(taskStartDate) : undefined,
            dueDate: taskDueDate ? new Date(taskDueDate) : undefined,
            estimatedHours: taskDef.estimatedHours,
            status: 'pending',
            progress: 0,
            completionPercentage: 0,
            // unifiedTasks has no template foreign key; record the originating
            // template via the generic source-entity fields instead.
            sourceEntityType: 'taskTemplate',
            sourceEntityId: template.templateId,
            createdById: actorUserId,
          })
          .returning();

        if (newTask) {
          created.push(newTask);
          await auditTaskActionInTx(tx, {
            orgId: organizationId,
            userId: actorUserId,
            command: 'task.create',
            taskId,
            payload: {
              moduleType: taskDef.moduleType || 'general',
              title: taskDef.title,
              priority: taskDef.priority || 'medium',
              status: 'pending',
              templateId: template.templateId,
            },
            summary: `Created from workflow template "${template.name}"`,
          });
        }
      }

      // Create dependencies from template, each with its task.link ledger row
      // as POST /tasks/dependencies records one.
      if (template.dependencies) {
        const dependencies = template.dependencies as any[];
        for (const dep of dependencies) {
          if (taskIdMapping[dep.predecessor] && taskIdMapping[dep.successor]) {
            const dependencyType = dep.type || 'finish-to-start';
            await tx.insert(taskDependencies).values({
              dependencyId: `DEP-${Date.now()}-${uuidv4().substr(0, 8)}`,
              organizationId,
              predecessorTaskId: taskIdMapping[dep.predecessor],
              successorTaskId: taskIdMapping[dep.successor],
              dependencyType,
              lagTime: dep.lag || 0,
              status: 'active',
            });
            await auditTaskActionInTx(tx, {
              orgId: organizationId,
              userId: actorUserId,
              command: 'task.link',
              taskId: taskIdMapping[dep.predecessor],
              payload: {
                successorTaskId: taskIdMapping[dep.successor],
                dependencyType,
                templateId: template.templateId,
              },
              summary: `Linked by workflow template "${template.name}"`,
            });
          }
        }
      }
      committing = true;
      return created;
    });
    committing = false;

    res.json({ success: true, data: createdTasks, count: createdTasks.length, template: template.name });
  } catch (error) {
    return workflowCreateFailure(req, res, error, committing);
  }
});

// Get tasks by module
router.get('/tasks/by-module/:moduleId', async (req: Request, res: Response) => {
  try {
    const moduleId = String(req.params.moduleId);
    const organizationIdRaw = getSecureOrgId(req);
    const organizationId = organizationIdRaw ? Number(organizationIdRaw) : NaN;
    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      return res.status(401).json({ success: false, error: 'Organization context required' });
    }
    const status = req.query.status as string;
    const priority = req.query.priority as string;

    const conditions = [
      eq(unifiedTasks.organizationId, organizationId),
      eq(unifiedTasks.moduleType, moduleId),
      isNull(unifiedTasks.deletedAt),
    ];
    if (status) {
      conditions.push(eq(unifiedTasks.status, status));
    }
    if (priority) {
      conditions.push(eq(unifiedTasks.priority, priority));
    }

    const tasks = await storage.db
      .select()
      .from(unifiedTasks)
      .where(and(...conditions))
      .orderBy(asc(unifiedTasks.dueDate), desc(unifiedTasks.priority));

    res.json({
      success: true,
      data: tasks,
      count: tasks.length,
    });
  } catch (error) {
    console.error('Error fetching tasks by module:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch tasks by module',
    });
  }
});

// Set task dependencies
router.post('/tasks/dependencies', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const validatedData = createDependencySchema.parse(req.body);

    const [predecessorRows, successorRows] = await Promise.all([
      storage.db
        .select({ taskId: unifiedTasks.taskId, status: unifiedTasks.status, reviewRouteId: unifiedTasks.reviewRouteId })
        .from(unifiedTasks)
        .where(
          and(
            eq(unifiedTasks.taskId, validatedData.predecessorTaskId),
            eq(unifiedTasks.organizationId, organizationId),
            isNull(unifiedTasks.deletedAt)
          )
        )
        .limit(1),
      storage.db
        .select({
          taskId: unifiedTasks.taskId,
          status: unifiedTasks.status,
          title: unifiedTasks.title,
          assigneeId: unifiedTasks.assigneeId,
          reviewRouteId: unifiedTasks.reviewRouteId,
        })
        .from(unifiedTasks)
        .where(
          and(
            eq(unifiedTasks.taskId, validatedData.successorTaskId),
            eq(unifiedTasks.organizationId, organizationId),
            isNull(unifiedTasks.deletedAt)
          )
        )
        .limit(1),
    ]);
    const predecessorTask = predecessorRows[0];
    const successorTask = successorRows[0];
    if (!predecessorTask || !successorTask) {
      return res.status(404).json({
        success: false,
        error: 'One or both tasks not found for organization',
      });
    }
    // Either end a route member: route steps are opened by the route, never
    // by the generic dependency graph (RR1a, B1, §3).
    refuseRouteTaskWrite(predecessorTask, 'task.link');
    refuseRouteTaskWrite(successorTask, 'task.link');

    // Reject an edge that would close a cycle — the DAG previously accepted
    // A→B, B→A, after which the critical-path walk relied on its visited-set
    // to avoid spinning (assessment D19).
    if (
      await wouldCreateDependencyCycle(
        validatedData.predecessorTaskId,
        validatedData.successorTaskId
      )
    ) {
      return res.status(409).json({
        success: false,
        error: 'This dependency would create a cycle in the task graph.',
      });
    }

    const dependencyId = `DEP-${Date.now()}-${uuidv4().substr(0, 8)}`;

    // A blocking edge onto an unfinished predecessor means the successor IS
    // blocked — so say so. Without this the edge was recorded but no task ever
    // entered 'blocked', which made cascadeUnblockOnCompletion dead code: it
    // only wakes successors whose status is literally 'blocked', so completing
    // a predecessor never unblocked anything and never notified the dependents'
    // assignees. Guarded by the same state machine the routes use, so an
    // already-completed or cancelled successor is left alone.
    const blockSuccessor =
      validatedData.isBlocking !== false &&
      predecessorTask.status !== 'completed' &&
      successorTask.status !== 'blocked' &&
      isLegalTransition(successorTask.status, 'blocked');

    // The edge, the successor's block and both ledger rows are one transaction.
    // The successor's UPDATE comes before either ledger row: row locks first,
    // the audit-chain lock last, as PATCH and auto-assign take them — two
    // transactions taking the same two locks in opposite orders deadlock.
    const { newDependency, successorBlocked } = await storage.db.transaction(async (tx) => {
      const [dependency] = await tx
        .insert(taskDependencies)
        .values({ dependencyId, organizationId, ...validatedData, status: 'active' })
        .returning();
      const [blocked] = blockSuccessor
        ? await tx
            .update(unifiedTasks)
            .set({ status: 'blocked', updatedAt: new Date() })
            .where(
              and(
                eq(unifiedTasks.taskId, successorTask.taskId),
                eq(unifiedTasks.organizationId, organizationId),
                // Compare-and-set: never stomp a status that moved under us.
                eq(unifiedTasks.status, successorTask.status)
              )
            )
            .returning({ taskId: unifiedTasks.taskId })
        : [];
      await auditTaskActionInTx(tx, {
        orgId: organizationId,
        userId: actorUserId,
        command: 'task.link',
        taskId: validatedData.predecessorTaskId,
        payload: {
          successorTaskId: validatedData.successorTaskId,
          dependencyType: validatedData.dependencyType,
          isBlocking: validatedData.isBlocking,
        },
      });
      if (blocked) {
        await auditTaskActionInTx(tx, {
          orgId: organizationId,
          userId: actorUserId,
          command: 'task.transition',
          taskId: successorTask.taskId,
          payload: { from: successorTask.status, to: 'blocked' },
          summary: `Blocked by new dependency on ${validatedData.predecessorTaskId}`,
        });
      }
      return { newDependency: dependency, successorBlocked: Boolean(blocked) };
    });

    if (successorBlocked) {
      notifyTaskEvent({
        organizationId,
        recipientUserId: successorTask.assigneeId,
        category: 'task_blocked',
        title: `Blocked: ${successorTask.title}`,
        body: 'This task now depends on work that is not finished yet.',
        taskId: successorTask.taskId,
      });
    }

    res.json({
      success: true,
      data: newDependency,
      /** So the client can say the successor moved, rather than the board
       *  silently re-rendering it in a different column. */
      successorBlocked,
    });
  } catch (error) {
    if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
    if (error instanceof TaskAuditNotRecordedError) return auditWriteFailed(res, 'The dependency');
    console.error('Error creating dependency:', error);
    res.status(400).json({
      success: false,
      error: error instanceof z.ZodError ? error.issues : 'Failed to create dependency',
    });
  }
});

// Calculate critical path for project
router.get('/tasks/critical-path/:projectId', async (req: Request, res: Response) => {
  try {
    const projectId = parseInt(String(req.params.projectId));
    const organizationIdRaw = getSecureOrgId(req);
    const organizationId = organizationIdRaw ? Number(organizationIdRaw) : NaN;
    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      return res.status(401).json({ success: false, error: 'Organization context required' });
    }

    const criticalPath = await calculateCriticalPath(projectId, organizationId);

    res.json({
      success: true,
      data: criticalPath,
    });
  } catch (error) {
    console.error('Error calculating critical path:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to calculate critical path',
    });
  }
});

// Auto-assign tasks based on workload
const autoAssignSchema = z.object({ taskIds: z.array(z.string().min(1)).min(1).max(500).refine(ids => new Set(ids).size === ids.length),
  reason: z.string().trim().max(1000).optional(),
  expectedAssignments: z.array(assignmentExpectedSchema.extend({ taskId: z.string().min(1) }).strict()).max(500).optional(),
}).strict().refine(body => !body.expectedAssignments || (new Set(body.expectedAssignments.map(row => row.taskId)).size === body.expectedAssignments.length && body.expectedAssignments.every(row => body.taskIds.includes(row.taskId))));
type AutoAssignment = { taskId: string; assignedTo: string; assigneeId: number };

/** Existing batch receipt: each assignment and lineage commit together. */
router.post('/tasks/auto-assign', async (req: Request, res: Response) => {
  const assignmentResults: AutoAssignment[] = [];
  let activeTask: string | null = null;
  try {
    const parsed = autoAssignSchema.parse(req.body ?? {});
    for (const taskId of parsed.taskIds) {
      activeTask = taskId;
      const expected = parsed.expectedAssignments?.find(row => row.taskId === taskId);
      const saved = await assignTask(req, { taskId, method: 'workload-balanced', ...expected, reason: parsed.reason || undefined });
      if (saved) assignmentResults.push({ taskId, assignedTo: saved.assigneeName ?? `Account #${saved.assigneeId}`, assigneeId: saved.assigneeId });
      activeTask = null;
    }
    return res.json({ success: true, data: assignmentResults, count: assignmentResults.length });
  } catch (error) {
    const unknown = error instanceof TaskAssignmentUnknown;
    const audit = error instanceof TaskAuditNotRecordedError;
    if (assignmentResults.length || unknown) {
      const n = assignmentResults.length;
      return res.status(500).json({ success: false, error: unknown ? 'OUTCOME_UNKNOWN' : audit ? 'AUDIT_WRITE_FAILED' : 'PARTIALLY_APPLIED',
        message: unknown
          ? `${n} task(s) were assigned and recorded. The request then failed: whether ${activeTask} was assigned is unknown, and the rest were not assigned. Reload the board before trying again.`
          : `${n} task(s) were assigned and recorded; the next assignment could not be ${audit ? 'recorded in the audit trail' : 'made'}, so it and the rest were not made.`,
        data: assignmentResults });
    }
    return assignmentFailure(res, error);
  }
});

// Get task analytics
router.get('/tasks/analytics', async (req: Request, res: Response) => {
  try {
    const organizationIdRaw = getSecureOrgId(req);
    const organizationId = organizationIdRaw ? Number(organizationIdRaw) : NaN;
    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      return res.status(401).json({ success: false, error: 'Organization context required' });
    }
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : null;
    const data = await loadTaskAnalytics(organizationId, projectId);
    res.json({ success: true, data });
  } catch (error) {
    console.error('Error fetching task analytics:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch task analytics',
    });
  }
});

/**
 * GET /api/task-management/templates — the org's workflow templates.
 *
 * The write half of this feature already existed and is thorough:
 * POST /tasks/from-template/:templateId inserts real unified_tasks with
 * server-generated ids, dates derived from each definition's dayOffset /
 * duration, task_dependencies from the template, provenance via
 * sourceEntityType 'taskTemplate', and createdById from the actor.
 *
 * Nothing could ENUMERATE templates, though, so the "Start a workflow" picker
 * on the TaskBoard was populated from a fixture constant and its instantiate
 * button fabricated the whole task set client-side — random ids
 * ('C2C-TASK-' + Math.random()), fixture assignees, and no persistence at all.
 * A template list is the one missing piece between that and the real route.
 *
 * Read-only, org-scoped, and returns the SHAPE the picker needs rather than the
 * whole row: `tasks` and `dependencies` are large json blobs the client does not
 * render, so only their counts are sent. Inactive templates are excluded —
 * is_active exists precisely so a template can be retired without deleting the
 * history of what it produced.
 */
router.get('/templates', async (req: Request, res: Response) => {
  try {
    const organizationIdRaw = getSecureOrgId(req);
    const organizationId = organizationIdRaw ? Number(organizationIdRaw) : NaN;
    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      return res.status(401).json({ success: false, error: 'Organization context required' });
    }
    const data = await listTemplatesForOrg(organizationId);
    return res.json({ success: true, data, meta: { count: data.length } });
  } catch (error) {
    console.error('Error listing task templates:', error);
    return res.status(500).json({ success: false, error: 'Failed to list task templates' });
  }
});

// Create task template
router.post('/templates', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const validatedData = createTemplateSchema.parse(req.body);
    const templateId = `TMPL-${Date.now()}-${uuidv4().substr(0, 8)}`;

    const [newTemplate] = await storage.db
      .insert(taskTemplates)
      .values({
        templateId,
        organizationId,
        ...validatedData,
        isActive: true,
        version: 1,
        usageCount: 0,
        createdById: actorUserId,
      })
      .returning();

    res.json({
      success: true,
      data: newTemplate,
    });
  } catch (error) {
    console.error('Error creating template:', error);
    res.status(400).json({
      success: false,
      error: error instanceof z.ZodError ? error.issues : 'Failed to create template',
    });
  }
});

// Create automation rule
router.post('/automation', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const validatedData = createAutomationSchema.parse(req.body);
    const automationId = `AUTO-${Date.now()}-${uuidv4().substr(0, 8)}`;

    const [newAutomation] = await storage.db
      .insert(taskAutomation)
      .values({
        automationId,
        organizationId,
        ...validatedData,
        isActive: true,
        priority: 50,
        executionCount: 0,
        successCount: 0,
        failureCount: 0,
        createdById: actorUserId,
      })
      .returning();

    res.json({
      success: true,
      data: newAutomation,
    });
  } catch (error) {
    console.error('Error creating automation:', error);
    res.status(400).json({
      success: false,
      error: error instanceof z.ZodError ? error.issues : 'Failed to create automation',
    });
  }
});

// Notify about a task — a REAL persisted notification to the task's assignee
// (or an explicit same-org recipient). This endpoint previously returned
// "Notification sent" over a commented-out emit (assessment D13); it now
// writes the shared notification inbox and the governed ledger, or says no.
const notifyTaskSchema = z.object({
  message: z.string().min(1).max(2000),
  recipientUserId: z.number().int().positive().optional(),
  severity: z.enum(['info', 'warning', 'critical']).optional(),
});
// Gated: it writes a governed ledger row naming the sender. (/messages below
// is not — a plain collaboration message, which a viewer may send.)
router.post('/tasks/:taskId/notify', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const taskId = String(req.params.taskId);
    const parsed = notifyTaskSchema.parse(req.body ?? {});

    const [task] = await storage.db
      .select()
      .from(unifiedTasks)
      .where(
        and(
          eq(unifiedTasks.taskId, taskId),
          eq(unifiedTasks.organizationId, organizationId),
          isNull(unifiedTasks.deletedAt)
        )
      )
      .limit(1);
    if (!task) {
      return res.status(404).json({ success: false, error: 'Task not found' });
    }
    // A review route member is reminded by the route's sender or an
    // administrator, while their step is open (RR1b, REVIEW_ROUTING §2.11).
    if (task.reviewRouteId) {
      const refused = await routeRemindRefusal(queryableFromDrizzle(storage.db), {
        organizationId, actorUserId, reviewRouteId: task.reviewRouteId, taskStatus: task.status,
      });
      if (refused) return res.status(refused.status).json({ success: false, error: refused.message, code: refused.code });
    }

    let recipientUserId = parsed.recipientUserId ?? task.assigneeId ?? null;
    if (parsed.recipientUserId) {
      // An explicit recipient must be a member of the caller's org.
      const [member] = await storage.db
        .select({ userId: organizationUsers.userId })
        .from(organizationUsers)
        .where(
          and(
            eq(organizationUsers.organizationId, organizationId),
            eq(organizationUsers.userId, parsed.recipientUserId)
          )
        )
        .limit(1);
      if (!member) {
        return res.status(404).json({ success: false, error: 'Recipient not found in organization' });
      }
      recipientUserId = parsed.recipientUserId;
    }
    if (!recipientUserId) {
      return res.status(422).json({
        success: false,
        error: 'The task has no assignee; pass recipientUserId to notify someone.',
      });
    }

    await createNotification({
      organizationId,
      recipientUserId,
      category: 'collaboration',
      severity: parsed.severity ?? 'info',
      title: `About "${task.title}"`,
      body: parsed.message,
      resourceType: 'unified_task',
      resourceId: taskId,
      metadata: { fromUserId: actorUserId },
    });

    // createNotification owns its own connection, so the two cannot share a
    // transaction. Ledger AFTER delivery, so the ledger never claims a message
    // that was not sent — and an unrecorded send is reported, not a 200.
    const audit = await auditTaskAction({
      orgId: organizationId,
      userId: actorUserId,
      command: 'task.notify',
      taskId,
      payload: { recipientUserId },
    });
    if (!audit.recorded) {
      return res.status(500).json({
        success: false,
        error: 'AUDIT_WRITE_FAILED',
        message: 'The notification was delivered, but it could not be recorded in the audit trail.',
      });
    }

    res.json({ success: true, taskId, recipientUserId });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.issues });
    }
    console.error('Error sending notification:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send notification',
    });
  }
});

// ── Direct collaboration message ────────────────────────────────────────────
//
// Backs the universal launcher's "Collaborate" tab, which previously composed
// a message and threw it away (assessment §2 P1). The message lands as a
// persisted notification in the recipient's inbox; recipient must be a member
// of the caller's organization.
const sendMessageSchema = z.object({
  recipientUserId: z.number().int().positive(),
  message: z.string().min(1).max(4000),
  about: z.string().max(300).optional(),
  sourceEntityType: z.string().max(80).optional(),
  sourceEntityId: z.string().max(200).optional(),
});
router.post('/messages', async (req: Request, res: Response) => {
  try {
    const parsed = sendMessageSchema.parse(req.body ?? {});
    const actorUserId = governedActorId(req);
    const organizationIdRaw = getSecureOrgId(req);
    const organizationId = organizationIdRaw ? Number(organizationIdRaw) : NaN;
    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      return res.status(401).json({ success: false, error: 'Organization context required' });
    }

    const [member] = await storage.db
      .select({ userId: organizationUsers.userId, name: users.name })
      .from(organizationUsers)
      .innerJoin(users, eq(users.id, organizationUsers.userId))
      .where(
        and(
          eq(organizationUsers.organizationId, organizationId),
          eq(organizationUsers.userId, parsed.recipientUserId)
        )
      )
      .limit(1);
    if (!member) {
      return res.status(404).json({ success: false, error: 'Recipient not found in organization' });
    }

    let senderName: string | null = null;
    if (actorUserId) {
      const [sender] = await storage.db
        .select({ name: users.name, email: users.email })
        .from(users)
        .where(eq(users.id, actorUserId))
        .limit(1);
      senderName = sender?.name || sender?.email || null;
    }

    const id = await createNotification({
      organizationId,
      recipientUserId: parsed.recipientUserId,
      category: 'collaboration',
      severity: 'info',
      title: senderName
        ? `Message from ${senderName}${parsed.about ? ` — ${parsed.about}` : ''}`
        : `New message${parsed.about ? ` — ${parsed.about}` : ''}`,
      body: parsed.message,
      resourceType: parsed.sourceEntityType ?? null,
      resourceId: parsed.sourceEntityId ?? null,
      metadata: { fromUserId: actorUserId },
    });

    res.status(201).json({ success: true, data: { id } });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: error.issues });
    }
    console.error('Error sending message:', error);
    res.status(500).json({ success: false, error: 'Failed to send message' });
  }
});

// ── Archive (soft delete) ───────────────────────────────────────────────────
//
// The ONLY removal verb for a task — stamps deleted_at/deleted_by instead of
// destroying the row (Part 11 retention, assessment D24). Archived rows leave
// every read model; the tombstone and its governed ledger record remain.
// The reason is REQUIRED: the board tells the user it is written to the Part 11
// trail, so a server that accepted none let a caller archive with a constant
// default the user never gave. Same bounds as the UI (3 to 1000, trimmed; the
// board's textarea stops at ARCHIVE_REASON_MAX).
const archiveTaskSchema = z.object({
  reason: z.string().trim().min(3).max(1000),
});
router.delete('/tasks/:taskId', requireEditorAccess, async (req: Request, res: Response) => {
  try {
    const ctx = governedWriter(req, res);
    if (!ctx) return;
    const { organizationId, actorUserId } = ctx;
    const taskId = String(req.params.taskId);
    const parsed = archiveTaskSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      // Name the bound it broke: a reason over the maximum used to be told it
      // needed "at least 3 characters".
      const tooLong = parsed.error.issues.some((i) => i.code === 'too_big');
      return res.status(400).json({
        success: false,
        error: tooLong ? 'REASON_TOO_LONG' : 'REASON_REQUIRED',
        message: tooLong
          ? 'The reason for archiving can be at most 1000 characters. It is recorded in the audit trail.'
          : 'Give a reason for archiving (at least 3 characters). It is recorded in the audit trail.',
      });
    }

    const archived = await storage.db.transaction(async (tx) => {
      // Read under the row lock first: a route member is archived only by its
      // route (RR1a, B1), and the refusal must come before any write.
      const [current] = await tx
        .select({ reviewRouteId: unifiedTasks.reviewRouteId })
        .from(unifiedTasks)
        .where(
          and(
            eq(unifiedTasks.taskId, taskId),
            eq(unifiedTasks.organizationId, organizationId),
            isNull(unifiedTasks.deletedAt)
          )
        )
        .for('update');
      if (current) refuseRouteTaskWrite(current, 'task.delete');
      const [row] = await tx
        .update(unifiedTasks)
        .set({ deletedAt: new Date(), deletedBy: actorUserId, updatedAt: new Date() })
        .where(
          and(
            eq(unifiedTasks.taskId, taskId),
            eq(unifiedTasks.organizationId, organizationId),
            isNull(unifiedTasks.deletedAt)
          )
        )
        .returning({ taskId: unifiedTasks.taskId, title: unifiedTasks.title });
      if (row) {
        await auditTaskActionInTx(tx, {
          orgId: organizationId,
          userId: actorUserId,
          command: 'task.delete',
          taskId,
          payload: { title: row.title, softDelete: true },
          reason: parsed.data.reason,
        });
      }
      return row;
    });

    if (!archived) {
      return res.status(404).json({ success: false, error: 'Task not found' });
    }
    return res.json({ success: true, archived: true, taskId });
  } catch (error) {
    if (error instanceof RouteTaskWriteRefused) return res.status(error.status).json(routeTaskRefusalBody(error));
    if (error instanceof TaskAuditNotRecordedError) return auditWriteFailed(res, 'The archive');
    console.error('Error archiving task:', error);
    return res.status(500).json({ success: false, error: 'Failed to archive task' });
  }
});

// ── My work — the Task Tray read-model ──────────────────────────────────────
//
// One org-scoped answer to "what is assigned to me right now" from the
// canonical store: open unified tasks for the caller, split into overdue /
// due-soon / open, plus the approvals awaiting them, each with its project's
// name (services/tasking/my-work.ts). The tray previously showed a hardcoded
// count (assessment D40).
router.get('/my-work', async (req: Request, res: Response) => {
  try {
    // A read, so not behind requireEditorAccess: the organization comes from
    // the sources the other reads use, "me" from the session (integer ids only).
    const organizationId = Number(getSecureOrgId(req) ?? NaN);
    const actorUserId = governedActorId(req);
    if (!Number.isFinite(organizationId) || organizationId <= 0 || !actorUserId) {
      return res.status(401).json({ success: false, error: 'Organization and user context required' });
    }
    const data = await readMyWork(storage.db as unknown as RequestDb, organizationId, actorUserId);
    return res.json({ success: true, data });
  } catch (error) {
    console.error('Error loading my work:', error);
    return res.status(500).json({ success: false, error: 'Failed to load my work' });
  }
});

export default router;
