"""Compare this worker's scoped ESLint metrics with its pinned prepatch source."""
import gzip
import json
from pathlib import Path
import subprocess

packet = Path(__file__).resolve().parents[1]
root = packet.parents[3]
runner = 'server/services/csr/csr-job-runner.ts'
test = 'server/services/csr/__tests__/csr-job-runner.placeholder-gate.test.ts'
command = ['/workspace/scratch/editor-toolchain/node_modules/.bin/node', 'node_modules/eslint/bin/eslint.js']
baseline = subprocess.run(command + ['--stdin', '--stdin-filename', runner, '--format', 'json'], cwd=root,
    input=gzip.decompress((packet/'csr/red-source-csr-job-runner.ts.gz').read_bytes()), stdout=subprocess.PIPE, check=True)
current = subprocess.run(command + [runner, test, '--format', 'json'], cwd=root, stdout=subprocess.PIPE, check=True)
old = json.loads(baseline.stdout)[0]
now = json.loads(current.stdout)
assert old['errorCount'] == now[0]['errorCount'] == now[1]['errorCount'] == 0
assert now[0]['warningCount'] <= old['warningCount']
assert now[1]['warningCount'] == 0
report = {'baseline': json.loads(baseline.stdout), 'current': now,
    'warningGrowth': now[0]['warningCount'] - old['warningCount']}
(packet/'csr/lint-details.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'sourceErrors': now[0]['errorCount'], 'sourceWarnings': now[0]['warningCount'],
    'baselineWarnings': old['warningCount'], 'testErrors': now[1]['errorCount'], 'testWarnings': now[1]['warningCount']}))
