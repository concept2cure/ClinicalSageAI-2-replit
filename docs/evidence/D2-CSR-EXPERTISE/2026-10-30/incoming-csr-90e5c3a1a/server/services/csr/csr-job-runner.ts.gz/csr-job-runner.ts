/**
 * @fileoverview Async CSR Build Job Runner
 * @module server/services/csr/csr-job-runner
 *
 * Wraps the synchronous in-process csr-builder.generateCSRSections loop with
 * persistent job state so a long ICH-E3 build can run out-of-band, be
 * resumed after a section-level failure, and surface progress to the caller
 * without blocking an HTTP request.
 *
 * Consumed by csr-builder.launchCSRBuildAsync, the one build path (the
 * synchronous launchCSRBuild was deleted 2026-10-30; this runner's completion
 * gate is the fail-closed status rule).
 *
 * State machine for csr_build_jobs.status:
 *   queued -> drafting -> complete
 *                      \-> failed (resumable: re-run leaves prior sections intact)
 *
 * Tenant scoping rules:
 *   - Every read query MUST filter by organizationId.
 *   - The single exception is runCSRBuildJob(jobId), which is invoked by the
 *     background worker and uses jobId as the only key. Status/section reads
 *     remain org-scoped because they are caller-facing.
 */

import { createHash } from 'node:crypto';
import { and, eq } from 'drizzle-orm';

import { db } from '../../db';
import { CsrScopeError, resolveCsrBuildContext, resolveCsrScope } from './project-scope';
import { verifySavedCsrSectionIntegrity } from './csr-output-integrity';
import {
  csrBuildJobs,
  csrSectionOutputs,
  type CsrSectionOutput,
} from '@shared/schema';
import {
  csrSectionSelectionRefusal,
  draftCSRSectionWithProvenance,
  hasUnresolvedPlaceholders,
  resolveCSRDraftTargets,
  type CSRBuildRequest,
  type CSRSection,
} from '../csr-builder';
import { CsrAuthoringContextError, parseCsrEvidenceSelection,
  type CsrAuthoringEvidence } from './cortex-authoring-context';
import type { RequestSqlClient } from '../../db/requestDb';

// ═══════════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface CSRBuildJobContext {
  organizationId: number;
  projectId?: number;
  programId?: string;
  clientWorkspaceId?: number;
  requestedBy?: number;
}

export interface EnqueueResult {
  jobId: number;
  status: 'queued';
}

export interface CSRBuildJobStatus {
  status: string;
  progress: number;
  sectionsComplete: number;
  error: unknown;
}

// ═══════════════════════════════════════════════════════════════════════════════
// INTERNAL HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

/** SHA-256 lowercase hex (Node default casing). */
function sha256Hex(content: string): string {
  return createHash('sha256').update(content).digest('hex');
}

function requireDb(): NonNullable<typeof db> {
  if (!db) {
    throw new Error('[csr-job-runner] Drizzle db is not initialized');
  }
  return db;
}

/**
 * Snapshot envelope stored on csr_build_jobs.study_info_snapshot. We persist
 * studyInfo plus deepResearchJobId so a resumed run can fully rebuild the
 * original CSRBuildRequest (including the citation source).
 */
interface CSRStudyInfoSnapshot {
  studyInfo: CSRBuildRequest['studyInfo'];
  deepResearchJobId?: number;
  /** The retained run whose engine tables ground the results sections. */
  evidenceSource?: CSRBuildRequest['evidenceSource'];
}

type EvidenceSource = NonNullable<CSRBuildRequest['evidenceSource']>;

/** A retained-run binding, normalised; throws CSR_EVIDENCE_SELECTION_INVALID. */
function parseEvidenceSource(value: unknown): EvidenceSource {
  const { programId, runId, studyId } = parseCsrEvidenceSelection({ ...(value as object), sectionNumber: '1' });
  return { programId, runId, studyId };
}

function readStudyInfoSnapshot(raw: unknown): CSRStudyInfoSnapshot {
  if (raw && typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    // New shape: { studyInfo, deepResearchJobId, evidenceSource? }
    if (obj.studyInfo && typeof obj.studyInfo === 'object') {
      return {
        studyInfo: obj.studyInfo as CSRBuildRequest['studyInfo'],
        deepResearchJobId:
          typeof obj.deepResearchJobId === 'number'
            ? obj.deepResearchJobId
            : undefined,
        ...(obj.evidenceSource !== undefined ? { evidenceSource: obj.evidenceSource as EvidenceSource } : {}),
      };
    }
    // Back-compat: legacy rows stored the raw studyInfo directly
    return {
      studyInfo: raw as CSRBuildRequest['studyInfo'],
      deepResearchJobId: undefined,
    };
  }
  return {
    studyInfo: {} as CSRBuildRequest['studyInfo'],
    deepResearchJobId: undefined,
  };
}

/**
 * The headings a retained job drafts (ICH_E3_GUIDANCE's draftable headings, or
 * those under its selection), or null when the retained selection is unusable:
 * unknown, duplicated in a way the builder refuses, or naming a manual heading.
 * Null or [] is the whole report.
 */
function retainedDraftTargets(persisted: unknown): CSRSection[] | null {
  if (persisted != null && !Array.isArray(persisted)) return null;
  const selection = Array.isArray(persisted) && persisted.length > 0 ? [...new Set(persisted as string[])] : undefined;
  try {
    const targets = resolveCSRDraftTargets(selection);
    return targets.length ? targets : null;
  } catch {
    return null;
  }
}

/**
 * The retained evidence pack for one section of a run-bound job. A heading
 * without table support still verifies its retained source; its explicit
 * empty pack preserves that missing-evidence state for the existing drafter.
 * Loaded through the canonical project-authorized, receipt-verified reader
 * as the job's requester, re-checked per section. A revoked or withdrawn
 * source, a missing requester or a pack for another protocol throws, and the
 * job fails closed rather than drafting the section from metadata.
 */
async function loadSectionEvidence(
  source: EvidenceSource, sectionNumber: string,
  job: { organizationId: number; requestedBy: number | null; studyId: string },
): Promise<CsrAuthoringEvidence> {
  const [{ loadCsrAuthoringEvidence }, { pool }] = await Promise.all([
    import('./cortex-authoring-reader'), import('../../db'),
  ]);
  const evidence = await loadCsrAuthoringEvidence(pool as unknown as RequestSqlClient,
    { organizationId: job.organizationId, userId: job.requestedBy ?? 0 }, { ...source, sectionNumber },
    undefined, { requireCurrent: true });
  if (evidence.source.protocolNumber !== job.studyId) {
    throw new CsrAuthoringContextError('CSR_EVIDENCE_STUDY_MISMATCH', 409);
  }
  return evidence;
}

function savedEvidenceDigest(lineage: unknown): string | null {
  if (!lineage || typeof lineage !== 'object') return null;
  const evidence = (lineage as Record<string, unknown>).evidence;
  if (!evidence || typeof evidence !== 'object') return null;
  const digest = (evidence as Record<string, unknown>).evidenceDigest;
  return typeof digest === 'string' && /^[a-f0-9]{64}$/.test(digest) ? digest : null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// PUBLIC API
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Enqueue a CSR build job for async execution. Returns immediately with the
 * jobId; the caller is responsible for kicking off runCSRBuildJob (see
 * launchCSRBuildAsync in csr-builder.ts for the standard setImmediate wiring).
 */
export async function enqueueCSRBuildJob(
  req: CSRBuildRequest,
  ctx: CSRBuildJobContext
): Promise<EnqueueResult> {
  // Validate identity before opening a database transaction or creating a job.
  const protocolNumber = req.studyInfo?.protocolNumber;
  if (typeof protocolNumber !== 'string' || !protocolNumber.trim()) {
    throw new Error('CSR_STUDY_IDENTIFIER_REQUIRED: Record the study protocol number before starting CSR drafting. No job was created.');
  }
  // Reject malformed section selections before creating a persistent job.
  // Undefined or [] retains the established whole-report behavior.
  const requestedSections = req.sectionsToGenerate;
  if (requestedSections !== undefined && requestedSections.length > 0) {
    const refusal = csrSectionSelectionRefusal(requestedSections);
    if (refusal) throw new CsrScopeError(refusal.code, 400, `${refusal.message} No job was created.`);
  } else if (requestedSections !== undefined && !Array.isArray(requestedSections)) {
    throw new CsrScopeError('CSR_SECTION_SELECTION_INVALID', 400,
      'Choose unique ICH E3 section numbers from the CSR template. No job was created.');
  }
  let evidenceSource: EvidenceSource | undefined;
  if (req.evidenceSource !== undefined) {
    try { evidenceSource = parseEvidenceSource(req.evidenceSource); } catch {
      throw new CsrScopeError('CSR_EVIDENCE_SELECTION_INVALID', 400, 'The retained run binding is invalid. No job was created.');
    }
  }
  // A CSR build must belong to an explicit project, rather than silently
  // creating an organization-wide job with no study dossier anchor.
  if (req.projectId === undefined && ctx.projectId === undefined && ctx.programId === undefined) {
    throw new CsrScopeError('CSR_PROJECT_REQUIRED', 400,
      'Select a project before starting CSR drafting. No job was created.');
  }
  const d = requireDb();
  const scope = await resolveCsrBuildContext(d, req, ctx);
  if (scope.projectId === undefined) {
    throw new CsrScopeError('CSR_PROJECT_REQUIRED', 400,
      'The selected CSR project could not be resolved. No job was created.');
  }
  if (evidenceSource) {
    // A matching protocol is not project identity. Reuse the unique program
    // anchor and current edit policy before storing a source-bound job.
    await resolveCsrScope(d, ctx.organizationId,
      { projectId: scope.projectId, programId: evidenceSource.programId },
      { forWrite: true, actorUserId: scope.requestedBy });
  }

  // Preserve the caller's intent: NULL == "full build", a non-empty array
  // == "draft only these sections". We deliberately do NOT expand to
  // defaultSectionNumbers() here — that expansion happens at run time inside
  // the runner for progress accounting only. Expanding at enqueue would make
  // a full build indistinguishable from a partial-build-of-all-sections,
  // which used to silently disable AI in generateCSRSections.
  const sectionsToGenerate =
    req.sectionsToGenerate && req.sectionsToGenerate.length > 0
      ? req.sectionsToGenerate
      : null;

  const snapshot: CSRStudyInfoSnapshot = {
    studyInfo: { ...req.studyInfo, protocolNumber: protocolNumber.trim() },
    deepResearchJobId: req.deepResearchJobId,
    ...(evidenceSource ? { evidenceSource } : {}),
  };

  const [row] = await d
    .insert(csrBuildJobs)
    .values({
      organizationId: ctx.organizationId,
      projectId: scope.projectId ?? null,
      // Preserve the recorded study protocol number without inventing an identifier.
      studyId: protocolNumber.trim(),
      status: 'queued',
      progress: 0,
      sectionsToGenerate,
      studyInfoSnapshot: snapshot as unknown as Record<string, unknown>,
      requestedBy: scope.requestedBy ?? null,
    })
    .returning({ id: csrBuildJobs.id });

  if (!row?.id) {
    throw new Error('[csr-job-runner] Failed to insert csr_build_jobs row');
  }

  return { jobId: row.id, status: 'queued' };
}

/**
 * Execute a previously-enqueued CSR build job.
 *
 * Loaded by jobId only (no org scope) because this is the worker entry point
 * — the org scope was enforced at enqueue time and is persisted on the row.
 * Validates state, transitions queued|failed -> drafting, generates each
 * section via the existing csr-builder pipeline, persists each section with
 * a SHA-256 content hash, and finishes with complete or failed.
 *
 * Partial-failure policy (v1): any section failure marks the whole job
 * failed; sections persisted before the failure remain on disk so a future
 * resume run can skip them. The runner does not retry inside this call.
 */
export async function runCSRBuildJob(jobId: number): Promise<void> {
  const d = requireDb();

  // 1. Load job (no org scope — worker entry point)
  const [job] = await d
    .select()
    .from(csrBuildJobs)
    .where(eq(csrBuildJobs.id, jobId))
    .limit(1);

  if (!job) {
    throw new Error(`[csr-job-runner] Job ${jobId} not found`);
  }

  // 2. Validate state — only queued or failed (resume) are runnable
  if (job.status !== 'queued' && job.status !== 'failed') {
    console.warn(
      `[csr-job-runner] Job ${jobId} is in state '${job.status}', not runnable; skipping`
    );
    return;
  }
  // Retain the state read above across admission awaits. A cancellation or a
  // competing claim must win over this worker's late setup/refusal writes.
  const runnableJob = and(eq(csrBuildJobs.id, job.id),
    eq(csrBuildJobs.organizationId, job.organizationId), eq(csrBuildJobs.status, job.status));
  const draftingJob = and(eq(csrBuildJobs.id, job.id),
    eq(csrBuildJobs.organizationId, job.organizationId), eq(csrBuildJobs.status, 'drafting'));

  // Legacy unanchored jobs cannot resume into a regulated dossier.
  // Refuse before any source reads or model calls.
  if (job.projectId == null) {
    await d.update(csrBuildJobs).set({
      status: 'failed',
      updatedAt: new Date(),
      error: {
        reason: 'project_anchor_missing',
        message: 'This CSR job has no project anchor. Select a project and start a new build.',
      },
    }).where(runnableJob);
    return;
  }

  // Permission is checked again when work starts, not retained from enqueue.
  // Refuse before section/source reads or AI calls; preserve prior outputs.
  try {
    await resolveCsrScope(d, job.organizationId, { projectId: job.projectId }, { actorUserId: job.requestedBy ?? undefined });
  } catch (error) {
    await d.update(csrBuildJobs).set({ status: 'failed', updatedAt: new Date(), error: {
      reason: error instanceof CsrScopeError ? 'project_access_refused' : 'project_access_verification_failed',
      code: error instanceof CsrScopeError ? error.code : 'CSR_PROJECT_ACCESS_UNAVAILABLE',
    } }).where(runnableJob);
    return;
  }

  // 3. Rebuild the CSRBuildRequest from the persisted snapshot
  const { studyInfo, deepResearchJobId, evidenceSource } = readStudyInfoSnapshot(
    job.studyInfoSnapshot
  );
  // Resume must use the study identity recorded on the job, not an edited,
  // missing, or legacy snapshot value. Refuse a mismatch rather than drafting
  // sections for a different protocol under the original job identifier.
  if (typeof studyInfo.protocolNumber !== 'string' ||
      studyInfo.protocolNumber.trim() !== job.studyId) {
    await d.update(csrBuildJobs).set({
      status: 'failed',
      updatedAt: new Date(),
      error: {
        reason: 'study_identity_mismatch',
        message: 'The saved CSR study identity does not match this job. No additional sections were drafted.',
      },
    }).where(runnableJob);
    return;
  }

  // Claim the job only after identity validation, and only if its state
  // remains runnable. A competing runner must not draft the same job.
  const [claimed] = await d.update(csrBuildJobs).set({
    status: 'drafting',
    startedAt: new Date(),
    updatedAt: new Date(),
    error: null,
  }).where(runnableJob).returning({ id: csrBuildJobs.id });
  if (!claimed) return;

  const persistedSubset = job.sectionsToGenerate ?? null;
  // Empty arrays retain the existing full-build meaning. An unusable retained
  // selection must never become a vacuously complete job or discard unknown slots.
  const allTargets = retainedDraftTargets(persistedSubset);
  if (!allTargets) {
    await d.update(csrBuildJobs).set({ status: 'failed', progress: 0, updatedAt: new Date(),
      error: { reason: 'invalid_section_selection', message: 'The retained CSR selection does not identify supported report sections.' },
    }).where(draftingJob);
    return;
  }
  const request: CSRBuildRequest = {
    organizationId: job.organizationId,
    userId: job.requestedBy ?? 0,
    projectId: job.projectId ?? undefined,
    studyInfo,
    deepResearchJobId,
    sectionsToGenerate:
      persistedSubset && persistedSubset.length > 0
        ? persistedSubset
        : undefined,
  };
  const aiCtx = {
    organizationId: job.organizationId,
    projectId: job.projectId ?? undefined,
    userId: job.requestedBy ?? undefined,
  };

  // 5. Resume only missing/blank targets; preserve every nonblank saved target.
  const targetNumbers = new Set(allTargets.map(section => section.number));

  const alreadyPersisted = await d
    .select({ sectionNumber: csrSectionOutputs.sectionNumber, content: csrSectionOutputs.content, contentHash: csrSectionOutputs.contentHash, lineage: csrSectionOutputs.lineage })
    .from(csrSectionOutputs)
    .where(and(eq(csrSectionOutputs.jobId, job.id), eq(csrSectionOutputs.organizationId, job.organizationId)));
  // Resume only verified, non-placeholder content. A damaged or incomplete
  // output must not be treated as finished merely because its row exists.
  const persistedSet = new Set(alreadyPersisted.filter(row =>
    targetNumbers.has(row.sectionNumber) &&
    typeof row.content === 'string' &&
    Boolean(row.content.trim()) &&
    !hasUnresolvedPlaceholders(row.content) &&
    typeof row.contentHash === 'string' &&
    row.contentHash === sha256Hex(row.content)
  ).map(row => row.sectionNumber));

  // A stored hash mismatch is evidence of changed or damaged source output.
  // Never overwrite that record during a resume: preserve it for investigation
  // and require a governed correction rather than silently regenerating it.
  const damaged = alreadyPersisted.filter(row =>
    targetNumbers.has(row.sectionNumber) &&
    (typeof row.content !== 'string' ||
      typeof row.contentHash !== 'string' ||
      row.contentHash !== sha256Hex(row.content))
  );
  if (damaged.length > 0) {
    await d.update(csrBuildJobs).set({
      status: 'failed',
      updatedAt: new Date(),
      error: {
        reason: 'saved_section_integrity_failed',
        sections: damaged.map(row => row.sectionNumber),
        message: 'Saved CSR section integrity verification failed. Existing content was preserved; review the affected sections before restarting.',
      },
    }).where(draftingJob);
    return;
  }

  const totalSections = allTargets.length;
  let sectionsCompleted = persistedSet.size;
  const currentSection = { number: '' as string };
  const currentDigests = new Map<string, string>();
  const savedByNumber = new Map(alreadyPersisted.map(row => [row.sectionNumber, row]));

  // The same admission runs before and after asynchronous drafting, and for
  // every retained target on completion. A populated resume cannot skip it.
  const revalidate = async (sectionNumber: string): Promise<CsrAuthoringEvidence | undefined> => {
    await resolveCsrScope(d, job.organizationId, {
      projectId: job.projectId,
      ...(evidenceSource ? { programId: parseEvidenceSource(evidenceSource).programId } : {}),
    }, { forWrite: true, actorUserId: job.requestedBy ?? undefined });
    if (!evidenceSource) return undefined;
    const evidence = await loadSectionEvidence(parseEvidenceSource(evidenceSource), sectionNumber, job);
    let expected = currentDigests.get(sectionNumber);
    if (!expected && persistedSet.has(sectionNumber)) {
      expected = savedEvidenceDigest(savedByNumber.get(sectionNumber)?.lineage) ?? undefined;
      if (!expected) throw new CsrAuthoringContextError('CSR_EVIDENCE_PROVENANCE_MISSING', 409);
    }
    if (expected && expected !== evidence.evidenceDigest) throw new CsrAuthoringContextError('CSR_EVIDENCE_CHANGED', 409);
    currentDigests.set(sectionNumber, evidence.evidenceDigest);
    return evidence;
  };

  // Seed initial progress so a resumed run reports the right number
  if (totalSections > 0) {
    const initialProgress = Math.floor(
      (sectionsCompleted / totalSections) * 100
    );
    await d
      .update(csrBuildJobs)
      .set({ progress: initialProgress, updatedAt: new Date() })
      .where(draftingJob);
  }

  try {
    // Per-section drafting + upsert. Each section is persisted IMMEDIATELY
    // after its AI call returns so a mid-job crash leaves prior sections on
    // disk and a resume picks up exactly where we left off (and re-bills
    // only the un-persisted remainder).
    for (const section of allTargets) {
      currentSection.number = section.number;
      const evidence = await revalidate(section.number);
      if (persistedSet.has(section.number)) continue;

      // A job bound to a retained run drafts each results section over that
      // section's engine tables; a refused or revoked source fails the job.
      const drafted = await draftCSRSectionWithProvenance(
        section,
        request,
        aiCtx,
        evidence
      );

      // A model response must target the section being drafted. An unexpected
      // section identifier must not overwrite another section via the upsert.
      if (drafted.number !== section.number) {
        throw new Error('CSR_DRAFT_SECTION_MISMATCH: Generated section identifier differs from the requested ICH E3 section.');
      }
      await revalidate(section.number);

      // Model calls are long-running. A cancelled or superseded job cannot
      // save a late model result into its previously governed section set.
      const [stillDrafting] = await d.select({ id: csrBuildJobs.id })
        .from(csrBuildJobs)
        .where(and(eq(csrBuildJobs.id, jobId),
          eq(csrBuildJobs.organizationId, job.organizationId),
          eq(csrBuildJobs.status, 'drafting')))
        .limit(1);
      if (!stillDrafting) return;

      // Missing output remains retryable work; never persist whitespace as a draft.
      if (typeof drafted.content !== 'string' || !drafted.content.trim()) {
        continue;
      }

      const contentHash = sha256Hex(drafted.content);
      const isAI = drafted.source === 'ai';

      await d
        .insert(csrSectionOutputs)
        .values({
          organizationId: job.organizationId,
          projectId: job.projectId ?? null,
          jobId: job.id,
          sectionNumber: drafted.number,
          content: drafted.content,
          contentHash,
          aiGenerated: isAI,
          model: drafted.model,
          tokenCost: drafted.tokenCost,
          lineage: drafted.lineage as Record<string, unknown> | null,
        })
        .onConflictDoUpdate({
          target: [csrSectionOutputs.jobId, csrSectionOutputs.sectionNumber],
          set: {
            content: drafted.content,
            contentHash,
            aiGenerated: isAI,
            model: drafted.model,
            tokenCost: drafted.tokenCost,
            lineage: drafted.lineage as Record<string, unknown> | null,
            generatedAt: new Date(),
          },
        });

      sectionsCompleted += 1;
      const progress =
        totalSections === 0
          ? 100
          : Math.floor((sectionsCompleted / totalSections) * 100);

      await d
        .update(csrBuildJobs)
        .set({ progress, updatedAt: new Date() })
        .where(and(eq(csrBuildJobs.id, jobId),
          eq(csrBuildJobs.organizationId, job.organizationId),
          eq(csrBuildJobs.status, 'drafting')));
    }

    // A source may have changed while a later section was drafted. Recheck
    // the complete selected set before issuing a completed-job verdict.
    for (const section of allTargets) {
      currentSection.number = section.number;
      await revalidate(section.number);
    }

    // 6. Re-read saved target coverage, including prior attempts. Missing rows
    // cannot pass a placeholder-only check; unrelated rows do not cover targets.
    const persistedOutputs = await d
      .select({
        sectionNumber: csrSectionOutputs.sectionNumber,
        content: csrSectionOutputs.content,
        contentHash: csrSectionOutputs.contentHash,
      })
      .from(csrSectionOutputs)
      .where(and(eq(csrSectionOutputs.jobId, job.id), eq(csrSectionOutputs.organizationId, job.organizationId)));
    const integrity = verifySavedCsrSectionIntegrity([...targetNumbers], persistedOutputs);
    const savedTargets = persistedOutputs.filter(row => targetNumbers.has(row.sectionNumber) && typeof row.content === 'string' && row.content.trim());
    const missingSections = integrity.missing;
    const finalProgress = Math.floor((integrity.covered.length / totalSections) * 100);
    if (integrity.mismatched.length) {
      await d.update(csrBuildJobs).set({ status: 'failed', progress: finalProgress, updatedAt: new Date(),
        error: { reason: 'saved_section_integrity_failed', sections: integrity.mismatched,
          message: 'A saved CSR section changed or failed checksum verification. No completed report was issued.' },
      }).where(and(eq(csrBuildJobs.id, jobId), eq(csrBuildJobs.organizationId, job.organizationId),
        eq(csrBuildJobs.status, 'drafting')));
      return;
    }
    if (missingSections.length) {
      await d.update(csrBuildJobs).set({ status: 'failed', progress: finalProgress, updatedAt: new Date(),
        error: { reason: 'missing_section_outputs', sections: missingSections,
          message: 'Requested CSR sections have no nonblank saved output; retained sections are preserved for resume.' },
      }).where(and(eq(csrBuildJobs.id, jobId),
          eq(csrBuildJobs.organizationId, job.organizationId),
          eq(csrBuildJobs.status, 'drafting')));
      return;
    }
    const placeholderSections = savedTargets
      .filter(r => hasUnresolvedPlaceholders(r.content))
      .map(r => r.sectionNumber)
      .sort();

    if (placeholderSections.length > 0) {
      // Retain the existing placeholder refusal and its exact target codes.
      console.warn(
        `[csr-job-runner] Job ${jobId} has unresolved placeholders in section(s) ${placeholderSections.join(
          ', ',
        )}; marking failed instead of complete`,
      );
      await d
        .update(csrBuildJobs)
        .set({
          status: 'failed',
          updatedAt: new Date(),
          error: {
            reason: 'unresolved_placeholders',
            sections: placeholderSections,
            message: `CSR section(s) ${placeholderSections.join(
              ', ',
            )} still contain unresolved template placeholders (AI drafting fell back to template text); these sections are not submission-ready.`,
            at: new Date().toISOString(),
          },
        })
        .where(and(eq(csrBuildJobs.id, jobId),
          eq(csrBuildJobs.organizationId, job.organizationId),
          eq(csrBuildJobs.status, 'drafting')));
      return;
    }

    // 6b. Success — only the actively claimed drafting job may transition
    // to complete. A revoked, cancelled, or superseded job must not be
    // resurrected by a late section-drafting worker.
    const completed = await d
      .update(csrBuildJobs)
      .set({
        status: 'complete',
        progress: 100,
        error: null,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(and(eq(csrBuildJobs.id, jobId),
        eq(csrBuildJobs.organizationId, job.organizationId),
        eq(csrBuildJobs.status, 'drafting')))
      .returning({ id: csrBuildJobs.id });
    if (completed.length !== 1) return;
    // Continue dependent submission work only after the CSR completion is durable.
    // This callback has its own failure boundary: a release/readiness refusal
    // must never relabel successfully generated CSR sections as a failed job.
    try {
      const { continueOrchestratorRunsForCsrJob } = await import('../submission-orchestrator-continuation.js');
      const outcomes = await continueOrchestratorRunsForCsrJob(jobId, job.organizationId);
      for (const outcome of outcomes) {
        if (outcome.continuation === 'retry-required') console.warn('[csr-job-runner] Submission continuation needs retry', { jobId, organizationId: job.organizationId, ...outcome });
      }
    } catch {
      console.warn('[csr-job-runner] CSR completed; submission continuation is temporarily unavailable', { jobId, organizationId: job.organizationId });
    }
  } catch (err) {
    // 7. Failure — record the failing section + message ONLY (never payload content)
    const message = err instanceof Error ? err.message : String(err);
    console.error(
      `[csr-job-runner] Job ${jobId} failed on section '${
        currentSection.number || '<setup>'
      }': ${message}`
    );
    await d
      .update(csrBuildJobs)
      .set({
        status: 'failed',
        updatedAt: new Date(),
        error: {
          message,
          section: currentSection.number || null,
          at: new Date().toISOString(),
        },
      })
      .where(and(eq(csrBuildJobs.id, jobId),
        eq(csrBuildJobs.organizationId, job.organizationId),
        eq(csrBuildJobs.status, 'drafting')));
  }
}

/**
 * Counts the verifiable, non-placeholder saved sections of a job, and says
 * whether a job recorded as complete fails its saved-output integrity check.
 */
function savedSectionsVerdict(
  row: { status: string; sectionsToGenerate: string[] | null },
  sectionRows: Array<{ sectionNumber: string; content: string; contentHash: string | null }>,
): { sectionsComplete: number; integrityFailure: boolean } {
  const resolvedTargets = retainedDraftTargets(row.sectionsToGenerate ?? null);
  const targetCodes = resolvedTargets?.map(section => section.number) ?? row.sectionsToGenerate ?? [];
  const validTargets = !!resolvedTargets && targetCodes.length > 0;
  const integrity = validTargets
    ? verifySavedCsrSectionIntegrity(targetCodes, sectionRows)
    : { covered: [], missing: targetCodes, mismatched: [] };
  const verified = new Set(integrity.covered);
  const sectionsComplete = sectionRows.filter(section =>
    verified.has(section.sectionNumber) && !hasUnresolvedPlaceholders(section.content)
  ).length;
  const integrityFailure = row.status === 'complete' &&
    (sectionRows.length === 0 || integrity.mismatched.length > 0 || integrity.missing.length > 0 ||
      sectionsComplete !== targetCodes.length);
  return { sectionsComplete, integrityFailure };
}

/**
 * Org-scoped read of a job's current state. Returns null when the job
 * either does not exist OR belongs to a different organization — the two
 * cases are deliberately collapsed to avoid leaking job existence across
 * tenants.
 */
export async function getCSRBuildJobStatus(
  jobId: number,
  organizationId: number
): Promise<CSRBuildJobStatus | null> {
  const d = requireDb();

  const [row] = await d
    .select({
      status: csrBuildJobs.status,
      progress: csrBuildJobs.progress,
      error: csrBuildJobs.error,
      sectionsToGenerate: csrBuildJobs.sectionsToGenerate,
    })
    .from(csrBuildJobs)
    .where(
      and(
        eq(csrBuildJobs.id, jobId),
        eq(csrBuildJobs.organizationId, organizationId)
      )
    )
    .limit(1);

  if (!row) return null;

  // Only count verifiable, non-placeholder sections. A persisted row alone
  // does not mean its content is complete or safe to reuse.
  const sectionRows = await d
    .select({
      sectionNumber: csrSectionOutputs.sectionNumber,
      content: csrSectionOutputs.content,
      contentHash: csrSectionOutputs.contentHash,
    })
    .from(csrSectionOutputs)
    .where(
      and(
        eq(csrSectionOutputs.jobId, jobId),
        eq(csrSectionOutputs.organizationId, organizationId)
      )
    );
  const { sectionsComplete, integrityFailure } = savedSectionsVerdict(row, sectionRows);

  return {
    status: integrityFailure ? 'failed' : row.status,
    progress: integrityFailure ? 0 : row.progress,
    sectionsComplete,
    error: integrityFailure
      ? { reason: 'saved_section_integrity_failed', message: 'Saved CSR outputs require integrity review.' }
      : row.error ?? null,
  };
}

/**
 * Org-scoped read of all persisted sections for a job. Returns an empty
 * array if the job has no sections yet (or if the org mismatch hides
 * them — the org scope on the WHERE clause silently filters cross-tenant
 * reads).
 */
export async function getCSRSectionOutputs(
  jobId: number,
  organizationId: number
): Promise<CsrSectionOutput[]> {
  const d = requireDb();

  const rows = await d
    .select()
    .from(csrSectionOutputs)
    .where(
      and(
        eq(csrSectionOutputs.jobId, jobId),
        eq(csrSectionOutputs.organizationId, organizationId)
      )
    );

  return rows;
}
