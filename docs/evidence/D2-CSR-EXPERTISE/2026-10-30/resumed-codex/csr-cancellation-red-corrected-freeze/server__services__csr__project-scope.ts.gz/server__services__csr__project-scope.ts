import { and, eq } from 'drizzle-orm';
import { clientWorkspaces, csrBuildJobs, projects } from '@shared/schema';
import type { RequestDb } from '../../db/requestDb';
import { queryableFromDrizzle } from '../../db/drizzle-queryable';
import { looksLikeProgramUuid } from '../../lib/project-id';
import { readProgramAnchorRow } from '../c2c/program-project-anchor';
import { canAccessReportProject, type ReportProjectActor } from '../report-os/project-access';

export class CsrScopeError extends Error {
  constructor(readonly code: string, readonly status: 400 | 403 | 404 | 409, message: string) {
    super(message);
    this.name = 'CsrScopeError';
  }
}

export interface CsrScopeInput { projectId?: unknown; programId?: unknown; clientWorkspaceId?: unknown }
export interface CsrScope { projectId?: number; programId?: string; clientWorkspaceId?: number }
export interface CsrScopeExecutor {
  query: (text: string, params?: unknown[]) => Promise<{ rows: Record<string, unknown>[] }>;
}

/** Read membership now, on the same connection used for the project policy.
 * A queued job must not inherit the creator's old session role after revocation. */
export async function readCsrProjectActor(
  database: Pick<RequestDb, 'select' | 'execute'> | CsrScopeExecutor,
  organizationId: number,
  userId: number | undefined,
  options: { allowReadOnlyTenant?: boolean; forShare?: boolean } = {},
): Promise<ReportProjectActor> {
  if (!Number.isSafeInteger(userId) || !userId || userId <= 0) throw new CsrScopeError('CSR_PROJECT_ACCESS_DENIED', 403, 'Current project access could not be established for the CSR actor.');
  const client = 'select' in database ? queryableFromDrizzle(database) : database;
  // Locked writer/signature admission always requires an active tenant.
  // Retained reads may separately opt into the pending-deletion read policy.
  const result = options.forShare
    ? await client.query(`SELECT ou.role FROM organization_users ou
        JOIN users u ON u.id=ou.user_id JOIN organizations o ON o.id=ou.organization_id
        WHERE ou.organization_id=$1 AND ou.user_id=$2 AND u.status='active' AND o.status='active'
        FOR SHARE OF ou,u,o`, [organizationId, userId])
    : await client.query(`SELECT ou.role FROM organization_users ou
        JOIN users u ON u.id=ou.user_id JOIN organizations o ON o.id=ou.organization_id
        WHERE ou.organization_id=$1 AND ou.user_id=$2 AND u.status='active'
          AND (o.status='active' OR ($3::boolean AND o.status='pending_deletion'))`,
      [organizationId, userId, options.allowReadOnlyTenant === true]);
  const { rows } = result;
  if (rows.length !== 1 || typeof rows[0].role !== 'string' || !rows[0].role.trim()) throw new CsrScopeError('CSR_PROJECT_ACCESS_DENIED', 403, 'The CSR actor is no longer an active member of this organization.');
  return { userId, role: rows[0].role.trim().toLowerCase() };
}

/** Explicit malformed scope never becomes an organization-wide request. */
export function parseCsrScopeId(value: unknown, name: string): number | undefined {
  if (value === undefined) return undefined;
  const number = typeof value === 'number' ? value : typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : NaN;
  if (!Number.isSafeInteger(number) || number <= 0) throw new CsrScopeError('CSR_SCOPE_INVALID', 400, `${name} must be a positive integer.`);
  return number;
}

async function resolveProgramScope(database: Pick<RequestDb, 'select'>, organizationId: number, input: CsrScopeInput): Promise<CsrScope> {
  let projectId = parseCsrScopeId(input.projectId, 'projectId');
  let programId: string | undefined;
  if (input.programId !== undefined) {
    if (typeof input.programId !== 'string' || !looksLikeProgramUuid(input.programId)) throw new CsrScopeError('CSR_SCOPE_INVALID', 400, 'programId must be a project UUID.');
    programId = input.programId.trim().toLowerCase();
    const anchor = await readProgramAnchorRow(database as RequestDb, { programId, orgId: organizationId, context: 'csr-workflow', requireUnique: true });
    if (!anchor) throw new CsrScopeError('CSR_PROGRAM_NOT_ANCHORED', 409, 'The project has no unique tracking record for this organization. Nothing was read or built under another project.');
    if (projectId !== undefined && projectId !== anchor.id) throw new CsrScopeError('CSR_SCOPE_MISMATCH', 400, 'projectId does not identify the selected project.');
    projectId = anchor.id;
  }
  return { projectId, programId };
}

async function verifyWorkspaceScope(database: Pick<RequestDb, 'select'>, organizationId: number, projectId: number | undefined, clientWorkspaceId: number | undefined): Promise<void> {
  if (clientWorkspaceId !== undefined) {
    const [workspace] = await database.select({ id: clientWorkspaces.id }).from(clientWorkspaces).where(and(eq(clientWorkspaces.id, clientWorkspaceId), eq(clientWorkspaces.organizationId, organizationId))).limit(1);
    if (!workspace) throw new CsrScopeError('CSR_WORKSPACE_NOT_FOUND', 403, 'That client workspace is not in your organization.');
    if (projectId === undefined) throw new CsrScopeError('CSR_SCOPE_INVALID', 400, 'A client workspace filter requires an explicit project or tracking record.');
  }
}

/** The project/program boundary shared by CSR writes and scoped board reads.
 * Reading an archived project's retained work remains valid; new builds refuse it. */
export async function resolveCsrScope(database: Pick<RequestDb, 'select' | 'execute'>, organizationId: number, input: CsrScopeInput, options: { forWrite?: boolean; actorUserId?: number } = {}): Promise<CsrScope> {
  if (!Number.isSafeInteger(organizationId) || organizationId <= 0) throw new CsrScopeError('CSR_SCOPE_INVALID', 400, 'A valid organization is required.');
  const { projectId, programId } = await resolveProgramScope(database, organizationId, input);
  const clientWorkspaceId = parseCsrScopeId(input.clientWorkspaceId, 'clientWorkspaceId');
  await verifyWorkspaceScope(database, organizationId, projectId, clientWorkspaceId);
  if (projectId === undefined) return {};
  const [project] = await database.select({ id: projects.id, status: projects.status, clientWorkspaceId: projects.clientWorkspaceId }).from(projects).where(and(eq(projects.id, projectId), eq(projects.organizationId, organizationId))).limit(1);
  if (!project) throw new CsrScopeError('CSR_PROJECT_NOT_FOUND', 404, 'Project not found for this organization.');
  const actor = await readCsrProjectActor(database, organizationId, options.actorUserId, { allowReadOnlyTenant: options.forWrite === false });
  if (!await canAccessReportProject(organizationId, actor, projectId, queryableFromDrizzle(database), { forWrite: options.forWrite !== false })) throw new CsrScopeError('CSR_PROJECT_ACCESS_DENIED', 403, 'The CSR actor does not have access to this project.');
  if (clientWorkspaceId !== undefined && clientWorkspaceId !== project.clientWorkspaceId) throw new CsrScopeError('CSR_WORKSPACE_SCOPE_MISMATCH', 403, 'The selected project is not in this client workspace.');
  if (options.forWrite !== false && ['archived', 'deleted'].includes(project.status)) throw new CsrScopeError('CSR_PROJECT_ARCHIVED', 409, 'New CSR builds are unavailable for an archived project. Retained CSR work can still be read.');
  return { projectId, ...(programId ? { programId } : {}), ...(clientWorkspaceId ? { clientWorkspaceId } : {}) };
}

export async function resolveCsrBuildContext(
  database: Pick<RequestDb, 'select' | 'execute'>,
  request: { organizationId: number; projectId?: number; userId: number },
  context: { organizationId: number; projectId?: number; programId?: string; clientWorkspaceId?: number; requestedBy?: number },
) {
  if (request.organizationId !== context.organizationId || (context.requestedBy !== undefined && context.requestedBy !== request.userId)) throw new CsrScopeError('CSR_SCOPE_MISMATCH', 400, 'The CSR request and execution context must identify the same organization and actor.');
  const requestProject = parseCsrScopeId(request.projectId, 'projectId');
  const contextProject = parseCsrScopeId(context.projectId, 'projectId');
  if (requestProject !== undefined && contextProject !== undefined && requestProject !== contextProject) throw new CsrScopeError('CSR_SCOPE_MISMATCH', 400, 'The CSR request and execution context identify different projects.');
  const scope = await resolveCsrScope(database, context.organizationId, { ...context, projectId: contextProject ?? requestProject }, { actorUserId: request.userId });
  return { ...context, ...scope, requestedBy: context.requestedBy ?? request.userId };
}

/** Saved reads use current read access; a job mutation must explicitly require editing. */
export async function requireCsrJobAccess(database: Pick<RequestDb, 'select' | 'execute'> | CsrScopeExecutor, organizationId: number, jobId: number, userId: number | undefined, options: { forWrite?: boolean } = {}): Promise<boolean> {
  const actor = await readCsrProjectActor(database, organizationId, userId, { allowReadOnlyTenant: options.forWrite !== true });
  if (!('select' in database)) {
    const { rows } = await database.query('SELECT project_id FROM csr_build_jobs WHERE id = $1 AND organization_id = $2', [jobId, organizationId]);
    if (rows.length !== 1) return false;
    const projectId = rows[0].project_id == null ? undefined : parseCsrScopeId(rows[0].project_id, 'projectId');
    if (projectId !== undefined && !await canAccessReportProject(organizationId, actor, projectId, database, options)) {
      throw new CsrScopeError('CSR_PROJECT_ACCESS_DENIED', 403, 'The CSR actor does not have access to this project.');
    }
    return true;
  }
  const [job] = await database.select({ projectId: csrBuildJobs.projectId }).from(csrBuildJobs).where(and(eq(csrBuildJobs.id, jobId), eq(csrBuildJobs.organizationId, organizationId))).limit(1);
  if (!job) return false;
  if (job.projectId != null) await resolveCsrScope(database, organizationId, { projectId: job.projectId }, { forWrite: options.forWrite === true, actorUserId: userId });
  return true;
}
