import { describe, expect, it } from 'vitest';
import { getExactSectionBlueprint, getSectionBlueprintContext } from '../../sectionBlueprintCatalog';
import { getTaskBlueprint } from '../../taskBlueprintCatalog';
import { getRegistryDocumentTemplate } from '../../../market-specs/document-template-library';

const section = (id: string, code: string) => getExactSectionBlueprint(id)?.sections.find(row => row.code === code);

describe('US reliance and abbreviated applications retain the actual CTD and their legal-basis evidence', () => {
  it.each(['US_505B2', 'US_351K', 'US_ANDA'])('%s reaches the existing full US CTD rather than the shallow fallback', async id => {
    const outline = await getRegistryDocumentTemplate(id);
    expect(outline?.sections.length).toBeGreaterThan(70);
    expect(outline?.sections.some(row => row.number === '3.2.S.4')).toBe(true);
    expect(outline?.sections.some(row => row.number === '5.3.1')).toBe(true);
    expect(getExactSectionBlueprint(id)).not.toBeNull();
  });

  it('505(b)(2) separates relied-upon evidence, scientific bridge, differences and patent statements', () => {
    for (const code of ['505B2-RELIANCE', '505B2-BRIDGE', '505B2-DIFFERENCES', '505B2-PATENTS']) {
      expect(section('US_505B2', code), code).toBeDefined();
    }
    expect(section('US_505B2', '505B2-RELIANCE')?.guidance).toMatch(/literature|finding/i);
    expect(section('US_505B2', '505B2-BRIDGE')?.contentType).toBe('narrative');
    expect(section('US_505B2', '505B2-BRIDGE-DATA')?.contentType).toBe('data');
    expect(section('US_505B2', '505B2-PATENTS')?.contentType).toBe('mixed');
    expect(section('US_505B2', '505B2-DIFFERENCES')?.guidance).toMatch(/applicant|additional|difference/i);
  });

  it('351(k) retains reference-product, comparative evidence and conditional extrapolation/interchangeability', () => {
    for (const code of ['351K-REFERENCE', '351K-ANALYTICAL', '351K-CLINICAL', '351K-EXTRAPOLATION', '351K-INTERCHANGEABILITY']) {
      expect(section('US_351K', code), code).toBeDefined();
    }
    expect(section('US_351K', '351K-ANALYTICAL')?.contentType).toBe('mixed');
    expect(section('US_351K', '351K-EXTRAPOLATION')?.required).toBe(false);
    expect(section('US_351K', '351K-INTERCHANGEABILITY')?.required).toBe(false);
    expect(section('US_351K', '351K-INTERCHANGEABILITY')?.guidance).toMatch(/separate|not automatic|not infer/i);
  });

  it('ANDA retains bioequivalence/biowaiver and does not require the full independent efficacy/toxicology program', () => {
    for (const code of ['ANDA-REFERENCE', 'ANDA-SAMENESS', 'ANDA-BE', 'ANDA-BIOWAIVER', 'ANDA-PATENTS']) {
      expect(section('US_ANDA', code), code).toBeDefined();
    }
    expect(section('US_ANDA', 'ANDA-BIOWAIVER')?.required).toBe(false);
    expect(section('US_ANDA', 'ANDA-BE')?.contentType).toBe('mixed');
    expect(section('US_ANDA', '4.2.3.2')?.required).toBe(false);
    expect(section('US_ANDA', '5.3.5.1')?.required).toBe(false);
    expect(section('US_ANDA', '5.3.1')?.module).toBe(5);
  });
});

describe('US procedural requests and postmarketing work are their own work products', () => {
  it('accelerated approval asks for endpoint justification and confirmatory evidence without claiming a designation or approval', () => {
    expect(section('US_ACCEL_APPROVAL', 'AA-ENDPOINT')?.contentType).toBe('narrative');
    expect(section('US_ACCEL_APPROVAL', 'AA-CONFIRMATORY')?.contentType).toBe('narrative');
    expect(section('US_ACCEL_APPROVAL', 'AA-DATA')?.contentType).toBe('data');
    expect(section('US_ACCEL_APPROVAL', 'AA-AGENCY-RECORD')?.contentType).toBe('mixed');
    expect(section('US_ACCEL_APPROVAL', 'AA-AGENCY-RECORD')?.required).toBe(false);
    expect(section('US_ACCEL_APPROVAL', '3.2.S')).toBeUndefined();
  });

  it('rolling review retains the underlying application and actual agreed submission plan', () => {
    for (const code of ['ROLLING-ELIGIBILITY', 'ROLLING-SCHEDULE', 'ROLLING-AGREEMENT', 'ROLLING-CHANGE-CONTROL']) {
      expect(section('US_ROLLING', code), code).toBeDefined();
    }
    expect(section('US_ROLLING', 'ROLLING-AGREEMENT')?.contentType).toBe('mixed');
    expect(section('US_ROLLING', 'ROLLING-AGREEMENT')?.required).toBe(false);
    expect(section('US_ROLLING', '3.2.S')).toBeUndefined();
  });

  it('PMR/PMC work binds the real requirement letter, milestone/status data and proposed response rather than assuming a protocol', () => {
    for (const code of ['PMR-SOURCE', 'PMR-OBLIGATION', 'PMR-MILESTONES', 'PMR-STATUS', 'PMR-RESPONSE']) {
      expect(section('US_PMR', code), code).toBeDefined();
    }
    expect(section('US_PMR', 'PMR-SOURCE')?.contentType).toBe('mixed');
    expect(section('US_PMR', 'PMR-MILESTONES')?.contentType).toBe('table');
    expect(section('US_PMR', 'PMR-STATUS')?.contentType).toBe('narrative');
    expect(section('US_PMR', '1.1')).toBeUndefined();
    expect(section('US_PMR', 'PMR-RESPONSE')?.guidance).toMatch(/fulfill|release|agency/i);
  });

  it('RFD includes constituent classification and PMOA jurisdiction rationale without inventing an FDA designation', () => {
    for (const code of ['RFD-PRODUCT', 'RFD-CONSTITUENTS', 'RFD-CLASSIFICATION', 'RFD-PMOA', 'RFD-ASSIGNMENT', 'RFD-AGENCY-RECORD']) {
      expect(section('US_RFD', code), code).toBeDefined();
    }
    expect(section('US_RFD', 'RFD-PMOA')?.contentType).toBe('narrative');
    expect(section('US_RFD', 'RFD-AGENCY-RECORD')?.contentType).toBe('mixed');
    expect(section('US_RFD', 'RFD-AGENCY-RECORD')?.required).toBe(false);
    expect(section('US_RFD', 'RFD-ASSIGNMENT')?.guidance).toMatch(/proposed|recommendation|FDA/i);
  });
});

describe('each completed existing US filing has one precise project plan and visible source limits', () => {
  it.each(['US_505B2', 'US_351K', 'US_ANDA', 'US_ACCEL_APPROVAL', 'US_ROLLING', 'US_PMR', 'US_RFD'])('%s has a matching exact task identity without invented agency deadlines', async id => {
    const tasks = await getTaskBlueprint(id);
    expect(tasks.id).toBe(`${id.toLowerCase()}_tasks`);
    expect(tasks.milestones.length).toBeGreaterThan(1);
    expect(tasks.milestones.flatMap(milestone => milestone.tasks).every(task => task.estimatedDays === undefined)).toBe(true);
    const blueprint = getExactSectionBlueprint(id);
    expect(blueprint?.id).toBe(`${id.toLowerCase()}_sections`);
    expect(new Set(blueprint?.sections.map(row => row.code)).size).toBe(blueprint?.sections.length);
    expect(getSectionBlueprintContext(id).limitations.join(' ')).toMatch(/source|applicab|agency/i);
  });
});
