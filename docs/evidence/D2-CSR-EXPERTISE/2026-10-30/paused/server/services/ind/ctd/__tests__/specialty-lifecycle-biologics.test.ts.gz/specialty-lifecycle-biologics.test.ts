import { describe, expect, it } from 'vitest';
import { LIFECYCLE_DOCUMENT_TYPES } from '../lifecycle-document-types';

const exactRecords = [
  ['bla_annual_report', 'US_BLA_ANNUAL'],
  ['bla_pediatric_annual_report', 'US_BLA_PEDIATRIC_ANNUAL'],
  ['bla_pmr_annual_report', 'US_BLA_PMR_ANNUAL'],
  ['bla_distribution_report', 'US_BLA_DISTRIBUTION'],
  ['biological_product_deviation', 'US_BPDR'],
  ['bla_cbe_30', 'US_BLA_CBE30'],
  ['bla_cbe_0', 'US_BLA_CBE0'],
  ['cber_master_file', 'US_CBER_MASTER_FILE'],
  ['cber_lot_release', 'US_CBER_LOT_RELEASE'],
  ['bla_periodic_adverse_experience', 'US_BLA_PAE_REPORT'],
  ['bla_pas', 'US_BLA_SUPP'],
  ['rems_modification', 'US_REMS'],
  ['rems_assessment', 'US_REMS'],
] as const;

const find = (id: string) => LIFECYCLE_DOCUMENT_TYPES.find(record => record.id === id);

describe('biologics filing parts extend the canonical lifecycle owner', () => {
  it.each(exactRecords)('%s has its exact regulatory identity and substantive source parts', (id, registryId) => {
    const record = find(id);
    expect(record, id).toBeDefined();
    expect(record?.registryId).toBe(registryId);
    expect(record?.agency).toBe('FDA');
    expect(record?.components.length).toBeGreaterThanOrEqual(5);
    expect(new Set(record?.components.map(part => part.code)).size).toBe(record?.components.length);
    expect(record?.components.some(part => part.contentType === 'narrative')).toBe(true);
    expect(record?.components.some(part => part.contentType !== 'narrative')).toBe(true);
    for (const part of record?.components ?? []) {
      expect(part.guidance.trim().length).toBeGreaterThan(15);
      expect(part.authoringGuidance.trim().length).toBeGreaterThan(30);
      expect(part.keyContentElements.length).toBeGreaterThanOrEqual(2);
      expect(part.generationPrompt).toMatch(/do not invent/i);
    }
  });

  it('does not replace biologics reports with the NDA annual-report parts', () => {
    expect(find('bla_annual_report')?.regulatoryBasis.join(' ')).toContain('601.12(d)');
    expect(find('bla_pediatric_annual_report')?.regulatoryBasis.join(' ')).toContain('601.28');
    expect(find('bla_pmr_annual_report')?.regulatoryBasis.join(' ')).toContain('601.70');
    expect(find('bla_distribution_report')?.regulatoryBasis.join(' ')).toContain('600.81');
    expect(find('bla_distribution_report')?.description).toMatch(/separate|distinct/i);
    expect(find('bla_distribution_report')?.description).not.toMatch(/annual report of distribution/i);
    expect(find('nda_bla_annual_report')?.components.length).toBeGreaterThan(0);
  });

  it('retains distinct original forms, validated data and controlled material', () => {
    const originals = [
      ['bla_annual_report', 'BLA-AR-CHANGES-DATA', 'data'],
      ['bla_pediatric_annual_report', 'BLA-PED-STUDIES', 'data'],
      ['bla_pmr_annual_report', 'BLA-PMR-STUDY-REGISTER', 'table'],
      ['bla_distribution_report', 'BLA-DIST-REPORT', 'data'],
      ['biological_product_deviation', 'BPDR-3486', 'form'],
      ['bla_cbe_30', 'BLA-CBE30-356H', 'form'],
      ['bla_cbe_0', 'BLA-CBE0-356H', 'form'],
      ['cber_master_file', 'BMF-TECHNICAL', 'data'],
      ['cber_lot_release', 'LOT-PROTOCOL', 'data'],
      ['bla_periodic_adverse_experience', 'BLA-PAE-CASES', 'data'],
      ['bla_pas', 'BLA-PAS-356H', 'form'],
      ['rems_modification', 'REMS-MOD-REDACTION', 'mixed'],
      ['rems_assessment', 'REMS-ASSESS-RESULTS', 'data'],
    ] as const;
    for (const [id, code, contentType] of originals) {
      expect(find(id)?.components.find(part => part.code === code), `${id}:${code}`).toMatchObject({ contentType });
    }
  });

  it('does not assert unrecorded labeling, authorization, sample or FDA-decision conditions', () => {
    for (const [id, code] of [
      ['bla_pas', 'BLA-PAS-LABELING'],
      ['bla_cbe_0', 'BLA-CBE0-ALLOWANCE'],
      ['cber_master_file', 'BMF-LOA'],
      ['cber_lot_release', 'LOT-SAMPLES'],
      ['cber_lot_release', 'LOT-AUTHORITY'],
      ['bla_periodic_adverse_experience', 'BLA-PAE-ALTERNATIVE'],
    ]) {
      expect(find(id)?.components.find(part => part.code === code), `${id}:${code}`).toMatchObject({ required: false });
    }
  });

  it('keeps NDA and BLA change categories and periodic safety sources separate', () => {
    expect(find('bla_pas')?.regulatoryBasis.join(' ')).toContain('601.12');
    expect(find('bla_cbe_30')?.regulatoryBasis.join(' ')).toContain('601.12(c)');
    expect(find('bla_cbe_0')?.regulatoryBasis.join(' ')).toContain('601.12(c)(5)');
    expect(find('bla_periodic_adverse_experience')?.regulatoryBasis.join(' ')).toContain('600.80');
    expect(find('bla_pas')?.components[0].code).not.toBe(find('nda_pas')?.components[0].code);
    expect(find('cber_master_file')?.family).toBe('MASTER_FILE');
    expect(find('biological_product_deviation')?.regulatoryBasis.join(' ')).toContain('600.14');
    expect(find('cber_lot_release')?.regulatoryBasis.join(' ')).toContain('610.2');
  });
});
