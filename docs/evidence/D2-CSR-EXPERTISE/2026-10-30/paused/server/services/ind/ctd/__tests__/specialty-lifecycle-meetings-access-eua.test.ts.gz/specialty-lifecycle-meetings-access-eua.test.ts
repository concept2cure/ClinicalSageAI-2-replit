import { describe, expect, it } from 'vitest';
import { FDA_FORMAL_MEETING_TIMELINES, FDA_MEETING_PACKAGE_CORE, LIFECYCLE_DOCUMENT_TYPES } from '../lifecycle-document-types';
import { planAnnualReport } from '../../../post-approval/post-approval-knowledge';
import { fdaMeetingClassification, fdaSchedulingTarget, isRegulatoryMeetingType, REGULATORY_MEETING_TYPES } from '../../../../../shared/constants/domain/regulatory-meeting-types';

function record(id: string) {
  const result = LIFECYCLE_DOCUMENT_TYPES.find(item => item.id === id);
  expect(result, `The exact source record ${id} must exist.`).toBeDefined();
  return result!;
}

describe('exact meeting, expanded-access and medicinal EUA source records', () => {
  it.each([
    ['type_d_meeting', 'US_TYPE_D_MEETING'], ['interact_meeting', 'US_INTERACT'],
    ['expanded_access_individual', 'US_EXPANDED_ACCESS_INDIVIDUAL'],
    ['expanded_access_intermediate', 'US_EXPANDED_ACCESS_INTERMEDIATE'],
    ['expanded_access_treatment', 'US_EXPANDED_ACCESS_TREATMENT'],
    ['eua_therapeutic', 'US_EUA_THERAPEUTIC'],
  ])('%s retains its own exact registry identity and substantive source parts', (id, registryId) => {
    const source = record(id);
    expect(source.registryId).toBe(registryId);
    expect(source.agency).toBe('FDA');
    expect(source.components.length).toBeGreaterThan(4);
    expect(new Set(source.components.map(part => part.code)).size).toBe(source.components.length);
    expect(source.components.every(part => part.authoringGuidance && part.keyContentElements.length && part.generationPrompt)).toBe(true);
  });

  it.each([['type_d_meeting', 'D'], ['interact_meeting', 'INTERACT']] as const)(
    '%s reuses the existing package core and keeps attendee/evidence originals distinct', (id, type) => {
      const source = record(id);
      expect(source.timing).toContain(String(FDA_FORMAL_MEETING_TIMELINES[type].scheduleDays));
      for (const part of FDA_MEETING_PACKAGE_CORE) {
        expect(source.components).toContainEqual(expect.objectContaining({ code: part.code, title: part.title }));
      }
      expect(source.components.find(part => part.code === 'MTG-ATTEND')?.contentType).toBe('table');
      expect(source.components.find(part => part.code === 'MTG-EVIDENCE')?.contentType).toBe('data');
      expect(source.components.some(part => part.contentType === 'narrative')).toBe(true);
    },
  );

  it('individual access distinguishes the optional emergency path and actual original request form', () => {
    const source = record('expanded_access_individual');
    expect(source.components.find(part => part.code === 'EA-EMERGENCY')).toMatchObject({ required: false });
    expect(source.components.find(part => part.code === 'EA-FORM')).toMatchObject({ contentType: 'form' });
    expect(source.components.find(part => part.code === 'EA-FORM')?.authoringGuidance).toMatch(/3926/);
    expect(source.components.find(part => part.code === 'EA-SOURCE-AUTHORIZATION')?.contentType).toBe('mixed');
    expect(source.regulatoryBasis.join(' ')).toMatch(/312\.310/);
  });

  it.each([['expanded_access_intermediate', '312.315'], ['expanded_access_treatment', '312.320']])(
    '%s uses its group mechanism rather than an individual-patient form', (id, regulation) => {
      const source = record(id);
      expect(source.regulatoryBasis.join(' ')).toContain(regulation);
      const form = source.components.find(part => part.code === 'EA-FORM');
      expect(form?.contentType).toBe('form');
      expect(form?.authoringGuidance).toMatch(/1571/);
      expect(form?.authoringGuidance).toMatch(/3926.*(?:individual|not)|(?:not|individual).*3926/i);
      expect(source.components.find(part => part.code === 'EA-PROTOCOL')?.contentType).toBe('narrative');
    },
  );

  it('medicinal EUA retains declaration, original evidence and conditional vaccine scope', () => {
    const source = record('eua_therapeutic');
    expect(source.family).toBe('EUA');
    expect(source.regulatoryBasis.join(' ')).toMatch(/564|360bbb-3/);
    expect(source.description).toMatch(/drug/i);
    expect(source.description).toMatch(/biologic|biological/i);
    expect(source.components.find(part => part.code === 'EUA-CONTEXT')?.contentType).toBe('narrative');
    expect(source.components.find(part => part.code === 'EUA-ORIGINAL-EVIDENCE')?.contentType).toBe('data');
    expect(source.components.find(part => part.code === 'EUA-VACCINE')).toMatchObject({ required: false, contentType: 'mixed' });
    expect(source.ctdSectionCodes).toBeUndefined();
  });
});

describe('meeting vocabulary and postapproval planner use the applicable source', () => {
  it('Type D is focused, rather than a mandatory written-response-only format', () => {
    const typeD = REGULATORY_MEETING_TYPES.find(item => item.value === 'type_d');
    expect(typeD?.description).not.toMatch(/written-response-only|no face-to-face/i);
    expect(fdaSchedulingTarget('type_d')).toBe(FDA_FORMAL_MEETING_TIMELINES.D.scheduleDays);
  });

  it('EOP2 keeps its B(EOP) classification and timing', () => {
    expect(fdaMeetingClassification('end_of_phase_2')).toBe('B(EOP)');
    expect(fdaSchedulingTarget('end_of_phase_2')).toBe(FDA_FORMAL_MEETING_TIMELINES['B(EOP)'].scheduleDays);
  });

  it('INTERACT is an actual supported vocabulary value', () => {
    const value = 'interact';
    expect(isRegulatoryMeetingType(value)).toBe(true);
    if (isRegulatoryMeetingType(value)) expect(fdaSchedulingTarget(value)).toBe(FDA_FORMAL_MEETING_TIMELINES.INTERACT.scheduleDays);
  });

  it.each(['biologic', 'vaccine', 'cell_gene_therapy'] as const)('%s annual CMC planning does not impose NDA parts', modality => {
    const result = planAnnualReport({ modality, changes: [{ changeArea: 'equipment', description: 'Retained minor-change assessment', assertedCategory: 'Annual Report' }] });
    const text = JSON.stringify({ contents: result.annualReportContents, guidance: result.guidance, citations: result.citations });
    expect(text).toContain('601.12(d)');
    expect(text).not.toMatch(/314\.70|314\.81/);
    expect(result.annualReportContents.requiredSections.join(' ')).not.toMatch(/distribution data|nonclinical\/clinical data summaries/i);
    expect(result.guidance.join(' ')).toMatch(/601\.28/);
    expect(result.guidance.join(' ')).toMatch(/601\.70/);
    expect(result.guidance.join(' ')).toMatch(/600\.81/);
  });

  it('small-molecule NDA annual-report planning retains its existing source', () => {
    const result = planAnnualReport({ modality: 'small_molecule' });
    expect(result.annualReportContents.requiredSections.join(' ')).toMatch(/314\.81/);
    expect(result.citations.some(citation => /314\.70/.test(citation.reference))).toBe(true);
  });
});
