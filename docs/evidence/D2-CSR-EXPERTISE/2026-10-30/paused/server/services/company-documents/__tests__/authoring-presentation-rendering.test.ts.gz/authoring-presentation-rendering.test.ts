import AdmZip from 'adm-zip';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { normalizeTemplateSpec } from '../../../../shared/templates/template-spec';
import type { CompanyDocumentProfile } from '../../../../shared/company-documents';

const h = vi.hoisted(() => ({ history: vi.fn(), convert: vi.fn() }));
vi.mock('../history', () => ({ readCompanyPresentationRevision: h.history }));
vi.mock('../../pdf-converter', () => ({ convertDocxToPdf: h.convert }));
import { companyProfileHash } from '../provenance';
import { renderAuthoringExport } from '../../authoring/authoring-export';

const PROGRAM = '11111111-1111-4111-8111-111111111111';
const VARIANT = '44444444-4444-4444-8444-444444444444';
const profile: CompanyDocumentProfile = {
  version: 1, revision: 1, variantId: VARIANT, companyName: 'Retained study sponsor', address: 'Retained sponsor address',
  contact: '', registrationDetails: '', importedFrom: null, applyToReports: false,
  applyToSubmissionCorrespondence: false, legalDocuments: [],
  letterhead: normalizeTemplateSpec({ page: { size: 'a4', orientation: 'landscape', marginsInches: { top: 0.6, right: 0.7, bottom: 0.8, left: 0.9 } },
    typography: { bodyFont: 'Courier New', headingFont: 'Arial', bodySizePt: 11, heading1SizePt: 19, heading2SizePt: 16, heading3SizePt: 14, lineSpacing: 1.4, paragraphSpaceAfterPt: 9 },
    colors: { text: '234567', tableHeaderBg: 'ABCDEF', tableBorder: '456789' },
    header: { text: 'Historical sponsor header', showLogo: false }, footer: { text: 'Historical sponsor footer', showPageNumbers: true } }),
};
const origin = () => ({ version: 1, organizationId: 7, programId: PROGRAM, variantId: VARIANT,
  publishedRevision: 1, designHash: 'a'.repeat(64), companyProfileHash: companyProfileHash(profile), name: 'Reviewed sponsor format' });
const executor = { query: async () => ({ rows: [] }) };
function args() {
  return { executor, tenantId: 7,
    doc: { id: '33333333-3333-4333-8333-333333333333', title: 'Study report', client_program_id: PROGRAM,
      provenance: { source: 'seed', companyPresentation: origin() } },
    sections: [{ id: 's1', code: '1', title: 'Report section', content: '<h1>Body heading</h1><p>Retained report text.</p><table><thead><tr><th>Assessment</th></tr></thead><tbody><tr><td>Recorded result</td></tr></tbody></table>' }], signatures: [] };
}
const xml = (buffer: Buffer) => {
  const zip = new AdmZip(buffer);
  return zip.getEntries().filter(entry => /^word\/(?:document|styles|header\d+|footer\d+)\.xml$/.test(entry.entryName))
    .map(entry => entry.getData().toString()).join('\n');
};
beforeEach(() => {
  h.history.mockReset().mockResolvedValue(profile);
  h.convert.mockReset().mockResolvedValue({ pdf: Buffer.from('%PDF-test-conversion'), backend: 'libreoffice' });
});

describe('ordinary authoring uses exact retained published company presentation', () => {
  it('renders actual rich Word with retained page furniture, typography and table styles', async () => {
    const out = await renderAuthoringExport({ ...args(), format: 'docx' });
    expect(h.history).toHaveBeenCalledWith(executor, 7, 1, VARIANT);
    const document = xml(out.fileContent);
    for (const value of ['Historical sponsor header', 'Historical sponsor footer', 'Retained study sponsor', 'Retained report text.', 'landscape', 'Courier New', 'ABCDEF', '456789']) expect(document).toContain(value);
    expect(document).toContain('w:sz w:val="38"');
    expect(document).toContain('w:line="336"');
    expect(document).toContain('w:after="180"');
  });

  it('converts the same styled rich Word via the existing strict PDF path', async () => {
    await renderAuthoringExport({ ...args(), format: 'pdf' });
    expect(h.convert).toHaveBeenCalledTimes(1);
    const [word, options] = h.convert.mock.calls[0];
    expect(options).toEqual({ backend: 'libreoffice' });
    expect(xml(word)).toContain('Historical sponsor header');
    expect(xml(word)).toContain('Recorded result');
  });

  it.each(['organization', 'project', 'hash', 'revision', 'variant'] as const)('refuses a mismatched %s binding without dropping the presentation', async mode => {
    const input = args();
    if (mode === 'organization') input.tenantId = 8;
    if (mode === 'project') input.doc.client_program_id = '22222222-2222-4222-8222-222222222222';
    if (mode === 'hash') input.doc.provenance.companyPresentation.companyProfileHash = 'b'.repeat(64);
    if (mode === 'revision') input.doc.provenance.companyPresentation.publishedRevision = 2;
    if (mode === 'variant') h.history.mockResolvedValue({ ...profile, variantId: '55555555-5555-4555-8555-555555555555' });
    await expect(renderAuthoringExport({ ...input, format: 'pdf' })).rejects.toBeTruthy();
    expect(h.convert).not.toHaveBeenCalled();
  });

  it('refuses an unavailable retained revision rather than current or default styling', async () => {
    h.history.mockRejectedValue(new Error('Retained revision missing'));
    await expect(renderAuthoringExport({ ...args(), format: 'docx' })).rejects.toBeTruthy();
  });

  it('refuses ambiguous ordinary and correspondence presentation origins', async () => {
    const input = args();
    await expect(renderAuthoringExport({ ...input, format: 'docx', doc: { ...input.doc,
      provenance: { ...input.doc.provenance, companyCorrespondence: { version: 1, organizationId: 7, programId: PROGRAM,
        companyDocumentRevision: 1, companyProfileHash: companyProfileHash(profile), companyBrandingApplied: true, variantId: VARIANT, explicitSelection: true } } } })).rejects.toBeTruthy();
  });

  it('refuses required form controls that this formatting renderer cannot populate', async () => {
    const required = { ...profile, letterhead: normalizeTemplateSpec({ ...profile.letterhead,
      formFields: [{ key: 'signature', label: 'Executed signature', type: 'signature', required: true }] }) };
    h.history.mockResolvedValue(required);
    const input = args(); input.doc.provenance.companyPresentation.companyProfileHash = companyProfileHash(required);
    await expect(renderAuthoringExport({ ...input, format: 'pdf' })).rejects.toMatchObject({ code: 'COMPANY_PRESENTATION_REQUIRED_FIELDS_UNSUPPORTED' });
    expect(h.convert).not.toHaveBeenCalled();
  });

  it('preserves ordinary unformatted authoring without a selected company format', async () => {
    const input = args();
    const out = await renderAuthoringExport({ ...input, format: 'docx', doc: { ...input.doc, provenance: { source: 'seed' } } });
    expect(xml(out.fileContent)).toContain('Retained report text.');
    expect(h.history).not.toHaveBeenCalled();
  });
});
