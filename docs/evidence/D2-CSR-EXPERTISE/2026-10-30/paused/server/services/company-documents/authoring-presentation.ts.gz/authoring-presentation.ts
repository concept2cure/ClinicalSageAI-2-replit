/** Ordinary Authoring binds the existing independently published company design owner. */
import { z } from 'zod';
import { authoringCompanyPresentationSchema, type AuthoringCompanyPresentation } from '../../../shared/authoring/company-presentation';
import { canonicalRegionOf } from '../../../shared/regulatory/region-identity';
import type { CompanyDocumentProfile } from '../../../shared/company-documents';
import type { RequestSqlClient } from '../../db/requestDb';
import type { Queryable } from '../authoring/authoring-evidence';
import type { CreateContext } from '../authoring/authoring-documents';
import { authorizeAuthoringProgram } from '../authoring/authoring-program-access';
import { readPublishedCompanyVariant } from './designs';
import { readCompanyPresentationRevision } from './history';
import { companyProfileHash } from './provenance';

export class AuthoringCompanyPresentationError extends Error {
  constructor(readonly status: 400 | 403 | 404 | 409 | 503, readonly code: string, message: string) {
    super(message); this.name = 'AuthoringCompanyPresentationError';
  }
}
const fail = (code: string, message: string, status: 400 | 403 | 404 | 409 | 503 = 409): never => {
  throw new AuthoringCompanyPresentationError(status, code, message);
};
export const objectRecord = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const selectionSchema = z.object({ company_design_id: z.string().uuid(), expected_design_hash: z.string().regex(/^[a-f0-9]{64}$/) }).strict();

export function companyPresentationSelection(input: { company_design_id?: unknown; expected_design_hash?: unknown }) {
  if (input.company_design_id === undefined && input.expected_design_hash === undefined) return null;
  const selected = selectionSchema.safeParse({ company_design_id: input.company_design_id, expected_design_hash: input.expected_design_hash });
  if (!selected.success) return fail('COMPANY_PRESENTATION_SELECTION_INVALID', 'Choose an exact published company format and its current version.', 400);
  return selected.data;
}

export function requireSupportedCompanyPresentation(profile: CompanyDocumentProfile): void {
  if (profile.letterhead.formFields?.some(field => field.required)) {
    fail('COMPANY_PRESENTATION_REQUIRED_FIELDS_UNSUPPORTED', 'This company format includes required form controls that the formatting renderer cannot populate. Use the original form or choose a format without required controls.');
  }
}

async function recordedMarket(q: Queryable, tenantId: number, programId: string, documentId: string | null) {
  if (documentId) {
    const result = await q.query(`SELECT d.agency,p.primary_agency FROM c2c_documents d
      JOIN regulatory_programs p ON p.id=d.project_id AND p.organization_id=d.org_id AND p.deleted_at IS NULL
      WHERE d.id=$1 AND d.org_id=$2 AND d.project_id=$3 FOR SHARE OF d,p`, [documentId, tenantId, programId]);
    if (result.rows.length !== 1) return fail('COMPANY_PRESENTATION_FILING_CHANGED', 'The recorded filing for this company format could not be verified.');
    return canonicalRegionOf(String(result.rows[0].agency ?? '')) ?? canonicalRegionOf(String(result.rows[0].primary_agency ?? '')) ?? null;
  }
  const result = await q.query('SELECT primary_agency FROM regulatory_programs WHERE id=$1 AND organization_id=$2 AND deleted_at IS NULL FOR SHARE', [programId, tenantId]);
  if (result.rows.length !== 1) return fail('COMPANY_PRESENTATION_PROJECT_CHANGED', 'The recorded project for this company format could not be verified.');
  return canonicalRegionOf(String(result.rows[0].primary_agency ?? '')) ?? null;
}

/** Called inside the canonical create/adoption transaction before any write. */
export async function admitAuthoringCompanyPresentation(q: Queryable, ctx: CreateContext, input: {
  selection: NonNullable<ReturnType<typeof companyPresentationSelection>>; programId: string;
  filingDocumentId: string | null; locale: string;
}): Promise<AuthoringCompanyPresentation> {
  await authorizeAuthoringProgram(q, { tenantId: ctx.tenantId, actor: ctx.actor, programId: input.programId });
  const market = await recordedMarket(q, ctx.tenantId, input.programId, input.filingDocumentId);
  const result = await q.query(`SELECT id,name,sha256,published_revision,published_profile_hash FROM company_document_designs
    WHERE id=$1 AND organization_id=$2 AND state='published' FOR SHARE`, [input.selection.company_design_id, ctx.tenantId]);
  const row = result.rows[0] as Record<string, unknown> | undefined;
  if (result.rows.length !== 1 || !row || row.sha256 !== input.selection.expected_design_hash) {
    return fail('COMPANY_PRESENTATION_VERSION_CHANGED', 'The selected company format is unavailable or differs from the published version. Read the formats again before continuing.');
  }
  const profile = await readPublishedCompanyVariant(q as RequestSqlClient, ctx.tenantId, input.selection.company_design_id,
    { userId: Number(ctx.actor.id), programId: input.programId, market, language: input.locale, subsidiary: null });
  requireSupportedCompanyPresentation(profile);
  if (profile.revision !== row.published_revision || companyProfileHash(profile) !== row.published_profile_hash) {
    return fail('COMPANY_PRESENTATION_PUBLICATION_CHANGED', 'The retained company format differs from its reviewed publication.');
  }
  return authoringCompanyPresentationSchema.parse({ version: 1, organizationId: ctx.tenantId, programId: input.programId,
    variantId: profile.variantId, publishedRevision: profile.revision, designHash: row.sha256,
    companyProfileHash: row.published_profile_hash, name: row.name });
}

/** Export never substitutes today's mutable template or organization default. */
export async function readRetainedAuthoringCompanyPresentation(q: RequestSqlClient, organizationId: number,
  doc: { client_program_id?: string | null; provenance?: unknown }): Promise<CompanyDocumentProfile | null> {
  const provenance = objectRecord(doc.provenance);
  if (provenance.companyPresentation === undefined) return null;
  if (provenance.companyCorrespondence !== undefined) return fail('COMPANY_PRESENTATION_AMBIGUOUS', 'This document has conflicting company format references. Nothing was rendered.');
  const parsed = authoringCompanyPresentationSchema.safeParse(provenance.companyPresentation);
  if (!parsed.success || parsed.data.organizationId !== organizationId || parsed.data.programId !== doc.client_program_id) {
    return fail('COMPANY_PRESENTATION_UNVERIFIED', 'The saved company format reference could not be verified. Nothing was rendered.');
  }
  const origin = parsed.data;
  const profile = await readCompanyPresentationRevision(q, organizationId, origin.publishedRevision, origin.variantId);
  if (profile.variantId !== origin.variantId || profile.revision !== origin.publishedRevision || companyProfileHash(profile) !== origin.companyProfileHash) {
    return fail('COMPANY_PRESENTATION_CHANGED', 'The retained company format does not match this document. Nothing was rendered.');
  }
  requireSupportedCompanyPresentation(profile);
  return profile;
}
