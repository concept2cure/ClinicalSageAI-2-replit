import { z } from 'zod';

/** Server-authored immutable reference; a format never replaces the structural template. */
export const authoringCompanyPresentationSchema = z.object({
  version: z.literal(1), organizationId: z.number().int().positive(), programId: z.string().uuid(),
  variantId: z.string().uuid(), publishedRevision: z.number().int().positive(),
  designHash: z.string().regex(/^[a-f0-9]{64}$/), companyProfileHash: z.string().regex(/^[a-f0-9]{64}$/),
  name: z.string().min(1).max(200),
}).strict();
export type AuthoringCompanyPresentation = z.infer<typeof authoringCompanyPresentationSchema>;

export interface AuthoringCompanyPresentationRead {
  documentId: string; programId: string; version: string | null; updatedAt: string;
  status: string; presentation: AuthoringCompanyPresentation | null; canEdit: boolean;
}
export const COMPANY_PRESENTATION_LIMIT = 'Applies the published page geometry, typography, header, footer and table style to Word and PDF. Original Word layouts and form controls are not recreated; formats with required form controls are refused.';
