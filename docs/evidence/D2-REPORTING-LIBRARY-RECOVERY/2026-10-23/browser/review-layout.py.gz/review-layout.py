"""Review serialized actual reporting artifact-pane DOM against built CSS.
No live application, authentication, transport or event acceptance is asserted.
"""
import gzip
import hashlib
import html
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/ClinicalSageAI-2-replit')
PRIVATE = Path('/workspace/.codex-notes/reporting-library-recovery-20261023/browser')
PUBLIC = Path(os.environ.get('REPORTING_LAYOUT_OUTPUT', str(ROOT / 'docs/evidence/D2-REPORTING-LIBRARY-RECOVERY/2026-10-23/browser')))
PUBLIC.mkdir(parents=True, exist_ok=True)
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
styles = sorted((ROOT / 'dist/public/assets').glob('*.css'), key=lambda p: (0 if p.name.startswith('index-') else 1 if p.name.startswith('V2App-') else 2, p.name))
assert styles
css = '\n'.join(p.read_text() for p in styles)
css = re.sub(r'url\(("|\')?(/assets/[^)\"\']+)(?:"|\')?\)', lambda m: 'url("' + (ROOT / ('dist/public' + m.group(2))).as_uri() + '")', css)
report = {'scope': 'Serialized actual mounted reporting artifact pane, built CSS. No shell/events/live authenticated acceptance.', 'styles': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in styles], 'source': {}, 'captures': []}
raw_log = []
measure = '''
const pane=document.querySelector('.rc-canvas');
const recovery=[...pane.querySelectorAll('[role="alert"],[role="status"]')].find(e=>/may have|Check schedules|Check bundles/.test(e.textContent));
const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};
const buttons=[...recovery.querySelectorAll('button')].map(e=>({label:e.textContent,disabled:e.disabled,...rect(e)}));
const rr=rect(recovery);
const pass=rr.x>=0&&rr.right<=innerWidth+1&&recovery.scrollWidth<=recovery.clientWidth+1&&buttons.every(b=>b.x>=rr.x-1&&b.right<=rr.right+1)&&document.documentElement.scrollWidth<=innerWidth+1;
const out={width:innerWidth,height:innerHeight,pageScrollWidth:document.documentElement.scrollWidth,paneWidth:pane.clientWidth,paneScrollWidth:pane.scrollWidth,recovery:{...rr,clientWidth:recovery.clientWidth,scrollWidth:recovery.scrollWidth},buttons,pass};
const marker=document.createElement('pre');marker.id='layout-result';marker.hidden=true;marker.textContent=JSON.stringify(out);document.body.append(marker);
'''
for state in ['schedules-uncertain', 'schedules-review', 'bundles-uncertain']:
    source = PRIVATE / (state + '.html')
    report['source'][state] = {'sha256': digest(source)}
    with gzip.open(PUBLIC / (source.name + '.gz'), 'wb') as target:
        target.write(source.read_bytes())
    for theme in ['light', 'dark']:
        for width,height in [(1440,900),(390,844)]:
            name=f'{state}-{theme}-{width}'
            page=PRIVATE/(name+'.html')
            page.write_text('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style><body style="margin:0" class="c2c-v2 '+theme+'" data-theme="'+theme+'"><div class="rc" style="height:100vh">'+source.read_text().replace('class="rc-canvas"', 'class="rc-canvas" style="grid-column:1/-1"',1)+'</div><script>'+measure+'</script></body>')
            screenshot=PUBLIC/(name+'.png')
            command=['python3',str(PRIVATE/'capture-layout.py'),'--width',str(width),'--height',str(height),'--screenshot',str(screenshot),page.as_uri()]
            result=subprocess.run(command,capture_output=True,text=True,timeout=35)
            raw_log.append(json.dumps({'name':name,'command':command,'exit':result.returncode})+'\n'+result.stdout+'\n'+result.stderr)
            assert result.returncode==0, name
            marker=re.search(r'<pre id="layout-result" hidden="">(.*?)</pre>',result.stdout,re.S)
            assert marker, name
            metrics=json.loads(html.unescape(marker.group(1)))
            report['captures'].append({'name':name,'htmlSha256':digest(page),'pngSha256':digest(screenshot),**metrics})
(PUBLIC/'component-layout.json').write_text(json.dumps(report,indent=2)+'\n')
with gzip.open(PUBLIC/'chromium.raw.log.gz','wb') as target:
    target.write('\n'.join(raw_log).encode())
print(json.dumps({'captures':len(report['captures']),'passed':sum(c['pass'] for c in report['captures']),'failures':[c['name'] for c in report['captures'] if not c['pass']]}))
