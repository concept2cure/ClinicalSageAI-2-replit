// @vitest-environment jsdom
// Component capture only: fixture transport, actual mounted reporting canvas.
import React from 'react';
import { writeFileSync } from 'node:fs';
import { cleanup, fireEvent, screen } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
const apiRequest = vi.hoisted(() => vi.fn());
vi.mock('@/lib/queryClient', async original => ({ ...(await original<typeof import('@/lib/queryClient')>()), apiRequest }));
vi.mock('@/services/portal/authService', async original => {
  const actual = await original<typeof import('@/services/portal/authService')>();
  return { ...actual, useAuthUser: () => actual.authService.getUser() };
});
import { authService } from '@/services/portal/authService';
import { SUBS, openTab, renderCanvas, route } from './_insights-library-fixture';
const actor = { id: '7', organizationId: '1', displayName: 'Reporting Reader', email: 'reader@example.test', permissions: ['governed:write', 'report:finalize'], mfaEnabled: false };
const unknownResponse = () => ({ ok: false, status: 503, json: async () => ({ success: false, error: { code: 'REPORT_BUNDLE_OUTCOME_UNKNOWN', message: 'Outcome unknown' }, recordingOutcome: 'unconfirmed', retryAllowed: false }) }) as Response;
beforeEach(() => {
  apiRequest.mockReset().mockImplementation(async (method: string, url: string) => method === 'POST' ? unknownResponse() : route(url));
  authService.setToken('fixture-session', actor, 'fixture-refresh', 3600);
  delete window.C2C_PROJECT;
});
afterEach(() => { cleanup(); authService.endSession(null); delete window.C2C_PROJECT; });
function capture(name: string) {
  const source = document.querySelector('.rc-canvas');
  expect(source).not.toBeNull();
  const clone = source!.cloneNode(true) as HTMLElement;
  source!.querySelectorAll('input,select,textarea').forEach((element, index) => {
    const target = clone.querySelectorAll('input,select,textarea')[index];
    if (element instanceof HTMLSelectElement) Array.from(target.querySelectorAll('option')).forEach(option => option.toggleAttribute('selected', option.value === element.value));
    if (element instanceof HTMLInputElement) { target.setAttribute('value', element.value); target.toggleAttribute('checked', element.checked); }
    if (element instanceof HTMLTextAreaElement) target.textContent = element.value;
  });
  writeFileSync(`/workspace/.codex-notes/reporting-library-recovery-20261023/browser/${name}.html`, clone.outerHTML);
}
it('captures the mounted schedule recovery and review controls', async () => {
  await renderCanvas(); await openTab(/Schedules/);
  fireEvent.click(await screen.findByRole('button', { name: /New schedule/ }));
  fireEvent.change(screen.getByLabelText('Report'), { target: { value: SUBS[0].reportTypeId } });
  fireEvent.change(screen.getByLabelText('Timezone'), { target: { value: 'UTC' } });
  fireEvent.click(screen.getByRole('button', { name: 'Save schedule' }));
  await screen.findByRole('button', { name: 'Check schedules' });
  capture('schedules-uncertain');
  fireEvent.click(screen.getByRole('button', { name: 'Check schedules' }));
  await screen.findByRole('button', { name: /Reviewed schedules.*allow another request/i });
  capture('schedules-review');
});
it('captures the mounted bundle recovery controls', async () => {
  await renderCanvas(); await openTab(/Run history/);
  fireEvent.click((await screen.findAllByRole('checkbox'))[0]);
  fireEvent.click(await screen.findByRole('button', { name: /Bundle 1 report/ }));
  fireEvent.change(await screen.findByLabelText('Bundle name'), { target: { value: 'Reviewed inspection pack' } });
  fireEvent.click(screen.getByRole('button', { name: 'Create bundle' }));
  await screen.findByRole('button', { name: 'Check bundles' });
  capture('bundles-uncertain');
});
