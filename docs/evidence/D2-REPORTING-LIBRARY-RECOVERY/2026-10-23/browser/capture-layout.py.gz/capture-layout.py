"""Capture one serialized artifact-pane file with the installed browser automation path."""
import argparse
import asyncio
import importlib.metadata
import json
import sys
from pathlib import Path
from urllib.parse import urlparse, unquote
from playwright.async_api import async_playwright

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--height', type=int, required=True)
    parser.add_argument('--screenshot', required=True)
    parser.add_argument('url')
    args = parser.parse_args()
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
            args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--no-proxy-server'], timeout=12000)
        try:
            page = await browser.new_page(viewport={'width': args.width, 'height': args.height}, device_scale_factor=1)
            parsed = urlparse(args.url)
            assert parsed.scheme == 'file'
            source = Path(unquote(parsed.path)).read_text()
            await page.set_content(source, wait_until='load', timeout=10000)
            await page.evaluate('document.fonts.ready')
            # Measure the same source script after the local font/layout load settles.
            await page.evaluate("() => {\n                const source = document.scripts[document.scripts.length - 1].textContent;\n                document.getElementById('layout-result')?.remove();\n                new Function(source)();\n            }")
            await page.screenshot(path=args.screenshot, timeout=8000)
            print(await page.content())
            print(json.dumps({'browser': browser.version, 'playwright': importlib.metadata.version('playwright'),
                'viewport': {'width': args.width, 'height': args.height}, 'fonts': await page.evaluate('document.fonts.status')}), file=sys.stderr)
        finally:
            await browser.close()

asyncio.run(asyncio.wait_for(main(), timeout=30))
