import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-proxy-server'],timeout=12000)
  try:
   page=await browser.new_page(viewport={'width':390,'height':844})
   await page.set_content('<!doctype html><h1 id="probe">browser-probe</h1>',timeout=5000)
   await page.screenshot(path='/workspace/.codex-notes/reporting-library-recovery-20261023/browser/playwright-probe.png',timeout=5000)
   print(json.dumps({'title':await page.locator('#probe').inner_text(),'screenshot':True}))
  finally:await browser.close()
asyncio.run(asyncio.wait_for(main(),timeout=22))
