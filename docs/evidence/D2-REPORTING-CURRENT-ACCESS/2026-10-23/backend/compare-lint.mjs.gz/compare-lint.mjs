import { ESLint } from '/workspace/ClinicalSageAI-2-replit/node_modules/eslint/lib/api.js';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
const root='/workspace/ClinicalSageAI-2-replit';
const privateRoot='/workspace/.codex-notes/reporting-current-access-20261023/backend';
const current=JSON.parse(fs.readFileSync(`${privateRoot}/eslint.json`,'utf8'));
const base=execFileSync('git',['rev-parse','dd749f3e5'],{cwd:root,encoding:'utf8'}).trim();
const eslint=new ESLint({cwd:root});
const rows=[];
for (const after of current) {
  const relative=after.filePath.slice(root.length+1);
  let before=[];
  try { before=await eslint.lintText(execFileSync('git',['show',`${base}:${relative}`],{cwd:root,encoding:'utf8',stdio:['ignore','pipe','ignore']}),{filePath:after.filePath}); }
  catch(error) { if(error.status!==128) throw error; }
  rows.push({file:relative,beforeWarnings:before.reduce((n,r)=>n+r.warningCount,0),afterWarnings:after.warningCount,beforeErrors:before.reduce((n,r)=>n+r.errorCount,0),afterErrors:after.errorCount});
}
const report={base,scope:'Ten changed backend source/test files; same ESLint config and original file paths for both versions.',rows,beforeWarnings:rows.reduce((n,r)=>n+r.beforeWarnings,0),afterWarnings:rows.reduce((n,r)=>n+r.afterWarnings,0),afterErrors:rows.reduce((n,r)=>n+r.afterErrors,0)};
report.netWarnings=report.afterWarnings-report.beforeWarnings;
fs.writeFileSync(`${privateRoot}/warning-comparison.json`,JSON.stringify(report,null,2)+'\n');
process.stdout.write(JSON.stringify(report,null,2)+'\n');
if(report.afterErrors||report.netWarnings>0) process.exitCode=1;
