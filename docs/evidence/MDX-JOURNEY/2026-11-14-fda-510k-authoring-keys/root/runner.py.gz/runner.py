import gzip,hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/workspace/ClinicalSageAI-2-replit')
base=repo/'docs/evidence/MDX-JOURNEY/2026-11-14-fda-510k-authoring-keys/root';base.mkdir(exist_ok=True)
mode=sys.argv[1]
env=dict(os.environ,PATH='/workspace/.tooling/node_modules/node/bin:'+os.environ['PATH'],TYPECHECK_HEAP_MB='12288');env.pop('GH_TOKEN',None)
if mode.startswith('typecheck'): command=['node','scripts/ci/typecheck-no-regression.mjs','--incremental']
elif mode.startswith('build'): command=['npm','run','build'];env['NODE_OPTIONS']='--max-old-space-size=6144'
elif mode.startswith('push'):
 ready=subprocess.run(['git','merge-base','--is-ancestor','origin/concept2cure-v2','HEAD'],cwd=repo)
 if ready.returncode:
  print('Canonical advanced beyond this checked HEAD. Integrate before starting the normal push; no push attempted.',flush=True)
  raise SystemExit(75)
 command=['git','push','origin','concept2cure-v2']
elif mode.startswith('integration'):
 command=['node','node_modules/vitest/vitest.mjs','run','server/routes/c2c/__tests__/projects-create-regional-devices.test.ts','tests/schema-contract/fda-510k-authoring-keys.contract.test.ts','--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile='+str(base/'integration-tests.json')]
else:raise ValueError(mode)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def pin():
 paths=git('ls-files').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 roots=('client/','server/','shared/','agents/','scripts/','migrations/','db/migrations/','tests/')
 configs={'package.json','package-lock.json','tsconfig.json','vite.config.ts','vitest.config.ts','.typecheck-baseline.json'}
 names=sorted({p for p in paths if (p.startswith(roots) and p.endswith(('.ts','.tsx','.js','.mjs','.json','.css','.html','.sql'))) or p in configs})
 return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in names if (repo/p).is_file()}
before=pin();head=git('rev-parse','HEAD');start=time.time();payload=(json.dumps(before,sort_keys=True,indent=2)+'\n').encode();snapshot=f'{mode}-source-pins.json.gz';(base/snapshot).write_bytes(gzip.compress(payload,mtime=0))
(base/f'{mode}-start.json').write_text(json.dumps({'head':head,'startedAt':start,'command':command,'sourcePins':snapshot,'sourceSnapshotSha256':hashlib.sha256(payload).hexdigest(),'declaredSourceFiles':len(before),'nodeVersion':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'TYPECHECK_HEAP_MB':env['TYPECHECK_HEAP_MB']},indent=2)+'\n')
raw=Path('/workspace/scratch/fda510k-'+mode+'.raw.log')
with raw.open('wb') as stream:result=subprocess.run(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
after=pin();(base/f'{mode}.log.gz').write_bytes(gzip.compress(raw.read_bytes(),mtime=0));summary={'head':head,'finishedHead':git('rev-parse','HEAD'),'command':command,'exitCode':result.returncode,'elapsedSeconds':round(time.time()-start,3),'sourceStable':before==after,'sourceChanges':sorted(p for p in set(before)|set(after) if before.get(p)!=after.get(p)),'declaredSourceFiles':len(before),'sourceSnapshotSha256':hashlib.sha256(payload).hexdigest(),'sourcePins':snapshot}
if mode.startswith('push'):
 try:summary['remoteHead']=subprocess.check_output(['git','ls-remote','origin','refs/heads/concept2cure-v2'],cwd=repo,env=env,text=True).split()[0]
 except subprocess.CalledProcessError:summary['remoteHead']=None
(base/f'{mode}.json').write_text(json.dumps(summary,indent=2)+'\n');(base/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print(json.dumps(summary),flush=True)
raise SystemExit(0 if result.returncode==0 and before==after and head==summary['finishedHead'] else 1)
