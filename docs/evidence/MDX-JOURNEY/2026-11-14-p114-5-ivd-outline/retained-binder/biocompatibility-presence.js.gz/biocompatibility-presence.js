function BCPresence() {//BC presence
	
	if (ApplicationType.ATRadioButton100.rawValue == 1) {//if FDA
		if (DeviceDescription.GeneralCharacteristics.DDDropDownList120.rawValue == "2") {//no
		  	Biocompatibility.PatientMaterials.presence = "hidden";
		  	Biocompatibility.BiocompatibilityDocs.presence = "hidden";
		  	Biocompatibility.BCText1.rawValue = "Based on the answer provided in the Device Description section, no biocompatibility information is needed.";
		}//elseif
		else {//null or yes
			if (ApplicationType.USA.ATCheckboxGroup117.ATCheckBox117e.rawValue == "1") {//BC modified
				Biocompatibility.PatientMaterials.presence = "visible";
		  		Biocompatibility.BiocompatibilityDocs.presence = "visible";
			  	Biocompatibility.BCText1.rawValue = "Based on the answer provided in the Device Description section, biocompatibility information is needed.";
			}//if
			else {//not modified
			  	Biocompatibility.PatientMaterials.presence = "hidden";
			  	Biocompatibility.BiocompatibilityDocs.presence = "hidden";
			  	Biocompatibility.BCText1.rawValue = "Based on the answer provided in the Application/Submission Type section, no biocompatibility information is needed.";
			}//else
		}//else
	}//if
	else {//IMDRF
		if (DeviceDescription.GeneralCharacteristics.DDDropDownList120.rawValue == "2") {//no
		  	Biocompatibility.BiocompatibilityDocs.presence = "hidden";
		  	Biocompatibility.BCText1.rawValue = "Based on the answer provided in the Device Description section, no biocompatibility information is needed.";
		}//elseif
		else {//null or yes
			Biocompatibility.BiocompatibilityDocs.presence = "visible";
			  Biocompatibility.BCText1.rawValue = "Based on the answer provided in the Device Description section, biocompatibility information is needed.";
		}//else
	}//else
	
	Biocompatibility.variables.Functions.Validation(); //ensure indicators are set
}//function

