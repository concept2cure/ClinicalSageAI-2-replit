if (AdministrativeDocumentation.SignedCheckBox.rawValue == 1) {//if signed at all
    app.alert("This question cannot be modified while this eSTAR is electronically signed. Please ask the original signatory to right-click and clear the signature first (e.g. in the T&A Statement) before you modify your answer to this question.");
    this.rawValue = Verification.prevValue.rawValue;
}//if
else{
	//default indicator
	this.ATYesIndicator110.border.fill.color.value = BlankIndicator.value;
	this.ATNoIndicator110.border.fill.color.value = IncompleteIndicator.value;
	this.ATYesIndicator110.assist.toolTip.value = QuestionIncomplete.value;
	this.ATNoIndicator110.assist.toolTip.value = QuestionIncomplete.value;
	
	//change title page status 
	GeneralIntroduction.GIHeading102.presence = "visible";
	GeneralIntroduction.GIText102.presence = "visible";
	GeneralIntroduction.GIHeading103.presence = "hidden";
	
	//default introduction
	this.ShowK.presence = "hidden";
	this.ATTextK.presence = "hidden";
	this.ATTextK2.presence = "hidden";
	this.ShowD.presence = "hidden";
	this.ATTextD.presence = "hidden";
	this.ShowP.presence = "hidden";
	this.ATTextP.presence = "hidden";	
	this.ShowKType.presence = "hidden";
	this.ATTextKType.presence = "hidden";
	this.ATTextKType2.presence = "hidden";
	this.ShowPType.presence = "hidden";
	this.ATTextPType.presence = "hidden";
	
	//type default
	this.ATYesIndicator114.presence = "hidden";
	this.ATNoIndicator114.presence = "hidden";
	this.ATText114.presence = "hidden";
	this.ATRadioButton114.presence = "hidden";
	if (xfa.host.getFocus().name != "ImportData") {//null 510(k) type
		this.ATRadioButton114.ATRadioButton114a.rawValue = null;
		this.ATRadioButton114.ATRadioButton114b.rawValue = null;
		this.ATRadioButton114.ATRadioButton114c.rawValue = null;
		this.ATRadioButton114.ATRadioButton114d.rawValue = null;
		this.ATRadioButton114.ATRadioButton114e.rawValue = null;
		//this.ATRadioButton114.ATRadioButton114f.rawValue = null;
		this.ATRadioButton114.ATRadioButton114g.rawValue = null;
		this.ATRadioButton114.ATRadioButton114h.rawValue = null;
		this.ATRadioButton114.ATRadioButton114i.rawValue = null;		
	}//if not importing data	
	this.ATYesIndicator115.presence = "hidden";
	this.ATNoIndicator115.presence = "hidden";
	this.ATText115.presence = "hidden";
	this.ATRadioButton115.presence = "hidden";
	if (xfa.host.getFocus().name != "ImportData") {
    	this.ATRadioButton115.ATRadioButton116.rawValue = null;
        this.ATRadioButton115.ATRadioButton117.rawValue = null;
        this.ATRadioButton115.ATRadioButton118.rawValue = null;
    }//if not importing data
	
	//default document subtype
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton131.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.presence = "hidden";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.caption.font.fill.color.value = "0,0,0";
	if (xfa.host.getFocus().name != "ImportData"){ 
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton131.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.rawValue = null;	
    }//if
	
	//default question presences for FDA submission types
	AdministrativeInformation.RelatedSubmissions.NSE510k.presence = "hidden";
	DeviceDescription.GeneralConsiderations.presence = "hidden";
	DeviceDescription.GeneralCharacteristics.DDYesIndicator401.presence = "hidden";//HC-only Q
	DeviceDescription.GeneralCharacteristics.DDNoIndicator401.presence 	= "hidden";//HC-only Q
	DeviceDescription.GeneralCharacteristics.DDDropDownList401.presence= "hidden";//HC-only Q
	DeviceDescription.GeneralCharacteristics.DDTips401.presence= "hidden";//HC-only Q
	DeviceDescription.Description.DDText401.presence = "hidden"; //510(k) dev descrip summary
	DeviceDescription.Guidance.presence = "hidden";
	Classification.presence = "hidden";
	Classification.USAKnownClassification.presence = "hidden";
	Classification.USAProposedClassification.presence = "hidden";
	MarketingHistory.presence = "hidden";
	PredicatesSE.presence = "hidden";
	RiskManagement.presence = "hidden";
	Labeling.Guidance.presence = "hidden";
	ReprocSter.Guidance.presence = "hidden";
	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator210.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator210.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList210.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips210.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator211.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator211.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment211.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText211.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips211.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator212.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator212.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText212.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField212.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator220.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator220.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList220.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips220.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator221.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator221.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment221.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText221.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips221.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator222.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator222.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText222.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField222.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator230.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator230.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList230.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips230.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator231.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator231.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment231.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText231.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips231.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator232.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator232.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText232.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField232.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator250.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator250.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList250.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips250.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator251.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator251.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment251.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText251.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips251.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator252.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator252.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText252.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField252.presence = "hidden";	 
	PerformanceTesting.BenchTesting.presence= "hidden";
	PerformanceTesting.ClinicalStudies.PTYesIndicator600.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTNoIndicator600.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTDropDownList600.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTTips600.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTYesIndicator620.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTNoIndicator620.presence = "hidden";	
	PerformanceTesting.ClinicalStudies.PTAddAttachment620.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTText620.presence = "hidden";
	PerformanceTesting.ClinicalStudies.PTTips620.presence = "hidden";		
	PerformanceTesting.ClinicalStudies.GeneralClinical.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator620.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator620.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTextField620.presence= "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator640.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator640.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment640.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText640.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips640.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator650.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator650.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment650.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText650.presence = "hidden";
	PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips650.presence = "hidden";
	PerformanceTesting.PMNSummaries.presence = "hidden";
	PerformanceTesting.Guidance.presence = "hidden";
	QualityManagement.presence = "hidden";
	PAS.presence = "hidden";
	//hide SSED question in Admin section
	AdministrativeDocumentation.ADYesIndicator807.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator807.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment807.presence = "hidden";
	AdministrativeDocumentation.ADText807.presence = "hidden";
	AdministrativeDocumentation.ADTips807.presence = "hidden";
	//hide EA Environmental Assessment questions in Admin section 
	AdministrativeDocumentation.ADYesIndicator809.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator809.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment809.presence = "hidden";
	AdministrativeDocumentation.ADText809.presence = "hidden";
	AdministrativeDocumentation.ADTips809.presence = "hidden"; 
	//statement of conformance for 30-Day disabled
	AdministrativeDocumentation.ADYesIndicator812.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator812.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment812.presence = "hidden";
	AdministrativeDocumentation.ADText812.presence = "hidden";
	AdministrativeDocumentation.ADTips812.presence = "hidden";	
	AdministrativeDocumentation.ADYesIndicator822.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator822.presence = "hidden";
	AdministrativeDocumentation.ADDropDownList822.presence = "hidden";
	AdministrativeDocumentation.ADTips822.presence = "hidden";
	AdministrativeDocumentation.ADYesIndicator832.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator832.presence = "hidden";
	AdministrativeDocumentation.ADDropDownList832.presence = "hidden";
	AdministrativeDocumentation.ADTips832.presence = "hidden";
	//515A/360e ped pop
	AdministrativeDocumentation.ADYesIndicator845.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator845.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment845.presence = "hidden";
	AdministrativeDocumentation.ADText845.presence = "hidden";
	AdministrativeDocumentation.ADTips845.presence = "hidden";
	//ped checkbox group
	AdministrativeDocumentation.ADYesIndicator855.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator855.presence = "hidden";
	AdministrativeDocumentation.ADCheckboxGroup855.presence = "hidden";
	AdministrativeDocumentation.ADTips855.presence = "hidden";	
	AdministrativeDocumentation.ADText860.presence = "hidden";
	AdministrativeDocumentation.ADYesIndicator870.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator870.presence = "hidden";
	AdministrativeDocumentation.ADText870.presence = "hidden";
	AdministrativeDocumentation.ADDropDownList870.presence = "hidden";
	AdministrativeDocumentation.ADYesIndicator880.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator880.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment880.presence = "hidden";
	AdministrativeDocumentation.ADText880.presence = "hidden";
	AdministrativeDocumentation.ADYesIndicator890.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator890.presence = "hidden";
	AdministrativeDocumentation.ADText890.presence = "hidden";
	AdministrativeDocumentation.ADDropDownList890.presence = "hidden";
	AdministrativeDocumentation.ADTips890.presence = "hidden";	
	AdministrativeDocumentation.ADYesIndicator900.presence = "hidden";
	AdministrativeDocumentation.ADNoIndicator900.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment900.presence = "hidden";
	AdministrativeDocumentation.ADText900.presence = "hidden";	
	AdministrativeDocumentation.TAStatement.presence = "hidden";
	AdministrativeDocumentation.PMNSummary.presence = "hidden";
	
	//default verification lists
	Verification.VRText1.rawValue = "";
	Verification.VRText2.rawValue = "";
	
	//set visibility of subforms that need to appear during data import
	if (xfa.host.getFocus() != null) {
	    if (xfa.host.getFocus().name == "ImportData") {
	        if (AdministrativeInformation.CorrespondentInformation.ADTextField330.rawValue != null){//if there is a correspondent, based on the existence of a first name 
	        AdministrativeInformation.CorrespondentInformation.presence = "visible"; 
	        }//if
	    }//if
	}//if
	
	//Unhide subforms and questions present in all FDA premarket types 
	if (xfa.host.getFocus().name.substr(0,15) != "ATRadioButton10"&& ApplicationType.ATRadioButton100.rawValue == 1){//only run validation functions if the region radiobutton didn't call this	
		CoverLetter.presence = "visible";
		AdministrativeInformation.presence = "visible";
		AdministrativeInformation.ApplicantInformation.presence = "visible";
		AdministrativeInformation.RelatedSubmissions.presence = "visible";
		AdministrativeInformation.Standards.presence = "visible";
		DeviceDescription.presence = "visible";
		DeviceDescription.Devices.presence = "visible";
		DeviceDescription.Devices.AddDevice.presence = "visible";
		DeviceDescription.Devices.DDText105.presence = "visible";
		DeviceDescription.Devices.Device.presence = "visible";
		DeviceDescription.AssayInstrumentInfo.presence="visible"; //unique for IVD eSTAR
		DeviceDescription.GeneralCharacteristics.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDYesIndicator110.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDNoIndicator110.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDDropDownList110.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDTips110.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDYesIndicator210.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDNoIndicator210.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDCheckboxGroup210.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDTips210.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDYesIndicator230.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDNoIndicator230.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDDropDownList230.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDTips230.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDYesIndicator251.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDNoIndicator251.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDCheckboxGroup251.presence = "visible";
        DeviceDescription.GeneralCharacteristics.DDTips251.presence = "visible";		
		DeviceDescription.Description.presence = "visible";
		DeviceDescription.ComponentsAccessories.presence = "visible";
		IndicationsForUse.presence = "visible";
		Labeling.presence = "visible";
		Labeling.GeneralLabeling.presence = "visible";
		Labeling.Packaging.presence = "visible";
		Labeling.Instructions.presence = "visible";
		Labeling.OtherLabeling.presence = "visible";
		Labeling.SpecificLabeling.presence = "visible";
		ReprocSter.presence = "visible";
		ReprocSter.Reprocessing.presence = "visible";
		ReprocSter.Sterility.presence = "visible";
		ReprocSter.ShelfLife.presence = "visible";
		ReprocSter.ReprocSterDocs.presence = "visible";
		Biocompatibility.presence = "visible";
		Biocompatibility.PatientMaterials.presence = "visible";
		Biocompatibility.BiocompatibilityDocs.presence = "visible";
		SoftwareCyber.presence = "visible";
		SoftwareCyber.Software.presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.presence = "visible";
		SoftwareCyber.Software.SoftwareDocLevel.presence = "visible";
		SoftwareCyber.Cybersecurity.presence = "visible";
       	SoftwareCyber.Cybersecurity.CSYesIndicator412.presence = "visible";
        SoftwareCyber.Cybersecurity.CSNoIndicator412.presence = "visible";
        SoftwareCyber.Cybersecurity.CSText412.presence = "visible";
       	SoftwareCyber.Cybersecurity.CSDropDownList412.presence = "visible";
        SoftwareCyber.Cybersecurity.CSTips412.presence = "visible";
    	SoftwareCyber.Cybersecurity.CSDropDownList412.execEvent("exit"); //run cyber mods question to determine presence of cyber subforms		
		SoftwareCyber.Interoperability.presence = "visible";
        SoftwareCyber.Interoperability.CSYesIndicator240.presence = "visible";
        SoftwareCyber.Interoperability.CSNoIndicator240.presence = "visible";
        SoftwareCyber.Interoperability.CSDropDownList240.presence = "visible";
        SoftwareCyber.Interoperability.CSTips240.presence = "visible";
        SoftwareCyber.Interoperability.CSDropDownList240.execEvent("exit"); //Interop, to show electronic interfaces
        for (var i = SoftwareCyber.Interoperability.ElectronicInterface.instanceManager.count; i > 0; i--) {//reveal FDA interop default questions
        //Reveal instance content. Don't need to do this when importing, since is present by default.
        //if (xfa.host.getFocus() != null) {//if not importing data, getfocus will be null if not
              //if (xfa.host.getFocus().name != "ImportData") {
              		for (var j = 0; j < SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.length; j++) {//cycle through parent's nodes 
                         if (SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).className == "draw" || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).className == "field") {//if this is NOT an attachment subform, and it is a draw or field
                             if (SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name == "YesIndicator" || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name == "NoIndicator" || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name.indexOf("242") > 0 || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name.indexOf("245") > 0 || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name.indexOf("250") > 0) {//reveal everything through 250
                                 SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).presence = "visible";
                             }//if                                                  
                        }//if
                    }//for
                    SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").CSDropDownList250.execEvent("exit"); //Interop first cascade question, shows proper content after 250
             //}//if
        //}//if
        }//for		
        EMCWireless.presence = "visible";
		EMCWireless.EMC.presence = "visible";
		EMCWireless.Wireless.presence = "visible";
		EMCWireless.EMCEMTSummary.presence = "visible";
		EMCWireless.EMCEMTDocs.presence = "visible";
		PerformanceTesting.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator120.presence = "visible";//since HC hides this item, need to display this in FDA
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator120.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList120.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips120.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator185.presence = "visible";//since HC hides this item, need to display this in FDA
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator185.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList185.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips185.presence = "visible";		
		PerformanceTesting.ComparisonStudies.presence= "visible";
		PerformanceTesting.ClinicalStudies.AssayClinical.presence= "visible";
		PerformanceTesting.AnimalTesting.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator660.presence = "visible"; // # is 550 in nIVD eSTAR
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator660.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText660.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips660.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTextField660.presence = "visible";
		PerformanceTesting.ClinicalStudies.RWD.presence = "visible";
		PerformanceTesting.HumanFactors.presence = "visible";	
		PerformanceTesting.PROPPI.presence = "visible";
		PerformanceTesting.CDR.presence = "visible";	
		PerformanceTesting.PTYesIndicator900.presence="hidden";
		PerformanceTesting.PTNoIndicator900.presence="hidden";
		PerformanceTesting.PTAddAttachment900.presence="hidden";
		PerformanceTesting.PTText900.presence="hidden";		
		PerformanceTesting.PTTips900.presence="hidden";
		PerformanceTesting.PTAttachment900.presence="hidden";
		PerformanceTesting.ClinicalStudies.GeneralClinical.presence = "hidden";	
		References.presence = "visible";
		AdministrativeDocumentation.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator822.presence = "visible";//820 and 830 presence uniquie for IVD eSTAR
		AdministrativeDocumentation.ADNoIndicator822.presence = "visible";
		AdministrativeDocumentation.ADDropDownList822.presence = "visible";
		AdministrativeDocumentation.ADTips822.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator832.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator832.presence = "visible";
		AdministrativeDocumentation.ADDropDownList832.presence = "visible";
		AdministrativeDocumentation.ADTips832.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator920.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator920.presence = "visible";
		AdministrativeDocumentation.ADTextField920.presence = "visible";
		AdministrativeDocumentation.ADTips920.presence = "visible";
		AdministrativeDocumentation.ShowUF.presence = "visible";
		Verification.presence = "visible";
	}//if
	
	if (this.rawValue == "1"){ //510(k)
		//set indicator
		this.ATYesIndicator110.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator110.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator110.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator110.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowK.presence = "visible";
		this.ShowKType.presence = "visible";
		
		//show type radiobutton
		this.ATYesIndicator115.presence = "visible";
		this.ATNoIndicator115.presence = "visible";
		this.ATText115.presence = "visible";
		this.ATRadioButton115.presence = "visible";
			
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected
		
		//set text		
	  	Labeling.LBText1.rawValue = "You must submit proposed labels, labeling, and advertisements sufficient to describe the device, its intended use, and the directions for its use. Where applicable, photographs or engineering drawings should be supplied (21 CFR 807.87(e)). We also strongly recommend you consult standard AAMI ANSI ES60601-1 Section 7 for applicable labeling that may be important for your device if it is electrical (consult ISO 14708-1 instead for implantable components).";
		ReprocSter.ShelfLife.SLText130.rawValue = "Provide a summary of the methods used to support the sterility and performance of the device over its proposed shelf-life. Alternatively, provide a rationale for why testing to establish shelf-life is not applicable.";
		References.RFDropDownList110.caption.value.text = "Is literature referenced in the submission?";
		References.RFText120.rawValue = "Please add legible reprints or a summary of each article in English.";
		References.RFText130.rawValue = "Please include a discussion of how each article is applicable to support the submission.";
		References.RFTextField130.assist.toolTip.value = "Please include a discussion of how each article is applicable to support the submission.";	
		
		//hide questions, done here rather than above since this is done in an FDA specific subform not shared by other jurisdictions, and so this doesn't need to be run when jurisdiction is changes
		ReprocSter.Sterility.STYesIndicator107.presence = "hidden";
		ReprocSter.Sterility.STNoIndicator107.presence = "hidden";
		ReprocSter.Sterility.STAddAttachment107.presence = "hidden";
		ReprocSter.Sterility.STText107.presence = "hidden";
		ReprocSter.Sterility.STTips107.presence = "hidden";
		
	  	//unhide subforms and questions for 510(k)
	  	DeviceDescription.Description.DDText401.presence = "visible";
		DeviceDescription.Guidance.presence = "visible";
		Classification.presence = "visible";
		Classification.USAKnownClassification.presence = "visible";
		Classification.USAProposedClassification.presence = "hidden";
		RiskManagement.presence = "hidden";
		PredicatesSE.presence = "visible";
		Labeling.Guidance.presence = "visible";
		ReprocSter.Sterility.STYesIndicator105.presence = "visible";
		ReprocSter.Sterility.STNoIndicator105.presence = "visible";
		ReprocSter.Sterility.STDropDownList105.presence = "visible";
		ReprocSter.Sterility.STDropDownList105.execEvent("exit"); //to reveal instances
		ReprocSter.Sterility.STTips105.presence = "visible";			
		ReprocSter.Guidance.presence = "visible";
		PerformanceTesting.PMNSummaries.presence = "visible";
		PerformanceTesting.Guidance.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator620.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator620.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTextField620.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips650.presence = "visible";
		PerformanceTesting.PTYesIndicator900.presence="hidden";
		PerformanceTesting.PTNoIndicator900.presence="hidden";
		PerformanceTesting.PTAddAttachment900.presence="hidden";
		PerformanceTesting.PTText900.presence="hidden";		
		PerformanceTesting.PTTips900.presence="hidden";
		PerformanceTesting.PTAttachment900.presence="hidden";
		References.RFDropDownList110.caption.value.text = "Is literature referenced in the submission?";
		AdministrativeDocumentation.ADText860.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator870.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator870.presence = "visible";
		AdministrativeDocumentation.ADText870.presence = "visible";
		AdministrativeDocumentation.ADDropDownList870.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator890.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator890.presence = "visible";
		AdministrativeDocumentation.ADText890.presence = "visible";
		AdministrativeDocumentation.ADDropDownList890.presence = "visible";
		AdministrativeDocumentation.ADTips890.presence = "visible";	
		
		//run functions that control existence of questions
		/*PerformanceTesting.PTDropDownList130.execEvent("exit"); //controls clinical forms */
		Classification.USAKnownClassification.DDDropDownList517.execEvent("exit"); //controls class III summary form
		AdministrativeDocumentation.ADDropDownList870.execEvent("exit"); //TA statement
		AdministrativeDocumentation.ADDropDownList890.execEvent("exit"); //510(k) summary
		DeviceDescription.ComponentsAccessories.DDDropDownList430.execEvent("exit"); //component
	}//if
	if (this.rawValue == "2"){ //de novo
	
		//set indicator
		this.ATYesIndicator110.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator110.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator110.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator110.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowD.presence = "visible";
	
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected
		
		//set text
		RiskManagement.BenefitRisk.BRText100.h = "0.9in";
        RiskManagement.BenefitRisk.BRText100.rawValue = "Provide a discussion demonstrating that, when subject to general controls or general and special controls, the probable benefits to health from use of the device outweigh any probable injury or illness from such use. Please also address how the data and information in the De Novo request constitute valid scientific evidence within the meaning of 21 CFR 860.7(c).";
        RiskManagement.BenefitRisk.BRTips100.maxH = "0.9in";
        RiskManagement.BenefitRisk.BRTips100.minH = "0.9in";
        //RiskManagement.BenefitRisk.BRTips100.margin.topInset = "0.4in";
	  	Labeling.LBText1.rawValue = "You must submit proposed labels, labeling, and advertisements sufficient to describe the device, its intended use, and the directions for its use (see 21 CFR parts 801 and 809, as applicable). Where applicable, photographs or engineering drawings should be supplied. We also strongly recommend you consult standard AAMI ANSI ES60601-1 Section 7 for applicable labeling that may be important for your device if it is electrical (consult ISO 14708-1 instead for implantable components).";
	  	ReprocSter.ShelfLife.SLText130.rawValue = "Provide a summary of the methods used to support the sterility and performance of the device over its proposed shelf-life. Alternatively, provide a rationale for why testing to establish shelf-life is not applicable.";
		References.RFDropDownList110.caption.value.text = "Did you find any relevant literature that should be cited as part of your bibliography?";
	  	References.RFText120.rawValue = "Please attach all the relevant literature searched.";
		References.RFText130.rawValue = "Include a discussion and analysis of how each article is relevant to safety and effectiveness.";
		References.RFTextField130.assist.toolTip.value = "Include a discussion and analysis of how each article is relevant to safety and effectiveness.";	  	

		//hide questions
		ReprocSter.Sterility.STYesIndicator107.presence = "hidden";
		ReprocSter.Sterility.STNoIndicator107.presence = "hidden";
		ReprocSter.Sterility.STAddAttachment107.presence = "hidden";
		ReprocSter.Sterility.STText107.presence = "hidden";
		ReprocSter.Sterility.STTips107.presence = "hidden";
		
	  	//unhide subforms for De Novo
		AdministrativeInformation.RelatedSubmissions.NSE510k.presence = "visible";
		Classification.presence = "visible";
		Classification.USAKnownClassification.presence = "hidden";
		Classification.USAProposedClassification.presence = "visible";
		RiskManagement.presence = "visible";
		RiskManagement.DesignControl.presence = "hidden";
		RiskManagement.VerificationValidation.presence = "hidden";
		RiskManagement.RiskMitigationTable.presence = "visible";
		RiskManagement.SpecialControls.presence = "visible";
		RiskManagement.BenefitRisk.presence = "visible";
		RiskManagement.AlternativePractices.presence = "visible";
		RiskManagement.DualSubmissionRisk.presence = "hidden";
		ReprocSter.Sterility.STYesIndicator105.presence = "visible"; 
		ReprocSter.Sterility.STNoIndicator105.presence = "visible"; 
		ReprocSter.Sterility.STDropDownList105.presence = "visible"; 
		ReprocSter.Sterility.STDropDownList105.execEvent("exit"); //to reveal instances 
		ReprocSter.Sterility.STTips105.presence = "visible"; 		
		
		PerformanceTesting.PTYesIndicator900.presence="visible";
		PerformanceTesting.PTNoIndicator900.presence="visible";
		PerformanceTesting.PTAddAttachment900.presence="visible";
		PerformanceTesting.PTText900.presence="visible";				
		PerformanceTesting.PTTips900.presence="visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.presence = "visible";
		var iGCIndices = [110,120,130,140,150,160,170,180,190,200,210,220,230];
		for (var i = 0; i < iGCIndices.length; i++) {//only make De Novo related questions in general clinical section visible
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTYesIndicator" + iGCIndices[i]).presence = "visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTNoIndicator" + iGCIndices[i]).presence = "visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTTextField" + iGCIndices[i]).presence = "visible";
		}//for
		iGCIndices = [310,320,330,340,350,360,370,380,390,400,410,420,430,440,450,460,470,475,480,490,500];
		for (var i = 0; i < iGCIndices.length; i++) {//PMA questions in general clinical section are hidden
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTYesIndicator" + iGCIndices[i]).presence = "hidden";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTNoIndicator" + iGCIndices[i]).presence = "hidden";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTTextField" + iGCIndices[i]).presence = "hidden";
		}//for	
		//Clinical break change to prevent rendering issues
        if (Verification.ViewerType.rawValue == "FoxIt") {//if foxit is used
            PerformanceTesting.ClinicalStudies.GeneralClinical.break.before = "pageArea"; //next page, messes up in foxit otherwise only because of addition of GeneralClinical
        }//if
        else{
            PerformanceTesting.ClinicalStudies.GeneralClinical.break.before = "";
        }//else
		//run functions that control existence of questions or indicators
		DeviceDescription.ComponentsAccessories.DDDropDownList430.execEvent("exit"); //component
	}//if
	
	if (this.rawValue == "3"){ //PMA
	
		//set indicator
		this.ATYesIndicator110.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator110.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator110.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator110.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowP.presence = "visible";
		this.ShowPType.presence = "visible";
		
		//show type radiobutton
		this.ATYesIndicator114.presence = "visible";
		this.ATNoIndicator114.presence = "visible";
		this.ATText114.presence = "visible";
		this.ATRadioButton114.presence = "visible";
		
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected
	
		//set text and height 
	  	RiskManagement.BenefitRisk.BRText100.h = "1.1in";
		RiskManagement.BenefitRisk.BRText100.rawValue = "Provide a discussion demonstrating that the probable benefits to health from use of the device outweigh any probable injury or illness from such use. This discussion shall include any adverse effects of the device on health and any proposed additional studies or surveillance the applicant intends to conduct following approval of the PMA. Also address how the data and information in the application constitute valid scientific evidence within the meaning of 21 CFR 860.7.";
		RiskManagement.BenefitRisk.BRTips100.maxH = "1.1in";
		RiskManagement.BenefitRisk.BRTips100.minH = "1.1in";
		//RiskManagement.BenefitRisk.BRTips100.margin.topInset = "0.5in";
		Labeling.LBText1.rawValue = "You must submit all proposed labeling for the device. Such labeling may include, e.g., instructions for installation and any information, literature, or advertising that constitutes labeling under section 201(m) of the Federal Food, Drug, and Cosmetic Act.";	  	References.RFDropDownList110.caption.value.text = "Did you find any relevant literature that should be cited as part of your bibliography?";
	  	ReprocSter.ShelfLife.SLText130.rawValue = "Please provide a comprehensive description of the methods used for package validation, including those used to support package performance and stability claims over the proposed shelf life.";
		References.RFText120.rawValue = "Please attach all the relevant literature searched.";
		References.RFText130.rawValue = "Include a discussion and analysis of how each article is relevant to safety and effectiveness.";
		References.RFTextField130.assist.toolTip.value = "Include a discussion and analysis of how each article is relevant to safety and effectiveness.";	  	

		//hide questions
		DeviceDescription.AssayInstrumentInfo.presence="hidden"; //for PMA, assay vs. instrument Q will not be asked
		PerformanceTesting.AnalyticalPerformance.InstrumentPerformance.presence= "hidden";//hide insturment only analytical studies
		PerformanceTesting.ClinicalStudies.InstrumentClinical.presence = "hidden";//hide insturment only clinical studies
		//PerformanceTesting.ComparisonStudies.PTDropDownList260.presence="hidden";//hide method comparison item
		//PerformanceTesting.ComparisonStudies.PTYesIndicator260.presence="hidden";
		//PerformanceTesting.ComparisonStudies.PTNoIndicator260.presence="hidden";
		//PerformanceTesting.ComparisonStudies.PTTips260.presence="hidden";		
		ReprocSter.Sterility.STYesIndicator105.presence = "hidden";
		ReprocSter.Sterility.STNoIndicator105.presence = "hidden";
		ReprocSter.Sterility.STDropDownList105.presence = "hidden";
		ReprocSter.Sterility.STTips105.presence = "hidden";
		for (var i = ReprocSter.Sterility.STMethod.instanceManager.count; i > 0; i--) {//hide instances
			ReprocSter.Sterility.resolveNode("STMethod[" + (parseInt(i)-1) + "]").presence = "hidden";
			if (ReprocSter.Sterility.STMethod.instanceManager.count != 1) {//last can't be removed
				ReprocSter.Sterility.STMethod.instanceManager.removeInstance(i-1);
			}//if multiple instances exist
		}//for
		ReprocSter.ShelfLife.break.before = ""; //not next page
		  	
	  	//unhide subforms for PMA
		Classification.USAKnownClassification.presence = "hidden";
		DeviceDescription.GeneralConsiderations.presence = "visible";
		MarketingHistory.presence = "visible";
		RiskManagement.presence = "visible";
		RiskManagement.DesignControl.presence = "hidden";
		RiskManagement.VerificationValidation.presence = "hidden";
		RiskManagement.RiskMitigationTable.presence = "hidden";
		RiskManagement.SpecialControls.presence = "hidden";
		RiskManagement.BenefitRisk.presence = "visible";
		RiskManagement.AlternativePractices.presence = "visible";
		RiskManagement.DualSubmissionRisk.presence = "hidden";
		ReprocSter.Sterility.STYesIndicator107.presence = "visible"; 
		ReprocSter.Sterility.STNoIndicator107.presence = "visible"; 
		ReprocSter.Sterility.STAddAttachment107.presence = "visible"; 
		ReprocSter.Sterility.STText107.presence = "visible"; 
		ReprocSter.Sterility.STTips107.presence = "visible"; 
		PerformanceTesting.PTYesIndicator900.presence="visible"; //#210 in nIVD eSTAR
		PerformanceTesting.PTNoIndicator900.presence="visible";
		PerformanceTesting.PTAddAttachment900.presence="visible";
		PerformanceTesting.PTText900.presence="visible";				
		PerformanceTesting.PTTips900.presence="visible";		
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator640.presence = "visible";//#530 in nIVD eSTAR
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips640.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTYesIndicator650.presence = "visible"; //#540 in nIVD eSTAR
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTNoIndicator650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTAddAttachment650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTText650.presence = "visible";
		PerformanceTesting.AnimalTesting.AnimalTestingQs.PTTips650.presence = "visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.presence = "visible";
		var iGCIndices = [310,320,330,340,350,360,370,380,390,400,410,420,430,440,450,460,470,475,480,490,500];
		for (var i = 0; i < iGCIndices.length; i++) {//only make PMA related questions in general clinical section visible
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTYesIndicator" + iGCIndices[i]).presence = "visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTNoIndicator" + iGCIndices[i]).presence = "visible";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTTextField" + iGCIndices[i]).presence = "visible";
		}//for
		iGCIndices = [110,120,130,140,150,160,170,180,190,200,210,220,230];
		for (var i = 0; i < iGCIndices.length; i++) {//De Novo questions in general clinical section are hidden
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTYesIndicator" + iGCIndices[i]).presence = "hidden";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTNoIndicator" + iGCIndices[i]).presence = "hidden";
		PerformanceTesting.ClinicalStudies.GeneralClinical.resolveNode("CTTextField" + iGCIndices[i]).presence = "hidden";
		}//for
		QualityManagement.presence = "visible";
		PAS.presence = "visible";

		//reveal EA Environmental Assessment questions in Admin section 
		AdministrativeDocumentation.ADYesIndicator809.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator809.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment809.presence = "visible";
		AdministrativeDocumentation.ADText809.presence = "visible";
		AdministrativeDocumentation.ADTips809.presence = "visible";
		
		//show Forms 3454 and 3674 if not 30 DN
		AdministrativeDocumentation.ADYesIndicator822.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator822.presence = "visible";
		AdministrativeDocumentation.ADDropDownList822.presence = "visible";
		AdministrativeDocumentation.ADTips822.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator832.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator832.presence = "visible";
		AdministrativeDocumentation.ADDropDownList832.presence = "visible";
		AdministrativeDocumentation.ADTips832.presence = "visible";		
		
		//Hide specific questions/sections
		var iQMIndices = [230];
		for (var i = 0; i < iQMIndices.length; i++){//hide QM parts
			QualityManagement.Procedures.resolveNode("QMYesIndicator" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMNoIndicator" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMAddAttachment" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMText" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMTips" + iQMIndices[i]).presence = "hidden";
		}//for
		//display QM questions
		QualityManagement.FacilitiesInfo.presence = "visible";
		var iQMIndices = [110,120,130,140,150,160,170,180,190,200,210,220,240];
		for (var i = 0; i < iQMIndices.length; i++) {//display QM parts
			QualityManagement.Procedures.resolveNode("QMYesIndicator" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMNoIndicator" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMAddAttachment" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMText" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMTips" + iQMIndices[i]).presence = "visible";
		}//for
		
		//run functions that control existence of questions or indicators
		DeviceDescription.ComponentsAccessories.DDDropDownList430.execEvent("exit"); //component
		ReprocSter.Sterility.variables.Functions.Validation(); //ensure indicators are set
		
	}//if
	
	//run changes now that visibility is set
	this.ATRadioButton114.execEvent("change"); //run radiobutton to ensure changes take effect	
	this.ATRadioButton115.execEvent("change"); //run radiobutton to ensure changes take effect
	ApplicationType.ApplicationSubType.ATRadioButton130.execEvent("change"); //run radiobutton to ensure changes take effect
	DeviceDescription.GeneralCharacteristics.DDCheckboxGroup251.DDCheckBox310.execEvent("change"); //PCCP checkbox
	DeviceDescription.ComponentsAccessories.DDDropDownList430.execEvent("exit"); //component/accessory
    References.RFDropDownList110.execEvent("exit"); //references, for controlling RFTextField130
    	
	//run validation functions for uniquely visible subforms and questions
	if (xfa.host.getFocus().name.substr(0,15) != "ATRadioButton10"){//only run validation functions if the region radiobutton didn't call this	
		AdministrativeInformation.RelatedSubmissions.Functions.Validation();
		AdministrativeInformation.Standards.variables.Functions.AutoPopulate(); //determine if DoC needs to be visible
		DeviceDescription.Devices.Functions.Validation(); //run for device name
		DeviceDescription.GeneralCharacteristics.Functions.Validation();	
		DeviceDescription.Description.Functions.Validation(); //needed to account for 422 and 424 that may or may not be visible
		DeviceDescription.Functions.Validation();
		IndicationsForUse.Functions.Validation(); //Rx/OTC checkbox changes for jurisdiction
		Classification.Functions.Validation();
		RiskManagement.Functions.Validation();
		Labeling.Functions.Validation();
		root.variables.Functions.RPSTPresence(); //fxn that determines presence of RP and ST sections. runs validation function too.
        root.variables.Functions.BCPresence(); //fxn that determines presence of BC section. runs validation function too.
		SoftwareCyber.Software.SoftwareDocLevel.variables.Functions.Validation(); //resets software documentation that is needed
		SoftwareCyber.Software.SoftwareDocs.variables.Functions.Validation(); //resets software documentation that is needed
		SoftwareCyber.Cybersecurity.variables.Functions.Validation(); //interop validation run in exit event above
		root.variables.Functions.SWCSPresence(); //fxn that determines presence of SW, CS, and Interop sections. runs validation function too.
		EMCWireless.EMC.Functions.Validation();
		EMCWireless.Wireless.Functions.Validation();
		PerformanceTesting.ClinicalStudies.GeneralClinical.Functions.Validation();
		PerformanceTesting.Functions.Validation();
		References.Functions.Validation();
		AdministrativeDocumentation.Functions.Validation();
		QualityManagement.Procedures.Functions.Validation();
		
		ApplicationType.variables.Functions.Validation();
	}//if
}//else
