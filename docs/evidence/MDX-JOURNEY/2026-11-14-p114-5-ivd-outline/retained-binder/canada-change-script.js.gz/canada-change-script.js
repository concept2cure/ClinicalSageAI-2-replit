if (AdministrativeDocumentation.SignedCheckBox.rawValue == 1) {//if signed at all
    app.alert("This question cannot be modified while this eSTAR is electronically signed. Please ask the original signatory to right-click and clear the signature first (e.g. in the T&A Statement) before you modify your answer to this question.");
    this.rawValue = Verification.prevValue.rawValue;
}//if
else{
	//default indicator
	this.ATYesIndicator120.border.fill.color.value = BlankIndicator.value;
	this.ATNoIndicator120.border.fill.color.value = IncompleteIndicator.value;
	this.ATYesIndicator120.assist.toolTip.value = QuestionIncomplete.value;
	this.ATNoIndicator120.assist.toolTip.value = QuestionIncomplete.value;
	
	//default introduction
	this.ShowHC.presence = "hidden";
	this.ATTextHC.presence = "hidden";
	
	//default document subtype
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton131.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.access = "open";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly";
	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.presence = "visible";
	//ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.caption.font.fill.color.value = "153,153,153";
	if (xfa.host.getFocus().name != "ImportData") {
    	ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton131.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton132.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton133.rawValue = null;
        ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.rawValue = null;	
    }//if
	
	//default verification lists
	Verification.VRText1.rawValue = "";
	Verification.VRText2.rawValue = "";
	
	//set visibility of subforms that need to appear during data import
	if (xfa.host.getFocus() != null) {
	    if (xfa.host.getFocus().name == "ImportData") {
	        if (AdministrativeInformation.CorrespondentInformation.ADTextField330.rawValue != null){//if there is a correspondent, based on the existence of a first name 
	        AdministrativeInformation.CorrespondentInformation.presence = "visible"; 
	        }//if
	    }//if
	}//if
	
	//hide subforms
	RiskManagement.presence = "hidden";
	QualityManagement.presence = "hidden";
	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator120.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator120.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList120.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips120.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator121.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator121.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment121.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText121.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips121.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator122.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator122.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText122.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField122.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator185.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator185.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList185.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips185.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator186.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator186.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTAddAttachment186.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText186.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips186.presence = "hidden";	
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator187.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator187.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTText187.presence = "hidden";
	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTextField187.presence = "hidden";	
	//PerformanceTesting.ComparisonStudies.presence = "hidden";
	//PerformanceTesting.ReferenceRange.presence = "hidden";
	PerformanceTesting.ClinicalStudies.AssayClinical.presence = "hidden";				
	PerformanceTesting.ClinicalStudies.GeneralClinical.presence = "hidden";
	PerformanceTesting.ClinicalStudies.RWD.presence = "hidden";
	PerformanceTesting.CDR.presence = "hidden";
	PerformanceTesting.AnimalTesting.presence = "hidden";
	
	RiskManagement.RiskMitigationTable.presence = "hidden";
	RiskManagement.DesignControl.presence = "hidden";
	RiskManagement.VerificationValidation.presence = "hidden";
	RiskManagement.SpecialControls.presence = "hidden";
	RiskManagement.AlternativePractices.presence = "hidden";
	RiskManagement.DualSubmissionRisk.presence = "hidden";
	
	ReprocSter.Guidance.presence = "hidden";
	Labeling.Guidance.presence = "hidden";
	
	AdministrativeDocumentation.ADYesIndicator803.presence = "hidden"; //803 deliberately redundant with AT100, since Class II below doesn't use it
	AdministrativeDocumentation.ADNoIndicator803.presence = "hidden";
	AdministrativeDocumentation.ADAddAttachment803.presence = "hidden";
	AdministrativeDocumentation.ADText803.presence = "hidden";
	AdministrativeDocumentation.ADTips803.presence = "hidden";
	
	//unhide subforms
	if (xfa.host.getFocus().name.substr(0,15) != "ATRadioButton10"){//only run validation functions if the region radiobutton didn't call this	
		CoverLetter.presence = "visible";
		AdministrativeInformation.presence = "visible";
		AdministrativeInformation.ApplicationForm.presence = "visible";
		AdministrativeInformation.RelatedSubmissions.presence = "visible";
		AdministrativeInformation.Standards.presence = "visible";
		DeviceDescription.presence = "visible";
		DeviceDescription.Devices.presence = "visible";
		DeviceDescription.Devices.DDAddAttachment104.presence = "visible";
		DeviceDescription.Devices.DDText104.presence = "visible";
		DeviceDescription.GeneralCharacteristics.presence = "visible";
		DeviceDescription.Description.presence = "visible";
		DeviceDescription.Description.DDYesIndicator422.presence = "visible";
		DeviceDescription.Description.DDNoIndicator422.presence = "visible";
		DeviceDescription.Description.DDAddAttachment422.presence = "visible";
		DeviceDescription.Description.DDText422.presence = "visible";
		DeviceDescription.Description.DDTips422.presence = "visible";
		DeviceDescription.Description.DDYesIndicator424.presence = "visible";
		DeviceDescription.Description.DDNoIndicator424.presence = "visible";
		DeviceDescription.Description.DDAddAttachment424.presence = "visible";
		DeviceDescription.Description.DDText424.presence = "visible";
		DeviceDescription.Description.DDTips424.presence = "visible";
		DeviceDescription.GeneralCharacteristics.DDYesIndicator401.presence = "visible"; //HC Only Question - Is Device Near Patient
		DeviceDescription.GeneralCharacteristics.DDNoIndicator401.presence = "visible"; //HC Only Question - Is Device Near Patient
		DeviceDescription.GeneralCharacteristics.DDDropDownList401.presence = "visible"; //HC Only Question - Is Device Near Patient
		DeviceDescription.GeneralCharacteristics.DDTips401.presence = "visible"; //HC Only Question - Is Device Near Patient
		
		IndicationsForUse.presence = "visible";
		Labeling.presence = "visible";
		Labeling.Packaging.presence = "visible";
		Labeling.Instructions.presence = "visible";
		Labeling.OtherLabeling.presence = "visible";
		MarketingHistory.presence = "visible";
		MarketingHistory.MHText1.rawValue = "Provide a description of the marketing history of the device.";
		var iMHIndices = [110,120,130];
		for (var i = 0; i < iMHIndices .length; i++){//only make specific MH question(s) applicable to US FDA visible and hide the others
			MarketingHistory.resolveNode("MHYesIndicator" + iMHIndices[i]).presence = "visible";
			MarketingHistory.resolveNode("MHNoIndicator" + iMHIndices[i]).presence = "visible";
			MarketingHistory.resolveNode("MHAddAttachment" + iMHIndices[i]).presence = "visible";
			MarketingHistory.resolveNode("MHText" + iMHIndices[i]).presence = "visible";
			MarketingHistory.resolveNode("MHTips" + iMHIndices[i]).presence = "visible";
		}//for		
				
		RiskManagement.BenefitRisk.presence = "visible";
		
		/*PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator210.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator210.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList210.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips210.presence = "visible";
	   	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator220.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator220.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList220.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips220.presence = "visible";*/
	    PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator230.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator230.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList230.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips230.presence = "visible";
	   	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator240.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator240.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList240.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips240.presence = "visible";
	   	PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTYesIndicator250.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTNoIndicator250.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTDropDownList250.presence = "visible";
		PerformanceTesting.AnalyticalPerformance.AssayPerformance.PTTips250.presence = "visible";
		PerformanceTesting.BenchTesting.presence = "visible";
	   	PerformanceTesting.ClinicalStudies.PTYesIndicator600.presence = "visible";
		PerformanceTesting.ClinicalStudies.PTNoIndicator600.presence = "visible";
		PerformanceTesting.ClinicalStudies.PTDropDownList600.presence = "visible";
		PerformanceTesting.ClinicalStudies.PTTips600.presence = "visible";
		ReprocSter.presence = "visible";
		ReprocSter.ReprocSterDocs.presence = "visible";
		Biocompatibility.presence = "visible";
		Biocompatibility.BiocompatibilityDocs.presence = "visible";
		SoftwareCyber.presence = "visible";
		SoftwareCyber.Software.presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.resolveNode("SWYesIndicator230").presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.resolveNode("SWNoIndicator230").presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.resolveNode("SWAddAttachment230").presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.resolveNode("SWText230").presence = "visible";
		SoftwareCyber.Software.SoftwareDocs.resolveNode("SWTips230").presence = "visible";
		SoftwareCyber.Cybersecurity.presence = "visible";
		SoftwareCyber.Cybersecurity.General.presence = "visible";
		SoftwareCyber.Interoperability.presence = "visible";
		SoftwareCyber.Interoperability.ElectronicInterface.presence = "visible";
        for (var i = SoftwareCyber.Interoperability.ElectronicInterface.instanceManager.count; i > 0; i--) {//reveal FDA interop default questions
            //Reveal instance content. Don't need to do this when importing, since is present by default.
            for (var j = 0; j < SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.length; j++) {//cycle through parent's nodes 
                 if (SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).className == "draw" || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).className == "field") {//if this is NOT an attachment subform, and it is a draw or field
                    if (SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).name.indexOf("285") > 0) {//reveal 285
                        //need to reveal each 285 for every instance, even those without attachments, since 1) the EI may be needed for that jurisdiction, and 2) if more than one EI, but only one attachment, that attachment instance will be removed if attachment removed, removing all places to attach
                        //if (SoftwareCyber.Interoperability.ElectronicInterface.instanceManager.count == 1 || SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").CSAttachment285.presence == "visible") {//if only one instance or more than one and attachment is visible
                              SoftwareCyber.Interoperability.resolveNode("ElectronicInterface[" + (parseInt(i)-1) + "]").nodes.item(j).presence = "visible";
                       //}//if
                    }//if                                                  
                }//if
           }//for
        }//for		
		EMCWireless.presence = "visible";
		EMCWireless.EMCEMTSummary.presence = "visible";
		EMCWireless.EMCEMTDocs.presence = "visible";
		PerformanceTesting.presence = "visible";
		References.presence = "visible";
		AdministrativeDocumentation.presence = "visible";
		AdministrativeDocumentation.ADYesIndicator815.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator815.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment815.presence = "visible";
		AdministrativeDocumentation.ADText815.presence = "visible";
		AdministrativeDocumentation.ADTips815.presence = "visible";
		//Hide FDA specific fields
		AdministrativeDocumentation.ADYesIndicator822.presence = "hidden";
		AdministrativeDocumentation.ADNoIndicator822.presence = "hidden";	
		AdministrativeDocumentation.ADDropDownList822.presence = "hidden";
		AdministrativeDocumentation.ADTips822.presence = "hidden";	
		AdministrativeDocumentation.ADYesIndicator825.presence = "hidden";
		AdministrativeDocumentation.ADNoIndicator825.presence = "hidden";	
		AdministrativeDocumentation.ADAddAttachment825.presence = "hidden";
		AdministrativeDocumentation.ADText825.presence = "hidden";			
		AdministrativeDocumentation.ADAttachment825.presence = "hidden";		
		AdministrativeDocumentation.ADYesIndicator832.presence = "hidden";
		AdministrativeDocumentation.ADNoIndicator832.presence = "hidden";	
		AdministrativeDocumentation.ADDropDownList832.presence = "hidden";
		AdministrativeDocumentation.ADTips832.presence = "hidden";	
		AdministrativeDocumentation.ADYesIndicator835.presence = "hidden";
		AdministrativeDocumentation.ADNoIndicator835.presence = "hidden";	
		AdministrativeDocumentation.ADAddAttachment835.presence = "hidden";
		AdministrativeDocumentation.ADText835.presence = "hidden";			
		AdministrativeDocumentation.ADAttachment835.presence = "hidden";	
		AdministrativeDocumentation.ADYesIndicator840.presence = "visible";
		AdministrativeDocumentation.ADNoIndicator840.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment840.presence = "visible";
		AdministrativeDocumentation.ADText840.presence = "visible";
		AdministrativeDocumentation.ADTips840.presence = "visible";	
		Verification.presence = "visible";	
	}//if
		
	if (this.rawValue == "1"){ //Class II
		//set indicator
		this.ATYesIndicator120.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator120.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator120.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator120.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowHC.presence = "visible";
	
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected
	  	  	  	
		//unhide admin fields
		/*AdministrativeDocumentation.ADYesIndicator840.presence = "visible"; //dec of conf
		AdministrativeDocumentation.ADNoIndicator840.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment840.presence = "visible";
		AdministrativeDocumentation.ADText840.presence = "visible";
		AdministrativeDocumentation.ADTips840.presence = "visible";*/
	
		//this.ATTextHC.rawValue = "Health Canada Class II introductory text goes here."
	
	}//if
	
	if (this.rawValue == "2"){ //Class III
		//set indicator
		this.ATYesIndicator120.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator120.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator120.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator120.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowHC.presence = "visible";
	
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected	

	  	//unhide admin fields
	  	AdministrativeDocumentation.ADYesIndicator803.presence = "visible"; //terms/acronyms
		AdministrativeDocumentation.ADNoIndicator803.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment803.presence = "visible";
		AdministrativeDocumentation.ADText803.presence = "visible";
		AdministrativeDocumentation.ADTips803.presence = "visible";
				
		RiskManagement.presence = "hidden";
		
		if (DeviceDescription.Description.DDAttachment425.presence == "visible") {//if
			//Material Specifications
			DeviceDescription.Description.DDYesIndicator425.border.fill.color.value = CompleteIndicator.value;
			DeviceDescription.Description.DDNoIndicator425.border.fill.color.value = "102,140,255";
			DeviceDescription.Description.DDYesIndicator425.assist.toolTip.value = QuestionComplete.value;
			DeviceDescription.Description.DDNoIndicator425.assist.toolTip.value = QuestionComplete.value;
		}//if
		else{//else
			//Material Specifications
			DeviceDescription.Description.DDYesIndicator425.border.fill.color.value = SecondaryHeading.value;
			DeviceDescription.Description.DDNoIndicator425.border.fill.color.value = "102,140,255";//blue
			DeviceDescription.Description.DDYesIndicator425.assist.toolTip.value = QuestionOptional.value;
			DeviceDescription.Description.DDNoIndicator425.assist.toolTip.value = QuestionOptional.value;
		}//else
					
		//this.ATTextHC.rawValue = "Health Canada Class III introductory text goes here."
	}//if
	
	if (this.rawValue == "3"){ //Class IV
		//set indicator
		this.ATYesIndicator120.border.fill.color.value = CompleteIndicator.value; //green
		this.ATNoIndicator120.border.fill.color.value = BlankIndicator.value; //white
		this.ATYesIndicator120.assist.toolTip.value = QuestionComplete.value;
		this.ATNoIndicator120.assist.toolTip.value = QuestionComplete.value;
	
		//show introduction
		this.ShowHC.presence = "visible";
	
		//show subtype form
		ApplicationType.ApplicationSubType.presence = "visible"; //will show ATRadioButton130
		
		//set subtype radiobutton access
		ApplicationType.ApplicationSubType.ATRadioButton130.ATRadioButton134.access = "readOnly"; //open, nonInteractive, protected
	  	
		if (DeviceDescription.Description.DDAttachment425.presence == "visible") {//if
			//Material Specifications
			DeviceDescription.Description.DDYesIndicator425.border.fill.color.value = CompleteIndicator.value;
			DeviceDescription.Description.DDNoIndicator425.border.fill.color.value = "102,140,255";
			DeviceDescription.Description.DDYesIndicator425.assist.toolTip.value = QuestionComplete.value;
			DeviceDescription.Description.DDNoIndicator425.assist.toolTip.value = QuestionComplete.value;
		}//if
		else {
			//Material Specifications
			DeviceDescription.Description.DDYesIndicator425.border.fill.color.value = BlankIndicator.value;
			DeviceDescription.Description.DDNoIndicator425.border.fill.color.value = IncompleteIndicator.value;
			DeviceDescription.Description.DDYesIndicator425.assist.toolTip.value = QuestionIncomplete.value;
			DeviceDescription.Description.DDNoIndicator425.assist.toolTip.value = QuestionIncomplete.value;
		}//else
	  	
	  	//unhide subforms
		QualityManagement.presence = "visible";
		RiskManagement.presence = "visible";
        RiskManagement.DesignControl.presence = "hidden";
        RiskManagement.VerificationValidation.presence = "hidden";
        RiskManagement.RiskMitigationTable.presence = "visible";
        RiskManagement.SpecialControls.presence = "hidden";
        RiskManagement.BenefitRisk.presence = "visible";
		RiskManagement.BenefitRisk.BRText100.h = "0.5in"; 
		RiskManagement.BenefitRisk.BRText100.rawValue = "Provide a discussion demonstrating that the probable benefits to health from use of the device outweigh any probable injury or illness from such use."; 
		RiskManagement.BenefitRisk.BRTips100.maxH = "0.5in";
		RiskManagement.BenefitRisk.BRTips100.minH = "0.5in";
		//RiskManagement.BenefitRisk.BRTips100.margin.topInset = "0.2in"; 
		RiskManagement.AlternativePractices.presence = "hidden";
		 
		//unhide admin fields
		AdministrativeDocumentation.ADYesIndicator803.presence = "visible"; //terms/acronyms
		AdministrativeDocumentation.ADNoIndicator803.presence = "visible";
		AdministrativeDocumentation.ADAddAttachment803.presence = "visible";
		AdministrativeDocumentation.ADText803.presence = "visible";
		AdministrativeDocumentation.ADTips803.presence = "visible";
		
		//Hide specific questions
		QualityManagement.FacilitiesInfo.presence = "hidden";
		var iQMIndices = [110,120,130,140,150,160,170,180,190,210,220];
		for (var i = 0; i < iQMIndices.length; i++){//hide QM parts
			QualityManagement.Procedures.resolveNode("QMYesIndicator" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMNoIndicator" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMAddAttachment" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMText" + iQMIndices[i]).presence = "hidden";
			QualityManagement.Procedures.resolveNode("QMTips" + iQMIndices[i]).presence = "hidden";
		}//for		
		//display QM questions
		var iQMIndices = [200,230,240];
		for (var i = 0; i < iQMIndices.length; i++) {//display QM parts
			QualityManagement.Procedures.resolveNode("QMYesIndicator" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMNoIndicator" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMAddAttachment" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMText" + iQMIndices[i]).presence = "visible";
			QualityManagement.Procedures.resolveNode("QMTips" + iQMIndices[i]).presence = "visible";
		}//for
		
		//this.ATTextHC.rawValue = "Health Canada Class IV introductory text goes here."
	}//if
	
	//run subform specific processes
	ApplicationType.ApplicationSubType.ATRadioButton130.execEvent("change"); //run radiobutton to ensure changes take effect
	DeviceDescription.ComponentsAccessories.DDDropDownList430.execEvent("exit"); //component/accessory
	References.RFDropDownList110.execEvent("exit"); //references, for controlling RFTextField130
	
	//run validation functions for uniquely visible subforms and questions
	if (xfa.host.getFocus().name.substr(0,15) != "ATRadioButton10"){//only run validation functions if the region radiobutton didn't call this	
		DeviceDescription.Devices.Functions.Validation(); //run for device name
		DeviceDescription.GeneralCharacteristics.Functions.Validation();
		DeviceDescription.Description.Functions.Validation(); //needed to account for 422 and 424 that may or may not be visible
		DeviceDescription.Functions.Validation();
		IndicationsForUse.Functions.Validation(); //Rx/OTC checkbox changes for jurisdiction
		RiskManagement.Functions.Validation();
		Labeling.Functions.Validation();
		
		root.variables.Functions.RPSTPresence(); //fxn that determines presence of RP and ST sections. runs validation function too.
		root.variables.Functions.BCPresence(); //fxn that determines presence of BC section. runs validation function too.
		SoftwareCyber.Software.SoftwareDocLevel.variables.Functions.Validation(); //resets software documentation that is needed
		SoftwareCyber.Software.SoftwareDocs.variables.Functions.Validation(); //resets software documentation that is needed
		SoftwareCyber.Cybersecurity.variables.Functions.Validation();
		SoftwareCyber.Interoperability.variables.Functions.Validation();; //Interop
		
		root.variables.Functions.SWCSPresence();
		EMCWireless.EMC.Functions.Validation();
		EMCWireless.Wireless.Functions.Validation();
		PerformanceTesting.Functions.Validation();
		References.Functions.Validation();
		AdministrativeDocumentation.Functions.Validation();
		QualityManagement.Procedures.Functions.Validation();
		
		ApplicationType.variables.Functions.Validation();
	}//if
}//else
