/**
 * eSTAR filing-readiness orchestrator — the single "can this client file X, and
 * what's left?" answer for any eSTAR submission.
 *
 * Ties together the four independently-verified pieces of the eSTAR program into
 * one honest verdict, so a surface doesn't have to call (and reconcile) each:
 *
 *   1. registration eligibility  — estar-registration (FDA ESG / CDRH Portal /
 *      DUNS / MDUFA-fee prerequisites → is this client allowed to file this type?)
 *   2. template + version         — estar-catalog / estar-versions (which family,
 *      the current recommended version, and the OMB control numbers)
 *   3. content readiness          — the right readiness mapper for the submission
 *      (estar-mapper for 510(k)/De Novo, pma-mapper for PMA + supplements,
 *      prestar-mapper for Q-Sub/IDE/513(g)) → are the required sections present?
 *   4. official-template producibility — whether the platform can actually fill
 *      the official FDA PDF (template vendored + verified field map)
 *   5. template version currency  — whether the official template on file is the
 *      version FDA currently publishes (estar-versions.templateVersionCurrency).
 *      A 7.0 PDF filled while FDA's page names 7.1 used to report "Can file now".
 *
 * PURE + DETERMINISTIC + HONEST-BY-CONSTRUCTION: no DB, no network, no filesystem.
 * Producibility is passed in (the caller reads it from the template registry / fill
 * orchestration) so this stays a pure projection; it defaults to not-producible so
 * the verdict fails closed. Nothing is invented — every gap is reported.
 *
 * @module server/services/pathway-engines/estar/estar-filing-readiness
 */

import {
  getCatalogEntry,
  resolveCatalogTemplate,
  type EstarCatalogKey,
} from './estar-catalog';
import {
  canFile,
  type EstarClientRegistration,
  type EstarRegistrationRequirement,
} from './estar-registration';
import {
  isVersionTableStale,
  templateVersionCurrency,
  type EstarProgramSubmissionType,
  type EstarTemplateFamily,
} from './estar-versions';
import { mapToEstar, type EstarType, type DeviceFlags } from './estar-mapper';
import { mapToPma, type PmaSubmissionType } from '../pma/pma-mapper';
import { mapToPreStar, type QSubType } from '../prestar/prestar-mapper';
import { PRESTAR_COMPLETION_NOTE } from './estar-field-map';
import { divergedSectionLabel, filedCopyDivergedSentence, type DivergedNode } from '../../c2c/filing-section-target';

/** A canonical content leaf — shape shared by every readiness mapper. */
export interface FilingLeaf {
  sectionCode: string;
  title: string;
  documentType?: string;
  /**
   * True only when this leaf carries real, finalized authored content — never a
   * draft/placeholder stub. Mirrors EstarInputLeaf/PmaInputLeaf/PreStarInputLeaf:
   * required so a caller must consciously mark a leaf substantive rather than a
   * title match silently counting as "present" (see those mappers' evalSlot).
   */
  substantive?: boolean; // optional: undefined ⇒ NOT substantive (fail-closed)
}

/** PMA catalog key → the pma-mapper submission type. */
const PMA_KEY_TO_TYPE: Record<string, PmaSubmissionType> = {
  pma_original: 'original',
  pma_panel_track_supplement: 'panel_track_supplement',
  pma_180_day_supplement: '180_day_supplement',
  pma_real_time_supplement: 'real_time_supplement',
  pma_30_day_notice: '30_day_notice',
  pma_135_day_supplement: '135_day_supplement',
};

/** Q-Sub catalog key → the prestar-mapper Q-Sub sub-type. */
const QSUB_KEY_TO_TYPE: Record<string, QSubType> = {
  qsub_pre_submission: 'pre_submission',
  qsub_submission_issue_request: 'submission_issue_request',
  qsub_informational_meeting: 'informational_meeting',
  qsub_study_risk_determination: 'study_risk_determination',
  qsub_pma_day_100_meeting: 'pma_day_100_meeting',
  qsub_accessory_classification_request: 'accessory_classification_request',
};

interface NormalizedContent {
  ready: boolean;
  missingSections: string[];
  completeness: number;
  /**
   * Sections whose applicability nobody has established yet — reported inside
   * `missingSections`, and counted here so the sentence can say which of the
   * two problems it is. A section that is missing is a document to write; a
   * section that is undetermined is a question to answer.
   */
  undeterminedCount: number;
}

/** Normalize any mapper's section list into a uniform readiness shape. */
function normalize(
  sections: Array<{ required: boolean; present: boolean }>,
  missingRequired: string[],
  ready: boolean,
  undeterminedCount = 0,
): NormalizedContent {
  const required = sections.filter((s) => s.required);
  const presentRequired = required.filter((s) => s.present).length;
  // Undetermined sections are REPORTED in missingSections but were excluded
  // from this denominator, so a submission with every known-required section
  // present and three unanswered applicability questions rendered
  // "Content incomplete (100%): missing required sections sterilization,
  // software, cybersecurity." A number that contradicts the list beside it
  // tells the reader nothing. They are counted here as not-present, which is
  // what they are: nobody has established that the section is not owed.
  const total = required.length + undeterminedCount;
  const completeness = total === 0 ? 0 : Math.round((presentRequired / total) * 100);
  return { ready, missingSections: missingRequired, completeness, undeterminedCount };
}

/** Dispatch to the correct readiness mapper for a catalog key. */
function assessContent(
  programType: EstarProgramSubmissionType,
  catalogKey: EstarCatalogKey,
  leaves: FilingLeaf[],
  qSubTypeOverride?: QSubType,
  deviceFlags?: DeviceFlags,
  /* nIVD or IVD: the slot registry follows it, so an IVD 510(k) is asked the
     analytical-performance questions FDA's IVD eSTAR actually contains. */
  variant: 'device' | 'ivd' = 'device',
): NormalizedContent {
  switch (programType) {
    case '510k':
    case 'de_novo': {
      const r = mapToEstar({ leaves, type: programType as EstarType, flags: deviceFlags, variant });
      /* An undetermined section is reported alongside the missing ones: the
         reader needs to know that "not ready" here means a question is
         unanswered, not that a document is absent. */
      return normalize(
        r.sections,
        [...r.summary.missingRequired, ...r.summary.undetermined],
        r.summary.ready,
        r.summary.undetermined.length,
      );
    }
    case 'pma': {
      const submissionType = PMA_KEY_TO_TYPE[catalogKey] ?? 'original';
      const r = mapToPma({ leaves, submissionType });
      return normalize(r.sections, r.summary.missingRequired, r.summary.ready);
    }
    case 'q_sub': {
      // Every Q-Sub catalog key maps to a sub-type; a key that does not is a
      // registry bug, and scoring it against the Pre-Submission set would hide
      // that behind a plausible verdict.
      const qSubType = qSubTypeOverride ?? QSUB_KEY_TO_TYPE[catalogKey];
      if (!qSubType) throw new Error(`Q-Sub catalog key "${catalogKey}" has no sub-type mapping.`);
      const r = mapToPreStar({ leaves, submissionType: 'q_sub', qSubType });
      return normalize(r.sections, r.summary.missingRequired, r.summary.ready);
    }
    case 'ide': {
      const r = mapToPreStar({ leaves, submissionType: 'ide' });
      return normalize(r.sections, r.summary.missingRequired, r.summary.ready);
    }
    case '513g': {
      const r = mapToPreStar({ leaves, submissionType: '513g' });
      return normalize(r.sections, r.summary.missingRequired, r.summary.ready);
    }
    default: {
      const _exhaustive: never = programType;
      throw new Error(`Unknown filing type: ${String(_exhaustive)}`);
    }
  }
}

export interface EstarFilingReadinessInput {
  /** What the client wants to file. */
  catalogKey: EstarCatalogKey;
  /** Device vs IVD (selects the nIVD/IVD template family for marketing pathways). */
  variant: 'device' | 'ivd';
  /** The client's eSTAR registration state (which FDA accounts/identifiers it holds). */
  registration: EstarClientRegistration;
  /** Canonical content leaves to project onto the submission's section tree. */
  leaves: FilingLeaf[];
  /** Override the Q-Sub sub-type (else derived from the catalog key). */
  qSubType?: QSubType;
  /**
   * The device's answers to the seven intake flags (DEVICE_FLAGS, W1-6).
   *
   * Several eSTAR sections are required only for some devices — sterilization
   * for a sterile one, software documentation for one containing software,
   * cybersecurity for a cyber device. Without these answers the model cannot
   * say whether those sections are needed, and `contentReady` fails closed
   * rather than reporting a submission complete on questions nobody asked
   * (W1-5).
   */
  deviceFlags?: DeviceFlags;
  /**
   * Platform-side producibility of the official FDA template (from the template
   * registry / fill orchestration). Both default to false so the verdict fails
   * closed — a submittable eSTAR is never claimed without them.
   */
  templateAvailable?: boolean;
  fieldMapPopulated?: boolean;
  /**
   * The FDA version of the official template on file — the caller fills it from
   * `descriptorFor(type, variant).version` (estar-template-registry). Absent or
   * `'unset'` fails closed: a version nobody pinned is not FDA's current one.
   */
  vendoredTemplateVersion?: string;
  /**
   * The date (YYYY-MM-DD) the version table's age is judged at. This module
   * reads no clock; without it `versionTableStale` is reported true.
   */
  asOf?: string;
  /**
   * Sections whose FILED copy is not the text their document holds — the
   * `rewritten` half of `governedDeviceFilingAgreement`, which the caller asks
   * before reading the filing (P-29.3, docs/EXIT_ATTESTATION_DECISION_2026-10-18.md).
   * The verdict is read from the filing and the submission is built from it, so
   * a rewritten filed copy blocks. Absent or empty: the filing agrees, or was
   * not compared (no governed document, or none bound to the editor).
   */
  filedCopyDiverged?: ReadonlyArray<DivergedNode>;
}

export interface EstarFilingReadinessResult {
  catalogKey: EstarCatalogKey;
  label: string;
  programType: EstarProgramSubmissionType;
  variant: 'device' | 'ivd';
  center: string;
  regulatoryRef: string;
  reviewGoalDays?: number;
  // Template + version (from the version registry).
  family: EstarTemplateFamily;
  currentVersion: string | null;
  ombNumbers: string[];
  // Registration eligibility.
  eligible: boolean;
  registrationMissing: EstarRegistrationRequirement[];
  // Content readiness.
  contentReady: boolean;
  missingSections: string[];
  completeness: number;
  // Official-template producibility.
  templateAvailable: boolean;
  fieldMapPopulated: boolean;
  officialTemplateProducible: boolean;
  /** Shared administrative mapping does not qualify an automated request. */
  requestSpecificAutomationQualified?: boolean;
  // Template version currency (vendored template vs FDA's current version).
  vendoredTemplateVersion: string | null;
  templateVersionCurrent: boolean;
  /** The version table is older than the currency registry's verification window (or no as-of date was given). */
  versionTableStale: boolean;
  /** Sections whose filed copy is not the document's text, as a refusal names them. Empty when none. */
  filedCopyDiverged: string[];
  // Overall verdict.
  canFileNow: boolean;
  blockers: string[];
}

/**
 * Assess whether a client can file a given eSTAR submission today, and what's
 * blocking the rest. `canFileNow` is true only when the client is registered for
 * it, the content is complete, the platform can produce the official FDA
 * template, AND that template is FDA's current version — every failing
 * dimension is reported in `blockers`.
 */
export function assessEstarFilingReadiness(
  input: EstarFilingReadinessInput,
): EstarFilingReadinessResult | undefined {
  const entry = getCatalogEntry(input.catalogKey);
  if (!entry) return undefined;

  const resolved = resolveCatalogTemplate(input.catalogKey, input.variant);
  const leaves = Array.isArray(input.leaves) ? input.leaves : [];

  // 1. Registration eligibility.
  const eligibility = canFile(input.registration, input.catalogKey);
  const eligible = eligibility?.eligible ?? false;
  const registrationMissing = eligibility?.missing ?? [];

  // 2. Content readiness (dispatched to the right mapper).
  const content = assessContent(entry.programType, input.catalogKey, leaves, input.qSubType, input.deviceFlags, input.variant);

  // 3. Official-template producibility (passed in; fails closed).
  const templateAvailable = input.templateAvailable ?? false;
  const fieldMapPopulated = input.fieldMapPopulated ?? false;
  const officialTemplateProducible = templateAvailable && fieldMapPopulated;

  // 4. Template version currency (one comparison, in estar-versions; fails closed).
  const family: EstarTemplateFamily = resolved?.family ?? 'nivd';
  const requestSpecificAutomationQualified = family !== 'prestar';
  const versionCurrency = templateVersionCurrency(family, input.vendoredTemplateVersion);
  const versionTableStale = input.asOf ? isVersionTableStale(input.asOf) : true;

  // Overall verdict + human-readable blockers.
  const blockers: string[] = [];
  if (!eligible) {
    blockers.push(
      `Client is not registered to file ${entry.label}: missing ${registrationMissing.join(', ') || 'registration prerequisites'}.`,
    );
  }
  if (!content.ready) {
    // Naming every entry a "missing required section" misstates the
    // undetermined ones: those sections are not absent documents, they are
    // unanswered applicability questions, and the reader acts on them
    // differently.
    const detail =
      content.undeterminedCount > 0
        ? `${content.missingSections.join(', ') || '(none reported)'} ` +
          `(${content.undeterminedCount} of these await an applicability answer, not a document)`
        : content.missingSections.join(', ') || '(none reported)';
    blockers.push(`Content incomplete (${content.completeness}%): missing required sections ${detail}.`);
  }
  if (!officialTemplateProducible) {
    const what = !templateAvailable && !fieldMapPopulated
      ? 'the official FDA template is not vendored and its field map is not populated'
      : !templateAvailable
        ? 'the official FDA template is not vendored'
        : 'the field map is not populated/verified';
    blockers.push(`Cannot produce a submittable eSTAR: ${what}.`);
  }
  if (versionCurrency.blocker) blockers.push(versionCurrency.blocker);
  if (!requestSpecificAutomationQualified) blockers.push(PRESTAR_COMPLETION_NOTE);
  const diverged = input.filedCopyDiverged ?? [];
  if (diverged.length > 0) blockers.push(`Cannot file yet. ${filedCopyDivergedSentence(diverged)}`);

  return {
    catalogKey: input.catalogKey,
    label: entry.label,
    programType: entry.programType,
    variant: input.variant,
    center: entry.center,
    regulatoryRef: entry.regulatoryRef,
    reviewGoalDays: entry.reviewGoalDays,
    family,
    currentVersion: resolved?.currentVersion ?? null,
    ombNumbers: resolved?.ombNumbers ?? [],
    eligible,
    registrationMissing,
    contentReady: content.ready,
    missingSections: content.missingSections,
    completeness: content.completeness,
    templateAvailable,
    fieldMapPopulated,
    officialTemplateProducible,
    requestSpecificAutomationQualified,
    vendoredTemplateVersion: versionCurrency.vendoredVersion,
    templateVersionCurrent: versionCurrency.current,
    versionTableStale,
    filedCopyDiverged: Array.from(new Set(diverged.map(divergedSectionLabel))),
    canFileNow: eligible && content.ready && officialTemplateProducible && versionCurrency.current
      && requestSpecificAutomationQualified && diverged.length === 0,
    blockers,
  };
}

export default { assessEstarFilingReadiness };
