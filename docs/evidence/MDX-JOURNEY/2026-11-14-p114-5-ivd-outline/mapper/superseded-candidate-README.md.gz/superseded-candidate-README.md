# Complete the existing IVD eSTAR mapper

Package F1, W1/D2; P-114 item 5. Scope is `server/services/pathway-engines/estar/estar-mapper.ts` and focused `ivd-mapper` tests. Root owns integration, compiler, build and publication.

## What already exists

`estar-mapper.ts` already defines separate IVD performance slots and a shared `whenApplicable` mechanism. Its IVD registry still inherits the non-IVD `performance-testing` requirement and always-required biocompatibility. `estar-outline-requirements.ts` and `estar-filing-readiness.ts` already project this single mapper into outline labels and filing content readiness; neither needs another implementation.

The existing vendored IVD eSTAR v7.1 has AnalyticalPerformance, ComparisonStudies, ClinicalStudies and ReferenceRange, with no BenchTesting or AnimalTesting branches. Its `Biocompatibility.PatientMaterials.BCDropDownList105` asks the tissue-contacting component count and permits zero. The outline worker independently inspected the actual PDF through production XFA readers and owns the form proof. Thus IVD biocompatibility is a human applicability question, not an inference from unrelated intake flags. Non-IVD and De Novo keep their existing policy.

The root design records the approved contract and search scope. Before edits, inspected live mapper/readiness/outline owners, existing mapper tests, form inspection output, and available deleted-path history. The checkout's shallow history limits deletion-search coverage.

## Verification

- Actual RED before editing the mapper: 3 passed / 8 failed across 11 new cases. All four declared pins stayed stable. The failures demonstrate inherited non-IVD bench/contact requirements and their outline/readiness projections.
- Focused GREEN: 11/11 passed. Final retained cohort: **107/107 passed across five unique files**, zero failed/pending; all 14 declared pins stayed stable. This includes the existing mapper, filing-readiness, outline-requirements and shipped-outline contract suites. Counts overlap and are not additive.
- Forced ESLint on the runtime owner and new test: zero errors, zero warnings. The actual original mapper source also has zero warnings. `eslint-result.json` records commands and source identity.
- Final runtime SHA-256: `5d9a332b5933a865c07d4d97f54c910b3af591f3598acad3053f17d4621bff1d`.

The change affects the IVD 510(k) registry only. Analytical evidence remains required and a matching placeholder stays absent. Contact remains explicitly reported for human applicability assessment. The existing when-applicable projection is preserved; content readiness is not a certification that every applicability assessment has been made. Non-IVD and De Novo requirements remain unchanged. The separate official-template release gate still refuses an unavailable/unpopulated template even when the content projection is complete.

Root owns full compiler, build, integrated migration/selector tests and canonical publication. This packet is automated component qualification, not FDA acceptance or human/deployment qualification.
