import { PGlite } from '/workspace/ClinicalSageAI-2-replit/node_modules/@electric-sql/pglite/dist/index.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root='/workspace/ClinicalSageAI-2-replit/';
const files=['migrations/20260527_mutation_primitives.sql','migrations/20260528_phase9_document_schema.sql','migrations/20260804_phase9_rule_pack_outlines.sql','migrations/20260810c_rule_pack_provenance.sql','migrations/20260810d_rule_pack_review_attribution.sql','migrations/20260901b_estar_510k_denovo_outlines.sql','migrations/20261005c_k510_denovo_estar_outline_v1_1.sql','migrations/20261114_k510_ivd_estar_outline_v1_0.sql','migrations/20261113_fda_priority_review_ea_icsr_class_packs.sql'];
const hashes=Object.fromEntries(files.map(f=>[f,createHash('sha256').update(readFileSync(root+f)).digest('hex')]));
const db=new PGlite();const started=new Date().toISOString();
try{
await db.exec(`CREATE TABLE organizations(id serial PRIMARY KEY); CREATE TABLE users(id serial PRIMARY KEY); CREATE TABLE regulatory_programs(id uuid PRIMARY KEY); CREATE TABLE audit_logs(id text PRIMARY KEY,tenant_id integer,user_id integer,action text,table_name text,record_id text,actor_id text,target text,target_type text,target_id text,reason text,payload_hash text,ana_action_id text,sha256_chain text,occurred_at timestamptz DEFAULT now(),hmac_seal text,old_values json,new_values json,ip_address text,user_agent text);`);
for(const f of files.slice(0,8))await db.exec(readFileSync(root+f,'utf8'));
await db.exec(`INSERT INTO regulatory_programs(id)VALUES('11111111-2222-3333-4444-555555555555');INSERT INTO c2c_documents(id,org_id,project_id,doc_type,agency,rule_pack_version,title,status,readiness)VALUES('compat_ivd',7,'11111111-2222-3333-4444-555555555555','k510','fda','fda-estar-510k-ivd-v1.0','Retained IVD compatibility fixture','draft',0)`);
const before=(await db.query(`SELECT * FROM c2c_documents WHERE id='compat_ivd'`)).rows;
await db.exec(readFileSync(root+files[8],'utf8'));
for(let pass=0;pass<2;pass++)for(const f of files.slice(2))await db.exec(readFileSync(root+f,'utf8'));
const rows=(await db.query(`SELECT doc_type,agency,version,jsonb_array_length(required_sections)AS nodes,superseded_by FROM c2c_rule_packs WHERE doc_type IN('k510','priority_review','environmental_assessment','icsr_15day')AND superseded_by IS NULL ORDER BY doc_type,version`)).rows;
const after=(await db.query(`SELECT * FROM c2c_documents WHERE id='compat_ivd'`)).rows;
const stable=JSON.stringify(before)===JSON.stringify(after);
if(!stable||!rows.some(r=>r.doc_type==='k510'&&r.version==='fda-estar-510k-ivd-v1.0'&&r.nodes===47)||!rows.some(r=>r.doc_type==='k510'&&r.version==='fda-estar-510k-v1.1'&&r.nodes===38))throw Error('Cross-migration compatibility invariant failed');
const result={started,finished:new Date().toISOString(),status:'passed',engine:'Actual PGlite SQL; no native PostgreSQL/RLS claim',replaysAfterNewClassMigration:2,sourcePins:hashes,livePacks:rows,retainedIvdDocumentUnchanged:stable};writeFileSync('/workspace/scratch/ivd-priority-compatibility.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}finally{await db.close()}
