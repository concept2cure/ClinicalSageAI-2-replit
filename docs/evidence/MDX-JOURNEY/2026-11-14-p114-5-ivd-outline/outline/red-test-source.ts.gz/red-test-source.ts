import { describe, expect, it } from 'vitest';
import { getApplicationType } from '../../shared/regulatory/global-document-registry';
import { getSectionBlueprintForEntry } from '../../shared/regulatory/project-bootstrap';
import { getRegistryDocumentTemplate } from '../../server/services/market-specs/document-template-library';
import { governedSectionsToDeviceSections, sectionsToLeaves } from '../../server/services/pathway-engines/estar/estar-content-leaves';
import { mapToEstar } from '../../server/services/pathway-engines/estar/estar-mapper';

const blueprint = () => getSectionBlueprintForEntry(getApplicationType('US_510K_IVD')!);

describe('the existing US IVD 510(k) template reaches its FDA filing outline', () => {
  it('retains FDA administrative, substantial-equivalence and labeling keys, and adds analytical performance', () => {
    const sections = blueprint().sections;
    expect(sections).toHaveLength(45);
    expect(sections.find(s => s.code === 'A1')?.title).toBe('Cover letter');
    expect(sections.find(s => s.code === 'C2')?.title).toContain('Substantial equivalence');
    expect(sections.find(s => s.code === 'D2')?.title).toContain('labeling');
    expect(sections.find(s => s.code === 'E9')?.title).toContain('Analytical performance');
    expect(sections.some(s => ['E5', 'E6'].includes(s.code))).toBe(false);
  });

  it('serves US content through the existing template library, without EU IVDR citations', async () => {
    const template = await getRegistryDocumentTemplate('US_510K_IVD');
    expect(template).toBeDefined();
    expect(template!.sections.map(s => s.number)).toEqual(blueprint().sections.map(s => s.code));
    expect(JSON.stringify(template)).not.toMatch(/IVDR|Annex XIII|Article 56/);
    expect(template!.sections.find(s => s.number === 'E9')?.purpose).toContain('FDA IVD eSTAR');
  });

  it('finished content in the actual template supplies every required IVD mapper slot', () => {
    const rows = blueprint().sections.map((s, i) => ({
      id: i + 1, section_key: s.code, label: s.title,
      status: 'approved', content: 'Sponsor source-linked evidence reviewed for this section. '.repeat(20),
    }));
    const leaves = sectionsToLeaves(governedSectionsToDeviceSections(rows as never) as never);
    const result = mapToEstar({ type: '510k', variant: 'ivd', leaves, flags: {} });
    expect(result.summary.missingRequired).toEqual([]);
    expect(result.sections.find(s => s.id === 'ivd-analytical-performance')?.present).toBe(true);
  });
});
