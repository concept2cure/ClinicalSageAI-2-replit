from __future__ import annotations

import os
import sys

from shadow_service.config import Settings
from shadow_service.db import AppContext, Database
from shadow_service.embeddings import build_provider
from shadow_service.sql import INSERT_PRECEDENT
from shadow_service.utils import vector_literal

SEED = [
    {
        "agency_code": "FDA",
        "failure_mode": "Clinical Gap",
        "historical_question": "Please justify the clinical relevance of the observed endpoint difference and provide sensitivity analyses.",
        "source_ref": "seed:example-1",
    },
    {
        "agency_code": "FDA",
        "failure_mode": "Safety Signal",
        "historical_question": "Provide a comprehensive analysis of adverse events including exposure-response and subgroup analyses.",
        "source_ref": "seed:example-2",
    },
    {
        "agency_code": "EMA",
        "failure_mode": "CMC Inconsistency",
        "historical_question": "Clarify batch-to-batch variability and demonstrate comparability between clinical and commercial material.",
        "source_ref": "seed:example-3",
    },
]

def main() -> int:
    settings = Settings.load()
    db = Database(settings.database_url)
    embedder = build_provider(settings.embedding_provider, settings.embedding_dim)

    ctx = AppContext(user="seed@concept2cure", reason="seed precedents", request_id="seed-precedents")

    with db.transaction(ctx) as conn:
        with conn.cursor() as cur:
            for item in SEED:
                vec = embedder.embed_text(item["historical_question"])
                precedent_vector = vector_literal(vec) if vec is not None else None
                cur.execute(
                    INSERT_PRECEDENT,
                    {
                        **item,
                        "precedent_vector": precedent_vector,
                    },
                )
                row = cur.fetchone()
                print("Inserted precedent:", row["id"])

    db.close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
