#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is required"
  exit 1
fi

export EMBEDDING_PROVIDER="${EMBEDDING_PROVIDER:-hash}"
export EMBEDDING_DIM="${EMBEDDING_DIM:-1536}"
export PRECEDENT_TOP_K="${PRECEDENT_TOP_K:-5}"

python -m uvicorn shadow_service.main:app --host 0.0.0.0 --port 8000 --reload
